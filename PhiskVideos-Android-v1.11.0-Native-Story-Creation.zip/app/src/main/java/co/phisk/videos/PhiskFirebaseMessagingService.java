package co.phisk.videos;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

/** Receives remote PhiskVideos push notifications and routes taps back into the app. */
public class PhiskFirebaseMessagingService extends FirebaseMessagingService {
    private static final String CHANNEL_ID = "phisk_native_updates";

    @Override public void onNewToken(String token) {
        super.onNewToken(token);
        FcmDeviceRegistrar.register(getApplicationContext(), token);
    }

    @Override public void onMessageReceived(RemoteMessage message) {
        super.onMessageReceived(message);
        String title = "PhiskVideos";
        String body = "You have a new notification.";
        String target = "https://videos.phisk.co/phisk-notifications/";
        if (message.getNotification() != null) {
            if (message.getNotification().getTitle() != null) title = message.getNotification().getTitle();
            if (message.getNotification().getBody() != null) body = message.getNotification().getBody();
        }
        if (message.getData() != null) {
            if (message.getData().containsKey("title")) title = message.getData().get("title");
            if (message.getData().containsKey("message")) body = message.getData().get("message");
            else if (message.getData().containsKey("body")) body = message.getData().get("body");
            if (message.getData().containsKey("target_url")) target = message.getData().get("target_url");
            else if (message.getData().containsKey("url")) target = message.getData().get("url");
            else if (message.getData().containsKey("link")) target = message.getData().get("link");
            else if (message.getData().containsKey("deep_link")) target = message.getData().get("deep_link");
        }
        showNotification(title, body, target);
    }

    private void showNotification(String title, String body, String target) {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager == null) return;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "PhiskVideos notifications", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Updates and activity from PhiskVideos");
            channel.enableVibration(true);
            manager.createNotificationChannel(channel);
        }
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        open.putExtra(MainActivity.EXTRA_NOTIFICATION_URL, safeTarget(target));
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pending = PendingIntent.getActivity(this, (int) (System.currentTimeMillis() & 0x7fffffff), open, flags);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        builder.setSmallIcon(R.drawable.ic_notification)
                .setColor(Color.rgb(124, 58, 237))
                .setContentTitle(title == null || title.trim().isEmpty() ? "PhiskVideos" : title)
                .setContentText(body == null || body.trim().isEmpty() ? "You have a new notification." : body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setAutoCancel(true)
                .setContentIntent(pending)
                .setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_VIBRATE);
        manager.notify((int) (System.currentTimeMillis() & 0x7fffffff), builder.build());
    }

    private String safeTarget(String value) {
        try {
            Uri uri = Uri.parse(value == null ? "https://videos.phisk.co/phisk-notifications/" : value);
            String host = uri.getHost();
            if ("https".equalsIgnoreCase(uri.getScheme()) && host != null &&
                    (host.equalsIgnoreCase("phisk.co") || host.toLowerCase().endsWith(".phisk.co"))) return uri.toString();
        } catch (Exception ignored) {}
        return "https://videos.phisk.co/phisk-notifications/";
    }
}
