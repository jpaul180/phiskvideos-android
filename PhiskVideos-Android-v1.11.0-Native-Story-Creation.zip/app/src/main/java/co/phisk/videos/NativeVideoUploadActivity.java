package co.phisk.videos;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.InputFilter;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Native video uploader using the authenticated Phisk Video Manager upload API. */
public class NativeVideoUploadActivity extends Activity {
    private static final String HOME="https://videos.phisk.co/";
    private static final int VIOLET=Color.rgb(124,58,237), INK=Color.rgb(25,29,38), MUTED=Color.rgb(112,117,128), BG=Color.rgb(247,248,250);
    private static final int PICK_VIDEO=4101, PICK_THUMB=4102;
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private LinearLayout root,body; private TextView videoName,thumbName,status,submit; private EditText title,description; private RadioGroup audience; private ProgressBar progress; private Uri videoUri,thumbUri; private String videoDisplayName="video.mp4",thumbDisplayName="thumbnail.jpg"; private int draftId=0; private boolean busy=false;

    @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(Color.WHITE);getWindow().setNavigationBarColor(Color.WHITE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);build();}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private String token(){return getSharedPreferences("phisk_native_auth",MODE_PRIVATE).getString("access_token","");}
    private void build(){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(14),0,dp(14),0);bar.setBackgroundColor(Color.WHITE);TextView back=text("‹",34,INK,false);back.setGravity(Gravity.CENTER);bar.addView(back,new LinearLayout.LayoutParams(dp(42),dp(52)));back.setOnClickListener(v->finish());bar.addView(text("Upload video",18,INK,true));root.addView(bar);
        ScrollView scroll=new ScrollView(this);body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(16),dp(18),dp(16),dp(28));scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        body.addView(text("Share your video with the PhiskVideos community.",14,MUTED,false));body.addView(label("Video file"));videoName=text("No video selected",13,MUTED,false);videoName.setPadding(0,dp(8),0,dp(8));body.addView(videoName);addButton("Choose video",()->pick(PICK_VIDEO,"video/*"),false);
        body.addView(label("Video title"));title=new EditText(this);title.setSingleLine(true);title.setTextSize(15);title.setTextColor(INK);title.setHint("Give your video a title");title.setFilters(new InputFilter[]{new InputFilter.LengthFilter(100)});title.setBackground(shape(Color.WHITE,7));title.setPadding(dp(12),dp(11),dp(12),dp(11));body.addView(title,fieldParams());
        body.addView(label("Description"));description=new EditText(this);description.setTextSize(15);description.setTextColor(INK);description.setHint("Tell viewers about this video...");description.setMinLines(4);description.setGravity(Gravity.TOP|Gravity.START);description.setBackground(shape(Color.WHITE,7));description.setPadding(dp(12),dp(11),dp(12),dp(11));body.addView(description,fieldParams());
        body.addView(label("Audience"));audience=new RadioGroup(this);audience.setOrientation(RadioGroup.VERTICAL);RadioButton notKids=new RadioButton(this);notKids.setId(View.generateViewId());notKids.setText("No, it's not for kids");notKids.setTextColor(INK);notKids.setTextSize(14);audience.addView(notKids);RadioButton kids=new RadioButton(this);kids.setId(View.generateViewId());kids.setText("Yes, it's for kids");kids.setTextColor(INK);kids.setTextSize(14);audience.addView(kids);body.addView(audience);
        body.addView(label("Video thumbnail"));thumbName=text("No thumbnail selected",13,MUTED,false);thumbName.setPadding(0,dp(8),0,dp(8));body.addView(thumbName);addButton("Choose thumbnail",()->pick(PICK_THUMB,"image/jpeg,image/png,image/webp,image/gif"),false);
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(100);progress.setProgressTintList(android.content.res.ColorStateList.valueOf(VIOLET));LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(7));pp.topMargin=dp(18);body.addView(progress,pp);progress.setVisibility(View.GONE);
        status=text("Accepted video formats: MP4, WebM, OGG, M4V and MOV. Landscape 16:9 or 21:9 only.",12,MUTED,false);status.setPadding(0,dp(10),0,dp(12));body.addView(status);
        submit=text("Upload and Publish",14,Color.WHITE,true);submit.setGravity(Gravity.CENTER);submit.setPadding(dp(16),dp(14),dp(16),dp(14));submit.setBackground(shape(VIOLET,7));body.addView(submit,new LinearLayout.LayoutParams(-1,-2));submit.setOnClickListener(v->submitUpload());
        setContentView(root);
    }
    private TextView label(String s){TextView t=text(s,14,INK,true);t.setPadding(0,dp(18),0,dp(4));return t;}
    private LinearLayout.LayoutParams fieldParams(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(2);return p;}
    private void addButton(String name,Runnable action,boolean primary){TextView b=text(name,13,primary?Color.WHITE:VIOLET,true);b.setGravity(Gravity.CENTER);b.setPadding(dp(14),dp(10),dp(14),dp(10));b.setBackground(shape(primary?VIOLET:Color.WHITE,7));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(4);body.addView(b,p);b.setOnClickListener(v->action.run());}
    private void pick(int code,String type){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(type);if(code==PICK_THUMB&&type.contains(","))i.setType("image/*");startActivityForResult(i,code);}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();if(requestCode==PICK_VIDEO){videoUri=uri;videoDisplayName=displayName(uri);videoName.setText(videoDisplayName);if(title.getText().toString().trim().isEmpty()){String n=videoDisplayName;int dot=n.lastIndexOf('.');title.setText(dot>0?n.substring(0,dot):n);}}else if(requestCode==PICK_THUMB){thumbUri=uri;thumbDisplayName=displayName(uri);thumbName.setText(thumbDisplayName);}}
    private String displayName(Uri uri){try(Cursor c=getContentResolver().query(uri,null,null,null,null)){if(c!=null&&c.moveToFirst()){int i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(i>=0)return c.getString(i);}}catch(Exception ignored){}return "selected file";}
    private long fileSize(Uri uri){try(Cursor c=getContentResolver().query(uri,null,null,null,null)){if(c!=null&&c.moveToFirst()){int i=c.getColumnIndex(OpenableColumns.SIZE);if(i>=0)return c.getLong(i);}}catch(Exception ignored){}return -1;}
    private String mime(Uri uri,String fallback){String m=getContentResolver().getType(uri);return m==null?fallback:m;}
    private void submitUpload(){if(busy)return;if(videoUri==null){message("Choose a video file first.");return;}if(thumbUri==null){message("Choose a thumbnail before publishing.");return;}String t=title.getText().toString().trim(),d=description.getText().toString().trim();if(t.isEmpty()||t.length()>100){message("Enter a title of no more than 100 characters.");return;}if(d.isEmpty()){message("Enter a video description.");return;}int checked=audience.getCheckedRadioButtonId();if(checked==-1){message("Choose whether this video is for kids.");return;}RadioButton selected=findViewById(checked);String age=selected.getText().toString().startsWith("Yes")?"Yes its for kids":"No its not for kids";
        busy=true;submit.setEnabled(false);progress.setVisibility(View.VISIBLE);progress.setProgress(0);message("Uploading video…");String finalAge=age;io.execute(()->{try{if(draftId==0){JSONObject uploaded=multipart("creator-studio/videos/upload","video_file",videoUri,videoDisplayName,mime(videoUri,"video/mp4"),null);draftId=uploaded.optInt("draft_id",0);if(draftId<=0)throw new Exception("The server did not return a video draft ID.");}runOnUiThread(()->message("Video uploaded. Saving details and thumbnail…"));
                JSONObject details=new JSONObject();details.put("title",t);details.put("description",d);details.put("age_restriction",finalAge);jsonRequest("creator-studio/videos/"+draftId+"/details",details);
                JSONObject published=multipart("creator-studio/videos/"+draftId+"/publish","thumbnail",thumbUri,thumbDisplayName,mime(thumbUri,"image/jpeg"),null);
                runOnUiThread(()->{busy=false;submit.setEnabled(true);progress.setProgress(100);Toast.makeText(this,published.optString("message","Your video has been published."),Toast.LENGTH_LONG).show();Intent watch=new Intent(this,NativePlayerActivity.class);watch.putExtra("video_id",draftId);startActivity(watch);finish();});
            }catch(Exception e){runOnUiThread(()->{busy=false;submit.setEnabled(true);message(cleanError(e.getMessage()));});}});}
    private JSONObject jsonRequest(String path,JSONObject payload)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(HOME+"wp-json/phisk/v1/"+path).openConnection();try{c.setRequestMethod("POST");c.setConnectTimeout(20000);c.setReadTimeout(60000);c.setRequestProperty("Authorization","Bearer "+token());c.setRequestProperty("Accept","application/json");c.setRequestProperty("Content-Type","application/json; charset=UTF-8");c.setDoOutput(true);try(OutputStream o=c.getOutputStream()){o.write(payload.toString().getBytes(StandardCharsets.UTF_8));}return readResponse(c);}finally{c.disconnect();}}
    private JSONObject multipart(String path,String field,Uri uri,String filename,String contentType,ProgressBar unused)throws Exception{String boundary="----PhiskNative"+System.currentTimeMillis();HttpURLConnection c=(HttpURLConnection)new URL(HOME+"wp-json/phisk/v1/"+path).openConnection();try{c.setRequestMethod("POST");c.setConnectTimeout(30000);c.setReadTimeout(0);c.setDoOutput(true);c.setChunkedStreamingMode(64*1024);c.setRequestProperty("Authorization","Bearer "+token());c.setRequestProperty("Accept","application/json");c.setRequestProperty("Content-Type","multipart/form-data; boundary="+boundary);long total=fileSize(uri);try(OutputStream out=c.getOutputStream()){String head="--"+boundary+"\r\nContent-Disposition: form-data; name=\""+field+"\"; filename=\""+filename.replace("\"","_")+"\"\r\nContent-Type: "+contentType+"\r\n\r\n";out.write(head.getBytes(StandardCharsets.UTF_8));try(InputStream in=getContentResolver().openInputStream(uri)){if(in==null)throw new Exception("Cannot read the selected file.");byte[] buffer=new byte[64*1024];long sent=0;int n;while((n=in.read(buffer))!=-1){out.write(buffer,0,n);sent+=n;if(total>0){int pct=(int)Math.min(98,(sent*98)/total);runOnUiThread(()->progress.setProgress(pct));}}}out.write(("\r\n--"+boundary+"--\r\n").getBytes(StandardCharsets.UTF_8));out.flush();}return readResponse(c);}finally{c.disconnect();}}
    private JSONObject readResponse(HttpURLConnection c)throws Exception{int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();ByteArrayOutputStream b=new ByteArrayOutputStream();if(in!=null){byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)b.write(buf,0,n);in.close();}String raw=b.toString("UTF-8");JSONObject result;try{result=new JSONObject(raw);}catch(Exception e){throw new Exception("The server returned an unreadable response (HTTP "+code+").");}if(code<200||code>=300){JSONObject data=result.optJSONObject("data");String msg=data==null?result.optString("message","Request failed (HTTP "+code+")."):data.optString("message",result.optString("message","Upload failed."));throw new Exception(msg);}return result;}
    private String cleanError(String s){if(s==null||s.trim().isEmpty())return "Something went wrong. Please try again.";try{JSONObject j=new JSONObject(s);JSONObject d=j.optJSONObject("data");return d==null?j.optString("message",s):d.optString("message",s);}catch(Exception ignored){return s;}}
    private void message(String s){status.setText(s);status.setTextColor(INK);}
    @Override protected void onDestroy(){io.shutdownNow();super.onDestroy();}
}
