package co.phisk.videos;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Native watch page. Player stays docked while the watch details scroll beneath it. */
public class NativePlayerActivity extends Activity {
    private static final String HOME="https://videos.phisk.co/";
    private static final int VIOLET=Color.rgb(124,58,237), INK=Color.rgb(25,29,38), MUTED=Color.rgb(112,117,128), BG=Color.rgb(247,248,250);
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private ExoPlayer player; private PlayerView playerView; private WebView youtubeView;
    private LinearLayout content, relatedList, commentsList; private EditText commentInput;
    private JSONObject video; private int videoId; private long playbackPosition=0; private boolean playWhenReady=true;
    private String playbackType="", playbackUrl="", youtubeId="";

    @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(Color.BLACK);getWindow().setNavigationBarColor(Color.WHITE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);videoId=getIntent().getIntExtra("video_id",0);if(videoId==0){try{videoId=Integer.parseInt(getIntent().getStringExtra("video_id"));}catch(Exception ignored){}}if(state!=null){playbackPosition=state.getLong("position",0);playWhenReady=state.getBoolean("play_when_ready",true);}buildShell();loadVideo();}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private TextView text(String value,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private void buildShell(){LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.WHITE);
        FrameLayout dock=new FrameLayout(this);dock.setBackgroundColor(Color.BLACK);dock.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(220)));playerView=new PlayerView(this);playerView.setUseController(true);playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);dock.addView(playerView,new FrameLayout.LayoutParams(-1,-1));root.addView(dock);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(16),dp(16),dp(16),dp(24));content.setBackgroundColor(BG);scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER);nav.setBackgroundColor(Color.WHITE);nav.setPadding(0,dp(7),0,dp(7));String[] labels={"⌂\nHome","▣\nStudio","＋\nCreate","♧\nActivity","◉\nYou"};for(int i=0;i<labels.length;i++){final int index=i;TextView item=text(labels[i],11,i==0?VIOLET:MUTED,true);item.setGravity(Gravity.CENTER);nav.addView(item,new LinearLayout.LayoutParams(0,dp(48),1));item.setOnClickListener(v->{if(index==0)finish();else if(index==2){startActivity(new Intent(this,NativeVideoUploadActivity.class));}else if(index==3){openWeb(HOME+"phisk-notifications/");}else if(index==1){startActivity(new Intent(this,NativeCreatorStudioActivity.class));}else{openWeb(HOME+"my-account/");}});}root.addView(nav);setContentView(root);
        TextView loading=text("Loading video…",14,MUTED,false);loading.setPadding(0,dp(20),0,dp(20));content.addView(loading);
    }
    private String token(){return getSharedPreferences("phisk_native_auth",MODE_PRIVATE).getString("access_token","");}
    private JSONObject request(String path,String method,JSONObject body)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(HOME+"wp-json/phisk/v1/"+path).openConnection();try{c.setRequestMethod(method);c.setConnectTimeout(15000);c.setReadTimeout(20000);c.setRequestProperty("Accept","application/json");c.setRequestProperty("Authorization","Bearer "+token());if(body!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=UTF-8");try(OutputStream out=c.getOutputStream()){out.write(body.toString().getBytes(StandardCharsets.UTF_8));}}int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();ByteArrayOutputStream out=new ByteArrayOutputStream();if(in!=null){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);in.close();}String raw=out.toString("UTF-8");if(code<200||code>=300)throw new Exception("Server returned "+code+": "+raw);return new JSONObject(raw);}finally{c.disconnect();}}
    private void openCreatorChannel(){JSONObject c=video==null?null:video.optJSONObject("creator");int id=c==null?0:c.optInt("id",0);if(id>0){Intent i=new Intent(this,NativeCreatorChannelActivity.class);i.putExtra("creator_id",id);startActivity(i);}else openWeb(c==null?HOME:c.optString("profile_url",HOME));}
    private void loadVideo(){if(videoId<=0){showError("This video link is invalid.");return;}io.execute(()->{try{JSONObject result=request("videos/"+videoId,"GET",null);JSONObject rel=request("videos/"+videoId+"/related","GET",null);JSONObject com=request("videos/"+videoId+"/comments?page=1&per_page=20","GET",null);runOnUiThread(()->render(result,rel.optJSONArray("videos"),com.optJSONArray("comments")));}catch(Exception e){runOnUiThread(()->showError("Couldn't load this video. Please check your connection and try again."));}});}
    private void render(JSONObject item,JSONArray related,JSONArray comments){video=item;content.removeAllViews();playbackType=item.optString("playback_type","");playbackUrl=item.optString("playback_url","");youtubeId=item.optString("youtube_video_id","");configurePlayback();
        TextView title=text(item.optString("title","Video"),21,INK,true);title.setPadding(0,0,0,dp(8));content.addView(title);
        TextView meta=text(formatViews(item.optInt("views"))+" views  ·  "+item.optString("published_at",""),12,MUTED,false);content.addView(meta);
        LinearLayout creator=new LinearLayout(this);creator.setGravity(Gravity.CENTER_VERTICAL);creator.setPadding(0,dp(16),0,dp(16));ImageView avatar=new ImageView(this);avatar.setImageDrawable(shapeDrawable(Color.rgb(230,222,247)));avatar.setBackground(shape(Color.rgb(230,222,247),40));creator.addView(avatar,new LinearLayout.LayoutParams(dp(44),dp(44)));LinearLayout nameCol=new LinearLayout(this);nameCol.setOrientation(LinearLayout.VERTICAL);nameCol.setPadding(dp(10),0,0,0);nameCol.addView(text(item.optJSONObject("creator")==null?"Creator":item.optJSONObject("creator").optString("name","Creator"),15,INK,true));nameCol.addView(text("Creator",12,MUTED,false));creator.addView(nameCol,new LinearLayout.LayoutParams(0,-2,1));TextView subscribe=text("View Channel",13,Color.WHITE,true);subscribe.setGravity(Gravity.CENTER);subscribe.setPadding(dp(16),dp(9),dp(16),dp(9));subscribe.setBackground(shape(VIOLET,6));creator.addView(subscribe);subscribe.setOnClickListener(v->openCreatorChannel());nameCol.setOnClickListener(v->openCreatorChannel());avatar.setOnClickListener(v->openCreatorChannel());content.addView(creator);
        LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER);actions.setPadding(0,0,0,dp(14));String[] actionNames={"♡  Like (soon)","↗  Share","↓  Download (soon)"};for(String a:actionNames){TextView b=text(a,13,INK,true);b.setGravity(Gravity.CENTER);b.setPadding(dp(12),dp(11),dp(12),dp(11));b.setBackground(shape(Color.WHITE,7));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.setMargins(dp(3),0,dp(3),0);actions.addView(b,p);b.setOnClickListener(v->{if(a.contains("Share")){Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(Intent.EXTRA_TEXT,item.optString("permalink",HOME));startActivity(Intent.createChooser(send,"Share video"));}else Toast.makeText(this,"This action is not connected yet.",Toast.LENGTH_SHORT).show();});}content.addView(actions);
        TextView description=text(item.optString("description",item.optString("excerpt","")),14,INK,false);description.setPadding(dp(13),dp(12),dp(13),dp(12));description.setBackground(shape(Color.WHITE,8));description.setMaxLines(4);content.addView(description);TextView expand=text("Show more",13,VIOLET,true);expand.setPadding(dp(4),dp(8),0,dp(12));content.addView(expand);expand.setOnClickListener(v->{boolean open=description.getMaxLines()==4;description.setMaxLines(open?100:4);expand.setText(open?"Show less":"Show more");});
        addSectionTitle("Related videos");relatedList=new LinearLayout(this);relatedList.setOrientation(LinearLayout.VERTICAL);content.addView(relatedList);if(related!=null)for(int i=0;i<related.length();i++){JSONObject r=related.optJSONObject(i);if(r!=null)addRelated(r);}
        addSectionTitle("Comments ("+item.optInt("comment_count")+")");commentInput=new EditText(this);commentInput.setHint("Add a comment…");commentInput.setTextSize(14);commentInput.setMinLines(2);commentInput.setGravity(Gravity.TOP);commentInput.setPadding(dp(12),dp(10),dp(12),dp(10));commentInput.setBackground(shape(Color.WHITE,7));content.addView(commentInput);TextView post=text("Post comment",13,Color.WHITE,true);post.setGravity(Gravity.CENTER);post.setPadding(dp(16),dp(10),dp(16),dp(10));post.setBackground(shape(VIOLET,6));LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-2,-2);pp.topMargin=dp(8);content.addView(post,pp);post.setOnClickListener(v->postComment());commentsList=new LinearLayout(this);commentsList.setOrientation(LinearLayout.VERTICAL);LinearLayout.LayoutParams clp=new LinearLayout.LayoutParams(-1,-2);clp.topMargin=dp(12);content.addView(commentsList,clp);if(comments!=null)for(int i=0;i<comments.length();i++){JSONObject c=comments.optJSONObject(i);if(c!=null)addComment(c);}
    }
    private android.graphics.drawable.Drawable shapeDrawable(int color){return shape(color,40);}
    private void configurePlayback(){if("youtube_embed".equals(playbackType)||!youtubeId.isEmpty()){releasePlayer();youtubeView=new WebView(this);WebSettings s=youtubeView.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setMediaPlaybackRequiresUserGesture(true);youtubeView.setWebChromeClient(new WebChromeClient());youtubeView.setWebViewClient(new WebViewClient());String html="<html><body style='margin:0;background:#000'><iframe width='100%' height='100%' src='https://www.youtube-nocookie.com/embed/"+youtubeId+"?playsinline=1&rel=0' title='YouTube video player' frameborder='0' allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share' allowfullscreen></iframe></body></html>";youtubeView.loadDataWithBaseURL("https://www.youtube-nocookie.com",html,"text/html","UTF-8",null);ViewGroup parent=(ViewGroup)playerView.getParent();int at=parent.indexOfChild(playerView);parent.removeView(playerView);parent.addView(youtubeView,at,new FrameLayout.LayoutParams(-1,-1));return;}if(playbackUrl.startsWith("https://")){if(youtubeView!=null){ViewGroup p=(ViewGroup)youtubeView.getParent();p.removeView(youtubeView);youtubeView.destroy();youtubeView=null;((ViewGroup)playerView.getParent()).addView(playerView,new FrameLayout.LayoutParams(-1,-1));}initializePlayer();}else Toast.makeText(this,"This video has no supported playback source.",Toast.LENGTH_LONG).show();}
    private void initializePlayer(){if(player!=null)return;player=new ExoPlayer.Builder(this).build();playerView.setPlayer(player);player.addListener(new Player.Listener(){@Override public void onPlayerError(PlaybackException error){Toast.makeText(NativePlayerActivity.this,"Playback failed. The source may be unavailable or unsupported.",Toast.LENGTH_LONG).show();}});player.setMediaItem(MediaItem.fromUri(playbackUrl));player.prepare();player.seekTo(playbackPosition);player.setPlayWhenReady(playWhenReady);}
    private void releasePlayer(){if(player!=null){playbackPosition=player.getCurrentPosition();playWhenReady=player.getPlayWhenReady();player.release();player=null;}if(playerView!=null)playerView.setPlayer(null);}
    private void addSectionTitle(String value){TextView h=text(value,18,INK,true);h.setPadding(0,dp(20),0,dp(10));content.addView(h);}
    private void addRelated(JSONObject r){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(0,0,0,dp(12));ImageView image=new ImageView(this);image.setBackground(shape(Color.LTGRAY,7));image.setLayoutParams(new LinearLayout.LayoutParams(dp(126),dp(78)));row.addView(image);LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(10),0,0,0);copy.addView(text(r.optString("title","Video"),14,INK,true));copy.addView(text(formatViews(r.optInt("views"))+" views",12,MUTED,false));row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));content.addView(row);row.setOnClickListener(v->{Intent i=new Intent(this,NativePlayerActivity.class);i.putExtra("video_id",r.optInt("id"));startActivity(i);});}
    private void addComment(JSONObject c){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(12),dp(10),dp(12),dp(10));box.setBackground(shape(Color.WHITE,7));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(8);commentsList.addView(box,p);box.addView(text(c.optString("author","User"),13,INK,true));TextView body=text(c.optString("content",""),14,INK,false);body.setPadding(0,dp(5),0,0);box.addView(body);JSONArray replies=c.optJSONArray("replies");if(replies!=null)for(int j=0;j<replies.length();j++){JSONObject reply=replies.optJSONObject(j);if(reply!=null){TextView rt=text("↳ "+reply.optString("author","User")+": "+reply.optString("content",""),12,MUTED,false);rt.setPadding(dp(12),dp(8),0,0);box.addView(rt);}}}
    private void postComment(){String value=commentInput.getText().toString().trim();if(value.isEmpty())return;commentInput.setEnabled(false);io.execute(()->{try{JSONObject body=new JSONObject();body.put("content",value);request("videos/"+videoId+"/comments","POST",body);JSONObject fresh=request("videos/"+videoId+"/comments?page=1&per_page=20","GET",null);runOnUiThread(()->{commentInput.setText("");commentInput.setEnabled(true);commentsList.removeAllViews();JSONArray arr=fresh.optJSONArray("comments");if(arr!=null)for(int i=0;i<arr.length();i++){JSONObject c=arr.optJSONObject(i);if(c!=null)addComment(c);}Toast.makeText(this,"Comment submitted.",Toast.LENGTH_SHORT).show();});}catch(Exception e){runOnUiThread(()->{commentInput.setEnabled(true);Toast.makeText(this,"Couldn't post comment. Please try again.",Toast.LENGTH_LONG).show();});}});}
    private String formatViews(int n){return String.format(java.util.Locale.US,"%,d",n);}
    private void openWeb(String url){Intent i=new Intent(this,MainActivity.class);i.putExtra(MainActivity.EXTRA_NOTIFICATION_URL,url);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(i);}
    private void showError(String message){content.removeAllViews();TextView t=text(message,15,MUTED,false);t.setPadding(dp(16),dp(30),dp(16),dp(30));content.addView(t);}
    @Override protected void onStart(){super.onStart();if(video!=null&&youtubeId.isEmpty())initializePlayer();}
    @Override protected void onStop(){super.onStop();releasePlayer();}
    @Override protected void onSaveInstanceState(Bundle out){if(player!=null){out.putLong("position",player.getCurrentPosition());out.putBoolean("play_when_ready",player.getPlayWhenReady());}super.onSaveInstanceState(out);}
    @Override protected void onDestroy(){releasePlayer();if(youtubeView!=null)youtubeView.destroy();io.shutdownNow();super.onDestroy();}
}
