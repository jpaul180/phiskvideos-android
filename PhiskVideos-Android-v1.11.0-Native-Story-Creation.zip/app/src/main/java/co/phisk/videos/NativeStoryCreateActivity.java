package co.phisk.videos;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.InputFilter;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Native Story composer backed by the existing Phisk Video Manager Story model. */
public class NativeStoryCreateActivity extends Activity {
    private static final String HOME="https://videos.phisk.co/";
    private static final int VIOLET=Color.rgb(124,58,237), INK=Color.rgb(25,29,38), MUTED=Color.rgb(112,117,128), BG=Color.rgb(247,248,250);
    private static final int PICK_IMAGES=4601;
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final ArrayList<Uri> imageUris=new ArrayList<>();
    private final ArrayList<Integer> uploadedIds=new ArrayList<>();
    private final ArrayList<String> imageNames=new ArrayList<>();
    private final ArrayList<Integer> interestIds=new ArrayList<>();
    private LinearLayout body,previewList;
    private EditText title,excerpt,content;
    private Spinner interest;
    private TextView imageSummary,status,postButton,draftButton,chooseButton;
    private ProgressBar progress;
    private boolean busy=false;

    @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(Color.WHITE);getWindow().setNavigationBarColor(Color.WHITE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);build();loadInterests();}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));d.setStroke(dp(1),Color.rgb(231,233,239));return d;}
    private TextView text(String value,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private String token(){return getSharedPreferences("phisk_native_auth",MODE_PRIVATE).getString("access_token","");}

    private void build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(14),0,dp(14),0);bar.setBackgroundColor(Color.WHITE);
        TextView back=text("‹",34,INK,false);back.setGravity(Gravity.CENTER);bar.addView(back,new LinearLayout.LayoutParams(dp(42),dp(54)));back.setOnClickListener(v->finish());bar.addView(text("Create a Story",18,INK,true));root.addView(bar);
        ScrollView scroll=new ScrollView(this);body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(16),dp(17),dp(16),dp(26));scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        body.addView(text("Share your knowledge, stories and ideas with the Phisk community.",14,MUTED,false));
        body.addView(label("Story title"));title=new EditText(this);title.setSingleLine(true);title.setTextSize(15);title.setTextColor(INK);title.setHint("Give your Story a clear title");title.setFilters(new InputFilter[]{new InputFilter.LengthFilter(100)});styleField(title);body.addView(title,fieldParams());
        body.addView(label("Interest"));interest=new Spinner(this);interest.setBackground(shape(Color.WHITE,7));body.addView(interest,fieldParams());
        body.addView(label("Story text"));content=new EditText(this);content.setTextSize(15);content.setTextColor(INK);content.setHint("Write your Story here...");content.setMinLines(7);content.setGravity(Gravity.TOP|Gravity.START);styleField(content);body.addView(content,fieldParams());
        body.addView(label("Short introduction (optional)"));excerpt=new EditText(this);excerpt.setTextSize(15);excerpt.setTextColor(INK);excerpt.setHint("A short summary of your Story");excerpt.setMinLines(2);excerpt.setGravity(Gravity.TOP|Gravity.START);styleField(excerpt);body.addView(excerpt,fieldParams());
        body.addView(label("Story images"));chooseButton=text("＋  Choose images",14,VIOLET,true);chooseButton.setGravity(Gravity.CENTER);chooseButton.setPadding(dp(14),dp(13),dp(14),dp(13));chooseButton.setBackground(shape(Color.WHITE,7));LinearLayout.LayoutParams chooseParams=new LinearLayout.LayoutParams(-1,-2);chooseParams.topMargin=dp(6);body.addView(chooseButton,chooseParams);chooseButton.setOnClickListener(v->pickImages());
        imageSummary=text("Add one or more images. The first image will be the Story cover.",12,MUTED,false);imageSummary.setPadding(0,dp(8),0,dp(5));body.addView(imageSummary);
        previewList=new LinearLayout(this);previewList.setOrientation(LinearLayout.VERTICAL);body.addView(previewList);
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(100);progress.setProgressTintList(android.content.res.ColorStateList.valueOf(VIOLET));LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(7));pp.topMargin=dp(17);body.addView(progress,pp);progress.setVisibility(View.GONE);
        status=text("Your Story will be reviewed before publication unless automatic approval is enabled.",12,MUTED,false);status.setPadding(0,dp(10),0,dp(12));body.addView(status);
        postButton=actionButton("Post Story",true);body.addView(postButton,fullWidth());postButton.setOnClickListener(v->submit(false));
        draftButton=actionButton("Save Draft",false);LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(-1,-2);dp.topMargin=dp(9);body.addView(draftButton,dp);draftButton.setOnClickListener(v->submit(true));
        setContentView(root);
    }
    private void styleField(EditText e){e.setPadding(dp(12),dp(11),dp(12),dp(11));e.setBackground(shape(Color.WHITE,7));}
    private LinearLayout.LayoutParams fieldParams(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(2);return p;}
    private LinearLayout.LayoutParams fullWidth(){return new LinearLayout.LayoutParams(-1,-2);}
    private TextView label(String s){TextView t=text(s,14,INK,true);t.setPadding(0,dp(18),0,dp(5));return t;}
    private TextView actionButton(String s,boolean primary){TextView b=text(s,14,primary?Color.WHITE:VIOLET,true);b.setGravity(Gravity.CENTER);b.setPadding(dp(15),dp(14),dp(15),dp(14));b.setBackground(shape(primary?VIOLET:Color.WHITE,7));return b;}

    private void pickImages(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);startActivityForResult(i,PICK_IMAGES);}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode!=PICK_IMAGES||resultCode!=RESULT_OK||data==null)return;
        ArrayList<Uri> chosen=new ArrayList<>();if(data.getClipData()!=null){for(int i=0;i<data.getClipData().getItemCount();i++)chosen.add(data.getClipData().getItemAt(i).getUri());}else if(data.getData()!=null)chosen.add(data.getData());
        for(Uri uri:chosen){if(!imageUris.contains(uri)){imageUris.add(uri);uploadedIds.add(0);imageNames.add(displayName(uri));}}
        renderImages();
    }
    private Bitmap decodePreview(Uri uri){try(InputStream in=getContentResolver().openInputStream(uri)){if(in==null)return null;BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;BitmapFactory.decodeStream(in,null,bounds);int sample=1;while(bounds.outWidth/sample>240||bounds.outHeight/sample>240)sample*=2;try(InputStream second=getContentResolver().openInputStream(uri)){BitmapFactory.Options opts=new BitmapFactory.Options();opts.inSampleSize=sample;return BitmapFactory.decodeStream(second,null,opts);}}catch(Exception ignored){return null;}}
    private String displayName(Uri uri){try(Cursor c=getContentResolver().query(uri,null,null,null,null)){if(c!=null&&c.moveToFirst()){int x=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(x>=0)return c.getString(x);}}catch(Exception ignored){}return "Story image";}
    private String mime(Uri uri){String m=getContentResolver().getType(uri);return m==null?"image/jpeg":m;}
    private long fileSize(Uri uri){try(Cursor c=getContentResolver().query(uri,null,null,null,null)){if(c!=null&&c.moveToFirst()){int x=c.getColumnIndex(OpenableColumns.SIZE);if(x>=0)return c.getLong(x);}}catch(Exception ignored){}return -1;}
    private void renderImages(){previewList.removeAllViews();imageSummary.setText(imageUris.isEmpty()?"Add one or more images. The first image will be the Story cover.":imageUris.size()+" image(s) selected. The first image will be the Story cover.");
        for(int i=0;i<imageUris.size();i++){final int index=i;LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(8),dp(7),dp(8),dp(7));row.setBackground(shape(Color.WHITE,7));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.topMargin=dp(6);previewList.addView(row,rp);
            ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.CENTER_CROP);Bitmap preview=decodePreview(imageUris.get(i));if(preview!=null)image.setImageBitmap(preview);row.addView(image,new LinearLayout.LayoutParams(dp(58),dp(58)));
            LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(10),0,dp(6),0);row.addView(info,new LinearLayout.LayoutParams(0,-2,1));info.addView(text(imageNames.get(i),12,INK,true));info.addView(text(uploadedIds.get(i)>0?"Uploaded":"Ready to upload",11,uploadedIds.get(i)>0?Color.rgb(22,163,74):MUTED,false));
            TextView remove=text("×",23,MUTED,false);remove.setGravity(Gravity.CENTER);row.addView(remove,new LinearLayout.LayoutParams(dp(38),dp(48)));remove.setOnClickListener(v->{if(busy)return;imageUris.remove(index);uploadedIds.remove(index);imageNames.remove(index);renderImages();});
        }
    }

    private void loadInterests(){status.setText("Loading Story interests…");io.execute(()->{try{JSONObject result=request("creator-studio/story-interests","GET",null);JSONArray arr=result.optJSONArray("interests");ArrayList<String> names=new ArrayList<>();interestIds.clear();if(arr!=null){for(int i=0;i<arr.length();i++){JSONObject item=arr.optJSONObject(i);if(item!=null){names.add(item.optString("name"));interestIds.add(item.optInt("id"));}}}runOnUiThread(()->{if(names.isEmpty()){status.setText("No Story interests are currently available. Please try again later.");return;}ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,names);adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);interest.setAdapter(adapter);status.setText("Your Story will be reviewed before publication unless automatic approval is enabled.");});}catch(Exception e){runOnUiThread(()->status.setText(cleanError(e.getMessage())+" You can retry by reopening this page."));}});}

    private void submit(boolean saveDraft){if(busy)return;String t=title.getText().toString().trim(),c=content.getText().toString().trim();if(t.isEmpty()||t.length()>100){message("Enter a Story title of no more than 100 characters.");return;}if(c.isEmpty()){message("Write some content for your Story.");return;}if(interestIds.isEmpty()||interest.getSelectedItemPosition()<0){message("Choose a Story interest.");return;}if(imageUris.isEmpty()){message("Add at least one Story image.");return;}
        int selectedInterest=interestIds.get(interest.getSelectedItemPosition());String summary=excerpt.getText().toString().trim();busy=true;setButtons(false);progress.setVisibility(View.VISIBLE);progress.setProgress(0);message(saveDraft?"Saving your Story draft…":"Preparing your Story…");
        io.execute(()->{try{int total=imageUris.size();for(int i=0;i<total;i++){if(uploadedIds.get(i)>0)continue;final int current=i+1;runOnUiThread(()->message("Uploading Story image "+current+" of "+total+"…"));JSONObject uploaded=multipart("creator-studio/stories/images","image",imageUris.get(i),imageNames.get(i),mime(imageUris.get(i)),i,total);int id=uploaded.optInt("id",0);if(id<=0)throw new Exception("The server did not return an image ID.");uploadedIds.set(i,id);}
            JSONObject payload=new JSONObject();payload.put("title",t);payload.put("content",c);payload.put("excerpt",summary);payload.put("interest_id",selectedInterest);payload.put("action",saveDraft?"draft":"submit");JSONArray ids=new JSONArray();for(Integer id:uploadedIds)ids.put(id);payload.put("image_ids",ids);runOnUiThread(()->message(saveDraft?"Saving your draft…":"Publishing your Story…"));JSONObject result=request("creator-studio/stories/publish","POST",payload);
            runOnUiThread(()->{busy=false;setButtons(true);progress.setProgress(100);String msg=result.optString("message",saveDraft?"Your Story draft has been saved.":"Your Story has been submitted.");Toast.makeText(this,msg,Toast.LENGTH_LONG).show();setResult(RESULT_OK);finish();});
        }catch(Exception e){runOnUiThread(()->{busy=false;setButtons(true);message(cleanError(e.getMessage()));});}});
    }
    private JSONObject request(String path,String method,JSONObject data)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(HOME+"wp-json/phisk/v1/"+path).openConnection();try{c.setRequestMethod(method);c.setConnectTimeout(20000);c.setReadTimeout(60000);c.setRequestProperty("Accept","application/json");c.setRequestProperty("Authorization","Bearer "+token());if(data!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=UTF-8");try(OutputStream out=c.getOutputStream()){out.write(data.toString().getBytes(StandardCharsets.UTF_8));}}return readResponse(c);}finally{c.disconnect();}}
    private JSONObject multipart(String path,String field,Uri uri,String filename,String contentType,int index,int count)throws Exception{String boundary="----PhiskStory"+System.currentTimeMillis()+index;HttpURLConnection c=(HttpURLConnection)new URL(HOME+"wp-json/phisk/v1/"+path).openConnection();try{c.setRequestMethod("POST");c.setConnectTimeout(30000);c.setReadTimeout(120000);c.setDoOutput(true);c.setChunkedStreamingMode(64*1024);c.setRequestProperty("Authorization","Bearer "+token());c.setRequestProperty("Accept","application/json");c.setRequestProperty("Content-Type","multipart/form-data; boundary="+boundary);long total=fileSize(uri);try(OutputStream out=c.getOutputStream()){String head="--"+boundary+"\r\nContent-Disposition: form-data; name=\""+field+"\"; filename=\""+filename.replace("\"","_")+"\"\r\nContent-Type: "+contentType+"\r\n\r\n";out.write(head.getBytes(StandardCharsets.UTF_8));try(InputStream in=getContentResolver().openInputStream(uri)){if(in==null)throw new Exception("Cannot read the selected image.");byte[] buffer=new byte[32*1024];long sent=0;int n;while((n=in.read(buffer))!=-1){out.write(buffer,0,n);sent+=n;if(total>0){int pct=(int)Math.min(99,(sent*100)/total);int overall=(int)(((index+(pct/100f))/count)*95);runOnUiThread(()->progress.setProgress(overall));}}}out.write(("\r\n--"+boundary+"--\r\n").getBytes(StandardCharsets.UTF_8));out.flush();}return readResponse(c);}finally{c.disconnect();}}
    private JSONObject readResponse(HttpURLConnection c)throws Exception{int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();ByteArrayOutputStream out=new ByteArrayOutputStream();if(in!=null){byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);in.close();}String raw=out.toString("UTF-8");JSONObject result;try{result=new JSONObject(raw);}catch(Exception e){throw new Exception("The server returned an unreadable response (HTTP "+code+").");}if(code<200||code>=300){JSONObject data=result.optJSONObject("data");throw new Exception(data==null?result.optString("message","Request failed (HTTP "+code+")."):data.optString("message",result.optString("message","Request failed.")));}return result;}
    private String cleanError(String s){if(s==null||s.trim().isEmpty())return "Something went wrong. Please try again.";try{JSONObject j=new JSONObject(s);JSONObject d=j.optJSONObject("data");return d==null?j.optString("message",s):d.optString("message",s);}catch(Exception ignored){return s;}}
    private void message(String s){status.setText(s);status.setTextColor(INK);}
    private void setButtons(boolean enabled){postButton.setEnabled(enabled);draftButton.setEnabled(enabled);chooseButton.setEnabled(enabled);postButton.setAlpha(enabled?1f:.55f);draftButton.setAlpha(enabled?1f:.55f);chooseButton.setAlpha(enabled?1f:.55f);}
    @Override protected void onDestroy(){io.shutdownNow();super.onDestroy();}
}
