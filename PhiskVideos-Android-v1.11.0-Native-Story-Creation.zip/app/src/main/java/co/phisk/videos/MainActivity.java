package co.phisk.videos;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;
import android.webkit.JavascriptInterface;
import android.webkit.CookieManager;
import android.webkit.WebStorage;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.ImageButton;
import android.widget.Toast;
import android.widget.EditText;
import android.widget.Button;
import android.widget.ScrollView;
import android.text.InputType;
import android.content.res.ColorStateList;
import android.view.Gravity;
import android.view.ViewGroup;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import org.json.JSONObject;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.Locale;
import java.util.Map;
import java.util.List;
import java.util.concurrent.Executor;
import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.exceptions.GetCredentialException;
import com.google.android.libraries.identity.googleid.GetGoogleIdOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthProvider;


public class MainActivity extends Activity {
    private static final String HOME = "https://videos.phisk.co/";
    private static final String SITE_HOST = "videos.phisk.co";
    private static final String AUTH_API = HOME + "wp-json/phisk/v1/app-auth/";
    private static final String GOOGLE_AUTH_API = HOME + "wp-json/phisk-auth/v1/google-login";
    private static final String AUTH_PREFS = "phisk_native_auth";
    public static final String EXTRA_NOTIFICATION_URL = "phisk_notification_url";
    private static final int VIOLET = Color.rgb(124,58,237);
    private final ExecutorService authExecutor = Executors.newSingleThreadExecutor();
    private final Executor mainThreadExecutor = command -> new Handler(Looper.getMainLooper()).post(command);
    private LinearLayout authRoot;
    private FrameLayout appFrame;
    private boolean authBusy = false;
    private WebView web;
    private ProgressBar progress;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_REQUEST = 22;
    private final ExecutorService downloadExecutor = Executors.newSingleThreadExecutor();
    private static final String DOWNLOAD_CHANNEL = "phisk_video_downloads";
    private static final String PREFS = "phisk_download_metadata";
    private static final String DOWNLOAD_CONTROL = "phisk_download_control";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        createDownloadChannel();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 71);
        }
        buildWebView();
        boolean signedIn = getSharedPreferences(AUTH_PREFS, MODE_PRIVATE).getBoolean("signed_in", false);
        if (signedIn) {
            FcmDeviceRegistrar.registerCurrentToken(this);
            if (hasIncomingDestination(getIntent())) { showWebsite(HOME); handleIncomingIntent(getIntent()); }
            else openNativeHome();
        } else { showWelcome(); handleIncomingIntent(getIntent()); }
    }

    private boolean hasIncomingDestination(Intent intent) {
        if (intent == null) return false;
        String[] keys = {EXTRA_NOTIFICATION_URL, "target_url", "url", "link"};
        for (String key : keys) { String value = intent.getStringExtra(key); if (value != null && !value.trim().isEmpty()) return true; }
        return Intent.ACTION_VIEW.equals(intent.getAction()) && intent.getData() != null;
    }

    private void openNativeHome() {
        Intent home = new Intent(this, NativeHomeActivity.class);
        home.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(home);
    }

    private void buildWebView() {
        appFrame = new FrameLayout(this);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.WHITE);
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100); progress.setProgressTintList(ColorStateList.valueOf(VIOLET));
        root.addView(progress, new LinearLayout.LayoutParams(-1, 4));
        web = new WebView(this); root.addView(web, new LinearLayout.LayoutParams(-1,0,1));
        appFrame.addView(root, new FrameLayout.LayoutParams(-1,-1));
        setContentView(appFrame);
        WebSettings settings = web.getSettings(); settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(true); settings.setAllowFileAccess(false); settings.setAllowContentAccess(true);
        settings.setSupportMultipleWindows(false);
        settings.setUserAgentString(settings.getUserAgentString() + " PhiskVideosApp/1.5.1");
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        web.addJavascriptInterface(new PhiskAppBridge(), "PhiskApp");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return handleNavigation(request.getUrl()); }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) { return handleNavigation(Uri.parse(url)); }
            @Override public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.GONE);
                injectInternalNavigationFixes(view);
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int value) { progress.setVisibility(value == 100 ? View.GONE : View.VISIBLE); progress.setProgress(value); }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback=callback;
                try { startActivityForResult(params.createIntent(), FILE_REQUEST); return true; }
                catch(Exception e) { fileCallback=null; return false; }
            }
        });
    }

    private boolean isPhiskHost(String host) {
        return host != null && (host.equalsIgnoreCase("phisk.co") || host.toLowerCase(Locale.US).endsWith(".phisk.co"));
    }

    private boolean handleNavigation(Uri uri) {
        String scheme = uri.getScheme();
        String host = uri.getHost();
        String path = uri.getPath() == null ? "/" : uri.getPath().toLowerCase(Locale.US);

        if (("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme)) && isPhiskHost(host)) {
            if ("videos.phisk.co".equalsIgnoreCase(host) && ("/phisk-notifications".equals(path.replaceAll("/+$", "")) || "/notifications".equals(path.replaceAll("/+$", "")))) {
                startActivity(new Intent(MainActivity.this, NotificationCentreActivity.class));
                return true;
            }
            if ("videos.phisk.co".equalsIgnoreCase(host) && "/downloads".equals(path.replaceAll("/+$", ""))) {
                startActivity(new Intent(MainActivity.this, DownloadsActivity.class));
                return true;
            }
            if ("videos.phisk.co".equalsIgnoreCase(host) && ("/upload".equals(path.replaceAll("/+$", "")) || "/upload-video".equals(path.replaceAll("/+$", "")))) {
                startActivity(new Intent(MainActivity.this, NativeVideoUploadActivity.class));
                return true;
            }
            if ("videos.phisk.co".equalsIgnoreCase(host) && "/creator-studio".equals(path.replaceAll("/+$", ""))) {
                startActivity(new Intent(MainActivity.this, NativeCreatorStudioActivity.class));
                return true;
            }

            String authMode = authModeForUri(uri);
            if (authMode != null) {
                showAuthForm(authMode);
                return true;
            }

            if ("http".equalsIgnoreCase(scheme)) {
                Uri secure = uri.buildUpon().scheme("https").build();
                web.loadUrl(secure.toString());
                return true;
            }
            return false;
        }

        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
        catch (Exception e) { Toast.makeText(this, "Cannot open link", Toast.LENGTH_SHORT).show(); }
        return true;
    }

    // Return the native screen for known authentication routes. Keep ordinary account/profile pages in the WebView.
    private String authModeForUri(Uri uri) {
        String path = uri.getPath() == null ? "" : uri.getPath().toLowerCase(Locale.US);
        String action = uri.getQueryParameter("action");
        String normalized = path.replaceAll("/+", "/");
        if (normalized.matches(".*/(register|signup|sign-up|sign_up|create-account|join)/?$") ||
                "register".equalsIgnoreCase(action) || "signup".equalsIgnoreCase(action)) return "register";
        if ("lostpassword".equalsIgnoreCase(action) || "rp".equalsIgnoreCase(action) ||
                normalized.matches(".*/(lost-password|forgot-password|password-reset|reset-password)/?$")) return "reset";
        if (normalized.matches(".*/(login|log-in|signin|sign-in|sign_in)/?$") ||
                "login".equalsIgnoreCase(action) ||
                (normalized.endsWith("wp-login.php") && action == null)) return "login";
        return null;
    }

    private void injectInternalNavigationFixes(WebView view) {
        // Keep native routing limited to the actual clicked control. Never infer an action
        // from a large parent container's text: menus often contain both Logout and Downloads.
        // The dedicated /logout/ confirmation page must retain normal HTML form/link behaviour.
        String js = "(function(){try{" +
          "if(window.__phiskNavigationFixesInstalled)return;window.__phiskNavigationFixesInstalled=true;" +
          "function norm(v){return (v||'').toString().replace(/[\\s\\u00a0]+/g,' ').trim().toLowerCase();}" +
          "function onLogoutPage(){return /\\/logout\\/?$/i.test(location.pathname);}" +
          "function actionElement(target){return target&&target.closest?target.closest('a,button,input,[role=button],[data-url],[data-href]'):null;}" +
          "function elementUrl(el){var raw=el?(el.getAttribute('href')||el.getAttribute('data-url')||el.getAttribute('data-href')||el.getAttribute('formaction')||''):'';try{return new URL(raw,location.href);}catch(e){return null;}}" +
          "function isDownloads(el){var u=elementUrl(el);return !!(u&&u.hostname.toLowerCase()==='videos.phisk.co'&&u.pathname.replace(/\\/+$/,'')==='/downloads');}" +
          "function isLogoutControl(el){if(!el)return false;var u=elementUrl(el);if(u&&(/\\/(logout|log-out|sign-out)(\\/|$)/i.test(u.pathname)||/(^|[?&])action=logout(&|$)/i.test(u.search)))return true;var marker=norm([el.getAttribute('aria-label'),el.getAttribute('title'),el.getAttribute('data-action'),el.getAttribute('name'),el.innerText,el.value].filter(Boolean).join(' '));return /\\b(log ?out|sign ?out|logoff)\\b/i.test(marker);}" +
          "function authMode(el){if(!el||isLogoutControl(el))return null;var u=elementUrl(el);var raw=norm([el.getAttribute('href'),el.getAttribute('action'),el.getAttribute('aria-label'),el.getAttribute('title'),el.getAttribute('name'),el.id,el.className,el.innerText,el.value,u?u.pathname+' '+u.search:''].filter(Boolean).join(' '));" +
          "if(/\\b(forgot password|lost password|reset password)\\b/.test(raw)||/\\/(lost-password|forgot-password|password-reset|reset-password)(\\/|$)/.test(raw))return 'reset';" +
          "if(/\\b(register|sign ?up|create account|create an account|join now)\\b/.test(raw))return 'register';" +
          "if(/\\b(log ?in|sign ?in|login|signin)\\b/.test(raw))return 'login';" +
          "if(u&&/\\/(register|signup|sign-up|sign_in|login|log-in|signin|sign-in)(\\/|$)/.test(u.pathname))return /register|signup|sign-up/.test(u.pathname)?'register':'login';return null;}" +
          "document.addEventListener('click',function(e){if(onLogoutPage())return;var el=actionElement(e.target);if(!el)return;" +
          "if(isDownloads(el)){e.preventDefault();e.stopPropagation();if(e.stopImmediatePropagation)e.stopImmediatePropagation();window.PhiskApp.openDownloads();return;}" +
          "if(isLogoutControl(el)){e.preventDefault();e.stopPropagation();if(e.stopImmediatePropagation)e.stopImmediatePropagation();var u=elementUrl(el);window.location.href=u?u.href:'https://videos.phisk.co/logout/';return;}" +
          "var mode=authMode(el);if(mode){e.preventDefault();e.stopPropagation();if(e.stopImmediatePropagation)e.stopImmediatePropagation();window.PhiskApp.openNativeAuth(mode);}},true);" +
          "document.addEventListener('submit',function(e){if(onLogoutPage())return;var form=e.target;if(!form||!form.matches)return;var action=elementUrl(form);if(action&&/\\/(logout|log-out|sign-out)(\\/|$)/i.test(action.pathname))return;var mode=authMode(form);if(!mode&&e.submitter)mode=authMode(e.submitter);if(mode){e.preventDefault();e.stopPropagation();window.PhiskApp.openNativeAuth(mode);}},true);" +
          "document.querySelectorAll('a[target=\\\"_blank\\\"]').forEach(function(a){try{var u=new URL(a.href,location.href);if(u.hostname==='phisk.co'||u.hostname.endsWith('.phisk.co'))a.target='_self';}catch(e){}});" +
          "}catch(e){console.log('Phisk navigation setup failed',e);}})();";
        view.evaluateJavascript(js, null);
    }

    private void showWebsite(String url) {
        if (authRoot != null && authRoot.getParent() == appFrame) appFrame.removeView(authRoot);
        authRoot = null;
        web.setVisibility(View.VISIBLE);
        web.loadUrl(url);
    }

    private void showWelcome() {
        // The native gateway always opens on Sign In; registration remains available from its switcher.
        showAuthForm("login");
    }

    private void showAuthForm(String mode) {
        if ("reset".equals(mode)) showResetForm();
        else showAuthScreen("register".equals(mode) ? "register" : "login");
    }

    private void showAuthScreen(String mode) {
        web.setVisibility(View.GONE);
        if (authRoot != null && authRoot.getParent() == appFrame) appFrame.removeView(authRoot);
        authRoot = new LinearLayout(this); authRoot.setOrientation(LinearLayout.VERTICAL); authRoot.setBackgroundColor(Color.WHITE);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setGravity(Gravity.CENTER_HORIZONTAL);
        content.setPadding(dp(28), dp(30), dp(28), dp(28));
        scroll.addView(content, new ScrollView.LayoutParams(-1, -2));
        ImageView brand = new ImageView(this);
        brand.setImageResource(R.drawable.auth_logo);
        brand.setScaleType(ImageView.ScaleType.FIT_CENTER);
        brand.setContentDescription("PhiskVideos logo");
        content.addView(brand, new LinearLayout.LayoutParams(dp(88), dp(88)));
        View spacer = new View(this); content.addView(spacer, new LinearLayout.LayoutParams(1, dp(mode.equals("welcome") ? 58 : 22)));
        if ("welcome".equals(mode)) {
            TextView heading = heading("Welcome to PhiskVideos"); content.addView(heading);
            TextView desc = body("Sign in to unlock account features, follow creators, save videos and join the PhiskVideos community."); desc.setGravity(Gravity.CENTER); desc.setPadding(0, dp(20), 0, dp(42)); content.addView(desc);
            Button signIn = primaryButton("Sign In"); signIn.setOnClickListener(v -> showAuthForm("login")); content.addView(signIn, fullWidth());
            addDivider(content, "New to PhiskVideos?");
            Button create = outlineButton("Create Account"); create.setOnClickListener(v -> showAuthForm("register")); content.addView(create, fullWidth());
            Button google = outlineButton("Continue with Google"); google.setOnClickListener(v -> signInWithGoogle(google)); content.addView(google, fullWidth());
            // Guest browsing is disabled: users must authenticate before entering the app.
        } else {
            boolean register = "register".equals(mode);
            TextView heading = heading(register ? "Create your account" : "Sign in to PhiskVideos"); content.addView(heading);
            TextView desc = body(register ? "Join the PhiskVideos community." : "Welcome back. Sign in to continue."); desc.setGravity(Gravity.CENTER); desc.setPadding(0, dp(10), 0, dp(22)); content.addView(desc);
            EditText identity = input(register ? "Username" : "Email or username", InputType.TYPE_CLASS_TEXT);
            EditText name = register ? input("Full name", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS) : null;
            EditText email = register ? input("Email address", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS) : null;
            EditText password = input("Password", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            EditText confirm = register ? input("Confirm password", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD) : null;
            if (register) { content.addView(name, fieldParams()); content.addView(identity, fieldParams()); content.addView(email, fieldParams()); }
            else content.addView(identity, fieldParams());
            content.addView(passwordField(password), fieldParams()); if (register) content.addView(passwordField(confirm), fieldParams());
            Button submit = primaryButton(register ? "Create Account" : "Sign In"); submit.setOnClickListener(v -> {
                if (register) submitRegistration(name.getText().toString(), identity.getText().toString(), email.getText().toString(), password.getText().toString(), confirm.getText().toString(), submit);
                else submitLogin(identity.getText().toString(), password.getText().toString(), submit);
            }); content.addView(submit, fullWidth());
            if (!register) { Button forgot = textButton("Forgot password?"); forgot.setOnClickListener(v -> showResetForm()); content.addView(forgot, fullWidth()); }
            Button google = outlineButton("Continue with Google"); google.setOnClickListener(v -> signInWithGoogle(google)); content.addView(google, fullWidth());
            Button switcher = textButton(register ? "Already have an account? Sign In" : "New to PhiskVideos? Create Account"); switcher.setOnClickListener(v -> showAuthForm(register ? "login" : "register")); content.addView(switcher, fullWidth());
            // Guest browsing is disabled: users must authenticate before entering the app.
        }
        authRoot.addView(scroll, new LinearLayout.LayoutParams(-1, -1));
        if (authRoot.getParent() instanceof ViewGroup) ((ViewGroup)authRoot.getParent()).removeView(authRoot);
        appFrame.addView(authRoot, new FrameLayout.LayoutParams(-1,-1));
    }

    private void signInWithGoogle(Button button) {
        if (authBusy) return;
        if (!getString(R.string.default_web_client_id).endsWith(".apps.googleusercontent.com")) {
            toast("Google sign-in is not configured yet. Please try again later.");
            return;
        }
        authBusy = true;
        button.setEnabled(false);
        button.setText("Connecting to Google…");
        try {
            CredentialManager credentialManager = CredentialManager.create(this);
            GetGoogleIdOption googleOption = new GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(getString(R.string.default_web_client_id))
                    .build();
            GetCredentialRequest request = new GetCredentialRequest.Builder()
                    .addCredentialOption(googleOption).build();
            credentialManager.getCredentialAsync(this, request, new CancellationSignal(), mainThreadExecutor,
                    new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                        @Override public void onResult(GetCredentialResponse result) {
                            Credential credential = result.getCredential();
                            if (!(credential instanceof CustomCredential) ||
                                    !GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(credential.getType())) {
                                finishGoogleError(button, "Google returned an unsupported sign-in response.");
                                return;
                            }
                            GoogleIdTokenCredential googleToken = GoogleIdTokenCredential.createFrom(((CustomCredential) credential).getData());
                            authenticateWithFirebase(googleToken.getIdToken(), button);
                        }
                        @Override public void onError(GetCredentialException error) {
                            String message = error.getMessage();
                            if (message == null || message.trim().isEmpty()) message = "Google sign-in was cancelled or could not be completed.";
                            finishGoogleError(button, message);
                        }
                    });
        } catch (Exception ex) {
            finishGoogleError(button, "Google sign-in could not start. Please try again.");
        }
    }

    private void authenticateWithFirebase(String googleIdToken, Button button) {
        AuthCredential credential = GoogleAuthProvider.getCredential(googleIdToken, null);
        FirebaseAuth.getInstance().signInWithCredential(credential)
                .addOnCompleteListener(this, task -> {
                    if (!task.isSuccessful() || FirebaseAuth.getInstance().getCurrentUser() == null) {
                        String message = task.getException() != null ? task.getException().getLocalizedMessage() : "Firebase could not verify this Google account.";
                        finishGoogleError(button, message);
                        return;
                    }
                    FirebaseAuth.getInstance().getCurrentUser().getIdToken(true)
                            .addOnCompleteListener(this, tokenTask -> {
                                if (!tokenTask.isSuccessful() || tokenTask.getResult() == null || tokenTask.getResult().getToken() == null) {
                                    finishGoogleError(button, "Could not obtain a secure PhiskVideos sign-in token.");
                                    return;
                                }
                                exchangeFirebaseTokenWithWordPress(tokenTask.getResult().getToken(), button);
                            });
                });
    }

    private void exchangeFirebaseTokenWithWordPress(String idToken, Button button) {
        authExecutor.execute(() -> {
            HttpURLConnection connection = null;
            String errorMessage = "PhiskVideos could not complete your account sign-in. Please try again.";
            boolean success = false;
            boolean receivedAuthCookie = false;
            try {
                JSONObject payload = new JSONObject();
                payload.put("id_token", idToken);
                payload.put("device_id", FcmDeviceRegistrar.getDeviceId(this));
                connection = (HttpURLConnection) new URL(GOOGLE_AUTH_API).openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(20000);
                connection.setReadTimeout(25000);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                connection.setRequestProperty("Accept", "application/json");
                byte[] body = payload.toString().getBytes("UTF-8");
                try (OutputStream out = connection.getOutputStream()) { out.write(body); }
                int status = connection.getResponseCode();
                Map<String, List<String>> headers = connection.getHeaderFields();
                if (headers != null) {
                    for (Map.Entry<String, List<String>> header : headers.entrySet()) {
                        if (header.getKey() != null && "Set-Cookie".equalsIgnoreCase(header.getKey()) && header.getValue() != null) {
                            for (String cookie : header.getValue()) {
                                if (cookie != null && (cookie.startsWith("wordpress_logged_in_") || cookie.startsWith("wordpress_sec_"))) receivedAuthCookie = true;
                                CookieManager.getInstance().setCookie(HOME, cookie);
                            }
                        }
                    }
                }
                CookieManager.getInstance().flush();
                InputStream stream = status >= 200 && status < 300 ? connection.getInputStream() : connection.getErrorStream();
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                if (stream != null) {
                    byte[] buffer = new byte[2048]; int count;
                    while ((count = stream.read(buffer)) != -1) bytes.write(buffer, 0, count);
                    stream.close();
                }
                JSONObject response = new JSONObject(new String(bytes.toByteArray(), "UTF-8"));
                String appAccessToken = response.optString("access_token", "");
                success = status >= 200 && status < 300 && response.optBoolean("success")
                        && receivedAuthCookie && !appAccessToken.trim().isEmpty();
                if (success) getSharedPreferences(AUTH_PREFS, MODE_PRIVATE).edit().putString("access_token", appAccessToken).apply();
                if (!success) {
                    JSONObject data = response.optJSONObject("data");
                    if (data != null) errorMessage = data.optString("message", errorMessage);
                    else errorMessage = response.optString("message", errorMessage);
                    if (status >= 200 && status < 300 && !receivedAuthCookie) errorMessage = "Google verified your account, but the website session cookie was not received. Please contact support.";
                    else if (status >= 200 && status < 300 && appAccessToken.trim().isEmpty()) errorMessage = "Google sign-in succeeded, but the app session could not be created. Please update Phisk Video Manager and try again.";
                }
            } catch (Exception ex) {
                errorMessage = "Could not securely connect to PhiskVideos. Check your internet connection and try again.";
            } finally {
                if (connection != null) connection.disconnect();
            }
            final boolean ok = success;
            final String message = errorMessage;
            runOnUiThread(() -> {
                authBusy = false;
                button.setEnabled(true);
                button.setText("Continue with Google");
                if (ok) {
                    getSharedPreferences(AUTH_PREFS, MODE_PRIVATE).edit().putBoolean("signed_in", true).apply();
                    FcmDeviceRegistrar.registerCurrentToken(this);
                    Toast.makeText(this, "Welcome to PhiskVideos!", Toast.LENGTH_SHORT).show();
                    String pending = consumePendingDestination();
                    if (pending == null) openNativeHome(); else showWebsite(pending);
                } else {
                    toast(message);
                }
            });
        });
    }

    private void finishGoogleError(Button button, String message) {
        runOnUiThread(() -> {
            authBusy = false;
            button.setEnabled(true);
            button.setText("Continue with Google");
            toast(message);
        });
    }

    private TextView heading(String text) { TextView v=new TextView(this); v.setText(text); v.setTextColor(Color.BLACK); v.setTextSize(25); v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); v.setGravity(Gravity.CENTER); return v; }
    private TextView body(String text) { TextView v=new TextView(this); v.setText(text); v.setTextColor(0xFF667085); v.setTextSize(16); return v; }
    private LinearLayout.LayoutParams fullWidth() { LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(54)); p.setMargins(0,dp(9),0,dp(9)); return p; }
    private LinearLayout.LayoutParams fieldParams() { LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(54)); p.setMargins(0,dp(6),0,dp(6)); return p; }
    private Button primaryButton(String text) { Button b=new Button(this); b.setText(text); b.setTextColor(Color.WHITE); b.setTextSize(16); b.setAllCaps(false); b.setBackground(roundDrawable(VIOLET, dp(9), 0)); return b; }
    private Button outlineButton(String text) { Button b=new Button(this); b.setText(text); b.setTextColor(Color.BLACK); b.setTextSize(16); b.setAllCaps(false); b.setBackground(roundDrawable(Color.WHITE, dp(9), VIOLET)); return b; }
    private Button textButton(String text) { Button b=new Button(this); b.setText(text); b.setTextColor(VIOLET); b.setTextSize(14); b.setAllCaps(false); b.setBackgroundColor(Color.TRANSPARENT); return b; }
    private GradientDrawable roundDrawable(int fill, int radius, int stroke) { GradientDrawable d=new GradientDrawable(); d.setColor(fill); d.setCornerRadius(radius); if(stroke!=0)d.setStroke(dp(2),stroke); return d; }
    private EditText input(String hint, int type) { EditText e=new EditText(this); e.setSingleLine(true); e.setHint(hint); e.setTextSize(15); e.setPadding(dp(14),0,dp(14),0); e.setInputType(type); e.setBackground(roundDrawable(0xFFF8F8FA,dp(8),0xFFE4E4E7)); return e; }
    private View passwordField(EditText field) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setBackground(roundDrawable(0xFFF8F8FA, dp(8), 0xFFE4E4E7));
        field.setBackgroundColor(Color.TRANSPARENT);
        field.setPadding(dp(14), 0, dp(4), 0);
        box.addView(field, new LinearLayout.LayoutParams(0, -1, 1f));
        ImageButton toggle = new ImageButton(this);
        toggle.setBackgroundColor(Color.TRANSPARENT);
        toggle.setPadding(dp(10), dp(10), dp(10), dp(10));
        toggle.setImageResource(R.drawable.ic_visibility_off);
        toggle.setImageTintList(ColorStateList.valueOf(0xFF667085));
        toggle.setContentDescription("Show password");
        box.addView(toggle, new LinearLayout.LayoutParams(dp(48), dp(48)));
        toggle.setOnClickListener(v -> {
            boolean currentlyHidden = (field.getInputType() & InputType.TYPE_MASK_VARIATION) == InputType.TYPE_TEXT_VARIATION_PASSWORD;
            int cursor = field.getSelectionStart();
            field.setInputType(InputType.TYPE_CLASS_TEXT | (currentlyHidden ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD : InputType.TYPE_TEXT_VARIATION_PASSWORD));
            field.setSelection(Math.max(0, Math.min(cursor, field.length())));
            toggle.setImageResource(currentlyHidden ? R.drawable.ic_visibility : R.drawable.ic_visibility_off);
            toggle.setContentDescription(currentlyHidden ? "Hide password" : "Show password");
        });
        return box;
    }
    private void addDivider(LinearLayout parent, String text) { TextView v=body(text); v.setGravity(Gravity.CENTER); v.setPadding(0,dp(24),0,dp(14)); parent.addView(v); }

    private void showResetForm() {
        showAuthScreen("reset");
        // Replace the reset-mode content with the dedicated reset form.
        authRoot.removeAllViews(); ScrollView scroll=new ScrollView(this); LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER_HORIZONTAL); box.setPadding(dp(28),dp(60),dp(28),dp(24)); scroll.addView(box);
        TextView title=heading("Reset your password"); box.addView(title); TextView info=body("Enter your email address or username and we'll send a password reset link."); info.setGravity(Gravity.CENTER); info.setPadding(0,dp(16),0,dp(24)); box.addView(info);
        EditText login=input("Email or username",InputType.TYPE_CLASS_TEXT); box.addView(login,fieldParams()); Button send=primaryButton("Send reset link"); box.addView(send,fullWidth()); send.setOnClickListener(v -> sendPasswordReset(login.getText().toString(),send)); Button back=textButton("Back to Sign In"); box.addView(back,fullWidth()); back.setOnClickListener(v -> showAuthForm("login")); authRoot.addView(scroll,new LinearLayout.LayoutParams(-1,-1));
    }

    private void submitLogin(String identity, String password, Button button) {
        if(identity.trim().isEmpty() || password.isEmpty()) { toast("Enter your email/username and password."); return; }
        JSONObject data=new JSONObject(); try { data.put("username",identity.trim()); data.put("password",password); data.put("device_id", FcmDeviceRegistrar.getDeviceId(this)); } catch(Exception ignored) {}
        performAuthRequest("login",data,button);
    }
    private void submitRegistration(String name,String username,String email,String password,String confirm,Button button) {
        if(name.trim().isEmpty() || username.trim().length()<3 || !android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches() || password.length()<10) { toast("Enter your name, a username (at least 3 characters), valid email and password (at least 10 characters)."); return; }
        if(!password.equals(confirm)) { toast("Passwords do not match."); return; }
        JSONObject data=new JSONObject(); try { data.put("name",name.trim()); data.put("username",username.trim()); data.put("email",email.trim()); data.put("password",password); data.put("device_id", FcmDeviceRegistrar.getDeviceId(this)); } catch(Exception ignored) {}
        performAuthRequest("register",data,button);
    }
    private void sendPasswordReset(String login,Button button) { if(login.trim().isEmpty()){toast("Enter your email address or username.");return;} JSONObject data=new JSONObject(); try{data.put("login",login.trim());}catch(Exception ignored){} performAuthRequest("password-reset",data,button); }

    private void performAuthRequest(String endpoint, JSONObject payload, Button button) {
        if(authBusy)return; authBusy=true; button.setEnabled(false); button.setText("Please wait…");
        authExecutor.execute(() -> {
            HttpURLConnection connection=null; String message="Something went wrong. Please try again."; boolean success=false;
            try {
                connection=(HttpURLConnection)new URL(AUTH_API+endpoint).openConnection(); connection.setRequestMethod("POST"); connection.setConnectTimeout(20000); connection.setReadTimeout(25000); connection.setDoOutput(true); connection.setRequestProperty("Content-Type","application/json; charset=UTF-8"); connection.setRequestProperty("Accept","application/json");
                byte[] body=payload.toString().getBytes("UTF-8"); try(OutputStream out=connection.getOutputStream()){out.write(body);} int status=connection.getResponseCode();
                for(java.util.Map.Entry<String,java.util.List<String>> header:connection.getHeaderFields().entrySet()) if(header.getKey()!=null && "Set-Cookie".equalsIgnoreCase(header.getKey())) for(String cookie:header.getValue()) CookieManager.getInstance().setCookie(HOME,cookie);
                CookieManager.getInstance().flush(); InputStream stream=status>=200&&status<300?connection.getInputStream():connection.getErrorStream(); ByteArrayOutputStream bytes=new ByteArrayOutputStream(); if(stream!=null){byte[] buf=new byte[2048];int n;while((n=stream.read(buf))!=-1)bytes.write(buf,0,n);stream.close();}
                JSONObject response=new JSONObject(new String(bytes.toByteArray(),"UTF-8")); success=status>=200&&status<300&&response.optBoolean("success");
                if(success) { String accessToken=response.optString("access_token", ""); if(!accessToken.isEmpty()) getSharedPreferences(AUTH_PREFS,MODE_PRIVATE).edit().putString("access_token",accessToken).apply(); message=response.optString("message", ""); } else message=response.optString("message", "Authentication failed. Please check your details.");
            } catch(Exception ex) { message="Could not connect securely to PhiskVideos. Check your internet connection and try again."; }
            finally { if(connection!=null)connection.disconnect(); }
            final boolean ok=success; final String result=message;
            runOnUiThread(() -> { authBusy=false; button.setEnabled(true); button.setText(endpoint.equals("register")?"Create Account":endpoint.equals("login")?"Sign In":"Send reset link"); if(ok && (endpoint.equals("login")||endpoint.equals("register"))) { getSharedPreferences(AUTH_PREFS,MODE_PRIVATE).edit().putBoolean("signed_in",true).apply(); FcmDeviceRegistrar.registerCurrentToken(this); Toast.makeText(this,"Welcome to PhiskVideos!",Toast.LENGTH_SHORT).show(); String pending=consumePendingDestination(); if(pending==null) openNativeHome(); else showWebsite(pending); } else { toast(result.isEmpty()?"If an account matches those details, a reset email has been sent.":result); } });
        });
    }
    private void toast(String text) { Toast.makeText(this,text,Toast.LENGTH_LONG).show(); }

    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    private class PhiskAppBridge {
        @JavascriptInterface public void downloadVideo(int videoId, String nonce, String rawName, String title, String thumbnail, String channel) {
            if (videoId < 1 || nonce == null || nonce.length() < 8 || nonce.length() > 128) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Invalid download request", Toast.LENGTH_LONG).show()); return;
            }
            final String name = safeFilename(rawName);
            final String safeTitle = title == null || title.trim().isEmpty() ? name.replaceFirst("(?i)\\.(mp4|m4v|mov|webm|ogv)$", "") : title.trim();
            downloadExecutor.execute(() -> requestAuthorisedDownload(videoId, nonce, name, safeTitle, thumbnail, channel));
        }
        @JavascriptInterface public void openDownloads() {
            runOnUiThread(() -> startActivity(new Intent(MainActivity.this, DownloadsActivity.class)));
        }
        @JavascriptInterface public void openNativeAuth(String mode) {
            runOnUiThread(() -> showAuthForm("register".equals(mode) ? "register" : "reset".equals(mode) ? "reset" : "login"));
        }
        @JavascriptInterface public void completeLogout() {
            runOnUiThread(() -> {
                FcmDeviceRegistrar.revokeSession(MainActivity.this);
                getSharedPreferences(AUTH_PREFS, MODE_PRIVATE).edit().putBoolean("signed_in", false).remove("access_token").apply();
                FirebaseAuth.getInstance().signOut();
                web.stopLoading();
                web.clearHistory();
                web.clearCache(true);
                WebStorage.getInstance().deleteAllData();
                CookieManager cookies = CookieManager.getInstance();
                cookies.removeAllCookies(removed -> {
                    cookies.flush();
                    runOnUiThread(() -> showWelcome());
                });
            });
        }
    }

    private String safeFilename(String input) {
        String name = input == null ? "phisk-video.mp4" : input.replaceAll("[^A-Za-z0-9._ -]", "_").trim();
        if (name.isEmpty()) name = "phisk-video.mp4";
        if (!name.matches("(?i).*\\.(mp4|m4v|mov|webm|ogv)$")) name += ".mp4";
        return name;
    }

    private void requestAuthorisedDownload(int videoId, String nonce, String filename, String title, String thumbnail, String channel) {
        HttpURLConnection api = null;
        try {
            URL endpoint = new URL(HOME + "wp-admin/admin-ajax.php");
            api = (HttpURLConnection) endpoint.openConnection(); api.setRequestMethod("POST"); api.setDoOutput(true); api.setConnectTimeout(20000); api.setReadTimeout(30000);
            api.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            api.setRequestProperty("Accept", "application/json");
            String cookie = CookieManager.getInstance().getCookie(HOME); if (cookie != null) api.setRequestProperty("Cookie", cookie);
            String body = "action=phisk_get_video_download&video_id=" + videoId + "&nonce=" + URLEncoder.encode(nonce, "UTF-8");
            try (OutputStream out = api.getOutputStream()) { out.write(body.getBytes("UTF-8")); }
            int status = api.getResponseCode();
            InputStream responseStream = status >= 200 && status < 300 ? api.getInputStream() : api.getErrorStream();
            ByteArrayOutputStream responseBuffer = new ByteArrayOutputStream(); byte[] responseChunk = new byte[4096]; int responseRead; while ((responseRead = responseStream.read(responseChunk)) != -1) responseBuffer.write(responseChunk, 0, responseRead); responseStream.close(); byte[] responseBytes = responseBuffer.toByteArray();
            JSONObject response = new JSONObject(new String(responseBytes, "UTF-8"));
            if (!response.optBoolean("success")) {
                JSONObject data = response.optJSONObject("data"); String message = data == null ? "Download is not available." : data.optString("message", "Download is not available.");
                throw new Exception(message);
            }
            JSONObject data = response.getJSONObject("data"); String fileUrl = data.getString("url");
            Uri parsed = Uri.parse(fileUrl);
            if (!"https".equalsIgnoreCase(parsed.getScheme()) || parsed.getHost() == null || fileUrl.length() > 4096) throw new Exception("The server returned an invalid video URL.");
            downloadToPrivateStorage(fileUrl, filename, title, thumbnail, channel);
        } catch (Exception error) {
            if (!"Download deleted".equals(error.getMessage())) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Download failed: " + error.getMessage(), Toast.LENGTH_LONG).show());
            }
        } finally { if (api != null) api.disconnect(); }
    }

    private void downloadToPrivateStorage(String urlString, String filename, String title, String thumbnail, String channel) {
        HttpURLConnection connection = null;
        FileOutputStream output = null;
        File partial = null;
        int notificationId = (int)(System.currentTimeMillis() & 0x7fffffff);
        createDownloadChannel();
        NotificationManager manager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        try {
            File directory = new File(getFilesDir(), "downloads");
            if (!directory.exists() && !directory.mkdirs()) throw new Exception("Could not create private download folder");
            File destination = new File(directory, System.currentTimeMillis() + "_" + filename);
            partial = new File(directory, destination.getName() + ".part");
            getSharedPreferences(DOWNLOAD_CONTROL, MODE_PRIVATE).edit().putString(destination.getName(), "running").apply();
            URL url = new URL(urlString);
            connection = (HttpURLConnection) url.openConnection(); connection.setConnectTimeout(20000); connection.setReadTimeout(1500); connection.setInstanceFollowRedirects(true);
            String cookie = CookieManager.getInstance().getCookie(urlString); if (cookie != null) connection.setRequestProperty("Cookie", cookie);
            connection.setRequestProperty("User-Agent", "PhiskVideosApp/1.1"); connection.connect();
            int status = connection.getResponseCode(); if (status < 200 || status >= 300) throw new Exception("Video host returned HTTP " + status);
            long total = connection.getContentLength();
            output = new FileOutputStream(partial); InputStream input = connection.getInputStream(); byte[] buffer = new byte[64 * 1024]; int read; long done = 0;
            while (true) {
                String control = getSharedPreferences(DOWNLOAD_CONTROL, MODE_PRIVATE).getString(destination.getName(), "running");
                if ("delete".equals(control)) throw new Exception("Download deleted");
                while ("paused".equals(control)) {
                    try { Thread.sleep(300); } catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); throw new Exception("Download interrupted"); }
                    control = getSharedPreferences(DOWNLOAD_CONTROL, MODE_PRIVATE).getString(destination.getName(), "running");
                    if ("delete".equals(control)) throw new Exception("Download deleted");
                }
                try { read = input.read(buffer); }
                catch (java.net.SocketTimeoutException timeout) { continue; }
                if (read == -1) break;
                output.write(buffer, 0, read); done += read;
                int pct = total > 0 ? (int)Math.min(100, (done * 100L) / total) : 0;
                postDownloadNotification(manager, notificationId, title, pct, false, total <= 0);
                saveDownloadProgress(destination.getName(), title, thumbnail, channel, pct, false);
            }
            output.flush(); input.close(); output.close(); output = null;
            if (!partial.renameTo(destination)) { partial.delete(); throw new Exception("Could not save the downloaded video"); }
            getSharedPreferences(DOWNLOAD_CONTROL, MODE_PRIVATE).edit().remove(destination.getName()).apply();
            saveDownloadProgress(destination.getName(), title, thumbnail, channel, 100, true);
            postDownloadNotification(manager, notificationId, title, 100, true, false);
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Video downloaded. Open Downloads to watch offline.", Toast.LENGTH_LONG).show());
        } catch (Exception error) {
            if (partial != null && partial.exists()) partial.delete();
            if (partial != null) getSharedPreferences(DOWNLOAD_CONTROL, MODE_PRIVATE).edit().remove(partial.getName().replaceFirst("\\.part$", "")).apply();
            if (manager != null) manager.cancel(notificationId);
            if (!"Download deleted".equals(error.getMessage())) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Download failed: " + error.getMessage(), Toast.LENGTH_LONG).show());
            }
        } finally { if (output != null) try { output.close(); } catch (Exception ignored) {} if (connection != null) connection.disconnect(); }
    }

    private void createDownloadChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager manager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            if (manager.getNotificationChannel(DOWNLOAD_CHANNEL) == null) manager.createNotificationChannel(new NotificationChannel(DOWNLOAD_CHANNEL, "Video downloads", NotificationManager.IMPORTANCE_LOW));
        }
    }

    private void postDownloadNotification(NotificationManager manager, int id, String title, int progressValue, boolean complete, boolean indeterminate) {
        if (manager == null) return;
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, DOWNLOAD_CHANNEL) : new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle(complete ? "Download complete" : "Downloading video")
                .setContentText(title).setOnlyAlertOnce(true).setOngoing(!complete).setAutoCancel(complete);
        if (!complete) builder.setProgress(100, progressValue, indeterminate);
        else builder.setProgress(0, 0, false); // clear the active progress meter on completion
        manager.notify(id, builder.build());
    }

    private void saveDownloadProgress(String key, String title, String thumbnail, String channel, int percent, boolean complete) {
        try {
            JSONObject item = new JSONObject(); item.put("title", title); item.put("thumbnail", thumbnail == null ? "" : thumbnail);
            item.put("channel", channel == null ? "" : channel); item.put("progress", percent); item.put("complete", complete);
            item.put("updated", System.currentTimeMillis());
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(key, item.toString()).apply();
        } catch (Exception ignored) {}
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request,result,data);
        if(request==FILE_REQUEST && fileCallback!=null) { fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result,data)); fileCallback=null; }
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingIntent(intent);
    }

    /**
     * Handles both notification taps and verified Android App Links.
     * A destination is held until sign-in completes instead of dropping the user at Home.
     */
    private void handleIncomingIntent(Intent intent) {
        if (intent == null) return;
        String destination = intent.getStringExtra(EXTRA_NOTIFICATION_URL);
        if (destination == null || destination.trim().isEmpty()) destination = intent.getStringExtra("target_url");
        if (destination == null || destination.trim().isEmpty()) destination = intent.getStringExtra("url");
        if (destination == null || destination.trim().isEmpty()) destination = intent.getStringExtra("link");
        if (destination == null || destination.trim().isEmpty()) {
            Uri data = intent.getData();
            if (Intent.ACTION_VIEW.equals(intent.getAction()) && data != null) {
                destination = data.toString();
            }
        }
        intent.removeExtra(EXTRA_NOTIFICATION_URL);
        if (!isAllowedPhiskDestination(destination)) return;

        boolean signedIn = getSharedPreferences(AUTH_PREFS, MODE_PRIVATE)
                .getBoolean("signed_in", false);
        if (signedIn && web != null) {
            showWebsite(destination);
        } else {
            getSharedPreferences(AUTH_PREFS, MODE_PRIVATE).edit()
                    .putString("pending_destination_url", destination)
                    .apply();
            showWelcome();
        }
    }

    private boolean isAllowedPhiskDestination(String value) {
        try {
            Uri uri = Uri.parse(value);
            String host = uri.getHost();
            return "https".equalsIgnoreCase(uri.getScheme()) && host != null
                    && (host.equalsIgnoreCase("phisk.co")
                    || host.toLowerCase(Locale.US).endsWith(".phisk.co"));
        } catch (Exception ignored) {
            return false;
        }
    }

    /** Reads the new pending key and migrates the earlier notification-only key. */
    private String consumePendingDestination() {
        android.content.SharedPreferences prefs = getSharedPreferences(AUTH_PREFS, MODE_PRIVATE);
        String pending = prefs.getString("pending_destination_url", null);
        if (pending == null || pending.trim().isEmpty()) {
            pending = prefs.getString("pending_notification_url", null);
        }
        prefs.edit().remove("pending_destination_url").remove("pending_notification_url").apply();
        return isAllowedPhiskDestination(pending) ? pending : null;
    }

    @Override public void onBackPressed() { if(authRoot!=null && authRoot.getParent()!=null) { if(getSharedPreferences(AUTH_PREFS,MODE_PRIVATE).getBoolean("signed_in",false)) openNativeHome(); else showWelcome(); } else if(web.canGoBack()) web.goBack(); else if(getSharedPreferences(AUTH_PREFS,MODE_PRIVATE).getBoolean("signed_in",false)) openNativeHome(); else showWelcome(); }
    @Override protected void onDestroy() { downloadExecutor.shutdown(); authExecutor.shutdown(); web.destroy(); super.onDestroy(); }
}