Version 1.12.2: Adds HTTPS-only native Android authentication REST endpoints for login, registration, password reset, current-user lookup and logout. Uses standard WordPress accounts and authentication cookies, preserves existing user_register hooks, and applies per-IP rate limits. Google authentication is not enabled.



= 1.12.6 =
* Fixed reply notification thumbnails: reply notifications now use the related video thumbnail or the first Story gallery image instead of a blank placeholder.
* Added secure revocable native-app bearer sessions (30-day expiry) alongside existing WordPress cookie authentication.
* Added native app device-registration storage and authenticated register/unregister API endpoints in preparation for Firebase Cloud Messaging.
* Added notification deletion API and thumbnail_url to the native notifications API response.
* Existing notification types, preferences, inbox records, and website pages remain unchanged. Firebase push sending is not enabled in this release; that is Stage 2.


= 1.12.7 =
* Added administrator User Strikes management with strike history, categories, reasons, revocation, and an audit trail.
* Added rolling 90-day strike expiry and automatic daily enforcement.
* Two active strikes pause monetization and stop new creator earnings; monetization is restored when the active count falls below two, subject to other restrictions.
* Three active strikes disable creator-channel access and video/Story publishing while preserving the channel and content data; channel access is restored when the active count falls below three.
* Added an Account Standing page and user appeals, with administrator review and automatic inbox messages for strikes, restrictions, expirations, appeals, and reinstatement.
* Existing administration-to-user messaging, notification types, and website inbox functionality are retained.


= 1.12.8 =
* Fixed administration message body layout in the Messages inbox. Message text now uses the full available width on mobile and desktop, wraps at word boundaries, and no longer collapses into a narrow vertical column.

= 1.13.4 =
* Adds Firebase Cloud Messaging HTTP v1 server integration.
* Adds administrator Firebase service-account path setting and authentication-only connection test.
* Sends push alerts after in-app notifications are stored, to the user's registered Android devices.
* Removes invalid/unregistered device tokens when Firebase reports them as unregistered.
* Service-account JSON contents and FCM tokens are never displayed in the admin UI.

Security: place the Firebase Admin SDK JSON outside the public web root, restrict it to file permission 600, and configure its absolute path under Settings > Phisk FCM. Run the connection test before relying on push delivery.

= 1.13.6 =
* Added an administrator-only FCM test-send form under Settings > Phisk FCM.
* Allows a test push to one selected registered device without exposing its FCM token.
* Reports Firebase acceptance or API errors; administrators must still confirm actual display on the device.


= 1.15.0 =
* Added authenticated native Creator Channel REST endpoints for creator profile details, paginated published videos, paginated published Stories, and subscribe/unsubscribe.
* Reuses the existing channel metadata, profile/cover attachments, phisk_following subscription list, and phisk_subscriber_count values.
* Story results are limited to published posts created through the Phisk Story composer (gallery metadata present).
* Added owner and subscription state to creator profile responses for native UI decisions.
* No separate channel or subscription data store is introduced.


= 1.16.0 =
* Added authenticated native Creator Studio dashboard API using existing creator metrics, genuine views, analytics ledger, monetization eligibility, payout ledger and top videos.
* Added native monetization application and payout request endpoints enforcing the existing website rules and restrictions.
* Existing website Creator Studio, authentication, and creator workflows remain available and unchanged.

= 1.17.0 =
* Added authenticated native Android video upload, draft details, thumbnail upload and publishing REST endpoints.
* Reuses existing Publit.io configuration or WordPress media storage, `phisk_video` records, creator-channel checks, publishing-strike restrictions and 16:9/21:9 landscape validation.
* Preserves the existing video metadata, thumbnail and WordPress publication hooks.


= 1.18.0 =
* Added authenticated native Story creation APIs for loading existing Story interests, uploading creator-owned Story images, and saving drafts or submitting Stories.
* Native Story publishing reuses the existing WordPress post model, phisk_interest taxonomy, gallery metadata, featured cover image, creator-channel checks, account-strike restrictions, automatic approval setting, and normal WordPress publication hooks.
* Existing website Story creation and native video upload APIs remain unchanged.
