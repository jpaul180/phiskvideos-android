# Native Story Creation API (Phisk Video Manager 1.18.0)

All endpoints require the authenticated Android bearer session over HTTPS and an active creator channel. Publishing endpoints enforce existing account-strike restrictions.

## 1. Load Story interests

`GET /wp-json/phisk/v1/creator-studio/story-interests`

Returns the existing `phisk_interest` terms as `{ interests: [{ id, name }] }`.

## 2. Upload a Story image

`POST /wp-json/phisk/v1/creator-studio/stories/images`

Multipart field: `image`. Accepted formats: JPG, PNG, WebP and GIF. The image is stored in the existing WordPress media library and assigned to the authenticated creator. The response includes its attachment `id`, `url` and `full` URL. Upload images individually; preserve the returned IDs for the publish request.

## 3. Save a draft or submit a Story

`POST /wp-json/phisk/v1/creator-studio/stories/publish`

JSON body:
- `title` — required, maximum 100 characters
- `content` — required Story text
- `excerpt` — optional short introduction
- `interest_id` — required existing `phisk_interest` term ID
- `image_ids` — required array of image attachment IDs uploaded by the authenticated creator
- `action` — `draft` to save a draft, or `submit` to submit for review / automatic publication

The endpoint reuses the existing WordPress `post` Story model, `phisk_interest` taxonomy, `_phisk_article_short_intro` and `_phisk_article_gallery_ids` metadata, and first-image featured cover. Drafts remain `draft`. Submitted Stories become `pending` unless the existing Story automatic-approval setting is enabled, in which case they are published. Normal WordPress publication hooks and notifications remain in effect.

The native app uploads selected images first, then submits their IDs with the Story details. A failed submission can be retried without re-uploading images already accepted during the current composer session.
