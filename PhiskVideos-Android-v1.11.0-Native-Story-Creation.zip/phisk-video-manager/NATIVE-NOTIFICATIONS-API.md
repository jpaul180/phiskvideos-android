# PhiskVideos Native Notifications API — Stage 1 (Video Manager 1.12.6)

All requests must use HTTPS. Base URL: `https://videos.phisk.co/wp-json/phisk/v1/`.

## Authentication

The existing `/app-auth/login` and `/app-auth/register` endpoints continue to set normal WordPress cookies. They now also return a revocable app bearer token:

```json
{
  "success": true,
  "token_type": "Bearer",
  "access_token": "<64-character-random-token>",
  "expires_in": 2592000,
  "user": { "id": 123, "username": "...", "name": "...", "email": "..." }
}
```

Pass the token on native API requests using `Authorization: Bearer <access_token>`. Tokens expire after 30 days. Logout revokes the current bearer session. Browser users may continue using WordPress cookie authentication. Never log or expose bearer tokens.

The app should send a stable per-installation `device_id` with login/register. This allows logout to remove the device registration belonging to that installation. Older clients that omit `device_id` remain compatible, but should be updated before push delivery is enabled.

## Notifications

- `GET /notifications?page=1&per_page=20` — returns the signed-in user's inbox, unread count and `thumbnail_url` for each notification. Reply notifications resolve the comment to its parent content and use the video thumbnail or first Story gallery image.
- `POST /notifications/read` JSON `{ "id": 123 }` — mark one of the current user's notifications as read.
- `POST /notifications/read-all` — mark all inbox-enabled notifications as read.
- `POST /notifications/delete` JSON `{ "id": 123 }` — delete only a notification owned by the signed-in user.
- `GET /notification-preferences` — read existing preferences.
- `POST /notification-preferences` — update the existing supported preference keys.

## Device registration (FCM sending is Stage 2)

- `POST /app-devices/register` JSON `{ "fcm_token": "...", "device_id": "stable-install-id", "platform": "android", "app_version": "1.3.x" }` — securely associates an FCM registration token with the authenticated account and installation. Registering an existing token again updates its account/device association.
- `POST /app-devices/unregister` JSON `{ "device_id": "stable-install-id" }` or `{ "fcm_token": "..." }` — removes only the current user's matching device registration.

The device table is prepared in Stage 1. This release does not contact Firebase or send push notifications. Firebase credentials, event dispatch and delivery handling are Stage 2.

## Messages assessment

The existing `/messages` and `/messages/read` routes expose the current administration-to-user inbox. They do not implement user-to-user conversations, message sending, attachments or conversation threads. Stage 1 intentionally preserves this existing functionality; native messaging design must account for that distinction before Stage 4.

## Native Google sign-in session bridge (v1.13.5)
When Phisk Auth v1.2.7 is active alongside this plugin, its verified Firebase Google login response is passed through the `phisk_mobile_google_login_response` filter. This plugin adds the same revocable 30-day `access_token`, `token_type`, and `expires_in` fields returned by `/app-auth/login` and `/app-auth/register`. The Android app requires this token before marking Google sign-in complete or registering an FCM device. Browser Google login is unchanged.
