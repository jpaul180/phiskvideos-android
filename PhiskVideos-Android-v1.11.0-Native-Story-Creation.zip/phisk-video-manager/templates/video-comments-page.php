<?php
if (!defined('ABSPATH')) exit;
$video_id = get_queried_object_id();
get_header();
?>
<div class="phisk-comments-page-shell">
  <?php if (isset($GLOBALS['phiskvideos_movie_tv_instance'])) echo $GLOBALS['phiskvideos_movie_tv_instance']->video_comments_markup($video_id); ?>
</div>
<?php get_footer(); ?>
