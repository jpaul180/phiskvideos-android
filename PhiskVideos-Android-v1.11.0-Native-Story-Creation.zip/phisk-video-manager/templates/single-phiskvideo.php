<?php
if (!defined('ABSPATH')) exit;
get_header();
while (have_posts()) : the_post();
$id = get_the_ID();
$type = get_post_type();
$is_video = $type === 'phisk_video';
$year = get_post_meta($id, 'phisk_year', true);
$country = get_post_meta($id, 'phisk_country', true);
$runtime = get_post_meta($id, 'phisk_runtime', true);
$age = get_post_meta($id, 'phisk_age_rating', true);
$watch_url = get_post_meta($id, 'phisk_watch_url', true);
$watch_label = get_post_meta($id, 'phisk_watch_label', true);
$genres = get_the_terms($id, $is_video ? 'phisk_video_genre' : 'phisk_genre');
$poster = get_the_post_thumbnail_url($id, 'large');
?>
<main class="phisk-single-shell">
  <article class="phisk-single <?php echo $is_video ? 'phisk-single-video' : ''; ?>">
    <?php if ($is_video && isset($GLOBALS['phiskvideos_movie_tv_instance']) && method_exists($GLOBALS['phiskvideos_movie_tv_instance'], 'video_publish_success_markup')) : ?>
      <?php echo $GLOBALS['phiskvideos_movie_tv_instance']->video_publish_success_markup($id); ?>
    <?php endif; ?>
    <?php if ($is_video) : ?>
      <div class="phisk-video-player-dock">
        <div class="phisk-video-player-wrap">
          <?php if (isset($GLOBALS['phiskvideos_movie_tv_instance'])) : ?>
            <?php echo $GLOBALS['phiskvideos_movie_tv_instance']->video_player_markup($id); ?>
          <?php endif; ?>
        </div>
      </div>
      <div class="phisk-video-player-spacer" aria-hidden="true"></div>

      <header class="phisk-video-watch-header">
        <?php $phisk_video_title = get_post_field('post_title', $id); ?>
        <h1 class="phisk-video-title" aria-label="<?php echo esc_attr($phisk_video_title); ?>"><?php echo esc_html($phisk_video_title); ?></h1>
        <div class="phisk-video-author-row">
          <?php $phisk_video_author_id = (int) get_post_field('post_author', $id); ?>
          <?php
          $phisk_video_author_avatar_id = $phisk_video_author_id ? absint(get_user_meta($phisk_video_author_id, 'phisk_profile_image_id', true)) : 0;
          $phisk_video_author_avatar = $phisk_video_author_avatar_id ? wp_get_attachment_image_url($phisk_video_author_avatar_id, 'thumbnail') : '';
          if (!$phisk_video_author_avatar && $phisk_video_author_id) {
              $phisk_video_author_avatar = get_avatar_url($phisk_video_author_id, ['size' => 96]);
          }
          ?>
          <div class="phisk-video-author-identity">
            <?php if (isset($GLOBALS['phiskvideos_movie_tv_instance']) && $phisk_video_author_id) : ?>
              <a class="phisk-video-author-avatar" href="<?php echo esc_url($GLOBALS['phiskvideos_movie_tv_instance']->phisk_channel_url($phisk_video_author_id)); ?>" aria-label="View <?php echo esc_attr($GLOBALS['phiskvideos_movie_tv_instance']->phisk_creator_display_name($phisk_video_author_id)); ?>'s channel"><img src="<?php echo esc_url($phisk_video_author_avatar); ?>" alt="<?php echo esc_attr($GLOBALS['phiskvideos_movie_tv_instance']->phisk_creator_display_name($phisk_video_author_id)); ?>"></a>
            <?php else : ?>
              <div class="phisk-video-author-avatar" aria-hidden="true"><?php echo esc_html(strtoupper(function_exists('mb_substr') ? mb_substr($GLOBALS['phiskvideos_movie_tv_instance']->phisk_creator_display_name($phisk_video_author_id), 0, 1) : substr($GLOBALS['phiskvideos_movie_tv_instance']->phisk_creator_display_name($phisk_video_author_id), 0, 1))); ?></div>
            <?php endif; ?>
            <div class="phisk-video-author">
              <span class="phisk-video-author-label">By</span>
              <strong><a class="phisk-video-author-name" href="<?php echo esc_url($GLOBALS['phiskvideos_movie_tv_instance']->phisk_channel_url($phisk_video_author_id)); ?>"><?php echo esc_html($GLOBALS['phiskvideos_movie_tv_instance']->phisk_creator_display_name($phisk_video_author_id)); ?></a></strong>
            </div>
          </div>
          <?php if (isset($GLOBALS['phiskvideos_movie_tv_instance'])) : ?>
            <div class="phisk-video-subscribe-wrap">
              <?php echo $GLOBALS['phiskvideos_movie_tv_instance']->phisk_subscribe_button((int) get_post_field('post_author', $id)); ?>
            </div>
          <?php endif; ?>
        </div>
        <?php if (get_post_meta($id, '_phisk_video_provider', true) === 'youtube_embed') : ?>
          <?php $phisk_youtube_id = (string)get_post_meta($id, '_phisk_youtube_video_id', true); ?>
          <?php if (preg_match('/^[A-Za-z0-9_-]{11}$/', $phisk_youtube_id)) : ?>
            <div class="phisk-youtube-watch-wrap"><a class="phisk-youtube-watch-button" href="<?php echo esc_url('https://www.youtube.com/watch?v=' . $phisk_youtube_id); ?>" target="_blank" rel="noopener noreferrer"><span aria-hidden="true">▶</span> Watch on YouTube <span aria-hidden="true">↗</span></a></div>
          <?php endif; ?>
        <?php endif; ?>
        <?php if (isset($GLOBALS['phiskvideos_movie_tv_instance'])) : ?>
          <div class="phisk-video-action-row">
            <?php echo $GLOBALS['phiskvideos_movie_tv_instance']->video_engagement_markup($id, 'single'); ?>
          </div>
        <?php endif; ?>
      </header>

      <section class="phisk-video-description">
        <?php if ($genres && !is_wp_error($genres)) : ?><div class="phisk-video-meta"><span><?php echo esc_html(implode(', ', wp_list_pluck($genres, 'name'))); ?></span><?php if ($year) : ?><span><?php echo esc_html($year); ?></span><?php endif; ?><?php if ($runtime) : ?><span><?php echo esc_html($runtime); ?></span><?php endif; ?></div><?php endif; ?>
        <div class="phisk-plot-content"><?php the_content(); ?></div>
      </section>

      <?php if (isset($GLOBALS['phiskvideos_movie_tv_instance'])) : ?>
        <?php echo $GLOBALS['phiskvideos_movie_tv_instance']->video_comments_markup($id); ?>
      <?php endif; ?>

      <?php
      $related_videos = [];
      if (isset($GLOBALS['phiskvideos_movie_tv_instance'])) {
          $related_videos = $GLOBALS['phiskvideos_movie_tv_instance']->watch_also_videos($id);
      }
      ?>
      <?php if (!empty($related_videos)) : ?>
        <section class="phisk-watch-also phisk-video-related-section">
          <h2>Related Videos</h2>
          <div class="phisk-feed phisk-grid phisk-feed-phisk_video">
            <?php foreach ($related_videos as $item) : ?>
              <a class="phisk-card" href="<?php echo esc_url($item['permalink']); ?>">
                <div class="phisk-card-image">
                  <?php if ($item['poster']) : ?><img loading="lazy" src="<?php echo esc_url($item['poster']); ?>" alt="<?php echo esc_attr($item['title']); ?>"><?php else : ?><span class="phisk-poster-placeholder">PHISKVIDEOS</span><?php endif; ?>
                  <span class="phisk-card-shade"></span>
                </div>
                <div class="phisk-card-info">
                  <h3><?php echo esc_html($item['title']); ?></h3>
                  <div class="phisk-card-meta"><?php if ($item['year']) : ?><span><?php echo esc_html($item['year']); ?></span><?php endif; ?><?php if ($item['genres'] && !is_wp_error($item['genres'])) : ?><span><?php echo esc_html($item['genres'][0]->name); ?></span><?php endif; ?></div>
                </div>
              </a>
            <?php endforeach; ?>
          </div>
        </section>
      <?php endif; ?>
    <?php else : ?>
      <header class="phisk-single-header">
        <p class="phisk-kicker"><?php echo $type === 'phisk_tvshow' ? 'TV SHOW' : 'MOVIE'; ?></p>
        <h1><?php the_title(); ?></h1>
      </header>

      <section class="phisk-single-overview">
        <div class="phisk-single-poster">
          <?php if ($poster) : ?><img src="<?php echo esc_url($poster); ?>" alt="<?php echo esc_attr(get_the_title()); ?>"><?php else : ?><div class="phisk-poster-placeholder">PHISKVIDEOS</div><?php endif; ?>
        </div>
        <div class="phisk-single-details">
          <?php if ($genres && !is_wp_error($genres)) : ?><div class="phisk-detail"><span>Genre</span><strong><?php echo esc_html(implode(', ', wp_list_pluck($genres, 'name'))); ?></strong></div><?php endif; ?>
          <?php if ($year) : ?><div class="phisk-detail"><span>Year</span><strong><?php echo esc_html($year); ?></strong></div><?php endif; ?>
          <?php if ($country) : ?><div class="phisk-detail"><span>Country</span><strong><?php echo esc_html($country); ?></strong></div><?php endif; ?>
          <?php if ($runtime) : ?><div class="phisk-detail"><span>Runtime</span><strong><?php echo esc_html($runtime); ?></strong></div><?php endif; ?>
          <?php if ($age) : ?><div class="phisk-detail"><span>Age Restriction</span><strong><?php echo esc_html($age); ?></strong></div><?php endif; ?>
          <?php if ($watch_url) : ?><a class="phisk-watch-button" href="<?php echo esc_url($watch_url); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($watch_label ?: 'Watch Now'); ?> <span aria-hidden="true">↗</span></a><?php endif; ?>
        </div>
      </section>

      <section class="phisk-plot"><h2>Plot</h2><div class="phisk-plot-content"><?php the_content(); ?></div></section>
    <?php endif; ?>

    <?php if (!$is_video) : ?>
      <?php
      $cast = get_post_meta($id, 'phisk_cast', true);
      $crew = get_post_meta($id, 'phisk_crew', true);
      $normalize_people = static function ($people) {
          if (!is_array($people)) return [];
          if (isset($people['name']) || isset($people['role']) || isset($people['photo']) || isset($people['person_id'])) $people = [$people];
          $normalized = [];
          foreach ($people as $person) {
              if (!is_array($person)) continue;
              $person_id = isset($person['person_id']) ? absint($person['person_id']) : 0;
              if ($person_id) {
                  $person_post = get_post($person_id);
                  if ($person_post && $person_post->post_type === 'phisk_person') {
                      $person['name'] = $person_post->post_title;
                      $thumb = get_the_post_thumbnail_url($person_id, 'thumbnail');
                      if ($thumb) $person['photo'] = $thumb;
                      elseif (empty($person['photo'])) $person['photo'] = get_post_meta($person_id, 'phisk_person_photo', true);
                  }
              }
              $normalized[] = $person;
          }
          return array_values($normalized);
      };
      $cast = $normalize_people($cast); $crew = $normalize_people($crew);
      $people_initials = static function ($name) { $parts=preg_split('/\s+/',trim((string)$name)); $initials=''; foreach($parts as $part){if($part!=='')$initials.=function_exists('mb_substr')?mb_substr($part,0,1):substr($part,0,1);if(strlen($initials)>=2)break;} return strtoupper($initials?:'P'); };
      ?>
      <?php if (!empty($cast) || !empty($crew)) : ?>
        <section class="phisk-cast-crew">
          <?php foreach (['cast'=>'Cast','crew'=>'Crew'] as $people_key=>$people_label) : $people=$$people_key; if(empty($people)) continue; ?>
            <div class="phisk-people-section">
              <h2><?php echo esc_html($people_label); ?></h2>
              <div class="phisk-people-grid">
                <?php foreach ($people as $person) : $name=trim((string)($person['name']??'')); $role=trim((string)($person['role']??'')); $photo=trim((string)($person['photo']??'')); if($name===''&&$role==='')continue; ?>
                  <div class="phisk-person-card"><div class="phisk-person-avatar"><?php if($photo): ?><img loading="lazy" src="<?php echo esc_url($photo); ?>" alt="<?php echo esc_attr($name); ?>"><?php else: ?><span><?php echo esc_html($people_initials($name)); ?></span><?php endif; ?></div><div class="phisk-person-info"><?php if($name): ?><strong><?php echo esc_html($name); ?></strong><?php endif; ?><?php if($role): ?><span><?php echo esc_html($role); ?></span><?php endif; ?></div></div>
                <?php endforeach; ?>
              </div>
            </div>
          <?php endforeach; ?>
        </section>
      <?php endif; ?>
    <?php endif; ?>

    <?php if (!$is_video) : ?>
      <?php
      $related = [];
      $related_heading = 'Watch Also';
      if (isset($GLOBALS['phiskvideos_movie_tv_instance'])) {
          if ($type === 'phisk_movie') $related = $GLOBALS['phiskvideos_movie_tv_instance']->watch_also_movies($id);
      }
      ?>
      <?php if (!empty($related)) : ?>
        <section class="phisk-watch-also"><h2><?php echo esc_html($related_heading); ?></h2><div class="phisk-feed phisk-carousel">
          <?php foreach ($related as $item) : ?><a class="phisk-card" href="<?php echo esc_url($item['permalink']); ?>"><div class="phisk-card-image"><?php if($item['poster']): ?><img loading="lazy" src="<?php echo esc_url($item['poster']); ?>" alt="<?php echo esc_attr($item['title']); ?>"><?php else: ?><span class="phisk-poster-placeholder">PHISKVIDEOS</span><?php endif; ?><span class="phisk-card-shade"></span></div><div class="phisk-card-info"><h3><?php echo esc_html($item['title']); ?></h3><div class="phisk-card-meta"><?php if($item['year']): ?><span><?php echo esc_html($item['year']); ?></span><?php endif; ?><?php if($item['genres']&&!is_wp_error($item['genres'])): ?><span><?php echo esc_html($item['genres'][0]->name); ?></span><?php endif; ?></div></div></a><?php endforeach; ?>
        </div></section>
      <?php endif; ?>
    <?php endif; ?>
  </article>
</main>
<?php endwhile; get_footer(); ?>
