# PhiskVideos native app authentication API (Video Manager 1.12.2)

All requests must use HTTPS. Base URL: `https://videos.phisk.co/wp-json/phisk/v1/app-auth/`.

## Login
`POST login` JSON: `{ "username": "email-or-username", "password": "..." }`

## Register
`POST register` JSON: `{ "name": "Full Name", "username": "public-login", "email": "user@example.com", "password": "at-least-10-characters" }`.
WordPress Settings > General > Membership must allow anyone to register. The endpoint uses normal WordPress user creation and the site's existing `user_register` hooks.

## Password reset
`POST password-reset` JSON: `{ "login": "email-or-username" }`. WordPress sends the normal password-reset email.

## Current session
`GET me` requires the WordPress authentication cookie established by login/register.

## Logout
`POST logout` requires the authenticated WordPress cookie.

Login/register responses set the standard WordPress authentication cookies. The Android client must persist the `Set-Cookie` values in Android `CookieManager` for `https://videos.phisk.co` before loading the site in its WebView. Do not store the password after authentication. Google OAuth is intentionally not implemented in this version; the app may show a disabled “Coming soon” button.

The public endpoints are rate-limited to 10 attempts per action/IP per 15 minutes and reject non-HTTPS requests. Never log submitted passwords.
