/* Phisk reusable Cast & Crew editor. */
jQuery(function ($) {
    'use strict';
    var personCounter = 0;
    var searchTimers = new WeakMap();

    function makeRow(type) {
        var roleLabel = type === 'cast' ? 'Character' : 'Role';
        var index = 'new_' + Date.now() + '_' + (++personCounter);
        var html = '' +
            '<div class="phisk-person-row" data-index="' + index + '">' +
              '<div class="phisk-person-fields">' +
                '<div class="phisk-person-picker">' +
                  '<input class="widefat phisk-person-search" type="text" autocomplete="off" placeholder="Search existing person by name...">' +
                  '<input type="hidden" class="phisk-person-id" name="phisk_' + type + '[' + index + '][person_id]" value="">' +
                  '<input type="hidden" class="phisk-person-photo" name="phisk_' + type + '[' + index + '][photo]" value="">' +
                  '<div class="phisk-person-results" style="display:none"></div>' +
                  '<div class="phisk-selected-person">Type at least 2 letters to search, or create a new person.</div>' +
                  '<button type="button" class="button phisk-create-person">+ Create New Person</button>' +
                '</div>' +
                '<input class="widefat" type="text" name="phisk_' + type + '[' + index + '][role]" placeholder="' + roleLabel + '">' +
                '<div class="phisk-photo-field">' +
                  '<button type="button" class="button phisk-person-photo-button">Select Photo</button>' +
                  '<button type="button" class="button-link-delete phisk-remove-person">Remove</button>' +
                  '<div class="phisk-photo-preview"></div>' +
                '</div>' +
              '</div>' +
            '</div>';
        return $(html);
    }

    // Use delegated events so the buttons work for both existing and newly created rows.
    $(document).on('click', '.phisk-add-person', function (event) {
        event.preventDefault();
        var button = $(this);
        var type = button.attr('data-people-type');
        var list = button.siblings('.phisk-people-list').first();
        if (!list.length) list = button.prevAll('.phisk-people-list').first();
        if (!list.length || (type !== 'cast' && type !== 'crew')) {
            window.console && console.error('Phisk: Could not find the ' + type + ' list for the Add button.');
            return;
        }
        list.append(makeRow(type));
    });

    $(document).on('click', '.phisk-remove-person', function (event) {
        event.preventDefault();
        $(this).closest('.phisk-person-row').remove();
    });

    $(document).on('input', '.phisk-person-search', function () {
        var input = $(this);
        var query = $.trim(input.val());
        var box = input.siblings('.phisk-person-results');
        var previousTimer = searchTimers.get(this);
        if (previousTimer) clearTimeout(previousTimer);
        if (query.length < 2) { box.hide().empty(); return; }
        var timer = setTimeout(function () {
            $.post(PhiskPeople.ajaxurl, {
                action: 'phisk_search_people', nonce: PhiskPeople.nonce, q: query
            }).done(function (response) {
                box.empty();
                if (!response || !response.success || !Array.isArray(response.data) || !response.data.length) {
                    box.text('No existing person found.').show();
                    return;
                }
                response.data.forEach(function (person) {
                    var item = $('<button type="button" class="phisk-person-result"></button>')
                        .css({display:'block',width:'100%',textAlign:'left',background:'#fff',border:0})
                        .attr('data-id', person.id)
                        .attr('data-name', person.name)
                        .attr('data-photo', person.photo || '')
                        .text(person.name + (person.photo ? '' : ' (no photo)'));
                    box.append(item);
                });
                box.show();
            }).fail(function () { box.text('Could not search People. Please try again.').show(); });
        }, 250);
        searchTimers.set(this, timer);
    });

    $(document).on('click', '.phisk-person-result[data-id]', function (event) {
        event.preventDefault();
        var result = $(this);
        var row = result.closest('.phisk-person-row');
        var name = result.attr('data-name') || '';
        var photo = result.attr('data-photo') || '';
        row.find('.phisk-person-id').val(result.attr('data-id'));
        row.find('.phisk-person-search').val(name);
        row.find('.phisk-person-photo').val(photo);
        row.find('.phisk-selected-person').text('Selected: ' + name);
        row.find('.phisk-person-results').hide().empty();
        row.find('.phisk-photo-preview').empty();
        if (photo) {
            $('<img>').attr('src', photo).attr('alt', '').css({maxWidth:'60px',height:'60px',objectFit:'cover',borderRadius:'50%',display:'block',marginTop:'6px'}).appendTo(row.find('.phisk-photo-preview'));
            row.find('.phisk-person-photo-button').text('Change Photo');
        } else {
            row.find('.phisk-person-photo-button').text('Select Photo');
        }
    });

    function createPerson(name, photo, photoId, row) {
        if (row.data('creating')) return;
        row.data('creating', true);
        $.post(PhiskPeople.ajaxurl, {
            action: 'phisk_create_person', nonce: PhiskPeople.nonce,
            name: name, photo: photo || '', photo_id: photoId || 0
        }).done(function (response) {
            if (!response || !response.success) {
                alert((response && response.data) || 'Could not create person.');
                return;
            }
            var person = response.data;
            row.find('.phisk-person-id').val(person.id);
            row.find('.phisk-person-search').val(person.name);
            row.find('.phisk-person-photo').val(person.photo || '');
            row.find('.phisk-selected-person').text('Selected: ' + person.name);
            row.find('.phisk-photo-preview').empty();
            if (person.photo) $('<img>').attr('src', person.photo).attr('alt', '').css({maxWidth:'60px',height:'60px',objectFit:'cover',borderRadius:'50%',display:'block',marginTop:'6px'}).appendTo(row.find('.phisk-photo-preview'));
            row.find('.phisk-person-photo-button').text(person.photo ? 'Change Photo' : 'Select Photo');
        }).fail(function () { alert('Could not connect to the People database. Please try again.'); })
          .always(function () { row.data('creating', false); });
    }

    $(document).on('click', '.phisk-create-person', function (event) {
        event.preventDefault();
        var row = $(this).closest('.phisk-person-row');
        var name = window.prompt("Enter the person's full name:");
        if (!name || !$.trim(name)) return;
        name = $.trim(name);
        var frame = wp.media({title:'Select Person Photo (optional)',button:{text:'Use Photo'},multiple:false,library:{type:'image'}});
        var completed = false;
        frame.on('select', function () {
            var attachment = frame.state().get('selection').first().toJSON();
            completed = true;
            createPerson(name, attachment.url, attachment.id, row);
        });
        frame.on('close', function () {
            if (!completed) { completed = true; createPerson(name, '', 0, row); }
        });
        frame.open();
    });

    $(document).on('click', '.phisk-person-photo-button', function (event) {
        event.preventDefault();
        var button = $(this), row = button.closest('.phisk-person-row');
        var personId = row.find('.phisk-person-id').val();
        var frame = wp.media({title:'Select Person Photo',button:{text:'Use Photo'},multiple:false,library:{type:'image'}});
        frame.on('select', function () {
            var attachment = frame.state().get('selection').first().toJSON();
            row.find('.phisk-person-photo').val(attachment.url);
            row.find('.phisk-photo-preview').empty();
            $('<img>').attr('src', attachment.url).attr('alt', '').css({maxWidth:'60px',height:'60px',objectFit:'cover',borderRadius:'50%',display:'block',marginTop:'6px'}).appendTo(row.find('.phisk-photo-preview'));
            button.text('Change Photo');
            if (personId) {
                $.post(PhiskPeople.ajaxurl, {action:'phisk_create_person',nonce:PhiskPeople.nonce,name:row.find('.phisk-person-search').val(),photo:attachment.url,photo_id:attachment.id,person_id:personId});
            }
        });
        frame.open();
    });

    $(document).on('click', function (event) {
        if (!$(event.target).closest('.phisk-person-picker').length) $('.phisk-person-results').hide();
    });
});
