(function($){
    'use strict';

    // Native-app-only video downloads. The native app asks WordPress for the
    // authorised file URL using the current WebView login cookie and nonce.
    function initPhiskAppDownloads() {
        if (!window.PhiskApp || typeof window.PhiskApp.downloadVideo !== 'function') return;
        $('.phisk-video-download-button').prop('hidden', false);
    }
    $(initPhiskAppDownloads);
    $(document).on('click.phiskNativeDownloads', 'a[href*="/downloads"]', function(e){
        if (!window.PhiskApp || typeof window.PhiskApp.openDownloads !== 'function') return;
        var link = document.createElement('a');
        try { if (new URL(this.href, window.location.href).pathname.replace(/\/+$/, '') !== '/downloads') return; } catch(err) { return; }
        e.preventDefault(); e.stopPropagation(); window.PhiskApp.openDownloads();
    });
    $(document).off('click.phiskVideoDownload', '.phisk-video-download-button').on('click.phiskVideoDownload', '.phisk-video-download-button', function (event) {
        event.preventDefault(); event.stopPropagation();
        var $button = $(this), videoId = parseInt($button.attr('data-video-id'), 10) || 0;
        if (!videoId || !window.PhiskApp || typeof window.PhiskApp.downloadVideo !== 'function' || $button.prop('disabled')) return;
        $button.prop('disabled', true).find('.phisk-download-label').text('Starting…');
        try {
            window.PhiskApp.downloadVideo(videoId, $button.attr('data-nonce') || '', $button.attr('data-filename') || 'phisk-video-' + videoId + '.mp4', $button.attr('data-title') || '', $button.attr('data-thumbnail') || '', $button.attr('data-channel') || '');
            $button.find('.phisk-download-label').text('Download started');
        } catch (error) {
            $button.find('.phisk-download-label').text('Download');
            window.alert('Could not start this download. Please try again.');
        }
        window.setTimeout(function () { $button.prop('disabled', false).find('.phisk-download-label').text('Download'); }, 2500);
    });

    // Channel cover/profile editor: selection, crop preview, real upload progress and success state.
    (function(){
        var modal = document.getElementById('phisk-image-editor-modal');
        if (!modal) return;
        var config = window.PhiskVideosFront || {};
        var fileInput = document.getElementById('phisk-image-editor-file');
        var selectButton = document.getElementById('phisk-image-editor-select');
        var changeButton = document.getElementById('phisk-image-editor-change');
        var uploadButton = document.getElementById('phisk-image-editor-upload');
        var title = document.getElementById('phisk-image-editor-title');
        var guidance = document.getElementById('phisk-image-editor-guidance');
        var illustration = document.getElementById('phisk-image-editor-illustration');
        var workspace = document.getElementById('phisk-image-editor-workspace');
        var crop = document.getElementById('phisk-image-editor-crop');
        var cropImage = document.getElementById('phisk-image-editor-crop-image');
        var zoom = document.getElementById('phisk-image-editor-zoom');
        var progress = document.getElementById('phisk-image-editor-progress');
        var progressBar = progress.querySelector('.phisk-image-editor-progress-track span');
        var progressLabel = progress.querySelector('.phisk-image-editor-progress-meta strong');
        var progressPercent = progress.querySelector('.phisk-image-editor-progress-meta span');
        var success = document.getElementById('phisk-image-editor-success');
        var error = document.getElementById('phisk-image-editor-error');
        var kind = 'cover', image = null, imageUrl = '', zoomValue = 1, centerX = .5, centerY = .5, dragging = false, dragStart = null, busy = false;
        var settings = {
            cover: {title:'Edit Cover Image', guidance:'Recommended: 1500 × 500 px · Landscape image (3:1)', ratio:3, illustration:(config.pluginUrl || '') + 'assets/image-editor-cover.svg'},
            profile: {title:'Edit Profile Image', guidance:'Recommended: 500 × 500 px · Square image (1:1)', ratio:1, illustration:(config.pluginUrl || '') + 'assets/image-editor-profile.svg'}
        };
        function resetState(){
            if (imageUrl) URL.revokeObjectURL(imageUrl);
            image = null; imageUrl = ''; zoomValue = 1; centerX = .5; centerY = .5; zoom.value = '1';
            fileInput.value = ''; workspace.hidden = true; selectButton.hidden = false; illustration.hidden = false;
            progress.hidden = true; success.hidden = true; error.hidden = true; error.textContent = '';
            progressBar.style.width = '0%'; progressPercent.textContent = '0%';
            uploadButton.disabled = false; selectButton.disabled = false; changeButton.disabled = false; busy = false;
        }
        function openEditor(type){
            kind = type === 'profile' ? 'profile' : 'cover'; resetState();
            title.textContent = settings[kind].title; guidance.textContent = settings[kind].guidance;
            illustration.src = settings[kind].illustration; crop.classList.toggle('is-profile', kind === 'profile');
            modal.hidden = false; modal.setAttribute('aria-hidden','false'); document.body.classList.add('phisk-image-editor-open');
            window.setTimeout(function(){ selectButton.focus(); }, 20);
        }
        function closeEditor(){ if (busy) return; modal.hidden = true; modal.setAttribute('aria-hidden','true'); document.body.classList.remove('phisk-image-editor-open'); resetState(); }
        document.addEventListener('click', function(e){
            var trigger = e.target.closest('[data-phisk-open-image-editor]');
            if (trigger) { e.preventDefault(); openEditor(trigger.getAttribute('data-phisk-open-image-editor')); return; }
            if (e.target.closest('[data-phisk-image-close]')) closeEditor();
        });
        document.addEventListener('keydown', function(e){ if (e.key === 'Escape' && !modal.hidden) closeEditor(); });
        selectButton.addEventListener('click', function(){ fileInput.click(); });
        changeButton.addEventListener('click', function(){ fileInput.click(); });
        fileInput.addEventListener('change', function(){
            var file = fileInput.files && fileInput.files[0]; if (!file) return;
            if (!/^image\/(jpeg|png|webp)$/i.test(file.type)) { showError('Please choose a JPG, PNG or WebP image.'); fileInput.value=''; return; }
            var nextUrl = URL.createObjectURL(file), nextImage = new Image();
            nextImage.onload = function(){
                if (imageUrl) URL.revokeObjectURL(imageUrl);
                image = nextImage; imageUrl = nextUrl; zoomValue = 1; centerX = .5; centerY = .5; zoom.value='1';
                cropImage.style.backgroundImage = 'url("' + imageUrl + '")'; updateCrop();
                illustration.hidden = true; selectButton.hidden = true; workspace.hidden = false; error.hidden = true;
            };
            nextImage.onerror = function(){ URL.revokeObjectURL(nextUrl); showError('This image could not be opened. Please choose another.'); };
            nextImage.src = nextUrl;
        });
        function updateCrop(){
            if (!image) return;
            var box = crop.getBoundingClientRect(), ratio = settings[kind].ratio;
            var baseW = box.width, baseH = box.width / ratio;
            if (baseH > box.height) { baseH = box.height; baseW = box.height * ratio; }
            var coverScale = Math.max(box.width / image.naturalWidth, box.height / image.naturalHeight);
            var w = image.naturalWidth * coverScale * zoomValue, h = image.naturalHeight * coverScale * zoomValue;
            var dx = (box.width - w) * centerX, dy = (box.height - h) * centerY;
            dx = Math.min(0, Math.max(box.width - w, dx)); dy = Math.min(0, Math.max(box.height - h, dy));
            cropImage.style.width = w + 'px'; cropImage.style.height = h + 'px'; cropImage.style.left = dx + 'px'; cropImage.style.top = dy + 'px';
            cropImage.style.backgroundSize = '100% 100%';
        }
        zoom.addEventListener('input', function(){ zoomValue = parseFloat(zoom.value) || 1; updateCrop(); });
        crop.addEventListener('pointerdown', function(e){ if (!image || busy) return; dragging=true; dragStart={x:e.clientX,y:e.clientY,dx:parseFloat(cropImage.style.left)||0,dy:parseFloat(cropImage.style.top)||0}; crop.setPointerCapture(e.pointerId); });
        crop.addEventListener('pointermove', function(e){ if (!dragging || !dragStart) return; var box=crop.getBoundingClientRect(), w=parseFloat(cropImage.style.width), h=parseFloat(cropImage.style.height); var left=Math.min(0,Math.max(box.width-w,dragStart.dx+(e.clientX-dragStart.x))); var top=Math.min(0,Math.max(box.height-h,dragStart.dy+(e.clientY-dragStart.y))); cropImage.style.left=left+'px'; cropImage.style.top=top+'px'; centerX=w===box.width?0:(left/(box.width-w)); centerY=h===box.height?0:(top/(box.height-h)); });
        ['pointerup','pointercancel','lostpointercapture'].forEach(function(evt){ crop.addEventListener(evt,function(){dragging=false;dragStart=null;}); });
        window.addEventListener('resize', updateCrop);
        function makeCroppedFile(){
            return new Promise(function(resolve,reject){
                if (!image) return reject(new Error('Choose an image first.'));
                var ratio=settings[kind].ratio, box=crop.getBoundingClientRect();
                var targetW=kind==='cover'?1500:800, targetH=Math.round(targetW/ratio);
                var sourceRatio=image.naturalWidth/image.naturalHeight, cropW, cropH;
                if(sourceRatio>ratio){cropH=image.naturalHeight/zoomValue;cropW=cropH*ratio;}else{cropW=image.naturalWidth/zoomValue;cropH=cropW/ratio;}
                var left=(image.naturalWidth-cropW)*centerX, top=(image.naturalHeight-cropH)*centerY;
                left=Math.max(0,Math.min(image.naturalWidth-cropW,left)); top=Math.max(0,Math.min(image.naturalHeight-cropH,top));
                var canvas=document.createElement('canvas');canvas.width=targetW;canvas.height=targetH;
                var ctx=canvas.getContext('2d');ctx.drawImage(image,left,top,cropW,cropH,0,0,targetW,targetH);
                canvas.toBlob(function(blob){if(!blob)return reject(new Error('The image could not be prepared.'));resolve(blob);},'image/jpeg',.9);
            });
        }
        function showError(message){ error.textContent=message; error.hidden=false; }
        uploadButton.addEventListener('click', function(){
            if (busy || !image) return; busy=true; uploadButton.disabled=true; selectButton.disabled=true; changeButton.disabled=true; error.hidden=true;
            makeCroppedFile().then(function(blob){
                var fd=new FormData();fd.append('action','phisk_update_channel_image');fd.append('nonce',config.channelImageNonce||'');fd.append('image_type',kind);fd.append('image_file',blob,kind+'-image.jpg');
                progress.hidden=false; progressLabel.textContent=kind==='cover'?'Uploading cover image…':'Uploading profile image…';
                var xhr=new XMLHttpRequest();xhr.open('POST',config.ajaxurl||window.ajaxurl,true);
                xhr.upload.addEventListener('progress',function(ev){if(!ev.lengthComputable)return;var pct=Math.max(0,Math.min(99,Math.round(ev.loaded/ev.total*100)));progressBar.style.width=pct+'%';progressPercent.textContent=pct+'%';});
                xhr.onload=function(){var response;try{response=JSON.parse(xhr.responseText);}catch(e){response=null;}
                    if(xhr.status>=200&&xhr.status<300&&response&&response.success&&response.data){
                        progressBar.style.width='100%';progressPercent.textContent='100%';progressLabel.textContent='Upload complete';
                        var url=response.data.url;
                        if(kind==='cover'){var cover=document.querySelector('.phisk-dashboard-cover');if(cover){cover.style.backgroundImage='url("'+url+'")';var placeholder=cover.querySelector('.phisk-dashboard-cover-placeholder');if(placeholder)placeholder.remove();}}
                        else{var avatar=document.querySelector('.phisk-dashboard-avatar');if(avatar){var img=avatar.querySelector('img');if(!img){img=document.createElement('img');avatar.innerHTML='';avatar.appendChild(img);}img.src=url;img.alt=document.querySelector('.phisk-dashboard-name-text')?document.querySelector('.phisk-dashboard-name-text').textContent:'';}}
                        workspace.hidden=true;selectButton.hidden=true;illustration.hidden=true;progress.hidden=true;success.hidden=false;busy=false;
                    }else{busy=false;uploadButton.disabled=false;selectButton.disabled=false;changeButton.disabled=false;progress.hidden=true;showError(response&&response.data&&response.data.message?response.data.message:'Upload failed. Please try again.');}
                };
                xhr.onerror=function(){busy=false;uploadButton.disabled=false;selectButton.disabled=false;changeButton.disabled=false;progress.hidden=true;showError('Upload failed. Check your connection and try again.');};
                xhr.send(fd);
            }).catch(function(err){busy=false;uploadButton.disabled=false;selectButton.disabled=false;changeButton.disabled=false;showError(err.message||'Unable to prepare this image.');});
        });
        document.getElementById('phisk-image-editor-ok').addEventListener('click',closeEditor);
    })();

    function updateSubscriptionUI(authorId, subscribed, count) {
        var selector = '.phisk-subscribe-button[data-author-id="' + authorId + '"]';
        $(selector).each(function(){
            var $btn = $(this);
            $btn.text(subscribed ? 'Subscribed' : 'Subscribe');
            $btn.toggleClass('is-subscribed', subscribed);
            $btn.attr('aria-pressed', subscribed ? 'true' : 'false');
            $btn.prop('disabled', false).removeAttr('data-phisk-busy');
        });
        $('.phisk-subscriber-count[data-author-id="' + authorId + '"]').text(count + ' ' + (count === 1 ? 'subscriber' : 'subscribers'));
    }
    function toggleSubscription(button) {
        var $button = $(button);
        if (!$button.length || $button.prop('disabled') || $button.attr('data-phisk-busy') === '1') return;
        var authorId = parseInt($button.attr('data-author-id'), 10) || 0;
        var nonce = $button.attr('data-nonce') || '';
        var config = window.PhiskVideosFront || {};
        var ajaxUrl = config.ajaxurl || (window.ajaxurl || '');
        if (!authorId || !nonce || !ajaxUrl) {
            window.alert('Unable to update subscription. Please refresh the page and try again.');
            return;
        }
        $button.attr('data-phisk-busy','1');
        $('.phisk-subscribe-button[data-author-id="' + authorId + '"]').prop('disabled', true);
        $.ajax({
            url: ajaxUrl,
            method: 'POST',
            data: {
                action: config.subscriptionAction || 'phisk_toggle_subscription',
                nonce: nonce,
                author_id: authorId
            },
            dataType: 'json',
            cache: false
        }).done(function(response){
            if (response && response.success && response.data) {
                var count = parseInt(response.data.display_subscriber_count !== undefined ? response.data.display_subscriber_count : response.data.subscriber_count, 10);
                if (isNaN(count)) count = 0;
                updateSubscriptionUI(authorId, !!response.data.subscribed, count);
            } else {
                var msg = response && response.data && response.data.message ? response.data.message : 'Unable to update subscription. Please try again.';
                window.alert(msg);
            }
        }).fail(function(xhr){
            var msg = 'Unable to update subscription. Please try again.';
            if (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) msg = xhr.responseJSON.data.message;
            window.alert(msg);
        }).always(function(){
            $('.phisk-subscribe-button[data-author-id="' + authorId + '"]').prop('disabled', false).removeAttr('data-phisk-busy');
        });
    }
    $(document).off('click.phiskSubscribe', '.phisk-subscribe-button').on('click.phiskSubscribe', '.phisk-subscribe-button', function(e){
        e.preventDefault();
        e.stopPropagation();
        toggleSubscription(this);
        return false;
    });
    $(document).off('click.phiskVideoMenu', '.phisk-video-menu-button').on('click.phiskVideoMenu', '.phisk-video-menu-button', function(e){
        e.preventDefault(); e.stopPropagation();
        var $button=$(this), $wrap=$button.closest('.phisk-video-feed-title-row'), $menu=$wrap.find('.phisk-video-menu').first();
        if(!$menu.length)return;
        var wasOpen=!$menu.prop('hidden');
        $('.phisk-video-menu').prop('hidden',true); $('.phisk-video-menu-button').attr('aria-expanded','false');
        $menu.prop('hidden',wasOpen); $button.attr('aria-expanded',wasOpen?'false':'true');
    });
    $(document).off('click.phiskVideoShare', '.phisk-video-share').on('click.phiskVideoShare', '.phisk-video-share', function(e){
        e.preventDefault(); e.stopPropagation();
        var button=this,url=$(button).attr('data-share-url')||window.location.href,title=$(button).attr('data-share-title')||document.title;
        if(navigator.share) navigator.share({title:title,url:url}).catch(function(){});
        else if(navigator.clipboard&&window.isSecureContext) navigator.clipboard.writeText(url).then(function(){$(button).text('Link copied');setTimeout(function(){$(button).text('Share');},1400);}).catch(function(){});
        else {var input=document.createElement('input');input.value=url;document.body.appendChild(input);input.select();try{document.execCommand('copy');$(button).text('Link copied');setTimeout(function(){$(button).text('Share');},1400);}catch(err){}input.remove();}
    });

    // PhiskVideos: lightweight embed dialog with copyable URL and iframe code.
    function phiskEmbedModal() {
        var $modal = $('#phisk-video-embed-modal');
        if ($modal.length) return $modal;
        $('body').append('<div id="phisk-video-embed-modal" class="phisk-embed-modal" hidden><div class="phisk-embed-backdrop"></div><section class="phisk-embed-dialog" role="dialog" aria-modal="true" aria-labelledby="phisk-embed-dialog-title"><button type="button" class="phisk-embed-close" aria-label="Close embed dialog">&times;</button><h2 id="phisk-embed-dialog-title">Embed this video</h2><p>Copy the link or embed code to share this video on another website.</p><label for="phisk-embed-url">Embed URL</label><div class="phisk-embed-copy-row"><input id="phisk-embed-url" readonly><button type="button" data-phisk-copy="url">Copy Link</button></div><label for="phisk-embed-code">Embed code</label><textarea id="phisk-embed-code" rows="4" readonly></textarea><button type="button" class="phisk-embed-copy-code" data-phisk-copy="code">Copy Embed Code</button><div class="phisk-embed-status" aria-live="polite"></div></section></div>');
        return $('#phisk-video-embed-modal');
    }
    $(document).off('click.phiskVideoEmbed', '.phisk-video-embed-button').on('click.phiskVideoEmbed', '.phisk-video-embed-button', function(e){
        e.preventDefault(); e.stopPropagation();
        var url = $(this).attr('data-embed-url') || '', title = $(this).attr('data-embed-title') || 'PhiskVideos video';
        if (!url) return;
        var $modal = phiskEmbedModal();
        var code = '<iframe src="' + url + '" title="' + title.replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;') + '" width="560" height="315" style="border:0;max-width:100%;" loading="lazy" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>';
        $modal.find('#phisk-embed-url').val(url);
        $modal.find('#phisk-embed-code').val(code);
        $modal.find('.phisk-embed-status').text('');
        $modal.removeAttr('hidden'); $('body').addClass('phisk-embed-open');
        setTimeout(function(){ $modal.find('#phisk-embed-url').trigger('focus').trigger('select'); }, 30);
    });
    function closePhiskEmbedModal(){ $('#phisk-video-embed-modal').attr('hidden',true); $('body').removeClass('phisk-embed-open'); }
    $(document).off('click.phiskEmbedClose','.phisk-embed-close,.phisk-embed-backdrop').on('click.phiskEmbedClose','.phisk-embed-close,.phisk-embed-backdrop',function(e){e.preventDefault();closePhiskEmbedModal();});
    $(document).off('keydown.phiskEmbedEscape').on('keydown.phiskEmbedEscape',function(e){if(e.key==='Escape'&&!$('#phisk-video-embed-modal').is('[hidden]'))closePhiskEmbedModal();});
    $(document).off('click.phiskEmbedCopy','[data-phisk-copy]').on('click.phiskEmbedCopy','[data-phisk-copy]',function(){
        var type=$(this).attr('data-phisk-copy'),$field=$('#phisk-embed-'+(type==='code'?'code':'url')),$status=$('.phisk-embed-status'),value=$field.val()||'';
        function copied(){ $status.text(type==='code'?'Embed code copied.':'Embed link copied.'); }
        if(navigator.clipboard&&window.isSecureContext){navigator.clipboard.writeText(value).then(copied).catch(function(){$field.trigger('focus').trigger('select');try{document.execCommand('copy');copied();}catch(err){$status.text('Select and copy the text above.');}});}
        else{$field.trigger('focus').trigger('select');try{document.execCommand('copy');copied();}catch(err){$status.text('Select and copy the text above.');}}
    });

    $(document).on('click.phiskCloseMenus', function(e){
        if(!$(e.target).closest('.phisk-video-menu,.phisk-video-menu-button').length){$('.phisk-video-menu').prop('hidden',true);$('.phisk-video-menu-button').attr('aria-expanded','false');}
    });

    function updateVideoEngagement(videoId, liked, count) {
        $('.phisk-video-like-button[data-video-id="' + videoId + '"]').each(function(){
            var $btn=$(this);
            $btn.toggleClass('is-liked', liked).attr('aria-pressed', liked ? 'true' : 'false');
            $btn.find('.phisk-like-label').text('Like');
            $btn.attr('aria-label', liked ? 'Unlike this video' : 'Like this video');
            $btn.find('.phisk-like-count').text(Number(count).toLocaleString());
        });
    }
    $(document).off('click.phiskVideoLike', '.phisk-video-like-button').on('click.phiskVideoLike', '.phisk-video-like-button', function(e){
        e.preventDefault(); e.stopPropagation();
        var $button=$(this);
        if($button.attr('data-phisk-busy')==='1') return false;
        var config=window.PhiskVideosFront||{}, videoId=parseInt($button.attr('data-video-id'),10)||0, nonce=$button.attr('data-nonce')||'';
        if(!videoId || !nonce || !config.ajaxurl){ window.alert('Unable to update like. Please refresh the page and try again.'); return false; }
        $button.attr('data-phisk-busy','1');
        $.post(config.ajaxurl,{action:config.likeAction||'phisk_toggle_video_like',nonce:nonce,video_id:videoId},null,'json')
        .done(function(response){
            if(response&&response.success&&response.data){
                updateVideoEngagement(videoId,!!response.data.liked,parseInt(response.data.like_count,10)||0);
            } else {
                window.alert(response&&response.data&&response.data.message?response.data.message:'Unable to update like. Please try again.');
            }
        }).fail(function(xhr){
            var msg='Please log in to like videos.';
            if(xhr&&xhr.responseJSON&&xhr.responseJSON.data&&xhr.responseJSON.data.message) msg=xhr.responseJSON.data.message;
            window.alert(msg);
        }).always(function(){ $button.removeAttr('data-phisk-busy'); });
        return false;
    });
    function phiskReportModal() {
        var $modal=$('#phisk-video-report-modal');
        if(!$modal.length){
            $('body').append('<div id="phisk-video-report-modal" class="phisk-report-modal" hidden><div class="phisk-report-backdrop"></div><div class="phisk-report-dialog" role="dialog" aria-modal="true" aria-labelledby="phisk-report-title"><button type="button" class="phisk-report-close" aria-label="Close report">&times;</button><h2 id="phisk-report-title">Report this video</h2><p class="phisk-report-intro">Tell us what is wrong with this video.</p><form class="phisk-video-report-form"><label for="phisk-report-reason"><strong>Reason</strong></label><select id="phisk-report-reason" name="reason" required><option value="">Select a reason</option><option>Spam or misleading</option><option>Hateful or abusive content</option><option>Harassment or bullying</option><option>Violence or dangerous content</option><option>Sexual or inappropriate content</option><option>Copyright infringement</option><option>Scam or fraud</option><option>Privacy violation</option><option>Something else</option></select><label for="phisk-report-details"><strong>Additional details</strong> <span>(optional)</span></label><textarea id="phisk-report-details" name="details" rows="4" maxlength="2000" placeholder="Add more information if helpful..."></textarea><div class="phisk-report-message" aria-live="polite"></div><div class="phisk-report-actions"><button type="button" class="phisk-report-cancel">Cancel</button><button type="submit" class="phisk-report-submit">Submit Report</button></div></form></div></div>');
            $modal=$('#phisk-video-report-modal');
        }
        return $modal;
    }
    function closePhiskReportModal(){ $('#phisk-video-report-modal').attr('hidden',true).removeAttr('data-video-id'); $('body').removeClass('phisk-report-open'); }
    $(document).off('click.phiskVideoReport','.phisk-video-report-button').on('click.phiskVideoReport','.phisk-video-report-button',function(e){
        e.preventDefault();e.stopPropagation();var $modal=phiskReportModal(),videoId=parseInt($(this).attr('data-video-id'),10)||0;
        $modal.attr('data-video-id',videoId).removeAttr('hidden');$modal.find('.phisk-video-report-form')[0].reset();$modal.find('.phisk-report-message').text('');$('body').addClass('phisk-report-open');
        setTimeout(function(){$modal.find('#phisk-report-reason').trigger('focus');},50);
    });
    $(document).off('click.phiskReportClose','.phisk-report-close,.phisk-report-cancel,.phisk-report-backdrop').on('click.phiskReportClose','.phisk-report-close,.phisk-report-cancel,.phisk-report-backdrop',function(e){e.preventDefault();closePhiskReportModal();});
    $(document).off('keydown.phiskReportEscape').on('keydown.phiskReportEscape',function(e){if(e.key==='Escape'&&!$('#phisk-video-report-modal').is('[hidden]'))closePhiskReportModal();});
    $(document).off('submit.phiskVideoReport','.phisk-video-report-form').on('submit.phiskVideoReport','.phisk-video-report-form',function(e){
        e.preventDefault();var $form=$(this),$modal=$form.closest('.phisk-report-modal'),$submit=$form.find('.phisk-report-submit'),$message=$form.find('.phisk-report-message');
        var config=window.PhiskVideosFront||{},videoId=parseInt($modal.attr('data-video-id'),10)||0,reason=$form.find('[name="reason"]').val(),details=$form.find('[name="details"]').val()||'';
        if(!videoId||!reason){$message.text('Please select a reason.');return false;} if(!config.ajaxurl){$message.text('Unable to submit the report. Please refresh the page.');return false;}
        $submit.prop('disabled',true);$message.text('Submitting…');
        $.post(config.ajaxurl,{action:config.reportAction||'phisk_submit_video_report',nonce:config.reportNonce||'',video_id:videoId,reason:reason,details:details},null,'json')
        .done(function(response){if(response&&response.success){$message.text(response.data&&response.data.message?response.data.message:'Report submitted. Thank you.');$form.find('select,textarea,button').prop('disabled',true);setTimeout(closePhiskReportModal,1200);}else{$message.text(response&&response.data&&response.data.message?response.data.message:'Unable to submit the report.');$submit.prop('disabled',false);}})
        .fail(function(xhr){$message.text(xhr&&xhr.responseJSON&&xhr.responseJSON.data&&xhr.responseJSON.data.message?xhr.responseJSON.data.message:'Unable to submit the report.');$submit.prop('disabled',false);});
        return false;
    });
    $(document).off('submit.phiskVideoComment', '.phisk-video-comment-form').on('submit.phiskVideoComment', '.phisk-video-comment-form', function(e){
        e.preventDefault();
        var $form=$(this), $textarea=$form.find('textarea[name="comment"]'), $message=$form.find('.phisk-comment-form-message'), $submit=$form.find('button[type="submit"]');
        var config=window.PhiskVideosFront||{}, videoId=parseInt($form.attr('data-video-id'),10)||0, nonce=$form.attr('data-nonce')||'', content=$.trim($textarea.val());
        if(!content) return false;
        if(!videoId||!nonce||!config.ajaxurl){$message.text('Unable to post your comment. Please refresh the page.');return false;}
        $submit.prop('disabled',true); $message.text('Posting…');
        $.post(config.ajaxurl,{action:config.commentAction||'phisk_add_video_comment',nonce:nonce,video_id:videoId,comment:content},null,'json')
        .done(function(response){
            if(response&&response.success&&response.data&&response.data.comment){
                var c=response.data.comment;
                var authorName=$('<div>').text(c.author).html();
                var authorMarkup=c.author_url?'<a class="phisk-comment-author-link" href="'+$('<div>').text(c.author_url).html()+'">'+authorName+'</a>':authorName;
                var html='<article id="phisk-comment-'+c.id+'" class="phisk-video-comment" data-comment-id="'+c.id+'"><img class="phisk-comment-avatar" src="'+$('<div>').text(c.avatar).html()+'" alt=""><div class="phisk-comment-body"><div class="phisk-comment-author-row"><strong>'+authorMarkup+'</strong><time>'+ $('<div>').text(c.date).html() +'</time></div><div class="phisk-comment-text">'+c.content+'</div><button type="button" class="phisk-comment-reply-button" data-parent-id="'+c.id+'">Reply</button><form class="phisk-comment-reply-form" data-video-id="'+videoId+'" data-parent-id="'+c.id+'" data-nonce="'+nonce+'" hidden><textarea name="comment" maxlength="2000" required placeholder="Write a reply..."></textarea><button type="submit">Send reply</button><span class="phisk-comment-form-message" aria-live="polite"></span></form></div></article>';
                var $commentRoot=$form.closest('.phisk-comments-page, .phisk-video-comments');
                $commentRoot.find('.phisk-no-comments').remove();
                $commentRoot.find('.phisk-video-comment-list').append(html);
                $commentRoot.find('.phisk-comments-total').text(Number(response.data.comment_count).toLocaleString());
                $('.phisk-comment-count').each(function(){
                    var href=$(this).closest('a').attr('href')||'';
                    if(href.indexOf('phisk-video-comments')!==-1) $(this).text(Number(response.data.comment_count).toLocaleString());
                });
                $textarea.val(''); $message.text('Comment posted.');
            } else {
                $message.text(response&&response.data&&response.data.message?response.data.message:'Unable to post your comment.');
            }
        }).fail(function(xhr){
            $message.text(xhr&&xhr.responseJSON&&xhr.responseJSON.data&&xhr.responseJSON.data.message?xhr.responseJSON.data.message:'Unable to post your comment.');
        }).always(function(){ $submit.prop('disabled',false); });
        return false;
    });

    // Comments are fetched only on the dedicated comments page; reply branches are fetched on demand.
    (function(){
        var $page=$('.phisk-comments-page[data-video-id]').first();
        if(!$page.length) return;
        var config=window.PhiskVideosFront||{}, videoId=parseInt($page.attr('data-video-id'),10)||0, nonce=$page.attr('data-comment-nonce'), page=1, loading=false, targetId=(window.location.hash.match(/^#phisk-comment-(\d+)$/)||[])[1]||'';
        var $spinner=$page.find('.phisk-comments-loading'), $list=$page.find('.phisk-video-comment-list'), $more=$page.find('.phisk-comments-load-more');
        function fetchReplyBranch(parentId, done){
            var $article=$list.find('[data-comment-id="'+parentId+'"]'), $button=$article.children('.phisk-comment-body').children('.phisk-comment-toggle-replies'), $children=$article.children('.phisk-comment-body').children('.phisk-comment-children');
            if(!$article.length || !$button.length){if(done)done();return;}
            if($button.attr('data-loaded')==='1'){if(done)done();return;}
            $button.attr('data-loading','1').text('Loading replies…');
            $.post(config.ajaxurl,{action:'phisk_load_video_comment_replies',nonce:nonce,parent_id:parentId},null,'json')
            .done(function(r){if(r&&r.success&&r.data){$children.html(r.data.html).prop('hidden',false);$button.attr({'data-loaded':'1','aria-expanded':'true'}).text('Hide replies');}else{$button.removeAttr('data-loading').text('Unable to load replies. Try again.');}})
            .fail(function(){$button.removeAttr('data-loading').text('Unable to load replies. Try again.');})
            .always(function(){if(done)done();});
        }
        function expandCommentPath(path,index){
            if(index>=path.length){phiskRevealCommentHash();return;}
            fetchReplyBranch(parseInt(path[index],10)||0,function(){expandCommentPath(path,index+1);});
        }
        function loadPage(nextPage, append){
            if(loading) return; loading=true; $spinner.prop('hidden',false); $more.prop('disabled',true);
            $.post(config.ajaxurl,{action:'phisk_load_video_comments',nonce:nonce,video_id:videoId,page:nextPage,target_comment_id:targetId},null,'json')
            .done(function(r){
                if(r&&r.success&&r.data){ if(append)$list.append(r.data.html);else $list.html(r.data.html); page=Number(r.data.page||nextPage);
                    $page.find('.phisk-comments-total').text(Number(r.data.total||0).toLocaleString());
                    $more.prop('hidden',!r.data.has_more); if(!r.data.html&&!append)$list.html('<p class="phisk-no-comments">No comments yet. Be the first to comment.</p>');
                    if(r.data.target_path&&r.data.target_path.length) expandCommentPath(r.data.target_path,0); else if(targetId) phiskRevealCommentHash();
                } else if(!append){$list.html('<p class="phisk-comments-load-error">Unable to load comments. Please try again.</p>');}
            }).fail(function(){if(!append)$list.html('<p class="phisk-comments-load-error">Unable to load comments. Please try again.</p>');})
            .always(function(){loading=false;$spinner.prop('hidden',true);$more.prop('disabled',false);});
        }
        loadPage(1,false);
        $more.off('click.phiskLoadMore').on('click.phiskLoadMore',function(){loadPage(page+1,true);});
        $page.on('click.phiskLazyReplies','.phisk-comment-toggle-replies',function(){
            var $button=$(this); if($button.attr('data-loaded')==='1'||$button.attr('data-loading')==='1') return;
            var parentId=parseInt($button.closest('.phisk-video-comment').attr('data-comment-id'),10)||0;
            fetchReplyBranch(parentId);
        });
    })();

    $(document).off('click.phiskCommentReply', '.phisk-comment-reply-button').on('click.phiskCommentReply', '.phisk-comment-reply-button', function(){
        var $button=$(this), $form=$button.siblings('.phisk-comment-reply-form');
        $form.prop('hidden', !$form.prop('hidden')); if(!$form.prop('hidden')) $form.find('textarea').trigger('focus');
    });
    $(document).off('click.phiskCommentToggle', '.phisk-comment-toggle-replies').on('click.phiskCommentToggle', '.phisk-comment-toggle-replies', function(){
        var $button=$(this), $article=$button.closest('.phisk-video-comment'), $children=$article.children('.phisk-comment-body').children('.phisk-comment-children'), open=$button.attr('aria-expanded')==='true';
        if(!open && $button.attr('data-loaded')!=='1') return;
        $button.attr('aria-expanded', open ? 'false' : 'true'); $children.prop('hidden', open);
        var count=$children.children('.phisk-video-comment').length;
        $button.text(open ? 'View '+count+(count===1?' reply':' replies') : 'Hide replies');
    });
    // Reply notification links may point into one or more collapsed reply groups.
    function phiskRevealCommentHash(){
        if(!window.location.hash||window.location.hash.indexOf('#phisk-comment-')!==0) return;
        var $target=$(window.location.hash); if(!$target.length) return;
        $target.parents('.phisk-comment-children').each(function(){
            var $children=$(this), $owner=$children.closest('.phisk-comment-body'), $toggle=$owner.children('.phisk-comment-toggle-replies');
            $children.prop('hidden',false);
            if($toggle.length) $toggle.attr('aria-expanded','true').text('Hide replies');
        });
        setTimeout(function(){var el=$target.get(0);if(el)el.scrollIntoView({behavior:'smooth',block:'center'});},120);
    }
    phiskRevealCommentHash();
    $(document).off('submit.phiskCommentReply', '.phisk-comment-reply-form').on('submit.phiskCommentReply', '.phisk-comment-reply-form', function(e){
        e.preventDefault(); var $form=$(this), $message=$form.find('.phisk-comment-form-message'), $submit=$form.find('button[type="submit"]'), $textarea=$form.find('textarea');
        var config=window.PhiskVideosFront||{}, content=$.trim($textarea.val()), parentId=parseInt($form.attr('data-parent-id'),10)||0; if(!content) return false;
        if(!config.ajaxurl||!parentId){$message.text('Unable to send reply. Please refresh the page.');return false;}
        $submit.prop('disabled',true); $message.text('Sending…');
        $.post(config.ajaxurl,{action:'phisk_reply_video_comment',nonce:$form.attr('data-nonce'),video_id:$form.attr('data-video-id'),parent_id:parentId,comment:content},null,'json')
        .done(function(r){
            if(r&&r.success&&r.data&&r.data.html){
                var $parent=$form.closest('.phisk-video-comment'), $body=$parent.children('.phisk-comment-body'), $children=$body.children('.phisk-comment-children'), $toggle=$body.children('.phisk-comment-toggle-replies');
                if(!$children.length){$children=$('<div class="phisk-comment-children"></div>').attr('data-parent-id',parentId).appendTo($body);}
                $children.append(r.data.html).prop('hidden',false);
                if(!$toggle.length){$toggle=$('<button type="button" class="phisk-comment-toggle-replies" aria-expanded="true"></button>').insertBefore($children);}
                var count=$children.children('.phisk-video-comment').length; $toggle.attr({'aria-expanded':'true','data-loaded':'1'}).text('Hide replies').prop('hidden',false);
                $textarea.val(''); $message.text('Reply posted.');
                $form.prop('hidden',true);
                $('.phisk-comments-total').text(Number(r.data.comment_count||0).toLocaleString());
            } else {$message.text(r&&r.data&&r.data.message?r.data.message:'Unable to send reply.');}
        })
        .fail(function(xhr){$message.text(xhr&&xhr.responseJSON&&xhr.responseJSON.data&&xhr.responseJSON.data.message?xhr.responseJSON.data.message:'Unable to send reply.');})
        .always(function(){$submit.prop('disabled',false);}); return false;
    });

    function phiskVideoWizardShowStep($wrap, step) {
        step = parseInt(step, 10) || 1;
        $wrap.find('.phisk-video-step').each(function(){
            var $section=$(this), active=parseInt($section.attr('data-step'),10)===step;
            $section.prop('hidden', !active).toggleClass('is-active', active);
        });
        $wrap.find('[data-step-indicator]').each(function(){
            var $indicator=$(this), n=parseInt($indicator.attr('data-step-indicator'),10)||0;
            $indicator.toggleClass('is-active', n===step).toggleClass('is-complete', n<step);
        });
        $wrap.attr('data-current-step', step);
        window.scrollTo({top:Math.max(0,$wrap.offset().top-20), behavior:'smooth'});
    }
    $(document).off('click.phiskVideoWizardNav','.phisk-wizard-next,.phisk-wizard-back').on('click.phiskVideoWizardNav','.phisk-wizard-next,.phisk-wizard-back',function(e){
        e.preventDefault();
        var $wrap=$(this).closest('[data-phisk-video-submit]');
        phiskVideoWizardShowStep($wrap, $(this).attr('data-go-step'));
    });
    $(document).off('click.phiskYoutubeReveal','.phisk-youtube-import-reveal').on('click.phiskYoutubeReveal','.phisk-youtube-import-reveal',function(e){
        e.preventDefault();
        var $panel=$(this).closest('.phisk-youtube-import-option').find('.phisk-youtube-import-panel');
        $panel.removeAttr('hidden');
        $(this).closest('.phisk-youtube-import-option').find('.phisk-youtube-ownership-check input').trigger('focus');
    });
    $(document).off('change.phiskYoutubeOwnership','.phisk-youtube-ownership-check input').on('change.phiskYoutubeOwnership','.phisk-youtube-ownership-check input',function(){
        var $panel=$(this).closest('.phisk-youtube-import-panel'), checked=this.checked;
        $panel.find('.phisk-youtube-url-field').prop('hidden',!checked);
        $panel.find('.phisk-youtube-import-button').prop('hidden',!checked);
        if(!checked){$panel.find('input[name="youtube_video_url"]').val('');}
    });
    $(document).off('click.phiskYoutubeImport','.phisk-youtube-import-button').on('click.phiskYoutubeImport','.phisk-youtube-import-button',function(e){
        e.preventDefault();
        var $button=$(this),$wrap=$button.closest('[data-phisk-video-submit]'),form=$wrap.find('.phisk-video-submit-wizard')[0],config=window.PhiskVideosFront||{},$message=$wrap.find('.phisk-video-submit-message'),url=$.trim(form.querySelector('input[name="youtube_video_url"]').value),confirmed=form.querySelector('input[name="youtube_ownership_confirmed"]').checked;
        if(!confirmed){$message.text('Please confirm the ownership and reduced-earnings warning first.');return false;}
        if(!url){$message.text('Please paste a YouTube video link.');return false;}
        if(!config.ajaxurl||!config.videoSubmitNonce){$message.text('The importer is not ready. Please refresh the page and try again.');return false;}
        $button.prop('disabled',true);$message.text('Checking YouTube link and retrieving video details…');
        $.post(config.ajaxurl,{action:'phisk_import_youtube_draft',nonce:config.videoSubmitNonce,youtube_url:url,ownership_confirmed:'1'},null,'json')
        .done(function(response){
            if(response&&response.success&&response.data){
                form.querySelector('input[name="draft_id"]').value=response.data.draft_id||'';
                form.querySelector('input[name="phisk_video_title"]').value=response.data.title||'';
                form.querySelector('textarea[name="phisk_video_description"]').value='';
                $wrap.find('input[name="phisk_age_rating"]').prop('checked',false);
                $wrap.find('.phisk-file-picker').prop('hidden',true);
                $wrap.find('.phisk-upload-hint,.phisk-upload-progress,.phisk-upload-video-button,.phisk-youtube-import-option').prop('hidden',true);
                $wrap.find('.phisk-upload-current').text('YouTube embed imported. The original video remains hosted on YouTube.');
                $message.text(response.data.message||'YouTube video imported. Continue to details.');
                phiskVideoWizardShowStep($wrap,2);
            }else{$message.text(response&&response.data&&response.data.message?response.data.message:'Unable to import this YouTube video.');}
        }).fail(function(xhr){$message.text(xhr&&xhr.responseJSON&&xhr.responseJSON.data&&xhr.responseJSON.data.message?xhr.responseJSON.data.message:'Unable to import this YouTube video. Please check the link and try again.');})
        .always(function(){$button.prop('disabled',false);});
        return false;
    });
    $(document).off('change.phiskVideoPicker','input[name="video_file"]').on('change.phiskVideoPicker','input[name="video_file"]',function(){
        var file=this.files&&this.files[0], $picker=$(this).closest('.phisk-file-picker'), $name=$picker.find('.phisk-file-name');
        if($name.length) $name.text(file ? file.name : '');
    });
    $(document).off('click.phiskVideoUpload','.phisk-upload-video-button').on('click.phiskVideoUpload','.phisk-upload-video-button',function(e){
        e.preventDefault();
        var $button=$(this), $wrap=$button.closest('[data-phisk-video-submit]'), form=$wrap.find('.phisk-video-submit-wizard')[0], input=form.querySelector('input[name="video_file"]'), file=input&&input.files&&input.files[0], config=window.PhiskVideosFront||{}, $message=$wrap.find('.phisk-video-submit-message'), $progress=$wrap.find('.phisk-upload-progress'), $bar=$progress.find('.phisk-upload-progress-track span'), $pct=$progress.find('.phisk-upload-progress-row span');
        var draftId=parseInt(form.querySelector('input[name="draft_id"]').value,10)||0;
        if(!draftId && !file){$message.text('Please choose a video file first.');return false;}
        if(!config.ajaxurl||!config.videoUploadNonce){$message.text('The uploader is not ready. Please refresh the page and try again.');return false;}
        if(!file){phiskVideoWizardShowStep($wrap,2);return false;}
        var fd=new FormData(); fd.append('action','phisk_upload_video_draft'); fd.append('nonce',config.videoUploadNonce); fd.append('draft_id',draftId); fd.append('video_file',file);
        $button.prop('disabled',true); $wrap.find('.phisk-wizard-next,.phisk-save-details-button,.phisk-finish-video-button').prop('disabled',true); $message.text('Uploading your video…'); $progress.removeAttr('hidden'); $bar.css('width','0%'); $pct.text('0%');
        $.ajax({url:config.ajaxurl,method:'POST',data:fd,dataType:'json',processData:false,contentType:false,cache:false,xhr:function(){var xhr=$.ajaxSettings.xhr();if(xhr&&xhr.upload){xhr.upload.addEventListener('progress',function(evt){if(!evt.lengthComputable)return;var percent=Math.max(0,Math.min(100,Math.round((evt.loaded/evt.total)*100)));$bar.css('width',percent+'%');$pct.text(percent+'%');$progress.find('.phisk-upload-progress-row strong').text(percent>=100?'Processing video…':'Uploading…');},false);}return xhr;}})
        .done(function(response){
            if(response&&response.success&&response.data){
                form.querySelector('input[name="draft_id"]').value=response.data.draft_id||'';
                $bar.css('width','100%');$pct.text('100%');$progress.find('.phisk-upload-progress-row strong').text('Upload complete');
                $message.text(response.data.message||'Video uploaded. Continue to the next step.');
                $wrap.find('.phisk-upload-current').text('Video uploaded successfully.');
                setTimeout(function(){phiskVideoWizardShowStep($wrap,2);},250);
            }else{$message.text(response&&response.data&&response.data.message?response.data.message:'The video could not be uploaded. Please try again.');}
        }).fail(function(xhr){$message.text(xhr&&xhr.responseJSON&&xhr.responseJSON.data&&xhr.responseJSON.data.message?xhr.responseJSON.data.message:'The video could not be uploaded. Please try again.');})
        .always(function(){$button.prop('disabled',false);$wrap.find('.phisk-wizard-next,.phisk-save-details-button,.phisk-finish-video-button').prop('disabled',false);});
        return false;
    });
    $(document).off('click.phiskVideoDetails','.phisk-save-details-button').on('click.phiskVideoDetails','.phisk-save-details-button',function(e){
        e.preventDefault();
        var $button=$(this),$wrap=$button.closest('[data-phisk-video-submit]'),form=$wrap.find('.phisk-video-submit-wizard')[0],config=window.PhiskVideosFront||{},$message=$wrap.find('.phisk-video-submit-message'),draftId=parseInt(form.querySelector('input[name="draft_id"]').value,10)||0,title=$.trim(form.querySelector('input[name="phisk_video_title"]').value),description=form.querySelector('textarea[name="phisk_video_description"]').value,age=form.querySelector('input[name="phisk_age_rating"]:checked');
        if(!draftId){$message.text('Please upload the video first.');phiskVideoWizardShowStep($wrap,1);return false;}
        if(!title){$message.text('Please enter a video title.');return false;}
        if(!$.trim(description)){$message.text('Please enter a description.');return false;}
        if(!age){$message.text('Please choose whether this video is for kids.');return false;}
        $button.prop('disabled',true);$message.text('Saving video details…');
        $.post(config.ajaxurl,{action:'phisk_update_video_draft',nonce:config.videoSubmitNonce||'',draft_id:draftId,title:title,description:description,age_restriction:age.value},null,'json')
        .done(function(response){if(response&&response.success){$message.text(response.data&&response.data.message?response.data.message:'Details saved.');phiskVideoWizardShowStep($wrap,3);}else{$message.text(response&&response.data&&response.data.message?response.data.message:'Unable to save the details.');}})
        .fail(function(xhr){$message.text(xhr&&xhr.responseJSON&&xhr.responseJSON.data&&xhr.responseJSON.data.message?xhr.responseJSON.data.message:'Unable to save the details. Please try again.');})
        .always(function(){$button.prop('disabled',false);});
    });
    // Story images upload immediately after selection; only attachment IDs are submitted with the Story.
    $(document).off('change.phiskStoryUpload','[data-phisk-story-composer] input[name="phisk_article_images[]"]').on('change.phiskStoryUpload','[data-phisk-story-composer] input[name="phisk_article_images[]"]',function(){
        var input=this,files=Array.prototype.slice.call(input.files||[]),$form=$(input).closest('form'),$list=$form.find('.phisk-article-image-preview-list'),$ids=$form.find('.phisk-story-hidden-ids'),config=window.PhiskVideosFront||{};input.value='';
        files.forEach(function(file){var $tile=$('<div class="phisk-article-image-preview"><img alt=""><div class="phisk-story-upload-track"><span></span></div><span class="phisk-story-upload-state">Preparing upload…</span></div>'),preview=(window.URL&&URL.createObjectURL)?URL.createObjectURL(file):'';if(preview)$tile.find('img').attr('src',preview);$list.append($tile);
            var fd=new FormData();fd.append('action','phisk_upload_story_image');fd.append('nonce',config.storyImageNonce||'');fd.append('file',file);var xhr=new XMLHttpRequest();xhr.open('POST',config.ajaxurl||'/wp-admin/admin-ajax.php',true);
            xhr.upload.addEventListener('progress',function(e){if(e.lengthComputable){var pct=Math.round(e.loaded/e.total*100);$tile.find('.phisk-story-upload-track span').css('width',pct+'%');$tile.find('.phisk-story-upload-state').text('Uploading '+pct+'%');}});
            xhr.onload=function(){var r={};try{r=JSON.parse(xhr.responseText||'{}');}catch(e){}if(xhr.status>=200&&xhr.status<300&&r.success&&r.data&&r.data.id){var id=parseInt(r.data.id,10);$tile.attr('data-image-id',id);$tile.find('.phisk-story-upload-track').remove();$tile.find('.phisk-story-upload-state').text('Uploaded');$tile.append('<button type="button" class="phisk-article-image-remove" aria-label="Remove image">×</button>');$ids.append($('<input type="hidden" name="phisk_article_image_ids[]">').val(id));}else{$tile.addClass('is-upload-error');$tile.find('.phisk-story-upload-state').text(r.data&&r.data.message?r.data.message:'Upload failed. Remove and try again.');$tile.append('<button type="button" class="phisk-article-image-remove" aria-label="Remove failed image">×</button>');}};
            xhr.onerror=function(){$tile.addClass('is-upload-error');$tile.find('.phisk-story-upload-state').text('Upload failed. Remove and try again.');$tile.append('<button type="button" class="phisk-article-image-remove" aria-label="Remove failed image">×</button>');};xhr.send(fd);
        });
    });
    $(document).off('click.phiskStoryImageRemove','.phisk-article-image-remove').on('click.phiskStoryImageRemove','.phisk-article-image-remove',function(){var $tile=$(this).closest('.phisk-article-image-preview'),id=String($tile.attr('data-image-id')||'');if(id)$tile.closest('[data-phisk-story-composer]').find('.phisk-story-hidden-ids input').filter(function(){return String(this.value)===id;}).first().remove();$tile.remove();});
    $(document).off('submit.phiskStorySubmit','[data-phisk-story-form]').on('submit.phiskStorySubmit','[data-phisk-story-form]',function(e){var $form=$(this),pending=$form.find('.phisk-story-upload-track').length,failed=$form.find('.is-upload-error').length,ids=$form.find('.phisk-story-hidden-ids input').length;if(pending||failed||!ids){e.preventDefault();$form.find('.phisk-story-upload-message').addClass('is-error').text(pending?'Please wait for all Story images to finish uploading.':(failed?'Remove failed images and upload them again.':'Please add at least one Story image.'));return false;}return true;});

    // Full-screen Story image viewer uses original attachment images and supports swipe/keyboard navigation.
    function phiskStoryViewerOpen($gallery,index){var items=[];$gallery.find('.phisk-article-gallery-slide').each(function(){var $b=$(this).find('.phisk-article-gallery-open').first();if($b.length)items.push({src:$b.attr('data-full-src')||$b.find('img').attr('src'),alt:$b.find('img').attr('alt')||''});});if(!items.length)return;var $v=$('#phisk-story-image-viewer');if(!$v.length){$v=$('<div id="phisk-story-image-viewer" role="dialog" aria-modal="true" aria-label="Story image viewer"><button type="button" class="phisk-story-viewer-close" aria-label="Close">×</button><button type="button" class="phisk-story-viewer-prev" aria-label="Previous image">‹</button><img alt=""><button type="button" class="phisk-story-viewer-next" aria-label="Next image">›</button><span class="phisk-story-viewer-count"></span></div>');$('body').append($v);}var current=index||0,show=function(){var item=items[(current+items.length)%items.length];$v.find('img').attr({src:item.src,alt:item.alt});$v.find('.phisk-story-viewer-count').text((current+1)+' / '+items.length);$v.find('.phisk-story-viewer-prev,.phisk-story-viewer-next').toggle(items.length>1);};$v.data('move',function(d){current=(current+d+items.length)%items.length;show();}).addClass('is-open');$('body').addClass('phisk-story-viewer-open');show();}
    $(document).off('click.phiskStoryViewerOpen','.phisk-article-gallery-open').on('click.phiskStoryViewerOpen','.phisk-article-gallery-open',function(){phiskStoryViewerOpen($(this).closest('[data-phisk-article-gallery]'),parseInt($(this).closest('.phisk-article-gallery-slide').attr('data-slide-index')||'0',10));});
    $(document).off('click.phiskStoryViewerControls','.phisk-story-viewer-close,.phisk-story-viewer-prev,.phisk-story-viewer-next').on('click.phiskStoryViewerControls','.phisk-story-viewer-close,.phisk-story-viewer-prev,.phisk-story-viewer-next',function(){var $v=$('#phisk-story-image-viewer');if($(this).hasClass('phisk-story-viewer-close')){$v.removeClass('is-open');$('body').removeClass('phisk-story-viewer-open');}else{var fn=$v.data('move');if(fn)fn($(this).hasClass('phisk-story-viewer-next')?1:-1);}});
    $(document).off('keydown.phiskStoryViewer').on('keydown.phiskStoryViewer',function(e){var $v=$('#phisk-story-image-viewer');if(!$v.hasClass('is-open'))return;if(e.key==='Escape'){$v.removeClass('is-open');$('body').removeClass('phisk-story-viewer-open');}else if(e.key==='ArrowRight'||e.key==='ArrowLeft'){var fn=$v.data('move');if(fn)fn(e.key==='ArrowRight'?1:-1);}});
    (function(){var sx=0;$(document).on('touchstart.phiskStoryViewer','#phisk-story-image-viewer',function(e){sx=e.originalEvent.touches[0].clientX;});$(document).on('touchend.phiskStoryViewer','#phisk-story-image-viewer',function(e){var dx=e.originalEvent.changedTouches[0].clientX-sx,fn=$(this).data('move');if(Math.abs(dx)>45&&fn)fn(dx<0?1:-1);});})();
    function phiskArticleGalleryShow($gallery,index){
        var $slides=$gallery.find('.phisk-article-gallery-slide'),count=$slides.length;
        if(!count)return; index=(index+count)%count;
        $slides.each(function(i){$(this).prop('hidden',i!==index).toggleClass('is-active',i===index);});
        $gallery.find('.phisk-article-gallery-current').text(index+1);
        $gallery.find('.phisk-article-gallery-dot').each(function(i){$(this).toggleClass('is-active',i===index).attr('aria-pressed',i===index?'true':'false');});
        $gallery.attr('data-current-slide',index);
    }
    $(document).off('click.phiskArticleGallery','.phisk-article-gallery-prev,.phisk-article-gallery-next,.phisk-article-gallery-dot').on('click.phiskArticleGallery','.phisk-article-gallery-prev,.phisk-article-gallery-next,.phisk-article-gallery-dot',function(e){
        e.preventDefault();e.stopPropagation();var $button=$(this),$gallery=$button.closest('[data-phisk-article-gallery]'),current=parseInt($gallery.attr('data-current-slide')||'0',10)||0;
        if($button.hasClass('phisk-article-gallery-prev'))current--;else if($button.hasClass('phisk-article-gallery-next'))current++;else current=parseInt($button.attr('data-go-to')||'0',10)||0;
        phiskArticleGalleryShow($gallery,current);
    });
    $(document).off('touchstart.phiskArticleGallerySwipe','[data-phisk-article-gallery]').on('touchstart.phiskArticleGallerySwipe','[data-phisk-article-gallery]',function(e){
        var touch=e.originalEvent&&e.originalEvent.touches&&e.originalEvent.touches[0];
        if(touch) $(this).data('phiskGalleryTouchStartX',touch.clientX);
    });
    $(document).off('touchend.phiskArticleGallerySwipe','[data-phisk-article-gallery]').on('touchend.phiskArticleGallerySwipe','[data-phisk-article-gallery]',function(e){
        var touch=e.originalEvent&&e.originalEvent.changedTouches&&e.originalEvent.changedTouches[0],start=$(this).data('phiskGalleryTouchStartX');
        if(!touch||typeof start!=='number')return;
        var delta=touch.clientX-start;
        if(Math.abs(delta)<35)return;
        var $gallery=$(this),current=parseInt($gallery.attr('data-current-slide')||'0',10)||0;
        phiskArticleGalleryShow($gallery,delta<0?current+1:current-1);
    });
    $(document).off('change.phiskThumbnail','.phisk-thumbnail-picker input[type=file]').on('change.phiskThumbnail','.phisk-thumbnail-picker input[type=file]',function(){
        var $input=$(this),$wrap=$input.closest('[data-phisk-video-submit]'),file=this.files&&this.files[0],$preview=$wrap.find('.phisk-thumbnail-preview'),img=$preview.find('img')[0];
        $input.closest('.phisk-thumbnail-picker').find('.phisk-thumbnail-file-name').text(file?file.name:'');
        $input.closest('.phisk-thumbnail-picker').find('.phisk-thumbnail-picker-label').text(file?'Thumbnail selected':'Select thumbnail');
        if(!file){$preview.attr('hidden',true);return;}
        if(window.URL&&window.URL.createObjectURL){img.src=window.URL.createObjectURL(file);$preview.removeAttr('hidden');}
    });
    $(document).off('click.phiskVideoFinish','.phisk-finish-video-button').on('click.phiskVideoFinish','.phisk-finish-video-button',function(e){
        e.preventDefault();
        var $button=$(this),$wrap=$button.closest('[data-phisk-video-submit]'),form=$wrap.find('.phisk-video-submit-wizard')[0],input=form.querySelector('input[name="thumbnail"]'),file=input&&input.files&&input.files[0],config=window.PhiskVideosFront||{},$message=$wrap.find('.phisk-video-submit-message'),draftId=parseInt(form.querySelector('input[name="draft_id"]').value,10)||0;
        if(!draftId){$message.text('Please upload the video first.');phiskVideoWizardShowStep($wrap,1);return false;}
        if(!file && !$wrap.find('.phisk-existing-thumbnail img').length && !$wrap.find('.phisk-youtube-import-option').prop('hidden')){$message.text('Please choose a thumbnail.');return false;}
        $button.prop('disabled',true);$message.text(file?'Saving thumbnail and video…':'Saving video changes…');
        var fd=new FormData();fd.append('action','phisk_finalize_video_draft');fd.append('nonce',config.videoSubmitNonce||'');fd.append('draft_id',draftId);if(file){fd.append('thumbnail',file);}
        $.ajax({url:config.ajaxurl,method:'POST',data:fd,dataType:'json',processData:false,contentType:false,cache:false})
        .done(function(response){if(response&&response.success){$message.text(response.data&&response.data.message?response.data.message:'Your video has been saved successfully.');if(response.data&&response.data.url){window.location.href=response.data.url;}else{window.location.reload();}}else{$message.text(response&&response.data&&response.data.message?response.data.message:'Unable to publish the video.');$button.prop('disabled',false);}})
        .fail(function(xhr){$message.text(xhr&&xhr.responseJSON&&xhr.responseJSON.data&&xhr.responseJSON.data.message?xhr.responseJSON.data.message:'Unable to publish the video. Please try again.');$button.prop('disabled',false);});
    });

    // Modern Phisk video player controls.
    function phiskFormatTime(seconds) {
        seconds = Math.max(0, Math.floor(Number(seconds) || 0));
        var h = Math.floor(seconds / 3600), m = Math.floor((seconds % 3600) / 60), s = seconds % 60;
        return (h ? h + ':' + String(m).padStart(2,'0') : String(m)) + ':' + String(s).padStart(2,'0');
    }
    function phiskPlayerUpdate($player) {
        var video = $player.find('.phisk-player-video')[0];
        if (!video) return;
        var duration = Number(video.duration) || 0, current = Number(video.currentTime) || 0;
        var pct = duration ? Math.round((current / duration) * 1000) : 0;
        var $seek = $player.find('.phisk-player-seek');
        $seek.val(pct).css('--phisk-progress', (pct / 10) + '%');
        $player.find('[data-player-current]').text(phiskFormatTime(current));
        $player.find('[data-player-duration]').text(phiskFormatTime(duration));
        $player.toggleClass('is-playing', !video.paused && !video.ended);
        $player.find('[data-player-end-screen]').prop('hidden', !video.ended);
        var $play = $player.find('[data-player-action="play"]');
        $play.attr('aria-label', video.paused || video.ended ? 'Play video' : 'Pause video');
        $play.find('.phisk-player-control-icon').toggleClass('phisk-icon-play', video.paused || video.ended).toggleClass('phisk-icon-pause', !video.paused && !video.ended);
        if (!video.paused && !video.ended) $player.find('.phisk-player-big-play').addClass('is-hidden');
        else $player.find('.phisk-player-big-play').removeClass('is-hidden');
    }
    function phiskPlayerSetVolume($player, value) {
        var video = $player.find('.phisk-player-video')[0];
        if (!video) return;
        value = Math.max(0, Math.min(1, Number(value)));
        video.volume = value;
        video.muted = value === 0;
        $player.find('.phisk-player-volume').val(video.muted ? 0 : value).css('--phisk-volume', ((video.muted ? 0 : value) * 100) + '%');
        $player.find('[data-player-action="mute"]').toggleClass('is-muted', video.muted);
    }
    function phiskPlayerInit(root) {
        var $player = $(root), video = $player.find('.phisk-player-video')[0];
        if (!video || $player.data('phiskPlayerReady')) return;
        $player.data('phiskPlayerReady', true);
        var hideTimer = null;
        var playRequested = false;
        function setPlayerLoading(loading) {
            $player.toggleClass('is-loading', !!loading);
            $player.find('[data-player-loading]').prop('hidden', !loading);
        }
        function showControls() {
            $player.addClass('is-controls-visible');
            clearTimeout(hideTimer);
            if (!video.paused) hideTimer = setTimeout(function(){ $player.removeClass('is-controls-visible'); }, 2200);
        }
        $player.on('mousemove touchstart', showControls);
        $player.on('click', '.phisk-player-video', function(){
            if (video.paused) { playRequested = true; if (video.readyState < 3) setPlayerLoading(true); video.play().catch(function(){ playRequested = false; setPlayerLoading(false); }); }
            else video.pause();
            showControls();
        });
        $player.on('click', '[data-player-action="replay"]', function(e){
            e.preventDefault(); e.stopPropagation(); video.currentTime = 0; playRequested = true; setPlayerLoading(true); video.play().catch(function(){ playRequested = false; setPlayerLoading(false); }); showControls();
        });
        $player.on('click', '[data-player-action="play"], .phisk-player-big-play', function(e){
            e.preventDefault(); e.stopPropagation();
            if (video.paused || video.ended) { playRequested = true; if (video.readyState < 3) setPlayerLoading(true); video.play().catch(function(){ playRequested = false; setPlayerLoading(false); }); }
            else { playRequested = false; setPlayerLoading(false); video.pause(); }
            showControls();
        });
        $player.on('click', '[data-player-action="mute"]', function(e){
            e.preventDefault();
            if (video.muted || video.volume === 0) phiskPlayerSetVolume($player, Number($player.data('phiskLastVolume')) || .8);
            else { $player.data('phiskLastVolume', video.volume || .8); phiskPlayerSetVolume($player, 0); }
            showControls();
        });
        $player.on('input change', '.phisk-player-volume', function(){ phiskPlayerSetVolume($player, this.value); showControls(); });
        $player.on('input change', '.phisk-player-seek', function(){
            var duration = Number(video.duration) || 0;
            if (duration) video.currentTime = (Number(this.value) / 1000) * duration;
            showControls();
        });
        $player.on('click', '[data-player-action="fullscreen"]', function(e){
            e.preventDefault();
            var el = $player[0];
            if (document.fullscreenElement || document.webkitFullscreenElement) {
                (document.exitFullscreen || document.webkitExitFullscreen).call(document);
            } else if (el.requestFullscreen) el.requestFullscreen().catch(function(){});
            else if (el.webkitRequestFullscreen) el.webkitRequestFullscreen();
            showControls();
        });
        $player.on('click', '[data-player-action="pip"]', function(e){
            e.preventDefault();
            if (document.pictureInPictureElement) {
                document.exitPictureInPicture().catch(function(){});
            } else if (video.requestPictureInPicture) {
                video.requestPictureInPicture().catch(function(){});
            }
            showControls();
        });
        $player.on('click', '[data-player-action="speed"]', function(e){
            e.preventDefault();
            var menu = $player.find('[data-player-speed-menu]')[0];
            if (!menu) return;
            $(menu).prop('hidden', !$(menu).prop('hidden'));
            showControls();
        });
        $player.on('click', '[data-speed]', function(e){
            e.preventDefault();
            var speed = Number($(this).attr('data-speed')) || 1;
            video.playbackRate = speed;
            $player.find('[data-player-action="speed"]').text(speed === 1 ? '1×' : speed + '×');
            $player.find('[data-speed]').removeClass('is-active');
            $(this).addClass('is-active');
            $player.find('[data-player-speed-menu]').prop('hidden', true);
            showControls();
        });
        $(document).on('click.phiskPlayerSpeed', function(e){
            if (!$(e.target).closest('.phisk-modern-player').length) $('.phisk-player-speed-menu').prop('hidden', true);
        });
        video.addEventListener('loadstart', function(){ if (video.readyState < 3) setPlayerLoading(true); });
        video.addEventListener('waiting', function(){ if (!video.paused && !video.ended) setPlayerLoading(true); });
        video.addEventListener('stalled', function(){ if (playRequested || !video.paused) setPlayerLoading(true); });
        video.addEventListener('playing', function(){ playRequested = false; setPlayerLoading(false); phiskPlayerUpdate($player); showControls(); });
        video.addEventListener('canplay', function(){ if (video.readyState >= 3) setPlayerLoading(false); });
        video.addEventListener('canplaythrough', function(){ setPlayerLoading(false); });
        video.addEventListener('loadedmetadata', function(){ phiskPlayerUpdate($player); }, {passive:true});
        video.addEventListener('timeupdate', function(){ phiskPlayerUpdate($player); }, {passive:true});
        video.addEventListener('play', function(){ if (video.readyState < 3) setPlayerLoading(true); phiskPlayerUpdate($player); showControls(); });
        video.addEventListener('pause', function(){ playRequested = false; setPlayerLoading(false); phiskPlayerUpdate($player); $player.addClass('is-controls-visible'); });
        video.addEventListener('ended', function(){ playRequested = false; setPlayerLoading(false); phiskPlayerUpdate($player); $player.addClass('is-controls-visible'); $player.find('[data-player-end-screen]').prop('hidden', false); });
        video.addEventListener('volumechange', function(){ phiskPlayerUpdate($player); });
        video.addEventListener('error', function(){ playRequested = false; setPlayerLoading(false); $player.addClass('is-error'); });
        video.addEventListener('loadeddata', function(){ $player.removeClass('is-error'); if (video.readyState >= 2 && !playRequested) setPlayerLoading(false); });
        phiskPlayerSetVolume($player, Number(video.volume) || 1);
        phiskPlayerUpdate($player);
    }
    function phiskInitModernPlayers() {
        $('.phisk-modern-player').each(function(){ phiskPlayerInit(this); });
    }
    $(phiskInitModernPlayers);
    $(document).on('phisk:content-updated', phiskInitModernPlayers);


    // Live character count for channel descriptions.
    $(document).on('input.phiskChannelDescription', '[data-phisk-char-limit]', function(){
        var limit = parseInt($(this).attr('data-phisk-char-limit'), 10) || 500;
        var value = $(this).val() || '';
        var count = typeof Array.from === 'function' ? Array.from(value).length : value.length;
        $(this).closest('label').find('.phisk-channel-description-count').text(count);
        if (count > limit) this.setCustomValidity('Please keep your channel description within ' + limit + ' characters.');
        else this.setCustomValidity('');
    });




    // Live character counters for video titles, Story titles, and channel names.
    function phiskUpdateCharacterCount(field) {
        var $field = $(field);
        var limit = parseInt($field.attr('data-phisk-title-limit') || $field.attr('data-phisk-name-limit'), 10) || 0;
        if (!limit) return;
        var value = $field.val() || '';
        var count = typeof Array.from === 'function' ? Array.from(value).length : value.length;
        $field.closest('label').find('.phisk-character-count').text(count);
        if (count > limit) {
            field.setCustomValidity('Please keep this field within ' + limit + ' characters.');
        } else {
            field.setCustomValidity('');
        }
    }
    $(document).on('input.phiskCharacterLimits', '[data-phisk-title-limit], [data-phisk-name-limit]', function(){
        phiskUpdateCharacterCount(this);
    });
    $(function(){
        $('[data-phisk-title-limit], [data-phisk-name-limit]').each(function(){
            phiskUpdateCharacterCount(this);
        });
    });

    // Reddit-inspired article voting, sharing, and compact overflow menu.
    function updateArticleVoteUI(articleId, upvoted, count) {
        $('.phisk-article-upvote[data-article-id="' + articleId + '"]').each(function(){
            var $button = $(this);
            $button.toggleClass('is-upvoted', !!upvoted).attr('aria-pressed', upvoted ? 'true' : 'false');
            $button.find('.phisk-article-upvote-count').text(Number(count || 0).toLocaleString());
            $button.prop('disabled', false).removeAttr('data-phisk-busy');
        });
    }
    $(document).on('click.phiskArticleVote', '.phisk-article-upvote', function(){
        var $button = $(this);
        if ($button.prop('disabled') || $button.attr('data-phisk-busy') === '1') return;
        var articleId = parseInt($button.attr('data-article-id'), 10) || 0;
        var config = window.PhiskVideosFront || {};
        if (!articleId) return;
        $button.attr('data-phisk-busy', '1').prop('disabled', true);
        $.ajax({url:config.ajaxurl || window.ajaxurl || '', method:'POST', data:{action:'phisk_toggle_article_upvote', article_id:articleId, nonce:$button.attr('data-nonce') || config.articleVoteNonce || ''}})
        .done(function(response){
            if (response && response.success && response.data) updateArticleVoteUI(articleId, response.data.upvoted, response.data.count);
            else { $button.prop('disabled', false).removeAttr('data-phisk-busy'); window.alert(response && response.data && response.data.message ? response.data.message : 'Please log in to upvote this Story.'); }
        }).fail(function(xhr){
            $button.prop('disabled', false).removeAttr('data-phisk-busy');
            var message = xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message;
            window.alert(message || 'Please log in to upvote Stories.');
        });
    });
    $(document).on('click.phiskArticleShare', '.phisk-article-share', function(){
        var button = this, url = button.getAttribute('data-share-url') || window.location.href, title = button.getAttribute('data-share-title') || document.title;
        if (navigator.share) { navigator.share({title:title, url:url}).catch(function(){}); return; }
        if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(url).then(function(){ button.classList.add('is-copied'); button.innerHTML = '<span aria-hidden="true">✓</span> Copied'; setTimeout(function(){button.classList.remove('is-copied');button.innerHTML='<span aria-hidden="true">↗</span> Share';}, 1800); }).catch(function(){ window.prompt('Copy Story link:', url); });
        else window.prompt('Copy Story link:', url);
    });
    $(document).on('click.phiskArticleMenu', '.phisk-article-more', function(e){
        e.preventDefault(); e.stopPropagation();
        var $button = $(this), $card = $button.closest('.phisk-article-card');
        $('.phisk-article-menu').not($card.find('.phisk-article-menu')).remove();
        var $menu = $card.find('.phisk-article-menu');
        if ($menu.length) { $menu.remove(); return; }
        var url = $card.find('.phisk-article-title-link').attr('href') || window.location.href;
        $menu = $('<div class="phisk-article-menu"><a class="phisk-article-menu-open" target="_self">Open Story</a><button type="button" class="phisk-article-menu-copy">Copy link</button></div>');
        $menu.find('.phisk-article-menu-open').attr('href', url);
        $menu.find('.phisk-article-menu-copy').attr('data-copy-url', url);
        if ($card.attr('data-channel-owner-view') === '1') {
            var editUrl = $card.attr('data-edit-story-url') || '';
            if (editUrl) $('<a class="phisk-article-menu-edit">Edit</a>').attr('href', editUrl).appendTo($menu);
            var deleteForm = $('<form method="post" class="phisk-article-menu-delete-form"><input type="hidden" name="phisk_dashboard_content_action" value="1"><input type="hidden" name="phisk_dashboard_post_id"><input type="hidden" name="phisk_dashboard_action" value="delete"><input type="hidden" name="phisk_dashboard_content_nonce"></form>');
            deleteForm.find('[name="phisk_dashboard_post_id"]').val($card.attr('data-article-id'));
            deleteForm.find('[name="phisk_dashboard_content_nonce"]').val($card.attr('data-delete-story-nonce'));
            $('<button type="submit" class="phisk-dashboard-delete">Delete</button>').appendTo(deleteForm);
            deleteForm.on('submit', function(){ return window.confirm('Delete this Story? It will be moved to the trash.'); });
            $menu.append(deleteForm);
        }
        $card.find('.phisk-article-card-head').append($menu);
    });
    $(document).on('click.phiskArticleMenuCopy', '.phisk-article-menu-copy', function(){
        var url = this.getAttribute('data-copy-url') || window.location.href;
        if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(url).then(function(){ $('.phisk-article-menu').remove(); }).catch(function(){window.prompt('Copy Story link:',url);});
        else window.prompt('Copy Story link:', url);
    });
    $(document).on('click.phiskArticleMenuClose', function(e){ if (!$(e.target).closest('.phisk-article-card-head').length) $('.phisk-article-menu').remove(); });

    // Close the channel cover's native details menu when clicking elsewhere or pressing Escape.
    $(document).on('click.phiskChannelMenuClose', function(e){
        $('.phisk-channel-menu[open]').each(function(){ if (!$(this).is(e.target) && !$(this).has(e.target).length) this.open = false; });
    });
    $(document).on('keydown.phiskChannelMenuClose', function(e){
        if (e.key === 'Escape') $('.phisk-channel-menu[open]').each(function(){ this.open = false; });
    });


    // Copy the current account's public channel/profile URL from the cover menu.
    $(document).off('click.phiskChannelCopy', '.phisk-channel-menu-copy').on('click.phiskChannelCopy', '.phisk-channel-menu-copy', function(e){
        e.preventDefault();
        e.stopPropagation();
        var button = this;
        var url = $(button).attr('data-copy-url') || '';
        if (!url) return;
        function copied() {
            var original = $(button).text();
            $(button).text('Link copied');
            setTimeout(function(){ $(button).text(original); }, 1500);
        }
        function fallbackCopy() {
            var input = document.createElement('textarea');
            input.value = url;
            input.setAttribute('readonly', '');
            input.style.position = 'absolute';
            input.style.left = '-9999px';
            document.body.appendChild(input);
            input.select();
            var success = false;
            try { success = document.execCommand('copy'); } catch (err) {}
            input.remove();
            if (success) copied();
        }
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(url).then(copied).catch(fallbackCopy);
        } else {
            fallbackCopy();
        }
    });


    $(document).off('click.phiskPublishShare', '.phisk-video-publish-share').on('click.phiskPublishShare', '.phisk-video-publish-share', function () {
        var box = this.closest('[data-phisk-publish-share]');
        if (!box) return;
        var url = box.getAttribute('data-share-url') || window.location.href;
        var title = box.getAttribute('data-share-title') || document.title;
        if (navigator.share) {
            navigator.share({ title: title, text: 'Watch my new video on PhiskVideos!', url: url }).catch(function () {});
        } else if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(url).then(function () {
                var feedback = box.querySelector('.phisk-video-publish-feedback');
                if (feedback) feedback.textContent = 'Video link copied. Share it anywhere!';
            }).catch(function () { window.prompt('Copy your video link:', url); });
        } else {
            window.prompt('Copy your video link:', url);
        }
    });
    $(document).off('click.phiskPublishCopy', '.phisk-video-publish-copy').on('click.phiskPublishCopy', '.phisk-video-publish-copy', function () {
        var box = this.closest('[data-phisk-publish-share]');
        if (!box) return;
        var url = box.getAttribute('data-share-url') || window.location.href;
        var feedback = box.querySelector('.phisk-video-publish-feedback');
        function success() { if (feedback) feedback.textContent = 'Link copied! Share your video with the world.'; }
        if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(url).then(success).catch(function () { window.prompt('Copy your video link:', url); });
        else window.prompt('Copy your video link:', url);
    });


    // Live public-username availability check (debounced while the member types).
    (function () {
        var timer = null;
        var request = null;
        var state = 'unchanged';
        var $input = $('.phisk-public-username-input');
        if (!$input.length) return;
        var $form = $input.closest('form');
        var original = String($input.val() || '').toLowerCase();
        var $status = $form.find('.phisk-username-availability');
        function show(message, status) {
            state = status;
            $status.text(message).attr('data-state', status);
        }
        $input.on('input', function () {
            var value = String($input.val() || '').trim().toLowerCase();
            window.clearTimeout(timer);
            if (request && request.readyState !== 4) request.abort();
            if (value === original) { show('', 'unchanged'); return; }
            if (!/^[a-z0-9_]{3,24}$/.test(value)) {
                show('Use 3–24 letters, numbers or underscores.', 'invalid'); return;
            }
            show('Checking availability…', 'checking');
            timer = window.setTimeout(function () {
                request = $.ajax({
                    url: (window.PhiskVideosFront && PhiskVideosFront.ajaxurl) || window.ajaxurl,
                    method: 'POST', dataType: 'json',
                    data: { action: 'phisk_check_public_username', username: value,
                        nonce: (window.PhiskVideosFront && PhiskVideosFront.usernameCheckNonce) || '' }
                }).done(function (response) {
                    if (String($input.val() || '').trim().toLowerCase() !== value) return;
                    if (response && response.success && response.data) {
                        show(response.data.message || '', response.data.available ? 'available' : 'taken');
                    } else { show('Could not check availability. Try again.', 'error'); }
                }).fail(function (xhr, statusText) {
                    if (statusText !== 'abort') show('Could not check availability. Try again.', 'error');
                });
            }, 350);
        });
        $form.on('submit', function (event) {
            var value = String($input.val() || '').trim().toLowerCase();
            if (value !== original && state !== 'available') {
                event.preventDefault();
                if (state === 'checking') show('Please wait for the availability check.', 'checking');
                else if (state === 'unchanged') $input.trigger('input');
                $input.trigger('focus');
            }
        });
    }());

})(jQuery);