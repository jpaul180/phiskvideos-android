# Native Creator Studio API (v1.16.0)

All endpoints require HTTPS and the authenticated PhiskVideos app Bearer session. The dashboard is scoped to the currently authenticated account; no user ID is accepted from the client. A valid PhiskVideos creator channel is required.

## GET `/wp-json/phisk/v1/creator-studio`

Returns the creator's real platform metrics, earnings ledger totals, eligibility progress, monetization status, last payout, 365-day chart history, top five published videos, and existing website shortcut URLs. Promotional display counters are excluded from verified video views.

## POST `/wp-json/phisk/v1/creator-studio/monetization`

Submits a monetization application. Enforces the existing channel, strike-pause, and application-status rules.

## POST `/wp-json/phisk/v1/creator-studio/payout`

Requests a payout using the existing eligibility rules, approved monetization status, strike-pause restriction, and $50 available-balance minimum. The request is recorded in the existing payout ledger and an in-app system message is sent.

The API reuses existing creator analytics and monetization data; it does not create a separate Android-only earnings or payout system.
