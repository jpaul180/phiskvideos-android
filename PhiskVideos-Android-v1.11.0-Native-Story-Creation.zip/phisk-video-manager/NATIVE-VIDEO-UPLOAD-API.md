# Native Video Upload API (Phisk Video Manager 1.17.0)

The Android app uses the existing PhiskVideos video model and upload policy. All routes require the app's authenticated bearer session over HTTPS and a creator channel. Publishing restrictions/strikes are checked server-side.

## 1. Upload video and create draft

`POST /wp-json/phisk/v1/creator-studio/videos/upload`

Multipart form field: `video_file`.

Accepted extensions: MP4, M4V, WebM, OGG/OGV and MOV. The server validates actual video dimensions and accepts landscape 16:9 or 21:9 only. If Publit.io is enabled in WordPress settings, the server forwards the upload to the configured Publit.io account; otherwise it stores the media in the WordPress media library. Provider credentials remain server-side and are never sent to Android.

Success response includes `draft_id`, `title`, `runtime`, and `message`.

## 2. Save video details

`POST /wp-json/phisk/v1/creator-studio/videos/{id}/details`

JSON body:

- `title` — required, maximum 100 characters
- `description` — required
- `age_restriction` — `No its not for kids` or `Yes its for kids`

The endpoint verifies that the draft belongs to the authenticated creator and uses the existing `phisk_video` post type and `phisk_age_rating` metadata.

## 3. Add thumbnail and publish

`POST /wp-json/phisk/v1/creator-studio/videos/{id}/publish`

Multipart form field: `thumbnail` (JPG, PNG, WebP or GIF).

The endpoint verifies ownership, validates the thumbnail, assigns it as the featured image, checks that the details are complete, and publishes the existing draft. It returns the canonical video URL and publication message.

## Notes

- This API does not create a parallel video library or storage configuration.
- Existing Publit.io/WordPress storage settings are reused.
- Existing strike/publishing restrictions, channel requirement, aspect-ratio policy, post author, metadata and notification publication hooks remain in effect.
- Upload size/time limits are still governed by the web server, PHP (`upload_max_filesize`, `post_max_size`, execution limits), and the configured video host. Large uploads should be tested on the production VPS before broad rollout.
- Native upload is direct file upload; the website's optional YouTube ownership-confirmed import remains a separate workflow for now.
