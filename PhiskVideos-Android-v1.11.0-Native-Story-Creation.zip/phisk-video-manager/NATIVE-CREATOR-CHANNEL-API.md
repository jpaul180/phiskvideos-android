# Native Creator Channel API (v1.15.0)

All endpoints use the existing native app bearer session and require HTTPS. Send `Authorization: Bearer <app_access_token>`.

## Creator profile
`GET /wp-json/phisk/v1/creators/{user_id}`

Returns `id`, `name`, `username`, `description`, `avatar_url`, `cover_url`, `profile_url`, `subscriber_count`, `subscribed`, `is_owner`, `has_channel`, `restricted`, and `can_edit`. A missing or unavailable channel returns 404.

## Published videos
`GET /wp-json/phisk/v1/creators/{user_id}/videos?page=1&per_page=10`

Returns `items` using the existing native watch video-card schema, plus `page`, `per_page`, `total`, `total_pages`, and `has_more`. `per_page` is capped at 20.

## Published Stories
`GET /wp-json/phisk/v1/creators/{user_id}/stories?page=1&per_page=10`

Returns published Story posts authored by the creator and marked with `_phisk_article_gallery_ids`, with `id`, `title`, `excerpt`, `permalink`, `thumbnail_url`, `published_at`, and `type`. Pagination fields match the videos endpoint.

## Subscribe / unsubscribe
`POST /wp-json/phisk/v1/creators/{user_id}/subscribe` with JSON body `{"action":"subscribe"}` or `{"action":"unsubscribe"}`. `toggle` is also accepted. Returns `subscribed` and `subscriber_count`. The endpoint writes to the existing `phisk_following` and `phisk_subscriber_count` user metadata, keeping website and app subscriptions aligned. Self-subscription is rejected.
