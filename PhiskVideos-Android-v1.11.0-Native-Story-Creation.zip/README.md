# PhiskVideos Android 1.11.0 — Native Story Creation

This release adds Stage 4.6 Native Story Creation while preserving the completed Stage 4.5 Native Video Upload workflow.

This source archive contains the staged native PhiskVideos Android app through Stage 4.6, including the native Homepage, Watch Page, Creator Channel, Creator Studio and Video Upload workflows.

## Included
- Native watch screen opened by video ID from the native homepage.
- Sticky 16:9 player dock while watch details scroll beneath it.
- Native Media3/ExoPlayer playback for supported direct HTTPS media URLs.
- YouTube playback through the official YouTube embedded player (no stream extraction).
- Video title, views/date, creator information, description expand/collapse.
- Related-video list and authenticated comment loading/submission.
- Persistent native bottom navigation and return-to-feed behavior.

## Required WordPress plugin
Install and activate **Phisk Video Manager v1.18.0** before testing this Android build. It includes the native Watch, Creator Channel, Creator Studio, Video Upload and Native Story Creation APIs. The app uses:
- `GET /wp-json/phisk/v1/videos/{id}`
- `GET /wp-json/phisk/v1/videos/{id}/related`
- `GET /wp-json/phisk/v1/videos/{id}/comments`
- `POST /wp-json/phisk/v1/videos/{id}/comments`

Requests use the existing native app bearer token. The app must be signed in.

## Build
Use the accompanying `android.yml` GitHub Actions workflow. Upload this archive to the repository root, then replace `.github/workflows/android.yml` with the accompanying workflow file and run the Android build workflow.

## Current scope note
Like toggling, real subscription toggling, threaded reply retrieval/reply UI, and direct integration with the existing offline-download manager are not yet connected because the current APIs do not expose those operations. Their visible controls are marked as not yet available rather than pretending to perform the action. YouTube videos are played using the official embedded player; direct HTTPS media uses ExoPlayer.


## Stage 4.3 — Native Creator Channel (v1.9.0)

- Adds the native Creator Channel activity with owner-aware Edit Channel / Creator Studio controls.
- Adds Videos and Stories tabs with 10-item pagination.
- Creator avatars and creator controls on the native homepage and watch page open the native channel screen.
- Requires Phisk Video Manager v1.15.0 for the `/wp-json/phisk/v1/creators/` endpoints.
- The API reuses existing `phisk_following`, `phisk_subscriber_count`, channel metadata, published `phisk_video` posts, and published Story posts.


Creator Studio is now a native Android screen. It reads creator analytics, the existing monetization ledger, eligibility, payout availability, and top videos from the authenticated Phisk Video Manager API. The Upload Video shortcut now opens the native uploader; Story writing now opens the native Story composer added in Stage 4.6.


Native Creator Studio (v1.9.0) is available from the owner controls on the Native Creator Channel page. It displays the existing creator analytics, vertical-bar performance chart with 7/30/90/12-month ranges, earnings summary, monetization status and eligibility, payout request controls, top videos, and shortcuts. Upload Video is now native; Story writing now opens the native Story composer in Android v1.11.0.

## Stage 4.5 — Native Video Upload (Android v1.10.0)

- Adds a native video upload screen launched from the Native Creator Studio.
- Supports selecting a local video and thumbnail, entering a title/description, and setting the audience declaration.
- Shows upload progress and publishes through authenticated Phisk Video Manager REST endpoints.
- Reuses the existing `phisk_video` post type, Publit.io setting (when enabled) or WordPress media storage, creator-channel checks, strike restrictions, landscape 16:9/21:9 validation, featured thumbnail and normal WordPress publication hooks.
- Requires Phisk Video Manager v1.18.0. See `phisk-video-manager/NATIVE-VIDEO-UPLOAD-API.md`.
- Upload and publishing must be tested against the live VPS because PHP/web-server upload limits still apply.


## Stage 4.6 — Native Story Creation (Android v1.11.0)

- Adds a native Story composer launched from the Native Creator Studio.
- Loads the existing Story interest categories from WordPress.
- Supports selecting multiple JPG, PNG, WebP or GIF images from device storage, previewing them, and removing selections before submission.
- Uploads images sequentially with progress feedback and retains successfully uploaded attachment IDs during the current composer session so a failed submission can be retried without uploading those images again.
- Supports Story title, interest, Story text, optional short introduction, Post Story and Save Draft.
- The first selected image becomes the Story cover.
- Uses the existing WordPress Story post model, taxonomy, gallery metadata, creator-channel access checks, account-strike restrictions and automatic-approval setting.
- Requires Phisk Video Manager v1.18.0. See `phisk-video-manager/NATIVE-STORY-CREATION-API.md`.
- Server-side integration and real-device publishing still require testing against the live VPS.
