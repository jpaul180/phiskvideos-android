<?php
/**
 * Plugin Name: Phisk Auth
 * Description: Professional front-end login, registration and logout experience for Phisk sites.
 * Version: 1.2.4
 * Author: Phisk
 * Text Domain: phisk-auth
 */
if (!defined('ABSPATH')) exit;

final class Phisk_Auth_Plugin {
    const VERSION = '1.2.4';
    public function __construct() {
        add_action('wp_enqueue_scripts', [$this, 'assets']);
        add_shortcode('phisk_auth', [$this, 'shortcode']);
        add_shortcode('phisk_login_button', [$this, 'login_button']);
        add_shortcode('phisk_restrict', [$this, 'restrict_shortcode']);
        add_action('init', [$this, 'handle_forms']);
        add_action('login_init', [$this, 'normalize_phone_login']);
        add_action('wp_login_failed', [$this, 'handle_login_failed'], 10, 2);
        add_filter('login_redirect', [$this, 'redirect_to_user_channel_after_login'], 10, 3);
        add_action('wp_footer', [$this, 'auto_modal'], 99);
        add_action('wp_ajax_nopriv_phisk_firebase_login', [$this, 'firebase_login']);
        add_action('wp_ajax_phisk_firebase_login', [$this, 'firebase_login']);
        add_action('rest_api_init', [$this, 'register_mobile_google_route']);
    }

    public function assets() {
        wp_register_style('phisk-auth', plugin_dir_url(__FILE__) . 'assets/phisk-auth.css', [], self::VERSION);
        wp_register_script('phisk-auth', plugin_dir_url(__FILE__) . 'assets/phisk-auth.js', [], self::VERSION, true);
        wp_localize_script('phisk-auth', 'PhiskAuth', [
            'loginUrl' => esc_url_raw(add_query_arg('phisk_auth', 'login', home_url('/'))),
            'loggedIn' => is_user_logged_in(),
            'assetUrl' => esc_url_raw(plugin_dir_url(__FILE__) . 'assets/'),
            'firebase' => [
                'apiKey' => 'AIzaSyAh0l5fo0O3k49VecgFgUFnLuobR3Cva44',
                'authDomain' => 'phiskvideos.firebaseapp.com',
                'projectId' => 'phiskvideos',
                'storageBucket' => 'phiskvideos.firebasestorage.app',
                'messagingSenderId' => '637988557537',
                'appId' => '1:637988557537:web:97b4e9415aa66450425da0',
            ],
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('phisk_firebase_login'),
        ]);
        $auth_requested = isset($_GET['phisk_auth']) && in_array(sanitize_key(wp_unslash($_GET['phisk_auth'])), ['login','register'], true);
        $registration_success = isset($_GET['phisk_auth_message']) && sanitize_key(wp_unslash($_GET['phisk_auth_message'])) === 'registered_success';
        if (!is_user_logged_in() || $auth_requested || $registration_success) {
            wp_enqueue_style('phisk-auth');
            wp_enqueue_script('phisk-auth');
        }
    }

    private function enqueue() {
        wp_enqueue_style('phisk-auth');
        wp_enqueue_script('phisk-auth');
    }

    public function shortcode($atts = []) {
        $atts = shortcode_atts(['open' => ''], $atts, 'phisk_auth');
        $open = in_array(sanitize_key($atts['open']), ['login', 'register'], true) ? sanitize_key($atts['open']) : '';
        $this->enqueue();
        if (is_user_logged_in()) {
            $user = wp_get_current_user();
            $logout = wp_logout_url($this->current_url());
            return '<div class="phisk-auth-account"><span class="phisk-auth-account-name">' . esc_html($user->display_name) . '</span><a class="phisk-auth-logout" href="' . esc_url($logout) . '">Log out</a></div>';
        }
        return $this->render_launcher($open);
    }

    public function login_button($atts = []) {
        $this->enqueue();
        if (is_user_logged_in()) {
            return '<a class="phisk-auth-trigger" href="' . esc_url(wp_logout_url($this->current_url())) . '">Log out</a>';
        }
        return '<button type="button" class="phisk-auth-trigger" data-phisk-auth-open="login">Log in</button>';
    }

    private function render_launcher($open_tab = '') {
        ob_start(); ?>
        <div class="phisk-auth-launcher">
            <button type="button" class="phisk-auth-trigger" data-phisk-auth-open="login">Login/Sign up</button>
        </div>
        <?php echo $this->modal_markup($open_tab); return ob_get_clean();
    }

    private $modal_rendered = false;
    private function modal_markup($open_tab = '') {
        $this->modal_rendered = true;
        ob_start(); ?>
        <div class="phisk-auth-overlay" data-phisk-auth-overlay<?php echo $open_tab ? ' data-phisk-auth-auto-open="' . esc_attr($open_tab) . '"' : ''; ?> aria-hidden="true">
          <section class="phisk-auth-modal" role="dialog" aria-modal="true" aria-labelledby="phisk-auth-title" tabindex="-1">
            <button type="button" class="phisk-auth-close" data-phisk-auth-close aria-label="Close dialog">Close</button>
            <div class="phisk-auth-mark" aria-hidden="true">P</div>
            <div class="phisk-auth-heading">
              <p class="phisk-auth-eyebrow">WELCOME TO PHISK</p>
              <h2 id="phisk-auth-title">Welcome back.</h2>
              <p class="phisk-auth-subtitle">Log in to continue watching and connect with creators.</p>
            </div>
            <div class="phisk-auth-tabs" role="tablist" aria-label="Account access">
              <button type="button" class="is-active" data-phisk-auth-tab="login" role="tab" aria-selected="true">Log in</button>
              <button type="button" data-phisk-auth-tab="register" role="tab" aria-selected="false">Create account</button>
            </div>
            <div class="phisk-auth-notice" data-phisk-auth-notice role="status" aria-live="polite"></div>
            <form class="phisk-auth-form is-active" data-phisk-auth-form="login" method="post" action="<?php echo esc_url(site_url('wp-login.php', 'login_post')); ?>">
              <input type="hidden" name="redirect_to" value="<?php echo esc_url($this->clean_redirect_url()); ?>">
              <label for="phisk-auth-identity">Username, email or phone number</label>
              <input id="phisk-auth-identity" name="log" type="text" autocomplete="username" placeholder="Enter username, email or phone" required>
              <div class="phisk-auth-password-label"><label for="phisk-auth-password">Password</label><a href="<?php echo esc_url(wp_lostpassword_url($this->current_url())); ?>">Forgot password?</a></div>
              <div class="phisk-auth-password-wrap">
                <input id="phisk-auth-password" name="pwd" type="password" autocomplete="current-password" placeholder="Enter your password" required>
                <button type="button" class="phisk-auth-eye" data-phisk-auth-toggle="phisk-auth-password" aria-label="Show password" aria-pressed="false">
                  <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>
                </button>
              </div>
              <input type="hidden" name="rememberme" value="forever">
              <button class="phisk-auth-submit" type="submit">Log in <span aria-hidden="true">→</span></button>
            </form>
            <form class="phisk-auth-form" data-phisk-auth-form="register" method="post">
              <input type="hidden" name="phisk_auth_action" value="register">
              <input type="hidden" name="redirect_to" value="<?php echo esc_url($this->current_url()); ?>">
              <?php wp_nonce_field('phisk_auth_register', 'phisk_auth_nonce'); ?>
              <label for="phisk-auth-username">Choose a username</label>
              <input id="phisk-auth-username" name="username" type="text" autocomplete="username" autocapitalize="none" spellcheck="false" pattern="[A-Za-z0-9_\\-]+" minlength="3" maxlength="60" placeholder="Choose your own username" required>
              <p class="phisk-auth-field-help">Use at least 3 letters or numbers. You can log in with your email too.</p>
              <label for="phisk-auth-email">Email address</label>
              <input id="phisk-auth-email" name="email" type="email" autocomplete="email" placeholder="you@example.com" required>
              <label for="phisk-auth-reg-password">Create password</label>
              <div class="phisk-auth-password-wrap">
                <input id="phisk-auth-reg-password" name="password" type="password" autocomplete="new-password" minlength="8" placeholder="At least 8 characters" required>
                <button type="button" class="phisk-auth-eye" data-phisk-auth-toggle="phisk-auth-reg-password" aria-label="Show password" aria-pressed="false">
                  <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>
                </button>
              </div>
              <button class="phisk-auth-submit" type="submit">Create account <span aria-hidden="true">→</span></button>
            </form>
            <div class="phisk-auth-divider"><span>More ways to join</span></div>
            <div class="phisk-auth-future-options">
              <button type="button" class="phisk-auth-future phisk-auth-google-button" data-phisk-google-login><span class="phisk-auth-google">G</span> Continue with Google</button>
              <button type="button" class="phisk-auth-future" disabled title="Phone OTP integration can be connected here"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="6" y="2.5" width="12" height="19" rx="2"/><path d="M10 18.5h4"/></svg> Continue with phone OTP <span class="phisk-auth-soon">Soon</span></button>
            </div>
            <p class="phisk-auth-terms">By continuing, you agree to our site's terms and privacy policy.</p>
          </section>
        </div>
        <?php return ob_get_clean();
    }

    public function restrict_shortcode($atts, $content = null) {
        $this->enqueue();
        if (is_user_logged_in()) return do_shortcode($content ?? '');
        return '<div class="phisk-auth-restricted" data-phisk-auth-restricted><p>Log in or create an account to continue.</p>' . $this->render_launcher('login') . '</div>';
    }

    public function auto_modal() {
        if (is_user_logged_in()) return;
        $requested = isset($_GET['phisk_auth']) && in_array(sanitize_key(wp_unslash($_GET['phisk_auth'])), ['login','register'], true);
        if (!$requested) return;
        $this->enqueue();
        if (!$this->modal_rendered) echo $this->modal_markup(sanitize_key(wp_unslash($_GET['phisk_auth'])));
    }

    /** Verify a Firebase ID token against Google's published Secure Token certificates. */
    private function verify_firebase_id_token($jwt) {
        $parts = explode('.', (string) $jwt);
        if (count($parts) !== 3) return new WP_Error('invalid_token', 'Invalid Google sign-in token.');
        $header = json_decode(base64_decode(strtr($parts[0], '-_', '+/')), true);
        $claims = json_decode(base64_decode(strtr($parts[1], '-_', '+/')), true);
        if (!is_array($header) || !is_array($claims) || empty($header['kid']) || ($header['alg'] ?? '') !== 'RS256') return new WP_Error('invalid_token', 'Invalid Google sign-in token.');
        $cache_key = 'phisk_firebase_certs_v1';
        $certs = get_transient($cache_key);
        if (!is_array($certs)) {
            $response = wp_remote_get('https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com', ['timeout' => 10]);
            if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) return new WP_Error('verification_unavailable', 'Google verification is temporarily unavailable. Please try again.');
            $certs = json_decode(wp_remote_retrieve_body($response), true);
            if (!is_array($certs)) return new WP_Error('verification_unavailable', 'Could not verify Google sign-in.');
            set_transient($cache_key, $certs, 3600);
        }
        if (empty($certs[$header['kid']])) return new WP_Error('invalid_token', 'Google sign-in token has expired or is invalid.');
        $signature = base64_decode(strtr($parts[2], '-_', '+/'));
        $verified = openssl_verify($parts[0] . '.' . $parts[1], $signature, $certs[$header['kid']], OPENSSL_ALGO_SHA256);
        if ($verified !== 1) return new WP_Error('invalid_token', 'Google sign-in token could not be verified.');
        $now = time();
        if (($claims['aud'] ?? '') !== 'phiskvideos' || ($claims['iss'] ?? '') !== 'https://securetoken.google.com/phiskvideos' || empty($claims['sub']) || strlen($claims['sub']) > 128 || (int)($claims['exp'] ?? 0) <= $now || (int)($claims['iat'] ?? 0) > $now + 60 || (int)($claims['iat'] ?? 0) < $now - 3600 || empty($claims['email']) || !is_email($claims['email']) || empty($claims['email_verified'])) {
            return new WP_Error('invalid_claims', 'Your Google account could not be verified. Please try again.');
        }
        return $claims;
    }

    /** Native Android exchange: Firebase ID token -> WordPress auth cookies. */
    public function register_mobile_google_route() {
        register_rest_route('phisk-auth/v1', '/google-login', [
            'methods' => 'POST',
            'callback' => [$this, 'mobile_google_login'],
            'permission_callback' => '__return_true',
        ]);
    }

    /** Resolve or create the WordPress account associated with a verified Firebase identity. */
    private function get_or_create_firebase_user($claims) {
        $email = sanitize_email($claims['email']);
        $linked_users = get_users(['meta_key' => 'phisk_firebase_uid', 'meta_value' => sanitize_text_field($claims['sub']), 'number' => 1, 'fields' => 'ids']);
        $user = !empty($linked_users) ? get_user_by('id', (int) $linked_users[0]) : get_user_by('email', $email);
        if (!$user) {
            $base = sanitize_user(strtok($email, '@'), true);
            if (strlen($base) < 3) $base = 'phiskuser';
            $login = substr($base, 0, 35);
            do { $login = substr($base, 0, 35) . '_' . wp_generate_password(6, false, false); } while (username_exists($login));
            $password = wp_generate_password(48, true, true);
            $display = sanitize_text_field($claims['name'] ?? $base);
            $user_id = wp_create_user($login, $password, $email);
            if (is_wp_error($user_id)) return new WP_Error('account_create_failed', 'We could not create your Phisk account. Please contact support.', ['status' => 500]);
            wp_update_user(['ID' => $user_id, 'display_name' => $display ?: $base, 'nickname' => $display ?: $base, 'first_name' => sanitize_text_field($claims['given_name'] ?? ''), 'last_name' => sanitize_text_field($claims['family_name'] ?? '')]);
            update_user_meta($user_id, 'phisk_firebase_uid', sanitize_text_field($claims['sub']));
            update_user_meta($user_id, 'phisk_auth_method', 'google');
            update_user_meta($user_id, 'phisk_password_set', 0);
            $public_name = sanitize_title($display ?: $base);
            if (!$public_name) $public_name = 'creator';
            $candidate = $public_name; $suffix = 2;
            while (get_users(['meta_key' => 'phisk_username', 'meta_value' => $candidate, 'number' => 1, 'fields' => 'ids'])) { $candidate = $public_name . $suffix; $suffix++; }
            update_user_meta($user_id, 'phisk_username', $candidate);
            do_action('phisk_auth_user_registered', $user_id, ['registration_method' => 'google']);
            $user = get_user_by('id', $user_id);
        } else {
            // A verified Firebase email may be linked to an existing WordPress account.
            update_user_meta($user->ID, 'phisk_firebase_uid', sanitize_text_field($claims['sub']));
        }
        if (!$user || is_wp_error($user)) return new WP_Error('account_lookup_failed', 'Unable to sign in to your Phisk account.', ['status' => 500]);
        return $user;
    }

    private function establish_firebase_wordpress_session($user) {
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID, true, is_ssl());
        do_action('wp_login', $user->user_login, $user);
    }

    public function mobile_google_login($request) {
        $token = trim((string) $request->get_param('id_token'));
        if (!$token || strlen($token) > 12000) return new WP_Error('invalid_token', 'Missing or invalid Google sign-in token.', ['status' => 400]);
        $claims = $this->verify_firebase_id_token($token);
        if (is_wp_error($claims)) return new WP_Error($claims->get_error_code(), $claims->get_error_message(), ['status' => 401]);
        $user = $this->get_or_create_firebase_user($claims);
        if (is_wp_error($user)) return $user;
        $this->establish_firebase_wordpress_session($user);
        return new WP_REST_Response([
            'success' => true,
            'message' => 'Signed in successfully.',
            'user' => ['id' => (int) $user->ID, 'display_name' => $user->display_name, 'email' => $user->user_email],
        ], 200);
    }

    public function firebase_login() {
        check_ajax_referer('phisk_firebase_login', 'nonce');
        $token = isset($_POST['id_token']) ? trim(wp_unslash($_POST['id_token'])) : '';
        if (!$token || strlen($token) > 12000) wp_send_json_error(['message' => 'Missing or invalid Google sign-in token.'], 400);
        $claims = $this->verify_firebase_id_token($token);
        if (is_wp_error($claims)) wp_send_json_error(['message' => $claims->get_error_message()], 401);
        $user = $this->get_or_create_firebase_user($claims);
        if (is_wp_error($user)) wp_send_json_error(['message' => $user->get_error_message()], 500);
        $this->establish_firebase_wordpress_session($user);
        $redirect = isset($_POST['redirect_to']) ? esc_url_raw(wp_unslash($_POST['redirect_to'])) : home_url('/');
        $redirect = wp_validate_redirect($redirect, home_url('/'));
        if (isset($_POST['channel_redirect']) && $_POST['channel_redirect'] === '1' && !empty($user->user_nicename)) $redirect = home_url('/' . rawurlencode($user->user_nicename) . '/');
        wp_send_json_success(['redirect' => $redirect]);
    }

    public function normalize_phone_login() {
        if (empty($_SERVER['REQUEST_METHOD']) || strtoupper($_SERVER['REQUEST_METHOD']) !== 'POST') return;
        if (!isset($_POST['log']) || !is_string($_POST['log'])) return;
        $identity = trim(wp_unslash($_POST['log']));
        if (!preg_match('/^[+\d\s().-]{7,}$/', $identity)) return;
        $phone = preg_replace('/[^\d+]/', '', $identity);
        $users = get_users(['number' => 1, 'meta_query' => ['relation' => 'OR',
            ['key' => 'phisk_phone', 'value' => $phone, 'compare' => '='],
            ['key' => 'billing_phone', 'value' => $phone, 'compare' => '='],
            ['key' => 'phone', 'value' => $phone, 'compare' => '='],
        ]]);
        if (!empty($users)) $_POST['log'] = $users[0]->user_login;
    }

    public function handle_forms() {
        if (empty($_POST['phisk_auth_action'])) return;
        $action = sanitize_key(wp_unslash($_POST['phisk_auth_action']));
        if (!in_array($action, ['login','register'], true)) return;
        $nonce = isset($_POST['phisk_auth_nonce']) ? sanitize_text_field(wp_unslash($_POST['phisk_auth_nonce'])) : '';
        if (!wp_verify_nonce($nonce, 'phisk_auth_' . $action)) {
            $this->redirect_with_message('security');
        }
        // Login submissions go directly to WordPress core at wp-login.php.
        if ($action === 'login') return;
        $username_raw = isset($_POST['username']) ? trim(wp_unslash($_POST['username'])) : '';
        $username = sanitize_user($username_raw, true);
        // Display name is optional at signup; default to username for public identity.
        $display = isset($_POST['display_name']) ? sanitize_text_field(wp_unslash($_POST['display_name'])) : '';
        if ($display === '') $display = $username;
        $email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
        // Phone numbers are no longer collected during signup. Existing phone-login support remains intact.
        $phone = '';
        $password = isset($_POST['password']) ? (string) wp_unslash($_POST['password']) : '';
        if (!$username || strlen($username) < 3 || $username !== $username_raw || !preg_match('/^[A-Za-z0-9_-]+$/', $username) || !is_email($email) || strlen($password) < 8) $this->redirect_with_message('register_missing');
        if (username_exists($username)) $this->redirect_with_message('username_exists');
        if (email_exists($email)) $this->redirect_with_message('email_exists');
        $user_id = wp_create_user($username, $password, $email);
        if (is_wp_error($user_id)) $this->redirect_with_message('register_error');
        // Ensure WordPress has a non-empty public display name and nickname.
        wp_update_user(['ID' => $user_id, 'display_name' => $display, 'nickname' => $display]);
        do_action('phisk_auth_user_registered', $user_id, ['phone' => $phone]);

        // Registration creates the account but does not sign the user in.
        // Ask the new member to log in and include their chosen username.
        $target = $this->safe_redirect_target();
        $target = add_query_arg([
            'phisk_auth' => 'login',
            'phisk_auth_message' => 'registered_success',
            'phisk_auth_username' => $username,
        ], $target);
        wp_safe_redirect($target);
        exit;
    }

    public function handle_login_failed($username, $error = null) {
        // Return modal-based login attempts to their originating page with a clear error.
        $target = '';
        if (!empty($_REQUEST['redirect_to'])) {
            $target = esc_url_raw(wp_unslash($_REQUEST['redirect_to']));
        }
        if (!$target) $target = wp_get_referer();
        $target = wp_validate_redirect($target, home_url('/'));
        $target = remove_query_arg(['phisk_auth_message', 'phisk_auth_channel_redirect'], $target);
        $target = add_query_arg(['phisk_auth' => 'login', 'phisk_auth_message' => 'invalid'], $target);
        wp_safe_redirect($target);
        exit;
    }

    private function redirect_with_message($message) {
        $target = $this->current_url();
        $target = remove_query_arg(['phisk_auth', 'phisk_auth_message'], $target);
        $tab = (isset($_POST['phisk_auth_action']) && sanitize_key(wp_unslash($_POST['phisk_auth_action'])) === 'register') ? 'register' : 'login';
        wp_safe_redirect(add_query_arg(['phisk_auth' => $tab, 'phisk_auth_message' => $message], $target));
        exit;
    }
    private function safe_redirect_target() {
        $target = isset($_POST['redirect_to']) ? esc_url_raw(wp_unslash($_POST['redirect_to'])) : '';
        if (!$target && isset($_GET['redirect_to'])) $target = esc_url_raw(wp_unslash($_GET['redirect_to']));
        $target = remove_query_arg(['phisk_auth', 'phisk_auth_message'], $target);
        // Never send a successful login back to the auth trigger URL; prefer the site home if empty/invalid.
        $fallback = home_url('/');
        $target = wp_validate_redirect($target, $fallback);
        if (!$target) $target = $fallback;
        return $target;
    }
    public function redirect_to_user_channel_after_login($redirect_to, $requested_redirect_to, $user) {
        // Only override redirects initiated by the Phisk Auth front-end login form.
        if (!is_object($user) || empty($user->ID) || !($user instanceof WP_User)) return $redirect_to;
        if (!$requested_redirect_to || !wp_parse_url($requested_redirect_to, PHP_URL_QUERY)) return $redirect_to;
        parse_str(wp_parse_url($requested_redirect_to, PHP_URL_QUERY), $redirect_args);
        if (empty($redirect_args['phisk_auth_channel_redirect'])) return $redirect_to;

        // PhiskVideoManager uses each WordPress user's nicename as their public channel URL.
        if (!empty($user->user_nicename)) {
            return home_url('/' . rawurlencode($user->user_nicename) . '/');
        }

        // Safe fallback to the configured dashboard page with the user ID.
        $page_id = absint(get_option('phiskvideos_dashboard_page_id'));
        $fallback = $page_id ? get_permalink($page_id) : home_url('/');
        return add_query_arg('phisk_profile_user', absint($user->ID), $fallback);
    }

    private function clean_redirect_url() {
        $url = $this->current_url();
        $url = remove_query_arg(['phisk_auth', 'phisk_auth_message'], $url);
        // Marker lets the login_redirect filter identify this front-end login flow only.
        return add_query_arg('phisk_auth_channel_redirect', '1', $url);
    }
    private function current_url() {
        $scheme = is_ssl() ? 'https://' : 'http://';
        $host = isset($_SERVER['HTTP_HOST']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_HOST'])) : parse_url(home_url(), PHP_URL_HOST);
        $uri = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '/';
        return esc_url_raw($scheme . $host . $uri);
    }
}
new Phisk_Auth_Plugin();
