=== Phisk Auth ===
Contributors: phisk
Tags: login, registration, modal, authentication
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 1.2.2
License: GPLv2 or later

A clean, responsive front-end login and registration experience for Phisk sites, with restrained violet styling and lightweight CSS/SVG illustrations.

== Changelog ==

= 1.2.2 =
* Redirect successful logins from the Phisk Auth front-end login form to the current user's PhiskVideos channel URL.
* Preserve existing authentication flows and avoid changing redirects for unrelated WordPress login forms.

== Shortcodes ==
[phisk_auth] — Login and sign-up buttons plus modal. When logged in, shows the current user's name and logout link.
[phisk_login_button] — A single login button (or logout link when logged in).
[phisk_restrict]Members-only content here[/phisk_restrict] — Shows content to logged-in users and opens the login modal for logged-out visitors.

Login is processed by the native WordPress wp-login.php endpoint and accepts the WordPress username, email, or phone numbers saved to phisk_phone, billing_phone, or phone user meta. Registration is handled by Phisk Auth. Registration creates a WordPress user without collecting a phone number. Existing phone-login support remains available for phone numbers already saved to phisk_phone, billing_phone, or phone user meta. If an email-based username is already taken, the plugin automatically generates a unique username and displays that exact username in the registration-success notification. Failed logins return to the modal with a clear message; WordPress username and email login are supported.

Google OAuth and phone OTP are intentionally shown as disabled future integration slots; no provider integration or SMS verification is active in this version.

== Notes ==
Use HTTPS on production sites. WordPress authentication and nonce validation are used for form processing.

Integration note: [phisk_auth open="login"] renders the modal and opens it automatically. The Phisk Videos Maker integration uses this on guest-only submission, My Videos, and Channel views.


Version 1.0.6: Fixed native login handoff by removing the test-cookie flag from custom login submissions. WordPress should only run that test when the native login page has set its test cookie.

Version 1.1.6: Removed the phone-number field from registration while preserving existing phone-based login compatibility.

Version 1.1.9: Removed the decorative logged-out page illustration and gateway message injection. Existing login/register modal behavior and shortcodes are preserved.


Version 1.2.2
- Added Firebase Google Sign-In using Firebase project phiskvideos.
- Server verifies Firebase ID tokens against Google Secure Token certificates before creating/logging in WordPress users.
- Google-created accounts receive a generated internal WordPress username and a separate phisk_username user meta value.

Setup requirements: ensure videos.phisk.co is an authorized Firebase Authentication domain and Google provider is enabled. The WordPress server must allow outbound HTTPS requests to Google certificate endpoints and have OpenSSL enabled.


= 1.2.4 =
* Added a native Android Google sign-in REST endpoint that validates Firebase ID tokens and issues a WordPress login session.
* Preserved the existing website Google sign-in AJAX endpoint and front-end flow.
