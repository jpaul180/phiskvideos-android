(function(){
'use strict';
var activeOverlay=null,previousFocus=null;
function noticeFromQuery(overlay){
 var params=new URLSearchParams(window.location.search), code=params.get('phisk_auth_message');
 if(!code)return;
 var messages={invalid:'Those login details did not match. Please check your username, email or phone number and password.',missing:'Enter your username/email/phone and password.',security:'Your session expired. Please try again.',register_missing:'Please check your details. Choose a username with at least 3 letters, numbers, underscores or hyphens, and use a password of at least 8 characters.',username_exists:'That username is already taken. Please choose another one.',email_exists:'An account with that email already exists. Try logging in instead.',register_error:'We could not create your account. Please try again.'};
 var n=overlay.querySelector('[data-phisk-auth-notice]');
 if(n&&messages[code]){n.textContent=messages[code];n.classList.add('is-visible');}
}
function setTab(overlay,tab){
 overlay.querySelectorAll('[data-phisk-auth-tab]').forEach(function(b){var on=b.getAttribute('data-phisk-auth-tab')===tab;b.classList.toggle('is-active',on);b.setAttribute('aria-selected',on?'true':'false');});
 overlay.querySelectorAll('[data-phisk-auth-form]').forEach(function(f){f.classList.toggle('is-active',f.getAttribute('data-phisk-auth-form')===tab);});
 var title=overlay.querySelector('#phisk-auth-title'),subtitle=overlay.querySelector('.phisk-auth-subtitle');
 if(title)title.textContent=tab==='register'?'Create your account.':'Welcome back.';
 if(subtitle)subtitle.textContent=tab==='register'?'Join Phisk to watch, share and connect with creators.':'Log in to continue watching and connect with creators.';
}
function open(tab){
 var overlays=document.querySelectorAll('[data-phisk-auth-overlay]');
 if(!overlays.length)return;
 var overlay=overlays[overlays.length-1];activeOverlay=overlay;previousFocus=document.activeElement;
 setTab(overlay,tab||'login');overlay.classList.add('is-open');overlay.setAttribute('aria-hidden','false');document.documentElement.classList.add('phisk-auth-no-scroll');document.body.style.overflow='hidden';
 noticeFromQuery(overlay);
 var field=overlay.querySelector(tab==='register'?'[data-phisk-auth-form="register"] input:not([type="hidden"])':'#phisk-auth-identity');
 window.setTimeout(function(){if(field)field.focus({preventScroll:true});},80);
}
function close(){
 if(!activeOverlay)return;
 activeOverlay.classList.remove('is-open');activeOverlay.setAttribute('aria-hidden','true');document.documentElement.classList.remove('phisk-auth-no-scroll');document.body.style.overflow='';
 if(previousFocus&&previousFocus.focus)previousFocus.focus();activeOverlay=null;
}
document.addEventListener('click',function(e){
 var openBtn=e.target.closest('[data-phisk-auth-open]');if(openBtn){e.preventDefault();open(openBtn.getAttribute('data-phisk-auth-open'));return;}
 var closeBtn=e.target.closest('[data-phisk-auth-close]');if(closeBtn){close();return;}
 var tab=e.target.closest('[data-phisk-auth-tab]');if(tab&&activeOverlay){setTab(activeOverlay,tab.getAttribute('data-phisk-auth-tab'));return;}
 var eye=e.target.closest('[data-phisk-auth-toggle]');if(eye){var input=document.getElementById(eye.getAttribute('data-phisk-auth-toggle'));if(input){var show=input.type==='password';input.type=show?'text':'password';eye.setAttribute('aria-label',show?'Hide password':'Show password');eye.setAttribute('aria-pressed',show?'true':'false');}return;}
 if(activeOverlay&&e.target===activeOverlay)close();
});
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&activeOverlay)close();if(e.key==='Tab'&&activeOverlay){var els=activeOverlay.querySelectorAll('button:not([disabled]),a[href],input:not([disabled])');if(!els.length)return;var first=els[0],last=els[els.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}});
window.PhiskAuthModal={open:open,close:close};

function initGoogleAuth(){
 var buttons=document.querySelectorAll('[data-phisk-google-login]');if(!buttons.length||!window.PhiskAuth||!PhiskAuth.firebase)return;
 function showError(message){var n=document.querySelector('[data-phisk-auth-notice]');if(n){n.textContent=message||'Google sign-in failed. Please try again.';n.classList.add('is-visible');}}
 buttons.forEach(function(button){button.addEventListener('click',function(){
  if(button.dataset.busy==='1')return;button.dataset.busy='1';button.disabled=true;var original=button.textContent;button.textContent='Connecting to Google…';
  function reset(){button.dataset.busy='0';button.disabled=false;button.textContent=original;}
  function loadSdk(){if(window.firebase&&firebase.auth)return Promise.resolve();return new Promise(function(resolve,reject){var script=document.createElement('script');script.src='https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js';script.onload=function(){var auth=document.createElement('script');auth.src='https://www.gstatic.com/firebasejs/10.12.2/firebase-auth-compat.js';auth.onload=resolve;auth.onerror=reject;document.head.appendChild(auth);};script.onerror=reject;document.head.appendChild(script);});}
  loadSdk().then(function(){if(!firebase.apps.length)firebase.initializeApp(PhiskAuth.firebase);var provider=new firebase.auth.GoogleAuthProvider();provider.setCustomParameters({prompt:'select_account'});return firebase.auth().signInWithPopup(provider);}).then(function(result){return result.user.getIdToken(true);}).then(function(idToken){var data=new FormData();data.append('action','phisk_firebase_login');data.append('nonce',PhiskAuth.nonce);data.append('id_token',idToken);data.append('redirect_to',window.location.href);data.append('channel_redirect',new URLSearchParams(window.location.search).get('phisk_auth_channel_redirect')==='1'?'1':'0');return fetch(PhiskAuth.ajaxUrl,{method:'POST',credentials:'same-origin',body:data}).then(function(r){return r.json();});}).then(function(response){if(!response||!response.success)throw new Error(response&&response.data&&response.data.message?response.data.message:'Could not complete Google sign-in.');window.location.href=response.data.redirect||window.location.href;}).catch(function(error){if(error&&error.code==='auth/popup-closed-by-user'){showError('Google sign-in was cancelled.');}else{showError(error&&error.message?error.message:'Google sign-in failed. Please try again.');}reset();});
 });});
}

document.addEventListener('DOMContentLoaded',function(){
 initGoogleAuth();
 var url=new URL(window.location.href),requested=url.searchParams.get('phisk_auth');
 var message=url.searchParams.get('phisk_auth_message');
 if(message==='registered_success'){
  var toast=document.createElement('div');
  toast.className='phisk-auth-success-toast';
  toast.setAttribute('role','status');
  toast.setAttribute('aria-live','polite');
  toast.innerHTML='<span class="phisk-auth-success-icon" aria-hidden="true">✓</span><span><strong>Welcome to Phisk!</strong><small></small></span><button type="button" aria-label="Dismiss notification">×</button>';
  var toastMessage=toast.querySelector('small');
  var registeredUsername=url.searchParams.get('phisk_auth_username')||'';
  toastMessage.textContent='Your account was created successfully. Please log in with username: '+registeredUsername+'.';
  document.body.appendChild(toast);
  toast.querySelector('button').addEventListener('click',function(){toast.remove();});
  window.setTimeout(function(){if(toast.parentNode)toast.classList.add('is-visible');},30);
  window.setTimeout(function(){if(toast.parentNode){toast.classList.remove('is-visible');window.setTimeout(function(){if(toast.parentNode)toast.remove();},300);}},6500);
  url.searchParams.delete('phisk_auth_message');
  url.searchParams.delete('phisk_auth_username');
  window.history.replaceState({},document.title,url.pathname+url.search+url.hash);
 }
 if(requested==='login'||requested==='register'){open(requested);return;}
 var autoOverlay=document.querySelector('[data-phisk-auth-overlay][data-phisk-auth-auto-open]');
 if(autoOverlay){open(autoOverlay.getAttribute('data-phisk-auth-auto-open')||'login');}
});
})();