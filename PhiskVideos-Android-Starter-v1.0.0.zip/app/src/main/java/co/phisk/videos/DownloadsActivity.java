package co.phisk.videos;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.VideoView;
import android.widget.MediaController;
import android.net.Uri;
import java.io.File;
import java.util.Arrays;

public class DownloadsActivity extends Activity {
    private LinearLayout list;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(18),dp(18),dp(18)); root.setBackgroundColor(Color.WHITE);
        TextView title = new TextView(this); title.setText("Downloads"); title.setTextColor(Color.BLACK); title.setTextSize(23); title.setTypeface(null,1); root.addView(title);
        TextView subtitle = new TextView(this); subtitle.setText("Videos saved on this device"); subtitle.setTextColor(Color.DKGRAY); subtitle.setTextSize(13); subtitle.setPadding(0,dp(4),0,dp(16)); root.addView(subtitle);
        list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); root.addView(list,new LinearLayout.LayoutParams(-1,-1));
        setContentView(root); refreshList();
    }
    private void refreshList() {
        list.removeAllViews(); File dir = new File(getFilesDir(),"downloads"); File[] files = dir.listFiles();
        if (files == null || files.length == 0) { TextView empty = new TextView(this); empty.setText("No downloaded videos yet."); empty.setTextColor(Color.GRAY); empty.setGravity(Gravity.CENTER); list.addView(empty,new LinearLayout.LayoutParams(-1,dp(180))); return; }
        Arrays.sort(files,(a,b)->Long.compare(b.lastModified(),a.lastModified()));
        for (File file : files) {
            if (!file.isFile() || file.getName().endsWith(".part")) continue;
            LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0,dp(10),0,dp(10));
            TextView name = new TextView(this); name.setText(file.getName().replaceFirst("^[0-9]+_", "")); name.setTextColor(Color.BLACK); name.setTextSize(14); name.setMaxLines(2); row.addView(name,new LinearLayout.LayoutParams(0,dp(52),1));
            TextView play = new TextView(this); play.setText("Play"); play.setTextColor(Color.rgb(124,58,237)); play.setTypeface(null,1); play.setPadding(dp(12),dp(12),dp(12),dp(12)); play.setOnClickListener(v->play(file)); row.addView(play);
            TextView delete = new TextView(this); delete.setText("Delete"); delete.setTextColor(Color.DKGRAY); delete.setPadding(dp(12),dp(12),0,dp(12)); delete.setOnClickListener(v->{file.delete();refreshList();}); row.addView(delete);
            list.addView(row); View divider = new View(this); divider.setBackgroundColor(0xFFEAEAEA); list.addView(divider,new LinearLayout.LayoutParams(-1,dp(1)));
        }
    }
    private void play(File file) {
        LinearLayout player = new LinearLayout(this); player.setOrientation(LinearLayout.VERTICAL); player.setPadding(dp(12),dp(12),dp(12),dp(12)); player.setBackgroundColor(Color.BLACK);
        VideoView video = new VideoView(this); player.addView(video,new LinearLayout.LayoutParams(-1,0,1));
        MediaController controls = new MediaController(this); controls.setAnchorView(video); video.setMediaController(controls); video.setVideoURI(Uri.fromFile(file)); video.start();
        setContentView(player);
    }
    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
}
