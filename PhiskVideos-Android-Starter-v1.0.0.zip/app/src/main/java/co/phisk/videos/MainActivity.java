package co.phisk.videos;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;
import android.webkit.JavascriptInterface;
import android.webkit.CookieManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.view.Gravity;
import android.view.ViewGroup;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import org.json.JSONObject;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String HOME = "https://videos.phisk.co/";
    private static final String SITE_HOST = "videos.phisk.co";
    private WebView web;
    private ProgressBar progress;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_REQUEST = 22;
    private final ExecutorService downloadExecutor = Executors.newSingleThreadExecutor();
    private static final String DOWNLOAD_CHANNEL = "phisk_video_downloads";
    private static final String PREFS = "phisk_download_metadata";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        FrameLayout frame = new FrameLayout(this);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.WHITE);
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100); progress.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.rgb(124,58,237)));
        root.addView(progress, new LinearLayout.LayoutParams(-1, 4));
        web = new WebView(this); root.addView(web, new LinearLayout.LayoutParams(-1,0,1));
        frame.addView(root, new FrameLayout.LayoutParams(-1,-1));

        setContentView(frame);
        createDownloadChannel();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 71);
        }

        WebSettings s = web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(true); s.setAllowFileAccess(false); s.setAllowContentAccess(true);
        s.setUserAgentString(s.getUserAgentString() + " PhiskVideosApp/1.1");
        CookieManager.getInstance().setAcceptCookie(true);
        web.addJavascriptInterface(new PhiskAppBridge(), "PhiskApp");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri=request.getUrl(); String scheme=uri.getScheme(); String host=uri.getHost();
                if ("https".equals(scheme) && SITE_HOST.equalsIgnoreCase(host) && "/downloads".equals(uri.getPath().replaceAll("/+$", ""))) {
                    startActivity(new Intent(MainActivity.this, DownloadsActivity.class)); return true;
                }
                if (("https".equals(scheme)) && host != null && (host.equals(SITE_HOST) || host.endsWith(".phisk.co"))) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch(Exception e) { Toast.makeText(MainActivity.this,"Cannot open link",Toast.LENGTH_SHORT).show(); }
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) { progress.setVisibility(View.GONE); }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int value) { progress.setVisibility(value == 100 ? View.GONE : View.VISIBLE); progress.setProgress(value); }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback=callback;
                try { startActivityForResult(params.createIntent(), FILE_REQUEST); return true; }
                catch(Exception e) { fileCallback=null; return false; }
            }
        });
        web.loadUrl(HOME);
    }

    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    private class PhiskAppBridge {
        @JavascriptInterface public void downloadVideo(int videoId, String nonce, String rawName, String title, String thumbnail, String channel) {
            if (videoId < 1 || nonce == null || nonce.length() < 8 || nonce.length() > 128) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Invalid download request", Toast.LENGTH_LONG).show()); return;
            }
            final String name = safeFilename(rawName);
            final String safeTitle = title == null || title.trim().isEmpty() ? name.replaceFirst("(?i)\\.(mp4|m4v|mov|webm|ogv)$", "") : title.trim();
            downloadExecutor.execute(() -> requestAuthorisedDownload(videoId, nonce, name, safeTitle, thumbnail, channel));
        }
        @JavascriptInterface public void openDownloads() {
            runOnUiThread(() -> startActivity(new Intent(MainActivity.this, DownloadsActivity.class)));
        }
    }

    private String safeFilename(String input) {
        String name = input == null ? "phisk-video.mp4" : input.replaceAll("[^A-Za-z0-9._ -]", "_").trim();
        if (name.isEmpty()) name = "phisk-video.mp4";
        if (!name.matches("(?i).*\\.(mp4|m4v|mov|webm|ogv)$")) name += ".mp4";
        return name;
    }

    private void requestAuthorisedDownload(int videoId, String nonce, String filename, String title, String thumbnail, String channel) {
        HttpURLConnection api = null;
        try {
            URL endpoint = new URL(HOME + "wp-admin/admin-ajax.php");
            api = (HttpURLConnection) endpoint.openConnection(); api.setRequestMethod("POST"); api.setDoOutput(true); api.setConnectTimeout(20000); api.setReadTimeout(30000);
            api.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            api.setRequestProperty("Accept", "application/json");
            String cookie = CookieManager.getInstance().getCookie(HOME); if (cookie != null) api.setRequestProperty("Cookie", cookie);
            String body = "action=phisk_get_video_download&video_id=" + videoId + "&nonce=" + URLEncoder.encode(nonce, "UTF-8");
            try (OutputStream out = api.getOutputStream()) { out.write(body.getBytes("UTF-8")); }
            int status = api.getResponseCode();
            InputStream responseStream = status >= 200 && status < 300 ? api.getInputStream() : api.getErrorStream();
            ByteArrayOutputStream responseBuffer = new ByteArrayOutputStream(); byte[] responseChunk = new byte[4096]; int responseRead; while ((responseRead = responseStream.read(responseChunk)) != -1) responseBuffer.write(responseChunk, 0, responseRead); responseStream.close(); byte[] responseBytes = responseBuffer.toByteArray();
            JSONObject response = new JSONObject(new String(responseBytes, "UTF-8"));
            if (!response.optBoolean("success")) {
                JSONObject data = response.optJSONObject("data"); String message = data == null ? "Download is not available." : data.optString("message", "Download is not available.");
                throw new Exception(message);
            }
            JSONObject data = response.getJSONObject("data"); String fileUrl = data.getString("url");
            Uri parsed = Uri.parse(fileUrl);
            if (!"https".equalsIgnoreCase(parsed.getScheme()) || parsed.getHost() == null || fileUrl.length() > 4096) throw new Exception("The server returned an invalid video URL.");
            downloadToPrivateStorage(fileUrl, filename, title, thumbnail, channel);
        } catch (Exception error) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Download failed: " + error.getMessage(), Toast.LENGTH_LONG).show());
        } finally { if (api != null) api.disconnect(); }
    }

    private void downloadToPrivateStorage(String urlString, String filename, String title, String thumbnail, String channel) {
        HttpURLConnection connection = null;
        FileOutputStream output = null;
        File partial = null;
        int notificationId = (int)(System.currentTimeMillis() & 0x7fffffff);
        createDownloadChannel();
        NotificationManager manager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        try {
            File directory = new File(getFilesDir(), "downloads");
            if (!directory.exists() && !directory.mkdirs()) throw new Exception("Could not create private download folder");
            File destination = new File(directory, System.currentTimeMillis() + "_" + filename);
            partial = new File(directory, destination.getName() + ".part");
            URL url = new URL(urlString);
            connection = (HttpURLConnection) url.openConnection(); connection.setConnectTimeout(20000); connection.setReadTimeout(60000); connection.setInstanceFollowRedirects(true);
            String cookie = CookieManager.getInstance().getCookie(urlString); if (cookie != null) connection.setRequestProperty("Cookie", cookie);
            connection.setRequestProperty("User-Agent", "PhiskVideosApp/1.1"); connection.connect();
            int status = connection.getResponseCode(); if (status < 200 || status >= 300) throw new Exception("Video host returned HTTP " + status);
            long total = connection.getContentLength();
            output = new FileOutputStream(partial); InputStream input = connection.getInputStream(); byte[] buffer = new byte[64 * 1024]; int read; long done = 0;
            while ((read = input.read(buffer)) != -1) {
                output.write(buffer, 0, read); done += read;
                int pct = total > 0 ? (int)Math.min(100, (done * 100L) / total) : 0;
                postDownloadNotification(manager, notificationId, title, pct, false, total <= 0);
                saveDownloadProgress(destination.getName(), title, thumbnail, channel, pct, false);
            }
            output.flush(); input.close(); output.close(); output = null;
            if (!partial.renameTo(destination)) { partial.delete(); throw new Exception("Could not save the downloaded video"); }
            saveDownloadProgress(destination.getName(), title, thumbnail, channel, 100, true);
            postDownloadNotification(manager, notificationId, title, 100, true, false);
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Video downloaded. Open Downloads to watch offline.", Toast.LENGTH_LONG).show());
        } catch (Exception error) {
            if (partial != null && partial.exists()) partial.delete();
            if (manager != null) manager.cancel(notificationId);
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Download failed: " + error.getMessage(), Toast.LENGTH_LONG).show());
        } finally { if (output != null) try { output.close(); } catch (Exception ignored) {} if (connection != null) connection.disconnect(); }
    }

    private void createDownloadChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager manager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            if (manager.getNotificationChannel(DOWNLOAD_CHANNEL) == null) manager.createNotificationChannel(new NotificationChannel(DOWNLOAD_CHANNEL, "Video downloads", NotificationManager.IMPORTANCE_LOW));
        }
    }

    private void postDownloadNotification(NotificationManager manager, int id, String title, int progressValue, boolean complete, boolean indeterminate) {
        if (manager == null) return;
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, DOWNLOAD_CHANNEL) : new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle(complete ? "Download complete" : "Downloading video")
                .setContentText(title).setOnlyAlertOnce(true).setOngoing(!complete).setAutoCancel(complete);
        if (!complete) builder.setProgress(100, progressValue, indeterminate);
        manager.notify(id, builder.build());
    }

    private void saveDownloadProgress(String key, String title, String thumbnail, String channel, int percent, boolean complete) {
        try {
            JSONObject item = new JSONObject(); item.put("title", title); item.put("thumbnail", thumbnail == null ? "" : thumbnail);
            item.put("channel", channel == null ? "" : channel); item.put("progress", percent); item.put("complete", complete);
            item.put("updated", System.currentTimeMillis());
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(key, item.toString()).apply();
        } catch (Exception ignored) {}
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request,result,data);
        if(request==FILE_REQUEST && fileCallback!=null) { fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result,data)); fileCallback=null; }
    }
    @Override public void onBackPressed() { if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { downloadExecutor.shutdown(); web.destroy(); super.onDestroy(); }
}
