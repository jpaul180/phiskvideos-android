package co.phisk.videos;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;
import android.webkit.JavascriptInterface;
import android.webkit.CookieManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.view.Gravity;
import android.view.ViewGroup;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import org.json.JSONObject;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String HOME = "https://videos.phisk.co/";
    private static final String SITE_HOST = "videos.phisk.co";
    private WebView web;
    private ProgressBar progress;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_REQUEST = 22;
    private final ExecutorService downloadExecutor = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        FrameLayout frame = new FrameLayout(this);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.WHITE);
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100); progress.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.rgb(124,58,237)));
        root.addView(progress, new LinearLayout.LayoutParams(-1, 4));
        web = new WebView(this); root.addView(web, new LinearLayout.LayoutParams(-1,0,1));
        frame.addView(root, new FrameLayout.LayoutParams(-1,-1));

        TextView downloads = new TextView(this);
        downloads.setText("Downloads"); downloads.setTextColor(Color.WHITE); downloads.setTextSize(13); downloads.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        downloads.setGravity(Gravity.CENTER); downloads.setPadding(dp(16), dp(11), dp(16), dp(11));
        GradientDrawable buttonBg = new GradientDrawable(); buttonBg.setColor(Color.rgb(124,58,237)); buttonBg.setCornerRadius(dp(9)); downloads.setBackground(buttonBg);
        FrameLayout.LayoutParams downloadParams = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM|Gravity.END);
        downloadParams.setMargins(0,0,dp(16),dp(22)); frame.addView(downloads, downloadParams);
        downloads.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, DownloadsActivity.class)));
        setContentView(frame);

        WebSettings s = web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(true); s.setAllowFileAccess(false); s.setAllowContentAccess(true);
        s.setUserAgentString(s.getUserAgentString() + " PhiskVideosApp/1.1");
        CookieManager.getInstance().setAcceptCookie(true);
        web.addJavascriptInterface(new PhiskAppBridge(), "PhiskApp");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri=request.getUrl(); String scheme=uri.getScheme(); String host=uri.getHost();
                if (("https".equals(scheme)) && host != null && (host.equals(SITE_HOST) || host.endsWith(".phisk.co"))) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch(Exception e) { Toast.makeText(MainActivity.this,"Cannot open link",Toast.LENGTH_SHORT).show(); }
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) { progress.setVisibility(View.GONE); }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int value) { progress.setVisibility(value == 100 ? View.GONE : View.VISIBLE); progress.setProgress(value); }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback=callback;
                try { startActivityForResult(params.createIntent(), FILE_REQUEST); return true; }
                catch(Exception e) { fileCallback=null; return false; }
            }
        });
        web.loadUrl(HOME);
    }

    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    private class PhiskAppBridge {
        @JavascriptInterface public void downloadVideo(int videoId, String nonce, String rawName) {
            if (videoId < 1 || nonce == null || nonce.length() < 8 || nonce.length() > 128) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Invalid download request", Toast.LENGTH_LONG).show()); return;
            }
            final String name = safeFilename(rawName);
            downloadExecutor.execute(() -> requestAuthorisedDownload(videoId, nonce, name));
        }
        @JavascriptInterface public void openDownloads() {
            runOnUiThread(() -> startActivity(new Intent(MainActivity.this, DownloadsActivity.class)));
        }
    }

    private String safeFilename(String input) {
        String name = input == null ? "phisk-video.mp4" : input.replaceAll("[^A-Za-z0-9._ -]", "_").trim();
        if (name.isEmpty()) name = "phisk-video.mp4";
        if (!name.matches("(?i).*\\.(mp4|m4v|mov|webm|ogv)$")) name += ".mp4";
        return name;
    }

    private void requestAuthorisedDownload(int videoId, String nonce, String filename) {
        HttpURLConnection api = null;
        try {
            URL endpoint = new URL(HOME + "wp-admin/admin-ajax.php");
            api = (HttpURLConnection) endpoint.openConnection(); api.setRequestMethod("POST"); api.setDoOutput(true); api.setConnectTimeout(20000); api.setReadTimeout(30000);
            api.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            api.setRequestProperty("Accept", "application/json");
            String cookie = CookieManager.getInstance().getCookie(HOME); if (cookie != null) api.setRequestProperty("Cookie", cookie);
            String body = "action=phisk_get_video_download&video_id=" + videoId + "&nonce=" + URLEncoder.encode(nonce, "UTF-8");
            try (OutputStream out = api.getOutputStream()) { out.write(body.getBytes("UTF-8")); }
            int status = api.getResponseCode();
            InputStream responseStream = status >= 200 && status < 300 ? api.getInputStream() : api.getErrorStream();
            ByteArrayOutputStream responseBuffer = new ByteArrayOutputStream(); byte[] responseChunk = new byte[4096]; int responseRead; while ((responseRead = responseStream.read(responseChunk)) != -1) responseBuffer.write(responseChunk, 0, responseRead); responseStream.close(); byte[] responseBytes = responseBuffer.toByteArray();
            JSONObject response = new JSONObject(new String(responseBytes, "UTF-8"));
            if (!response.optBoolean("success")) {
                JSONObject data = response.optJSONObject("data"); String message = data == null ? "Download is not available." : data.optString("message", "Download is not available.");
                throw new Exception(message);
            }
            JSONObject data = response.getJSONObject("data"); String fileUrl = data.getString("url");
            Uri parsed = Uri.parse(fileUrl);
            if (!"https".equalsIgnoreCase(parsed.getScheme()) || parsed.getHost() == null || fileUrl.length() > 4096) throw new Exception("The server returned an invalid video URL.");
            downloadToPrivateStorage(fileUrl, filename);
        } catch (Exception error) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Download failed: " + error.getMessage(), Toast.LENGTH_LONG).show());
        } finally { if (api != null) api.disconnect(); }
    }

    private void downloadToPrivateStorage(String urlString, String filename) {
        HttpURLConnection connection = null;
        FileOutputStream output = null;
        File partial = null;
        try {
            File directory = new File(getFilesDir(), "downloads");
            if (!directory.exists() && !directory.mkdirs()) throw new Exception("Could not create private download folder");
            File destination = new File(directory, System.currentTimeMillis() + "_" + filename);
            partial = new File(directory, destination.getName() + ".part");
            URL url = new URL(urlString);
            connection = (HttpURLConnection) url.openConnection(); connection.setConnectTimeout(20000); connection.setReadTimeout(60000); connection.setInstanceFollowRedirects(true);
            String cookie = CookieManager.getInstance().getCookie(urlString); if (cookie != null) connection.setRequestProperty("Cookie", cookie);
            connection.setRequestProperty("User-Agent", "PhiskVideosApp/1.1"); connection.connect();
            int status = connection.getResponseCode(); if (status < 200 || status >= 300) throw new Exception("Video host returned HTTP " + status);
            output = new FileOutputStream(partial); InputStream input = connection.getInputStream(); byte[] buffer = new byte[64 * 1024]; int read;
            while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
            output.flush(); input.close(); output.close(); output = null;
            if (!partial.renameTo(destination)) { partial.delete(); throw new Exception("Could not save the downloaded video"); }
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Video downloaded. Open Downloads to watch offline.", Toast.LENGTH_LONG).show());
        } catch (Exception error) {
            if (partial != null && partial.exists()) partial.delete();
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Download failed: " + error.getMessage(), Toast.LENGTH_LONG).show());
        } finally { if (output != null) try { output.close(); } catch (Exception ignored) {} if (connection != null) connection.disconnect(); }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request,result,data);
        if(request==FILE_REQUEST && fileCallback!=null) { fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result,data)); fileCallback=null; }
    }
    @Override public void onBackPressed() { if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { downloadExecutor.shutdown(); web.destroy(); super.onDestroy(); }
}
