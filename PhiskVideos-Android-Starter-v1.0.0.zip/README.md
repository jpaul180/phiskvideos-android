# PhiskVideos Android starter (v1.0.0)

This is an **Android Studio source project**, not a compiled APK. It loads `https://videos.phisk.co/` inside an Android WebView. The address is an assumption; edit `HOME` in `MainActivity.java` if the actual site differs.

## Build an APK without a laptop
1. Upload this project to a private GitHub repository (or open in Android Studio on a computer).
2. Set up a trusted Android build environment with JDK 17, Android SDK 35, and Gradle 8.9 (or use Android Studio's compatible Gradle tooling).
3. Run `gradle assembleDebug` from the project root (a Gradle wrapper is not included).
4. The resulting file is `app/build/outputs/apk/debug/app-debug.apk`. Install only on your own device for testing.

## Included
- Secure HTTPS-only WebView for PhiskVideos and other phisk.co subdomains
- Violet loading indicator, Android back navigation, file chooser for uploads
- External links open in browser; JavaScript and local storage enabled

## Before public distribution
- Confirm the website address and test login, video playback, uploads, and navigation on real devices.
- Add branded launcher icons, splash screen, full-screen playback, offline/error UI, and app link verification.
- Implement Android notification permissions and a proper push messaging backend if push notifications are required. **Push notifications are not implemented in this starter.**
- Test external sign-in and payments; WebView can be unsuitable for some third-party auth/payment flows.
- Use a release signing key and generate an AAB for Google Play; meet current Play target API, policy, privacy and testing requirements.
- Do not publish a thin WebView wrapper without ensuring meaningful mobile functionality and compliance with Play policies.


## Branding update (v1.0.0)
- Launcher icon uses the supplied transparent Phisk logo on a solid white background.
- Android adaptive and round launcher icons are included, with a white background layer.
- Launch splash uses a white background and a small centered Phisk logo (padded asset to keep it visually modest on Android 12+).
- Original WebView behaviour and package ID (`co.phisk.videos`) are unchanged.
