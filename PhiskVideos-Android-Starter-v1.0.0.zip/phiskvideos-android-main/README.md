# phiskvideos-android

PhiskVideos Android application source. The Android Studio project is packaged in `PhiskVideos-Android-Starter-v1.0.0.zip` and built by the GitHub Actions workflow in `.github/workflows/android.yml`.

Current app version: **1.3.0**.

To build, push/commit the updated repository to `main` or run the **Build PhiskVideos APK** workflow manually. The resulting debug APK is published as the `PhiskVideos-APK` workflow artifact.
