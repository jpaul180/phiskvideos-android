package co.phisk.videos;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Native Settings surface. Account forms remain securely served in the in-app WebView. */
public class NativeSettingsActivity extends Activity {
    private static final String HOME="https://videos.phisk.co/";
    private static final String PREFS="phisk_native_settings";
    private static final int VIOLET=Color.rgb(124,58,237);
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private LinearLayout content; private ProgressBar progress; private TextView accountName,accountEmail;
    private JSONObject notificationPrefs=new JSONObject(); private boolean prefsLoaded=false, dark=false;
    private String currentName="Your PhiskVideos account", currentEmail="Loading account…";
    private int bg,cardColor,ink,muted,border,divider;

    @Override public void onCreate(Bundle state){PhiskTheme.configureActivityTheme(this);super.onCreate(state);dark=getSharedPreferences(PREFS,MODE_PRIVATE).getBoolean("dark_mode",false);applySystemBars();build();loadRemoteSettings();}
    private void applySystemBars(){getWindow().setStatusBarColor(dark?Color.rgb(20,20,24):Color.WHITE);getWindow().setNavigationBarColor(dark?Color.rgb(20,20,24):Color.WHITE);getWindow().getDecorView().setSystemUiVisibility(dark?0:(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR));}
    private void palette(){bg=dark?Color.rgb(20,20,24):Color.rgb(247,248,250);cardColor=dark?Color.rgb(31,32,38):Color.WHITE;ink=dark?Color.rgb(245,245,248):Color.rgb(25,29,38);muted=dark?Color.rgb(170,172,183):Color.rgb(112,117,128);border=dark?Color.rgb(58,59,68):Color.rgb(231,233,238);divider=dark?Color.rgb(54,55,63):Color.rgb(239,240,243);}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable shape(int color,int stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
    private TextView text(String value,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private String token(){return getSharedPreferences("phisk_native_auth",MODE_PRIVATE).getString("access_token","");}
    private JSONObject request(String path,String method,JSONObject body)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(HOME+"wp-json/phisk/v1/"+path).openConnection();
        try{c.setRequestMethod(method);c.setConnectTimeout(15000);c.setReadTimeout(20000);c.setRequestProperty("Accept","application/json");c.setRequestProperty("Authorization","Bearer "+token());
            if(body!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=UTF-8");try(OutputStream out=c.getOutputStream()){out.write(body.toString().getBytes(StandardCharsets.UTF_8));}}
            int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();ByteArrayOutputStream out=new ByteArrayOutputStream();if(in!=null){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);in.close();}String raw=out.toString("UTF-8");if(code<200||code>=300)throw new Exception("Server returned "+code);return new JSONObject(raw);
        }finally{c.disconnect();}
    }
    private void build(){
        palette();LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(14),0,dp(14),0);bar.setBackgroundColor(cardColor);
        TextView back=text("‹",34,ink,false);back.setGravity(Gravity.CENTER);bar.addView(back,new LinearLayout.LayoutParams(dp(42),dp(54)));back.setOnClickListener(v->finish());bar.addView(text("Settings",18,ink,true));root.addView(bar);
        View line=new View(this);line.setBackgroundColor(border);root.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
        FrameLayout frame=new FrameLayout(this);ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(16),dp(16),dp(16),dp(30));scroll.addView(content);frame.addView(scroll,new FrameLayout.LayoutParams(-1,-1));progress=new ProgressBar(this);FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(dp(36),dp(36),Gravity.TOP|Gravity.CENTER_HORIZONTAL);pp.topMargin=dp(12);frame.addView(progress,pp);root.addView(frame,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);progress.setVisibility(prefsLoaded||token().isEmpty()?View.GONE:View.VISIBLE);
        addSection("ACCOUNT");LinearLayout account=card();LinearLayout identity=new LinearLayout(this);identity.setGravity(Gravity.CENTER_VERTICAL);identity.setPadding(dp(14),dp(13),dp(14),dp(13));account.addView(identity);ImageView identityIcon=icon(R.drawable.ic_settings_user_hexagon,true);LinearLayout.LayoutParams identityIconParams=new LinearLayout.LayoutParams(dp(24),dp(24));identityIconParams.rightMargin=dp(13);identity.addView(identityIcon,identityIconParams);LinearLayout identityCopy=new LinearLayout(this);identityCopy.setOrientation(LinearLayout.VERTICAL);accountName=text(currentName,16,ink,true);identityCopy.addView(accountName);accountEmail=text(currentEmail,12,muted,false);accountEmail.setPadding(0,dp(4),0,0);identityCopy.addView(accountEmail);identity.addView(identityCopy,new LinearLayout.LayoutParams(0,-2,1));
        addIconRow(account,"Edit profile","Manage your profile information",R.drawable.ic_settings_user_edit,"my-account/edit-account/",true);addDivider(account);
        addIconRow(account,"Password & security","Manage your sign-in details",R.drawable.ic_settings_lock,"my-account/edit-account/",true);addDivider(account);
        addIconRow(account,"Privacy & account","Open account privacy settings",R.drawable.ic_settings_spy,"my-account/",true);addDivider(account);
        addSettingRow(account,"Log out","Sign out of this PhiskVideos account",R.drawable.ic_settings_logout,false,()->confirmLogout(),false);

        addSection("NOTIFICATIONS");LinearLayout notices=card();addSwitch(notices,"Video notifications","In-app notifications about videos from channels you follow","video_inbox",true);addDivider(notices);addSwitch(notices,"Video email updates","Receive video activity by email","video_email",true);addDivider(notices);addSwitch(notices,"Story notifications","In-app notifications about Stories from channels you follow","story_inbox",true);addDivider(notices);addSwitch(notices,"Story email updates","Receive Story activity by email","story_email",true);addDivider(notices);addSwitch(notices,"Story approval emails","Email me when my Story is approved","story_approved_email",true);addDivider(notices);addSwitch(notices,"Monetization approval emails","Email me when monetization is approved","monetization_approved_email",true);
        TextView note=text("Important account approval notices remain in your in-app Activity inbox. Email preferences only control email delivery.",11,muted,false);note.setPadding(dp(4),dp(8),dp(4),dp(2));content.addView(note);
        addSection("APP");LinearLayout app=card();addSettingRow(app,"Dark/Light mode","Change the appearance of the entire app",R.drawable.ic_settings_brightness_half,true,()->{});addDivider(app);addSettingRow(app,"Watch offline","View and manage videos saved on this device",R.drawable.ic_settings_wifi_off,false,()->startActivity(new Intent(this,DownloadsActivity.class)));
        addSection("ABOUT");LinearLayout about=card();addRow(about,"About PhiskVideos","Learn more about the platform",false,()->openWeb("about/"));addDivider(about);addRow(about,"Help & support","Get help with your account or the app",false,()->openWeb("contact/"));addDivider(about);addRow(about,"Privacy policy","Read how PhiskVideos handles information",false,()->openWeb("privacy-policy/"));
        TextView version=text("PhiskVideos Android · v1.16.9",11,muted,false);version.setGravity(Gravity.CENTER);version.setPadding(0,dp(20),0,dp(4));content.addView(version);
    }
    private LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setBackground(shape(cardColor,border,10));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(4);content.addView(c,p);return c;}
    private void addSection(String title){TextView t=text(title,11,muted,true);t.setLetterSpacing(.08f);t.setPadding(dp(3),dp(18),dp(3),dp(8));content.addView(t);}
    private void addDivider(LinearLayout parent){View d=new View(this);d.setBackgroundColor(divider);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(1));p.leftMargin=dp(14);p.rightMargin=dp(14);parent.addView(d,p);}
    private void addRow(LinearLayout parent,String title,String subtitle,boolean danger,Runnable action){addRow(parent,title,subtitle,danger,action,false);}
    private void addRow(LinearLayout parent,String title,String subtitle,boolean danger,Runnable action,boolean toggle){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(14),dp(12),dp(14),dp(12));LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.addView(text(title,14,danger?Color.rgb(220,65,65):ink,true));copy.addView(text(subtitle,11,muted,false));row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));if(toggle){Switch sw=new Switch(this);sw.setChecked(dark);sw.setOnCheckedChangeListener((b,on)->{dark=on;PhiskTheme.setDark(this,on);recreate();});row.addView(sw);}else if(!danger){TextView arrow=text("›",25,muted,false);row.addView(arrow);}parent.addView(row);row.setOnClickListener(v->{if(!toggle)action.run();});}
    private ImageView icon(int resource,boolean tintForDark){ImageView image=new ImageView(this);image.setImageResource(resource);image.setScaleType(ImageView.ScaleType.FIT_CENTER);if(dark&&tintForDark)image.setColorFilter(Color.WHITE);return image;}
    private void addIconRow(LinearLayout parent,String title,String subtitle,int resource,String path,boolean tintForDark){addSettingRow(parent,title,subtitle,resource,false,()->openWeb(path),tintForDark);}
    private void addSettingRow(LinearLayout parent,String title,String subtitle,int resource,boolean toggle,Runnable action){addSettingRow(parent,title,subtitle,resource,toggle,action,true);}
    private void addSettingRow(LinearLayout parent,String title,String subtitle,int resource,boolean toggle,Runnable action,boolean tintForDark){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(14),dp(12),dp(14),dp(12));ImageView image=icon(resource,tintForDark);LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(dp(24),dp(24));ip.rightMargin=dp(13);row.addView(image,ip);LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.addView(text(title,14,ink,true));copy.addView(text(subtitle,11,muted,false));row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));if(toggle){Switch sw=new Switch(this);sw.setChecked(dark);sw.setOnCheckedChangeListener((button,on)->{dark=on;PhiskTheme.setDark(this,on);recreate();});row.addView(sw);}else{row.addView(text("›",25,muted,false));}parent.addView(row);row.setOnClickListener(v->{if(!toggle)action.run();});}
    private void addSwitch(LinearLayout parent,String title,String subtitle,String key,boolean defaultValue){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(14),dp(10),dp(12),dp(10));LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.addView(text(title,14,ink,true));TextView sub=text(subtitle,11,muted,false);sub.setMaxLines(2);copy.addView(sub);row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));Switch toggle=new Switch(this);toggle.setChecked(notificationPrefs.optBoolean(key,defaultValue));toggle.setEnabled(prefsLoaded);row.addView(toggle);parent.addView(row);toggle.setOnCheckedChangeListener((button,checked)->saveNotificationPreference(key,checked,toggle));}
    private void loadRemoteSettings(){if(token().isEmpty()){progress.setVisibility(View.GONE);currentEmail="Sign in to manage your account settings.";accountEmail.setText(currentEmail);return;}io.execute(()->{try{JSONObject me=request("app-auth/me","GET",null);JSONObject user=me.optJSONObject("user");JSONObject prefs=request("notification-preferences","GET",null);runOnUiThread(()->{if(user!=null){currentName=user.optString("name","Your account");currentEmail=user.optString("email","");accountName.setText(currentName);accountEmail.setText(currentEmail);}notificationPrefs=prefs;prefsLoaded=true;progress.setVisibility(View.GONE);rebuildNotificationSwitches();});}catch(Exception e){runOnUiThread(()->{progress.setVisibility(View.GONE);currentEmail="Couldn't load account preferences. Check your connection and try again.";accountEmail.setText(currentEmail);Toast.makeText(this,"Some settings could not be loaded.",Toast.LENGTH_LONG).show();});}});}
    private void rebuildNotificationSwitches(){build();}
    private void saveNotificationPreference(String key,boolean value,Switch toggle){toggle.setEnabled(false);io.execute(()->{try{JSONObject body=new JSONObject();body.put(key,value);JSONObject saved=request("notification-preferences","POST",body);runOnUiThread(()->{notificationPrefs=saved;toggle.setEnabled(true);Toast.makeText(this,"Notification preference saved",Toast.LENGTH_SHORT).show();});}catch(Exception e){runOnUiThread(()->{toggle.setEnabled(true);toggle.setOnCheckedChangeListener(null);toggle.setChecked(!value);toggle.setOnCheckedChangeListener((button,checked)->saveNotificationPreference(key,checked,toggle));Toast.makeText(this,"Couldn't save this preference. Please try again.",Toast.LENGTH_LONG).show();});}});}
    private void confirmLogout(){new android.app.AlertDialog.Builder(this).setTitle("Log out?").setMessage("You'll need to sign in again to access your account.").setNegativeButton("Cancel",null).setPositiveButton("Log out",(d,w)->performLogout()).show();}
    private void performLogout(){if(token().isEmpty()){clearLocalSession();return;}progress.setVisibility(View.VISIBLE);io.execute(()->{boolean ok=false;try{request("app-auth/logout","POST",new JSONObject());ok=true;}catch(Exception ignored){}final boolean serverOk=ok;runOnUiThread(()->{if(!serverOk){progress.setVisibility(View.GONE);new android.app.AlertDialog.Builder(this).setTitle("Couldn't log out").setMessage("We couldn't revoke your session. Check your connection and try again.").setPositiveButton("OK",null).show();return;}clearLocalSession();});});}
    private void clearLocalSession(){getSharedPreferences("phisk_native_auth",MODE_PRIVATE).edit().putBoolean("signed_in",false).remove("access_token").apply();try{com.google.firebase.auth.FirebaseAuth.getInstance().signOut();}catch(Exception ignored){}getSharedPreferences("phisk_fcm_device",MODE_PRIVATE).edit().remove("registered_token").apply();Intent i=new Intent(this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);startActivity(i);finish();}
    private void openWeb(String path){Intent i=new Intent(this,MainActivity.class);i.putExtra(MainActivity.EXTRA_NOTIFICATION_URL,HOME+path);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(i);}
    @Override protected void onDestroy(){io.shutdownNow();super.onDestroy();}
    @Override protected void onResume(){super.onResume();PhiskTheme.apply(this);}
}
