# PhiskVideos Android v1.16.5 — Native Icon Refresh

This release is based on v1.16.4 (Fullscreen Playback Restore). It refreshes the native app icon set and adds the Subscribe action to the native video page while preserving the existing playback, download, notification and navigation flows.

## Icon refresh
- Replaces the sticky bottom navigation icons with the supplied Home, Activities, Create, Creator Studio and Settings SVG designs.
- Replaces the video-page Download, Like, Share and Report icons with the supplied SVG designs.
- Adds the supplied User Heart icon as the native Subscribe action.
- Replaces the three-dot control on every homepage video card with the supplied white Share icon. Tapping it opens the Android share chooser with the video's title and permalink.
- Retains the supplied SVG files in `app/src/main/assets/phisk-icons/` and uses Android vector drawables for native rendering.
- Removes obsolete navigation/action icon resources while retaining app branding, avatar artwork, notification illustrations and other non-icon media.

## Native video page
- Keeps the existing action order: Download, Like, Share, Report. Subscribe follows as an additional action.
- Download, Like, Share and Subscribe are icon-only. Report uses its icon, a vertical divider and the “Report” label.
- Subscribe uses the existing Phisk Video Manager `creators/{id}/subscribe` endpoint and reads the creator's existing subscription/ownership state from `creators/{id}`. It requires sign-in and does not expose Subscribe on the creator's own video.
- Existing Download, Like, Share and Report behavior remains connected to the existing native/server functionality.

## Build
- Android version: `1.16.5`
- Android version code: `34`
- Minimum SDK: 24
- Target/compile SDK: 35
- Java: 17
- GitHub Actions builds signed APK and AAB outputs using the existing repository signing secrets.
