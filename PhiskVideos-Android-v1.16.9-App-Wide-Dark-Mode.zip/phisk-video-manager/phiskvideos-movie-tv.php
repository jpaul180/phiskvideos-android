<?php
/**
 * Plugin Name: Phisk Video Manager
 * Description: Movie, TV show, video, and Story management with responsive feeds, frontend submissions, user video editing, and threaded Story discussions.
 * Version: 1.20.3
 * Author: PhiskVideos
 * Text Domain: phiskvideos
 */
if (!defined('ABSPATH')) exit;

final class PhiskVideos_Movie_TV {
    const VERSION = '1.20.3';
    const NONCE = 'phiskvideos_save_meta';

    /** Prevent the Related Stories cards from recursively re-entering the_content. */
    private $rendering_related_stories = false;

    public function __construct() {
        $GLOBALS['phiskvideos_movie_tv_instance'] = $this;
        add_action('init', [$this, 'register_content']);
        add_action('init', [$this, 'seed_african_countries'], 30);
        add_action('init', [$this, 'seed_video_genres'], 31);
        add_action('init', [$this, 'seed_article_interests'], 32);
        add_action('transition_post_status', [$this, 'stamp_article_publication_time'], 10, 3);
        add_action('transition_post_status', [$this, 'handle_notification_content_publication'], 20, 3);
        add_action('init', [$this, 'ensure_notification_tables'], 2);
        add_action('init', [$this, 'ensure_app_notification_tables'], 3);
        add_action('init', [$this, 'handle_notification_preferences_submission'], 8);
        add_action('init', [$this, 'handle_user_device_removal'], 8);
        add_action('admin_init', [$this, 'handle_admin_device_action']);
        add_action('admin_init', [$this, 'register_fcm_settings']);
        add_action('init', [$this, 'handle_notification_open_action'], 9);
        add_action('init', [$this, 'handle_notification_mark_all_action'], 9);
        add_action('rest_api_init', [$this, 'register_notification_rest_routes']);
        add_action('rest_api_init', [$this, 'register_app_auth_rest_routes']);
        add_action('rest_api_init', [$this, 'register_native_watch_rest_routes']);
        add_action('rest_api_init', [$this, 'register_native_creator_rest_routes']);
        add_filter('phisk_mobile_google_login_response', [$this, 'attach_mobile_google_app_session'], 10, 3);
        add_action('wp_ajax_phisk_unread_notification_count', [$this, 'ajax_unread_notification_count']);
        add_action('wp_ajax_phisk_check_public_username', [$this, 'ajax_check_public_username']);
        add_filter('phisk_theme_mobile_unread_total', [$this, 'theme_mobile_unread_total']);
        add_shortcode('phisk_notifications', [$this, 'notifications_inbox_shortcode']);
        add_shortcode('phisk_messages', [$this, 'admin_messages_inbox_shortcode']);
        add_shortcode('phisk_strike_appeal', [$this, 'user_strike_appeal_shortcode']);
        add_action('admin_menu', [$this, 'register_admin_messages_menu']);
        add_action('admin_menu', [$this, 'register_app_devices_menu']);
        add_action('admin_menu', [$this, 'register_fcm_admin_menu']);
        add_action('admin_post_phisk_fcm_test_connection', [$this, 'handle_fcm_test_connection']);
        add_action('admin_post_phisk_fcm_send_test', [$this, 'handle_fcm_send_test']);
        add_action('admin_menu', [$this, 'register_user_strikes_menu']);
        add_action('admin_init', [$this, 'handle_user_strike_admin_actions']);
        add_action('init', [$this, 'ensure_user_strike_tables'], 3);
        add_action('init', [$this, 'schedule_user_strike_maintenance'], 4);
        add_action('phisk_user_strike_daily_maintenance', [$this, 'run_user_strike_maintenance']);
        add_action('init', [$this, 'handle_user_strike_appeal_submission'], 7);
        add_action('admin_init', [$this, 'handle_admin_message_submission']);
        add_action('init', [$this, 'handle_admin_message_open_action'], 9);
        add_action('add_meta_boxes', [$this, 'add_meta_boxes']);
        add_action('save_post', [$this, 'save_meta'], 10, 2);
        add_action('save_post_phisk_report', [$this, 'save_report_status'], 20, 2);
        add_action('wp_enqueue_scripts', [$this, 'register_assets']);
        add_action('init', [$this, 'register_downloads_route'], 99);
        add_filter('query_vars', [$this, 'register_downloads_query_var']);
        add_action('template_redirect', [$this, 'render_downloads_fallback'], 0);
        add_action('init', [$this, 'register_logout_route'], 99);
        add_filter('query_vars', [$this, 'register_logout_query_var']);
        add_action('template_redirect', [$this, 'handle_universal_logout'], 0);
        add_action('wp_head', [$this, 'video_open_graph_metadata'], 1);
        add_action('wp_head', [$this, 'profile_open_graph_metadata'], 2);
        add_shortcode('phiskvideos_movies', [$this, 'movies_shortcode']);
        add_shortcode('phiskvideos_tvshows', [$this, 'tvshows_shortcode']);
        add_shortcode('phiskvideos_videos', [$this, 'videos_shortcode']);
        add_shortcode('phiskvideos_video_feed', [$this, 'latest_video_feed_shortcode']);
        add_shortcode('phiskvideos_following_feed', [$this, 'following_video_feed_shortcode']);
        add_shortcode('phiskvideos_posts', [$this, 'posts_shortcode']);
        add_shortcode('phisk_article_wall', [$this, 'article_wall_shortcode']);
        add_shortcode('phisk_top_stories_wall', [$this, 'top_stories_wall_shortcode']);
        add_action('wp_ajax_phisk_toggle_article_upvote', [$this, 'ajax_toggle_article_upvote']);
        add_shortcode('phisk_submit', [$this, 'frontend_submit_shortcode']);
        add_shortcode('phisk_video_submit', [$this, 'video_submit_shortcode']);
        add_shortcode('phisk_my_videos', [$this, 'my_videos_shortcode']);
        add_shortcode('phisk_user_dashboard', [$this, 'user_dashboard_shortcode']);
        add_shortcode('phisk_account_settings', [$this, 'account_settings_shortcode']);
        add_shortcode('phisk_creator_studio', [$this, 'creator_studio_shortcode']);
        add_shortcode('phisk_creator_studio_link', [$this, 'creator_studio_link_shortcode']);
        add_shortcode('phisk_article_submit', [$this, 'article_submit_shortcode']);
        add_action('init', [$this, 'handle_article_frontend_submission'], 20);
        add_action('init', [$this, 'handle_frontend_submission'], 20);
        add_action('init', [$this, 'handle_video_frontend_submission'], 21);
        add_action('init', [$this, 'handle_dashboard_profile'], 19);
        add_action('template_redirect', [$this, 'redirect_old_public_usernames'], 1);
        // Send logged-out visitors from Video Manager member pages to Phisk Auth.
        add_action('template_redirect', [$this, 'redirect_guest_member_pages_to_phisk_auth'], 2);
        add_action('init', [$this, 'handle_dashboard_content_action'], 18);
        add_filter('template_include', [$this, 'single_template']);
        add_filter('the_content', [$this, 'append_post_rating'], 20);
        add_filter('comments_open', [$this, 'open_story_comments'], 20, 2);
        add_filter('pre_option_thread_comments', [$this, 'enable_story_threaded_comments']);
        add_filter('pre_option_thread_comments_depth', [$this, 'set_story_thread_depth']);
        add_filter('get_avatar', [$this, 'use_phisk_profile_avatar'], 20, 6);
        add_filter('post_thumbnail_html', [$this, 'filter_article_featured_image_gallery'], 20, 5);
        add_action('wp_footer', [$this, 'video_sticky_header_script'], 99);
        add_action('admin_notices', [$this, 'rewrite_notice']);
        add_action('admin_menu', [$this, 'publitio_admin_menu']);
        add_action('admin_init', [$this, 'handle_auto_subscribe_settings']);
        add_action('user_register', [$this, 'auto_subscribe_new_member'], 20, 1);
        add_action('user_register', [$this, 'initialize_new_member_channel_state'], 25, 1);
        add_action('init', [$this, 'handle_channel_creation'], 17);
        add_filter('preprocess_comment', [$this, 'filter_phisk_comment_author_name'], 20);
        add_filter('the_author', [$this, 'filter_phisk_author_display_name'], 20, 2);
        add_action('admin_init', [$this, 'save_display_stats_settings']);
        add_action('admin_init', [$this, 'handle_article_review_action']);
        add_action('admin_init', [$this, 'register_publitio_settings']);
        add_action('admin_init', [$this, 'register_cloudflare_settings']);
        add_action('admin_init', [$this, 'handle_cloudflare_migration_actions']);
        add_action('admin_enqueue_scripts', [$this, 'admin_assets']);
        add_action('admin_init', [$this, 'maybe_migrate_people']);
        add_action('init', [$this, 'register_video_rewrite_rules'], 100);
        add_filter('query_vars', [$this, 'register_embed_query_var']);
        add_action('template_redirect', [$this, 'render_video_embed_page'], 0);
        add_action('init', [$this, 'maybe_flush_rewrites'], 101);
        add_filter('request', [$this, 'resolve_video_request'], 1);
        add_action('wp_ajax_phisk_search_people', [$this, 'ajax_search_people']);
        add_action('wp_ajax_phisk_create_person', [$this, 'ajax_create_person']);
        add_action('wp_ajax_nopriv_phisk_create_person', [$this, 'ajax_create_person']);
        add_action('wp_ajax_phisk_toggle_subscription', [$this, 'ajax_toggle_subscription']);
        add_action('wp_ajax_phisk_toggle_video_like', [$this, 'ajax_toggle_video_like']);
        add_action('wp_ajax_phisk_get_video_download', [$this, 'ajax_get_video_download']);
        add_action('wp_ajax_nopriv_phisk_toggle_video_like', [$this, 'ajax_toggle_video_like']);
        add_action('wp_ajax_phisk_add_video_comment', [$this, 'ajax_add_video_comment']);
        add_action('wp_ajax_phisk_reply_video_comment', [$this, 'ajax_reply_video_comment']);
        add_action('wp_ajax_nopriv_phisk_load_video_comment_replies', [$this, 'ajax_load_video_comment_replies']);
        add_action('wp_ajax_phisk_load_video_comment_replies', [$this, 'ajax_load_video_comment_replies']);
        add_action('wp_ajax_nopriv_phisk_load_video_comments', [$this, 'ajax_load_video_comments']);
        add_action('wp_ajax_phisk_load_video_comments', [$this, 'ajax_load_video_comments']);
        add_action('wp_ajax_phisk_submit_video_report', [$this, 'ajax_submit_video_report']);
        add_action('wp_ajax_phisk_monetization_event', [$this, 'ajax_monetization_event']);
        add_action('wp_ajax_nopriv_phisk_monetization_event', [$this, 'ajax_monetization_event']);
        add_action('init', [$this, 'ensure_guest_monetization_id'], 1);
        add_action('init', [$this, 'handle_monetization_frontend_actions'], 25);
        add_action('wp_footer', [$this, 'monetization_tracking_script'], 98);
        add_action('admin_init', [$this, 'handle_monetization_admin_actions']);
        add_action('admin_init', [$this, 'ensure_monetization_tables']);
        add_action('wp_ajax_phisk_upload_video_draft', [$this, 'ajax_upload_video_draft']);
        add_action('wp_ajax_phisk_upload_story_image', [$this, 'ajax_upload_story_image']);
        add_action('wp_ajax_phisk_update_channel_image', [$this, 'ajax_update_channel_image']);
        add_action('wp_ajax_phisk_import_youtube_draft', [$this, 'ajax_import_youtube_draft']);
        add_action('wp_ajax_phisk_update_video_draft', [$this, 'ajax_update_video_draft']);
        add_action('wp_ajax_phisk_finalize_video_draft', [$this, 'ajax_finalize_video_draft']);
        add_action('add_meta_boxes', [$this, 'add_report_meta_box']);
        add_filter('manage_phisk_report_posts_columns', [$this, 'report_columns']);
        add_action('manage_phisk_report_posts_custom_column', [$this, 'report_column_content'], 10, 2);
        add_filter('manage_edit-phisk_report_sortable_columns', [$this, 'report_sortable_columns']);
        register_activation_hook(__FILE__, [$this, 'activate']);
        register_deactivation_hook(__FILE__, [$this, 'deactivate']);
    }

    /**
     * Output video-specific Open Graph metadata so social platforms use the
     * individual video's thumbnail rather than the site-wide header image.
     */
    /**
     * Add Open Graph metadata for public channel/profile links so social sites
     * can render the account name and avatar when a link is shared.
     */
    public function profile_open_graph_metadata() {
        if (is_admin()) return;
        $user_id = !empty($_GET['phisk_profile_user']) ? absint($_GET['phisk_profile_user']) : absint(get_query_var('phisk_profile_user'));
        if (!$user_id) return;
        $user = $user_id ? get_userdata($user_id) : false;
        if (!$user) return;

        $name = $this->phisk_creator_display_name($user_id);
        if (!$name) $name = $user->display_name;
        $image = $this->dashboard_image_url($user_id, 'phisk_profile_image_id', 'full');
        if (!$image) {
            $avatar = get_avatar_url($user_id, ['size' => 512]);
            if ($avatar) $image = $avatar;
        }
        $url = $this->phisk_user_dashboard_url($user_id);
        $description = get_user_meta($user_id, 'description', true);
        $description = $description ? wp_trim_words(wp_strip_all_tags($description), 28, '…') : sprintf('View %s on PhiskVideos.', $name);

        echo "\n<!-- PhiskVideos channel/profile Open Graph metadata -->\n";
        echo '<meta property="og:type" content="profile">' . "\n";
        echo '<meta property="og:title" content="' . esc_attr(wp_strip_all_tags($name)) . '">' . "\n";
        echo '<meta property="og:description" content="' . esc_attr($description) . '">' . "\n";
        echo '<meta property="og:url" content="' . esc_url($url) . '">' . "\n";
        if ($image) {
            echo '<meta property="og:image" content="' . esc_url($image) . '">' . "\n";
            echo '<meta property="og:image:secure_url" content="' . esc_url($image) . '">' . "\n";
            echo '<meta property="og:image:alt" content="' . esc_attr($name) . '">' . "\n";
        }
        echo '<meta name="twitter:card" content="summary">' . "\n";
        echo '<meta name="twitter:title" content="' . esc_attr(wp_strip_all_tags($name)) . '">' . "\n";
        echo '<meta name="twitter:description" content="' . esc_attr($description) . '">' . "\n";
        if ($image) echo '<meta name="twitter:image" content="' . esc_url($image) . '">' . "\n";
    }

    public function video_open_graph_metadata() {
        if (is_admin() || !is_singular('phisk_video')) return;
        $post_id = get_queried_object_id();
        if (!$post_id || get_post_status($post_id) !== 'publish') return;

        $title = get_the_title($post_id);
        $description = get_post_field('post_excerpt', $post_id);
        if (!$description) {
            $content = get_post_field('post_content', $post_id);
            $description = wp_trim_words(wp_strip_all_tags(strip_shortcodes((string) $content)), 30, '…');
        }
        $description = trim(preg_replace('/\s+/', ' ', wp_strip_all_tags((string) $description)));
        if ($description === '') $description = $title;

        $image = get_the_post_thumbnail_url($post_id, 'full');
        if (!$image) {
            $youtube_id = (string) get_post_meta($post_id, '_phisk_youtube_video_id', true);
            if (preg_match('/^[A-Za-z0-9_-]{11}$/', $youtube_id)) {
                $image = 'https://i.ytimg.com/vi/' . $youtube_id . '/hqdefault.jpg';
            }
        }
        if (!$image) {
            $image = get_post_meta($post_id, 'phisk_video_thumbnail', true);
            if (!$image) $image = get_post_meta($post_id, '_phisk_video_thumbnail', true);
        }
        if (!$image) return;

        $url = get_permalink($post_id);
        echo "\n<!-- PhiskVideos video Open Graph metadata -->\n";
        echo '<meta property="og:type" content="video.other">' . "\n";
        echo '<meta property="og:title" content="' . esc_attr(wp_strip_all_tags($title)) . '">' . "\n";
        echo '<meta property="og:description" content="' . esc_attr($description) . '">' . "\n";
        echo '<meta property="og:image" content="' . esc_url($image) . '">' . "\n";
        echo '<meta property="og:image:secure_url" content="' . esc_url($image) . '">' . "\n";
        echo '<meta property="og:url" content="' . esc_url($url) . '">' . "\n";
        echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
        echo '<meta name="twitter:title" content="' . esc_attr(wp_strip_all_tags($title)) . '">' . "\n";
        echo '<meta name="twitter:description" content="' . esc_attr($description) . '">' . "\n";
        echo '<meta name="twitter:image" content="' . esc_url($image) . '">' . "\n";
    }

    public function publitio_admin_menu() {
        add_options_page('Phisk Videos · Publit.io', 'Phisk Videos', 'manage_options', 'phiskvideos-publitio', [$this, 'publitio_settings_page']);
        add_submenu_page('options-general.php', 'Cloudflare Stream Migration', 'Cloudflare Stream', 'manage_options', 'phiskvideos-cloudflare', [$this, 'cloudflare_migration_page']);
        add_submenu_page('options-general.php', 'Phisk Promotional Stats', 'Phisk Promotional Stats', 'manage_options', 'phiskvideos-display-stats', [$this, 'display_stats_admin_page']);
        add_submenu_page('options-general.php', 'Automatic Subscribe', 'Automatic Subscribe', 'manage_options', 'phiskvideos-auto-subscribe', [$this, 'auto_subscribe_admin_page']);
        add_submenu_page('options-general.php', 'Phisk Monetization', 'Monetization', 'manage_options', 'phiskvideos-monetization', [$this, 'monetization_admin_page']);
        add_submenu_page('options-general.php', 'PhiskVideos Empty States', 'Phisk Empty States', 'manage_options', 'phiskvideos-empty-states', [$this, 'empty_states_admin_page']);
        add_submenu_page('options-general.php', 'PhiskVideos Related Stories', 'Related Stories', 'manage_options', 'phiskvideos-related-stories', [$this, 'related_stories_admin_page']);
        add_submenu_page('options-general.php', 'Story Publishing', 'Story Publishing', 'manage_options', 'phiskvideos-story-publishing', [$this, 'story_publishing_admin_page']);
        add_submenu_page('edit.php', 'Article Review Queue', 'Article Review Queue', 'edit_others_posts', 'phisk-article-review', [$this, 'article_review_admin_page']);
    }


    /** Admin controls for empty-state images and sizes used by creator-facing feeds. */
    public function empty_states_admin_page() {
        if (!current_user_can('manage_options')) return;
        $settings = get_option('phiskvideos_empty_state_settings', []);
        if (!is_array($settings)) $settings = [];
        if (isset($_POST['phisk_empty_states_save'])) {
            check_admin_referer('phisk_empty_states_save_action', 'phisk_empty_states_nonce');
            $new = [];
            foreach (['video','story'] as $kind) {
                $new[$kind . '_image_id'] = isset($_POST[$kind . '_image_id']) ? absint($_POST[$kind . '_image_id']) : 0;
                $new[$kind . '_image_size'] = isset($_POST[$kind . '_image_size']) ? max(40, min(600, absint($_POST[$kind . '_image_size']))) : 150;
                $new[$kind . '_title'] = isset($_POST[$kind . '_title']) ? sanitize_text_field(wp_unslash($_POST[$kind . '_title'])) : '';
                $new[$kind . '_message'] = isset($_POST[$kind . '_message']) ? sanitize_textarea_field(wp_unslash($_POST[$kind . '_message'])) : '';
            }
            update_option('phiskvideos_empty_state_settings', $new, false);
            $settings = $new;
            echo '<div class="notice notice-success is-dismissible"><p>Empty-state settings saved.</p></div>';
        }
        wp_enqueue_media();
        ?>
        <div class="wrap phisk-empty-admin">
          <h1>PhiskVideos — Empty-State Design</h1>
          <p>Choose an image or mascot and display width for creator sections when no videos or Stories are available. Leave an image unset to show text only.</p>
          <form method="post">
            <?php wp_nonce_field('phisk_empty_states_save_action', 'phisk_empty_states_nonce'); ?>
            <?php foreach (['video'=>'No videos yet','story'=>'No Stories yet'] as $kind=>$heading):
                $image_id = absint($settings[$kind . '_image_id'] ?? 0);
                $image_url = $image_id ? wp_get_attachment_image_url($image_id, 'medium') : '';
                $size = absint($settings[$kind . '_image_size'] ?? 150);
            ?>
            <div style="max-width:820px;background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:20px;margin:20px 0">
              <h2><?php echo esc_html($heading); ?></h2>
              <input type="hidden" id="phisk-<?php echo esc_attr($kind); ?>-image-id" name="<?php echo esc_attr($kind); ?>_image_id" value="<?php echo esc_attr($image_id); ?>">
              <div id="phisk-<?php echo esc_attr($kind); ?>-image-preview" style="margin:12px 0">
                <?php if ($image_url): ?><img src="<?php echo esc_url($image_url); ?>" alt="" style="width:<?php echo esc_attr($size); ?>px;max-width:100%;height:auto;object-fit:contain"><?php else: ?><em>No image selected</em><?php endif; ?>
              </div>
              <button type="button" class="button phisk-empty-select-image" data-kind="<?php echo esc_attr($kind); ?>">Choose image / mascot</button>
              <button type="button" class="button phisk-empty-remove-image" data-kind="<?php echo esc_attr($kind); ?>">Remove image</button>
              <p><label>Image width (px)<br><input type="number" min="40" max="600" step="10" name="<?php echo esc_attr($kind); ?>_image_size" value="<?php echo esc_attr($size); ?>"></label></p>
              <p><label>Heading<br><input class="large-text" type="text" name="<?php echo esc_attr($kind); ?>_title" value="<?php echo esc_attr($settings[$kind . '_title'] ?? ''); ?>"></label></p>
              <p><label>Message<br><textarea class="large-text" rows="3" name="<?php echo esc_attr($kind); ?>_message"><?php echo esc_textarea($settings[$kind . '_message'] ?? ''); ?></textarea></label></p>
            </div>
            <?php endforeach; ?>
            <p><button type="submit" class="button button-primary" name="phisk_empty_states_save" value="1">Save Empty-State Settings</button></p>
          </form>
        </div>
        <script>
        jQuery(function($){
          $('.phisk-empty-select-image').on('click',function(){
            var kind=$(this).data('kind'), frame=wp.media({title:'Choose an empty-state image or mascot',button:{text:'Use this image'},multiple:false});
            frame.on('select',function(){var item=frame.state().get('selection').first().toJSON();$('#phisk-'+kind+'-image-id').val(item.id);$('#phisk-'+kind+'-image-preview').html('<img src="'+item.url.replace(/&/g,'&amp;').replace(/"/g,'&quot;')+'" alt="" style="max-width:100%;height:auto;object-fit:contain">');});
            frame.open();
          });
          $('.phisk-empty-remove-image').on('click',function(){var kind=$(this).data('kind');$('#phisk-'+kind+'-image-id').val('0');$('#phisk-'+kind+'-image-preview').html('<em>No image selected</em>');});
        });
        </script>
        <?php
    }

    private function render_creator_empty_state($kind, $default_title, $default_message) {
        $settings = get_option('phiskvideos_empty_state_settings', []);
        if (!is_array($settings)) $settings = [];
        $id = absint($settings[$kind . '_image_id'] ?? 0);
        $size = max(40, min(600, absint($settings[$kind . '_image_size'] ?? 150)));
        $title = sanitize_text_field($settings[$kind . '_title'] ?? '') ?: $default_title;
        $message = sanitize_textarea_field($settings[$kind . '_message'] ?? '') ?: $default_message;
        $html = '<section class="phisk-empty phisk-empty-state phisk-empty-state-' . esc_attr($kind) . '" style="text-align:center;padding:32px 20px">';
        if ($id) {
            $url = wp_get_attachment_image_url($id, 'full');
            if ($url) $html .= '<img src="' . esc_url($url) . '" alt="" loading="lazy" style="display:block;width:' . esc_attr($size) . 'px;max-width:100%;height:auto;object-fit:contain;margin:0 auto 16px">';
        } else {
            $icon_file = $kind === 'story' ? 'phisk-icon-story.svg' : 'phisk-icon-camera.svg';
            $icon_url = plugins_url('assets/' . $icon_file, __FILE__);
            $html .= '<img class="phisk-empty-state-icon" src="' . esc_url($icon_url) . '" width="56" height="56" alt="" aria-hidden="true" loading="lazy" style="display:block;width:56px;height:56px;object-fit:contain;margin:0 auto 16px">';
        }
        $html .= '<h3>' . esc_html($title) . '</h3><p>' . esc_html($message) . '</p></section>';
        return $html;
    }

    /** Manage default creators followed by new members, using the existing Phisk follow data. */
    public function handle_auto_subscribe_settings() {
        if (!is_admin() || !current_user_can('manage_options') || empty($_POST['phisk_auto_subscribe_action'])) return;
        check_admin_referer('phisk_auto_subscribe_save', 'phisk_auto_subscribe_nonce');
        $action = sanitize_key(wp_unslash($_POST['phisk_auto_subscribe_action']));
        if ($action === 'save') {
            $selected = isset($_POST['creator_ids']) && is_array($_POST['creator_ids']) ? array_map('absint', wp_unslash($_POST['creator_ids'])) : [];
            $selected = array_values(array_unique(array_filter($selected, function($id) { return $id > 0 && get_userdata($id); })));
            update_option('phisk_auto_subscribe_creator_ids', $selected, false);
            update_option('phisk_auto_subscribe_enabled', !empty($_POST['enabled']) ? 1 : 0, false);
            wp_safe_redirect(add_query_arg(['page'=>'phiskvideos-auto-subscribe','saved'=>'1'], admin_url('options-general.php')));
            exit;
        }
        if ($action === 'apply_existing') {
            $targets = get_option('phisk_auto_subscribe_creator_ids', []);
            if (!is_array($targets)) $targets = [];
            $added = 0;
            $users = get_users(['fields'=>'ID', 'number'=>-1, 'orderby'=>'ID', 'order'=>'ASC']);
            foreach ($users as $uid) {
                $uid = absint($uid);
                if (!$uid) continue;
                $following = $this->phisk_following_ids($uid);
                $changed = false;
                foreach ($targets as $target) {
                    $target = absint($target);
                    if (!$target || $target === $uid || !get_userdata($target) || in_array($target, $following, true)) continue;
                    $following[] = $target;
                    $count = $this->phisk_subscriber_count($target);
                    update_user_meta($target, 'phisk_subscriber_count', $count + 1);
                    $added++;
                    $changed = true;
                }
                if ($changed) update_user_meta($uid, 'phisk_following', array_values(array_unique(array_map('absint', $following))));
            }
            update_option('phisk_auto_subscribe_existing_applied', current_time('mysql'), false);
            update_option('phisk_auto_subscribe_existing_added', $added, false);
            wp_safe_redirect(add_query_arg(['page'=>'phiskvideos-auto-subscribe','existing_applied'=>'1'], admin_url('options-general.php')));
            exit;
        }
    }

    public function auto_subscribe_new_member($user_id) {
        $user_id = absint($user_id);
        if (!$user_id || !get_option('phisk_auto_subscribe_enabled', 0)) return;
        $targets = get_option('phisk_auto_subscribe_creator_ids', []);
        if (!is_array($targets) || !$targets) return;
        $following = $this->phisk_following_ids($user_id);
        $changed = false;
        foreach ($targets as $target) {
            $target = absint($target);
            if (!$target || $target === $user_id || !get_userdata($target) || in_array($target, $following, true)) continue;
            $following[] = $target;
            update_user_meta($target, 'phisk_subscriber_count', $this->phisk_subscriber_count($target) + 1);
            $changed = true;
        }
        if ($changed) update_user_meta($user_id, 'phisk_following', array_values(array_unique(array_map('absint', $following))));
    }

    public function auto_subscribe_admin_page() {
        if (!current_user_can('manage_options')) return;
        $selected = get_option('phisk_auto_subscribe_creator_ids', []);
        if (!is_array($selected)) $selected = [];
        $enabled = (bool) get_option('phisk_auto_subscribe_enabled', 0);
        $users = get_users(['orderby'=>'display_name', 'order'=>'ASC', 'number'=>-1, 'fields'=>['ID','display_name','user_login']]);
        echo '<div class="wrap"><h1>Phisk Videos · Automatic Subscribe</h1><p>Select creators that every newly registered member should automatically follow. This uses the existing Phisk subscription system and does not replace existing subscriptions.</p>';
        if (!empty($_GET['saved'])) echo '<div class="notice notice-success is-dismissible"><p>Automatic Subscribe settings saved.</p></div>';
        if (!empty($_GET['existing_applied'])) echo '<div class="notice notice-success is-dismissible"><p>One-time subscription pass completed for existing members. Added '.absint(get_option('phisk_auto_subscribe_existing_added', 0)).' new follow relationships; existing follows were left unchanged.</p></div>';
        echo '<form method="post">';
        wp_nonce_field('phisk_auto_subscribe_save', 'phisk_auto_subscribe_nonce');
        echo '<input type="hidden" name="phisk_auto_subscribe_action" value="save"><p><label><input type="checkbox" name="enabled" value="1" '.checked($enabled, true, false).'> <strong>Enable automatic subscriptions for new members</strong></label></p>';
        echo '<div style="max-width:850px;background:#fff;border:1px solid #c3c4c7;padding:16px;max-height:440px;overflow:auto">';
        if (!$users) echo '<p>No users found.</p>';
        foreach ($users as $user) {
            $id = absint($user->ID);
            $name = $user->display_name ? $user->display_name : $user->user_login;
            echo '<label style="display:block;padding:7px 0;border-bottom:1px solid #f0f0f1"><input type="checkbox" name="creator_ids[]" value="'.$id.'" '.checked(in_array($id, array_map('absint',$selected), true), true, false).'> '.esc_html($name).' <span style="color:#646970">@'.esc_html($user->user_login).' · ID '.$id.'</span></label>';
        }
        echo '</div><p><button class="button button-primary">Save Automatic Subscribe Settings</button></p></form>';
        echo '<hr><h2>Apply to existing members once</h2><p>This optional action adds the selected creators to existing members who do not already follow them. It does not remove or duplicate subscriptions. Save your creator selection first.</p>';
        $last = get_option('phisk_auto_subscribe_existing_applied', '');
        if ($last) echo '<p><strong>Last run:</strong> '.esc_html($last).'</p>';
        echo '<form method="post" onsubmit="return confirm(\'Apply selected creator subscriptions to all existing members who do not already follow them?\');">';
        wp_nonce_field('phisk_auto_subscribe_save', 'phisk_auto_subscribe_nonce');
        echo '<input type="hidden" name="phisk_auto_subscribe_action" value="apply_existing"><button class="button" '.(empty($selected)?'disabled':'').'>Run one-time subscription for existing members</button></form></div>';
    }

    /** Save display-only demo/promotional rules. Never modify genuine counters. */
    public function save_display_stats_settings() {
        if (!is_admin() || !current_user_can('manage_options') || empty($_POST['phisk_display_stats_save'])) return;
        check_admin_referer('phisk_display_stats_save_action', 'phisk_display_stats_nonce');
        $kind = isset($_POST['kind']) ? sanitize_key(wp_unslash($_POST['kind'])) : '';
        $id = isset($_POST['item_id']) ? absint($_POST['item_id']) : 0;
        $enabled = !empty($_POST['demo_enabled']) ? 1 : 0;
        $base = isset($_POST['demo_base']) ? absint($_POST['demo_base']) : 0;
        $growth = isset($_POST['demo_growth']) ? min(absint($_POST['demo_growth']), 1000000) : 0;

        if ($kind === 'channel' && $id && get_userdata($id)) {
            update_user_meta($id, '_phisk_demo_stats_enabled', $enabled);
            update_user_meta($id, '_phisk_demo_subscribers_base', $base);
            update_user_meta($id, '_phisk_demo_subscribers_growth', $growth);
            update_user_meta($id, '_phisk_demo_video_views_base', isset($_POST['demo_video_base']) ? absint($_POST['demo_video_base']) : 0);
            update_user_meta($id, '_phisk_demo_video_views_growth', isset($_POST['demo_video_growth']) ? min(absint($_POST['demo_video_growth']), 1000000) : 0);
            if ($enabled) update_user_meta($id, '_phisk_demo_subscribers_started', time());
            else delete_user_meta($id, '_phisk_demo_subscribers_started');
        } elseif ($kind === 'video' && $id && get_post_type($id) === 'phisk_video') {
            update_post_meta($id, '_phisk_demo_stats_enabled', $enabled);
            update_post_meta($id, '_phisk_demo_views_base', $base);
            update_post_meta($id, '_phisk_demo_views_growth', $growth);
            if ($enabled) update_post_meta($id, '_phisk_demo_views_started', time());
            else delete_post_meta($id, '_phisk_demo_views_started');
        }

        $args = ['page' => 'phiskvideos-display-stats', 'stats_saved' => '1'];
        if (!empty($_POST['return_search'])) {
            $args['search'] = sanitize_text_field(wp_unslash($_POST['return_search']));
            $args['search_kind'] = $kind;
        }
        wp_safe_redirect(add_query_arg($args, admin_url('options-general.php')));
        exit;
    }

    public function display_stats_admin_page() {
        if (!current_user_can('manage_options')) return;
        $search = isset($_GET['search']) ? sanitize_text_field(wp_unslash($_GET['search'])) : '';
        $search_kind = isset($_GET['search_kind']) && $_GET['search_kind'] === 'video' ? 'video' : 'channel';
        echo '<div class="wrap"><h1>Phisk Promotional Stats</h1><p>Manage clearly identified <strong>promotional stats</strong>. These values are display-only: genuine view and subscriber counters remain unchanged and must continue to be used for recommendations, trending, analytics, and monetization.</p>';
        if (!empty($_GET['stats_saved'])) echo '<div class="notice notice-success is-dismissible"><p>Display stats settings saved.</p></div>';
        echo '<form method="get" style="margin:18px 0 24px;display:flex;gap:8px;align-items:center;flex-wrap:wrap"><input type="hidden" name="page" value="phiskvideos-display-stats"><select name="search_kind"><option value="channel" ' . selected($search_kind, 'channel', false) . '>Channels</option><option value="video" ' . selected($search_kind, 'video', false) . '>Videos</option></select><input type="search" name="search" value="' . esc_attr($search) . '" class="regular-text" placeholder="Search username, channel name, or video title"><button class="button button-primary">Search</button></form>';

        if ($search !== '') {
            if ($search_kind === 'channel') {
                $users = get_users(['search' => '*' . $search . '*', 'search_columns' => ['user_login', 'user_nicename', 'display_name', 'user_email'], 'number' => 30, 'orderby' => 'display_name', 'order' => 'ASC']);
                if (!$users) echo '<p>No matching channels found.</p>';
                foreach ($users as $user) {
                    $enabled = (int) get_user_meta($user->ID, '_phisk_demo_stats_enabled', true);
                    $base = (int) get_user_meta($user->ID, '_phisk_demo_subscribers_base', true);
                    $growth = (int) get_user_meta($user->ID, '_phisk_demo_subscribers_growth', true);
                    $video_base = (int) get_user_meta($user->ID, '_phisk_demo_video_views_base', true);
                    $video_growth = (int) get_user_meta($user->ID, '_phisk_demo_video_views_growth', true);
                    echo '<div style="background:#fff;border:1px solid #ccd0d4;padding:16px;margin:12px 0;max-width:900px"><h2 style="margin-top:0">' . esc_html($user->display_name ?: $user->user_login) . ' <small style="font-weight:normal">(@' . esc_html($user->user_login) . ')</small></h2><form method="post">';
                    wp_nonce_field('phisk_display_stats_save_action', 'phisk_display_stats_nonce');
                    echo '<input type="hidden" name="phisk_display_stats_save" value="1"><input type="hidden" name="kind" value="channel"><input type="hidden" name="item_id" value="' . absint($user->ID) . '"><input type="hidden" name="return_search" value="' . esc_attr($search) . '"><label><input type="checkbox" name="demo_enabled" value="1" ' . checked($enabled, 1, false) . '> Enable promotional stats for this channel</label><p><label>Starting subscriber display count <input type="number" min="0" step="1" name="demo_base" value="' . esc_attr($base) . '" class="small-text"></label> &nbsp; <label>Additional subscribers per day <input type="number" min="0" step="1" name="demo_growth" value="' . esc_attr($growth) . '" class="small-text"></label></p><p><label>Starting view display count for each channel video <input type="number" min="0" step="1" name="demo_video_base" value="' . esc_attr($video_base) . '" class="small-text"></label> &nbsp; <label>Additional display views per video per day <input type="number" min="0" step="1" name="demo_video_growth" value="' . esc_attr($video_growth) . '" class="small-text"></label></p><p class="description">Videos inherit the channel view rules unless a video-specific rule is enabled. Display values carry a visible promotional stats label.</p><button class="button button-primary">Save channel rules</button></form></div>';
                }
            } else {
                $posts = get_posts(['post_type' => 'phisk_video', 'post_status' => ['publish', 'draft', 'pending'], 's' => $search, 'numberposts' => 30, 'orderby' => 'title', 'order' => 'ASC']);
                if (!$posts) echo '<p>No matching videos found.</p>';
                foreach ($posts as $post) {
                    $enabled = (int) get_post_meta($post->ID, '_phisk_demo_stats_enabled', true);
                    $base = (int) get_post_meta($post->ID, '_phisk_demo_views_base', true);
                    $growth = (int) get_post_meta($post->ID, '_phisk_demo_views_growth', true);
                    echo '<div style="background:#fff;border:1px solid #ccd0d4;padding:16px;margin:12px 0;max-width:900px"><h2 style="margin-top:0">' . esc_html($post->post_title ?: '(Untitled video)') . '</h2><p>Author: ' . esc_html(get_the_author_meta('display_name', $post->post_author)) . ' · Status: ' . esc_html($post->post_status) . '</p><form method="post">';
                    wp_nonce_field('phisk_display_stats_save_action', 'phisk_display_stats_nonce');
                    echo '<input type="hidden" name="phisk_display_stats_save" value="1"><input type="hidden" name="kind" value="video"><input type="hidden" name="item_id" value="' . absint($post->ID) . '"><input type="hidden" name="return_search" value="' . esc_attr($search) . '"><label><input type="checkbox" name="demo_enabled" value="1" ' . checked($enabled, 1, false) . '> Enable promotional views and automatic display growth for this video</label><p><label>Starting view display count <input type="number" min="0" step="1" name="demo_base" value="' . esc_attr($base) . '" class="small-text"></label> &nbsp; <label>Additional display views per day <input type="number" min="0" step="1" name="demo_growth" value="' . esc_attr($growth) . '" class="small-text"></label></p><p class="description">A video-specific rule overrides its channel\'s view display rule. Real views are not changed.</p><button class="button button-primary">Save video rules</button></form></div>';
                }
            }
        }
        echo '<hr><p><strong>Safety:</strong> Turning a rule off immediately returns the interface to genuine counts. Promotional figures are never written into <code>_phisk_views</code> or <code>phisk_subscriber_count</code>.</p></div>';
    }

    private function phisk_demo_display_count($base, $growth, $started) {
        $base = max(0, (int) $base);
        $growth = max(0, (int) $growth);
        $started = max(0, (int) $started);
        $days = $started ? max(0, (int) floor((time() - $started) / DAY_IN_SECONDS)) : 0;
        return $base + ($days * $growth);
    }

    public function phisk_display_subscriber_count($author_id) {
        $author_id = absint($author_id);
        if ($author_id && get_user_meta($author_id, '_phisk_demo_stats_enabled', true)) {
            return $this->phisk_demo_display_count(get_user_meta($author_id, '_phisk_demo_subscribers_base', true), get_user_meta($author_id, '_phisk_demo_subscribers_growth', true), get_user_meta($author_id, '_phisk_demo_subscribers_started', true));
        }
        return $this->phisk_subscriber_count($author_id);
    }

    public function phisk_display_video_views($video_id) {
        $video_id = absint($video_id);
        if (!$video_id) return 0;
        if (get_post_meta($video_id, '_phisk_demo_stats_enabled', true)) {
            return $this->phisk_demo_display_count(get_post_meta($video_id, '_phisk_demo_views_base', true), get_post_meta($video_id, '_phisk_demo_views_growth', true), get_post_meta($video_id, '_phisk_demo_views_started', true));
        }
        $author_id = (int) get_post_field('post_author', $video_id);
        if ($author_id && get_user_meta($author_id, '_phisk_demo_stats_enabled', true)) {
            return $this->phisk_demo_display_count(get_user_meta($author_id, '_phisk_demo_video_views_base', true), get_user_meta($author_id, '_phisk_demo_video_views_growth', true), get_user_meta($author_id, '_phisk_demo_subscribers_started', true));
        }
        return max(0, (int) get_post_meta($video_id, '_phisk_views', true));
    }

    public function phisk_video_demo_label($video_id) {
        if (get_post_meta(absint($video_id), '_phisk_demo_stats_enabled', true)) return true;
        $author_id = (int) get_post_field('post_author', absint($video_id));
        return $author_id && (bool) get_user_meta($author_id, '_phisk_demo_stats_enabled', true);
    }

    public function register_publitio_settings() {
        register_setting('phiskvideos_publitio_group', 'phiskvideos_publitio_settings', [$this, 'sanitize_publitio_settings']);
    }

    public function sanitize_publitio_settings($input) {
        $old = get_option('phiskvideos_publitio_settings', []);
        $input = is_array($input) ? $input : [];
        $mode = isset($input['auth_mode']) && in_array($input['auth_mode'], ['key_secret', 'bearer'], true) ? $input['auth_mode'] : 'key_secret';
        return [
            'enabled' => !empty($input['enabled']) ? 1 : 0,
            'auth_mode' => $mode,
            'api_key' => isset($input['api_key']) ? sanitize_text_field($input['api_key']) : ($old['api_key'] ?? ''),
            'api_secret' => isset($input['api_secret']) && $input['api_secret'] !== '' ? sanitize_text_field($input['api_secret']) : ($old['api_secret'] ?? ''),
            'bearer_token' => isset($input['bearer_token']) && $input['bearer_token'] !== '' ? sanitize_text_field($input['bearer_token']) : ($old['bearer_token'] ?? ''),
            'privacy' => isset($input['privacy']) && (string)$input['privacy'] === '0' ? '0' : '1',
            'option_hls' => !empty($input['option_hls']) ? '1' : '0',
        ];
    }

    public function story_publishing_admin_page() {
        if (!current_user_can('manage_options')) return;
        if (isset($_POST['phisk_story_publishing_save'])) {
            check_admin_referer('phisk_story_publishing_settings');
            update_option('phiskvideos_story_auto_approval', !empty($_POST['story_auto_approval']) ? 1 : 0);
            echo '<div class="notice notice-success is-dismissible"><p>Story publishing settings saved.</p></div>';
        }
        $enabled = (bool) get_option('phiskvideos_story_auto_approval', 0);
        echo '<div class="wrap"><h1>Story Publishing</h1><form method="post">';
        wp_nonce_field('phisk_story_publishing_settings');
        echo '<table class="form-table"><tr><th scope="row">Automatic Story approval</th><td><label><input type="checkbox" name="story_auto_approval" value="1" '.checked($enabled, true, false).'> Automatically publish creator Stories without admin review</label><p class="description">When disabled, new Stories and creator edits are sent to Pending Review. Drafts remain drafts.</p></td></tr></table>';
        submit_button('Save Story Settings', 'primary', 'phisk_story_publishing_save');
        echo '</form></div>';
    }

    public function ajax_upload_story_image() {
        if (!is_user_logged_in() || !$this->user_has_phisk_channel(get_current_user_id())) wp_send_json_error(['message'=>'Please sign in with an active creator channel.'], 403);
        if ($this->user_strike_blocks_publishing(get_current_user_id())) wp_send_json_error(['message'=>'Publishing is restricted on your account. Visit Account Standing to review your strikes or appeal.'], 403);
        check_ajax_referer('phisk_story_image_upload', 'nonce');
        if (empty($_FILES['file'])) wp_send_json_error(['message'=>'Choose an image to upload.'], 400);
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        $file = $_FILES['file'];
        $allowed = ['image/jpeg','image/png','image/webp','image/gif'];
        $type = wp_check_filetype_and_ext($file['tmp_name'], $file['name']);
        if (empty($type['type']) || !in_array($type['type'], $allowed, true)) wp_send_json_error(['message'=>'Please upload a JPG, PNG, WebP or GIF image.'], 400);
        $attachment_id = media_handle_upload('file', 0, [], ['test_form'=>false]);
        if (is_wp_error($attachment_id)) wp_send_json_error(['message'=>$attachment_id->get_error_message()], 400);
        wp_update_post(['ID'=>$attachment_id, 'post_author'=>get_current_user_id()]);
        wp_send_json_success(['id'=>(int)$attachment_id,'url'=>wp_get_attachment_image_url($attachment_id,'medium'),'full'=>wp_get_attachment_image_url($attachment_id,'full'),'name'=>basename(get_attached_file($attachment_id))]);
    }

    public function publitio_settings_page() {
        if (!current_user_can('manage_options')) return;
        $o = get_option('phiskvideos_publitio_settings', []);
        $enabled = !empty($o['enabled']);
        ?>
        <div class="wrap">
          <h1>Phisk Videos — Publit.io Storage</h1>
          <p>Configure Publit.io for new video uploads. Existing WordPress-hosted videos are not moved automatically.</p>
          <form method="post" action="options.php">
            <?php settings_fields('phiskvideos_publitio_group'); ?>
            <table class="form-table" role="presentation">
              <tr><th scope="row">Use Publit.io for new uploads</th><td><label><input type="checkbox" name="phiskvideos_publitio_settings[enabled]" value="1" <?php checked($enabled); ?>> Enable Publit.io storage</label></td></tr>
              <tr><th scope="row">Authentication method</th><td><select name="phiskvideos_publitio_settings[auth_mode]"><option value="key_secret" <?php selected(($o['auth_mode'] ?? 'key_secret'), 'key_secret'); ?>>API Key + API Secret</option><option value="bearer" <?php selected(($o['auth_mode'] ?? 'key_secret'), 'bearer'); ?>>Bearer Access Token</option></select><p class="description">Use a token with create/upload permission if choosing Bearer Token.</p></td></tr>
              <tr><th scope="row"><label for="phisk-publitio-key">API Key</label></th><td><input id="phisk-publitio-key" class="regular-text" type="password" autocomplete="new-password" name="phiskvideos_publitio_settings[api_key]" value="<?php echo esc_attr($o['api_key'] ?? ''); ?>"><p class="description">Required for API Key + Secret authentication.</p></td></tr>
              <tr><th scope="row"><label for="phisk-publitio-secret">API Secret</label></th><td><input id="phisk-publitio-secret" class="regular-text" type="password" autocomplete="new-password" name="phiskvideos_publitio_settings[api_secret]" value="<?php echo esc_attr($o['api_secret'] ?? ''); ?>"><p class="description">Required with the API Key. Leave blank to keep the currently saved secret.</p></td></tr>
              <tr><th scope="row"><label for="phisk-publitio-token">Bearer Access Token</label></th><td><input id="phisk-publitio-token" class="regular-text" type="password" autocomplete="new-password" name="phiskvideos_publitio_settings[bearer_token]" value="<?php echo esc_attr($o['bearer_token'] ?? ''); ?>"><p class="description">Required only when Bearer Access Token is selected. Leave blank to keep the currently saved token.</p></td></tr>
              <tr><th scope="row">Uploaded video privacy</th><td><select name="phiskvideos_publitio_settings[privacy]"><option value="1" <?php selected(($o['privacy'] ?? '1'), '1'); ?>>Public</option><option value="0" <?php selected(($o['privacy'] ?? '1'), '0'); ?>>Private</option></select><p class="description">Public is required for public playback links to work on your site.</p></td></tr>
              <tr><th scope="row">HLS encryption</th><td><label><input type="checkbox" name="phiskvideos_publitio_settings[option_hls]" value="1" <?php checked(($o['option_hls'] ?? '0') === '1'); ?>> Enable HLS encryption (if supported by your Publit.io plan)</label></td></tr>
            </table>
            <?php submit_button('Save Publit.io Settings'); ?>
          </form>
          <hr><p><strong>Security:</strong> Credentials are stored in WordPress options and are never included in the plugin ZIP. Since an API key was shared in chat, consider rotating it in Publit.io before production use.</p>
        </div>
        <?php
    }

    /** Register Cloudflare settings. Credentials are kept server-side in WordPress options. */
    public function register_cloudflare_settings() {
        register_setting('phiskvideos_cloudflare_group', 'phiskvideos_cloudflare_settings', [$this, 'sanitize_cloudflare_settings']);
    }

    public function sanitize_cloudflare_settings($input) {
        $old = get_option('phiskvideos_cloudflare_settings', []);
        $input = is_array($input) ? $input : [];
        return [
            'account_id' => isset($input['account_id']) ? sanitize_text_field($input['account_id']) : ($old['account_id'] ?? ''),
            'api_token' => isset($input['api_token']) && $input['api_token'] !== '' ? sanitize_text_field($input['api_token']) : ($old['api_token'] ?? ''),
        ];
    }

    private function cloudflare_settings() {
        $o = get_option('phiskvideos_cloudflare_settings', []);
        return is_array($o) ? $o : [];
    }

    private function cloudflare_api_request($method, $path, $body = null) {
        $o = $this->cloudflare_settings();
        if (empty($o['account_id']) || empty($o['api_token'])) {
            return new WP_Error('phisk_cf_credentials', 'Enter your Cloudflare Account ID and Stream API token before using migration.');
        }
        $url = 'https://api.cloudflare.com/client/v4/accounts/' . rawurlencode(trim($o['account_id'])) . '/stream' . $path;
        $args = [
            'method' => strtoupper($method),
            'timeout' => 45,
            'redirection' => 0,
            'headers' => ['Authorization' => 'Bearer ' . trim($o['api_token']), 'Content-Type' => 'application/json', 'Accept' => 'application/json'],
        ];
        if ($body !== null) $args['body'] = wp_json_encode($body);
        $response = wp_remote_request($url, $args);
        if (is_wp_error($response)) return new WP_Error('phisk_cf_request', 'Cloudflare request failed: ' . $response->get_error_message());
        $code = (int) wp_remote_retrieve_response_code($response);
        $decoded = json_decode(wp_remote_retrieve_body($response), true);
        if ($code < 200 || $code >= 300 || !is_array($decoded) || empty($decoded['success'])) {
            $message = 'Cloudflare API request failed (HTTP ' . $code . ').';
            if (!empty($decoded['errors']) && is_array($decoded['errors'])) {
                $first = reset($decoded['errors']);
                if (is_array($first) && !empty($first['message'])) $message .= ' ' . sanitize_text_field($first['message']);
            }
            return new WP_Error('phisk_cf_api', $message);
        }
        return $decoded['result'] ?? [];
    }

    private function cloudflare_source_url($post_id) {
        $url = (string) get_post_meta($post_id, '_phisk_video_source_url', true);
        $attachment_id = absint(get_post_meta($post_id, '_phisk_video_attachment_id', true));
        if (!$url && $attachment_id) $url = (string) wp_get_attachment_url($attachment_id);
        if (!$url && get_post_meta($post_id, '_phisk_video_provider', true) === 'wordpress' && $attachment_id) $url = (string) wp_get_attachment_url($attachment_id);
        return esc_url_raw($url);
    }

    private function cloudflare_video_candidates($limit = 100) {
        return get_posts([
            'post_type' => 'phisk_video',
            'post_status' => ['publish', 'draft', 'pending', 'private'],
            'posts_per_page' => max(1, min(500, (int)$limit)),
            'orderby' => 'date', 'order' => 'ASC', 'fields' => 'ids',
            'meta_query' => [
                'relation' => 'OR',
                ['key' => '_phisk_video_provider', 'compare' => 'NOT EXISTS'],
                ['key' => '_phisk_video_provider', 'value' => 'wordpress', 'compare' => '='],
            ],
        ]);
    }

    public function handle_cloudflare_migration_actions() {
        if (!is_admin() || !current_user_can('manage_options') || empty($_POST['phisk_cf_action'])) return;
        check_admin_referer('phisk_cf_migration_action', 'phisk_cf_nonce');
        $action = sanitize_key(wp_unslash($_POST['phisk_cf_action']));
        $post_id = isset($_POST['video_id']) ? absint($_POST['video_id']) : 0;
        $notice = '';
        $type = 'updated';
        if ($action === 'save_settings') {
            $old = $this->cloudflare_settings();
            $account = isset($_POST['cf_account_id']) ? sanitize_text_field(wp_unslash($_POST['cf_account_id'])) : '';
            $token = isset($_POST['cf_api_token']) ? sanitize_text_field(wp_unslash($_POST['cf_api_token'])) : '';
            update_option('phiskvideos_cloudflare_settings', ['account_id'=>$account ?: ($old['account_id'] ?? ''), 'api_token'=>$token ?: ($old['api_token'] ?? '')], false);
            $notice = 'Cloudflare settings saved.';
        } elseif (in_array($action, ['migrate', 'retry_migrate'], true) && $post_id) {
            $post = get_post($post_id);
            if (!$post || $post->post_type !== 'phisk_video') {
                $notice = 'Video post not found.'; $type = 'error';
            } elseif (get_post_meta($post_id, '_phisk_video_provider', true) === 'cloudflare_stream') {
                $notice = 'This video is already using Cloudflare Stream.'; $type = 'error';
            } elseif (get_post_meta($post_id, '_phisk_cloudflare_stream_uid', true) && get_post_meta($post_id, '_phisk_cloudflare_migration_status', true) !== 'error' && $action !== 'retry_migrate') {
                $notice = 'This video already has a Cloudflare migration record. Check its status instead of submitting it again.'; $type = 'error';
            } else {
                if ($action === 'retry_migrate') { delete_post_meta($post_id, '_phisk_cloudflare_stream_uid'); delete_post_meta($post_id, '_phisk_cloudflare_migration_status'); }
                $source = $this->cloudflare_source_url($post_id);
                if (!$source || !wp_http_validate_url($source)) {
                    $notice = 'No valid public source URL was found. The original video must be accessible to Cloudflare for URL-based import.'; $type = 'error';
                } else {
                    $result = $this->cloudflare_api_request('POST', '/copy', ['url'=>$source, 'meta'=>['name'=>get_the_title($post_id), 'phisk_post_id'=>(string)$post_id], 'requireSignedURLs'=>false]);
                    if (is_wp_error($result)) { $notice = $result->get_error_message(); $type = 'error'; }
                    elseif (empty($result['uid'])) { $notice = 'Cloudflare accepted the request but did not return a video ID. No playback source was changed.'; $type = 'error'; }
                    else {
                        update_post_meta($post_id, '_phisk_cloudflare_stream_uid', sanitize_text_field($result['uid']));
                        update_post_meta($post_id, '_phisk_cloudflare_migration_status', 'processing');
                        update_post_meta($post_id, '_phisk_cloudflare_original_provider', get_post_meta($post_id, '_phisk_video_provider', true) ?: 'wordpress');
                        update_post_meta($post_id, '_phisk_cloudflare_original_url', $source);
                        update_post_meta($post_id, '_phisk_cloudflare_migration_started', current_time('mysql'));
                        $notice = 'Migration submitted for “' . get_the_title($post_id) . '”. The original playback source remains active until Cloudflare reports the video is ready.';
                    }
                }
            }
        } elseif ($action === 'check_status' && $post_id) {
            $uid = sanitize_text_field((string)get_post_meta($post_id, '_phisk_cloudflare_stream_uid', true));
            if (!$uid) { $notice = 'No Cloudflare migration ID is saved for this video.'; $type = 'error'; }
            else {
                $result = $this->cloudflare_api_request('GET', '/' . rawurlencode($uid));
                if (is_wp_error($result)) { $notice = $result->get_error_message(); $type = 'error'; }
                else {
                    $ready = !empty($result['readyToStream']) || (!empty($result['status']['state']) && $result['status']['state'] === 'ready');
                    $state = !empty($result['status']['state']) ? sanitize_key($result['status']['state']) : ($ready ? 'ready' : 'processing');
                    update_post_meta($post_id, '_phisk_cloudflare_migration_status', $state);
                    if ($ready) {
                        $manifest = 'https://videodelivery.net/' . rawurlencode($uid) . '/manifest/video.m3u8';
                        update_post_meta($post_id, '_phisk_video_provider', 'cloudflare_stream');
                        update_post_meta($post_id, '_phisk_video_source_id', $uid);
                        update_post_meta($post_id, '_phisk_video_source_url', $manifest);
                        update_post_meta($post_id, '_phisk_cloudflare_migrated_at', current_time('mysql'));
                        if (!empty($result['duration'])) {
                            $seconds = (int)round((float)$result['duration']);
                            if ($seconds > 0) {
                                $formatted = $seconds >= 3600 ? sprintf('%d:%02d:%02d', floor($seconds/3600), floor(($seconds%3600)/60), $seconds%60) : sprintf('%d:%02d', floor($seconds/60), $seconds%60);
                                update_post_meta($post_id, 'phisk_runtime', $formatted);
                                update_post_meta($post_id, '_phisk_video_duration_seconds', $seconds);
                            }
                        }
                        $notice = 'Cloudflare confirms this video is ready. Playback has been switched to Cloudflare; the WordPress post and featured thumbnail were preserved.';
                    } else {
                        $notice = 'Cloudflare status: ' . $state . '. The original playback source remains active.';
                    }
                }
            }
        }
        $url = add_query_arg(['page'=>'phiskvideos-cloudflare','phisk_cf_notice'=>rawurlencode($notice),'phisk_cf_notice_type'=>$type], admin_url('options-general.php'));
        wp_safe_redirect($url);
        exit;
    }

    public function cloudflare_migration_page() {
        if (!current_user_can('manage_options')) return;
        $o = $this->cloudflare_settings();
        $candidates = $this->cloudflare_video_candidates(500);
        $ready_count = 0; $pending_count = 0; $failed_count = 0;
        foreach (get_posts(['post_type'=>'phisk_video','post_status'=>['publish','draft','pending','private'],'posts_per_page'=>-1,'fields'=>'ids','meta_key'=>'_phisk_video_provider','meta_value'=>'cloudflare_stream']) as $id) $ready_count++;
        foreach (get_posts(['post_type'=>'phisk_video','post_status'=>['publish','draft','pending','private'],'posts_per_page'=>-1,'fields'=>'ids','meta_key'=>'_phisk_cloudflare_migration_status','meta_value'=>'processing']) as $id) $pending_count++;
        foreach (get_posts(['post_type'=>'phisk_video','post_status'=>['publish','draft','pending','private'],'posts_per_page'=>-1,'fields'=>'ids','meta_key'=>'_phisk_cloudflare_migration_status','meta_value'=>'error']) as $id) $failed_count++;
        echo '<div class="wrap"><h1>Phisk Videos — Cloudflare Stream Migration</h1>';
        if (isset($_GET['phisk_cf_notice'])) {
            $msg = sanitize_text_field(wp_unslash($_GET['phisk_cf_notice']));
            $class = isset($_GET['phisk_cf_notice_type']) && $_GET['phisk_cf_notice_type'] === 'error' ? 'notice notice-error' : 'notice notice-success';
            echo '<div class="' . esc_attr($class) . '"><p>' . esc_html($msg) . '</p></div>';
        }
        echo '<p>Prepare and migrate existing WordPress-hosted videos to Cloudflare Stream. This tool does not create new WordPress posts. Featured images, titles, descriptions, creator details, comments, likes, views and permalinks remain on the existing posts. The source is switched only after Cloudflare reports the asset is ready.</p>';
        echo '<div style="display:flex;gap:12px;flex-wrap:wrap;margin:16px 0"><div class="card" style="padding:12px 18px;margin:0"><strong>Eligible WordPress videos</strong><p style="font-size:22px;margin:8px 0">' . count($candidates) . '</p></div><div class="card" style="padding:12px 18px;margin:0"><strong>On Cloudflare</strong><p style="font-size:22px;margin:8px 0">' . (int)$ready_count . '</p></div><div class="card" style="padding:12px 18px;margin:0"><strong>Processing</strong><p style="font-size:22px;margin:8px 0">' . (int)$pending_count . '</p></div><div class="card" style="padding:12px 18px;margin:0"><strong>Failed</strong><p style="font-size:22px;margin:8px 0">' . (int)$failed_count . '</p></div></div>';
        echo '<h2>Cloudflare credentials</h2><p>Use an API token restricted to the correct account with Cloudflare Stream read/write permissions. The token is stored in WordPress options and is never shown after saving.</p><form method="post">';
        wp_nonce_field('phisk_cf_migration_action','phisk_cf_nonce');
        echo '<input type="hidden" name="phisk_cf_action" value="save_settings"><table class="form-table"><tr><th><label for="phisk-cf-account">Cloudflare Account ID</label></th><td><input class="regular-text" id="phisk-cf-account" name="cf_account_id" value="' . esc_attr($o['account_id'] ?? '') . '" autocomplete="off"></td></tr><tr><th><label for="phisk-cf-token">Stream API Token</label></th><td><input class="regular-text" type="password" id="phisk-cf-token" name="cf_api_token" value="" autocomplete="new-password"><p class="description">Leave blank to keep the existing token. Only paste the token in your private WordPress admin, never into chat.</p></td></tr></table>';
        submit_button('Save Cloudflare Settings'); echo '</form><hr><h2>Existing videos</h2><p>Migration uses Cloudflare URL copy. The source URL must be publicly reachable by Cloudflare. Start with one test video and verify it before migrating more.</p>';
        if (!$candidates) echo '<p>No WordPress-hosted videos are currently eligible for migration.</p>';
        else {
            echo '<table class="widefat striped"><thead><tr><th>Video</th><th>Status</th><th>Source</th><th>Action</th></tr></thead><tbody>';
            foreach ($candidates as $id) {
                $title = get_the_title($id); $source = $this->cloudflare_source_url($id); $uid = get_post_meta($id, '_phisk_cloudflare_stream_uid', true); $status = get_post_meta($id, '_phisk_cloudflare_migration_status', true) ?: 'not started';
                echo '<tr><td><strong><a href="' . esc_url(get_edit_post_link($id)) . '">' . esc_html($title ?: '(Untitled video)') . '</a></strong><br><small>ID ' . (int)$id . ' · ' . esc_html(get_post_status($id)) . '</small></td><td>' . esc_html($status) . ($uid ? '<br><small>UID: ' . esc_html($uid) . '</small>' : '') . '</td><td>' . ($source ? '<a href="' . esc_url($source) . '" target="_blank" rel="noopener">Open source</a>' : '<span style="color:#b32d2e">No source URL</span>') . '</td><td><form method="post" style="display:inline-block;margin-right:6px">';
                wp_nonce_field('phisk_cf_migration_action','phisk_cf_nonce');
                if ($uid && $status === 'error') echo '<input type="hidden" name="phisk_cf_action" value="retry_migrate">'; elseif ($uid) echo '<input type="hidden" name="phisk_cf_action" value="check_status">'; else echo '<input type="hidden" name="phisk_cf_action" value="migrate">';
                echo '<input type="hidden" name="video_id" value="' . (int)$id . '">';
                $button_label = ($uid && $status === 'error') ? 'Retry migration' : ($uid ? 'Check status / switch when ready' : 'Migrate video');
                submit_button($button_label, 'secondary small', 'submit', false, $uid && $status !== 'error' ? ['onclick'=>"return confirm('Check this Cloudflare asset status? If ready, playback will switch to Cloudflare.')"] : ['onclick'=>"return confirm('Submit this video to Cloudflare for import? The existing playback source will stay active until it is ready.')"]);
                echo '</form></td></tr>';
            }
            echo '</tbody></table>';
        }
        echo '<p class="description" style="margin-top:16px">Safety note: do not delete original WordPress media files until each migrated video has been tested on its Phisk page and you have a backup.</p></div>';
    }

    private function publitio_upload_video($file, $title) {
        $o = get_option('phiskvideos_publitio_settings', []);
        if (empty($o['enabled'])) return new WP_Error('publitio_disabled', 'Publit.io storage is not enabled.');
        if (empty($file['tmp_name']) || !is_readable($file['tmp_name'])) return new WP_Error('publitio_file', 'The uploaded temporary video file is not readable.');
        $mode = $o['auth_mode'] ?? 'key_secret';
        $url = 'https://api.publit.io/v1/files/create';
        $headers = ['Accept: application/json'];
        if ($mode === 'bearer') {
            if (empty($o['bearer_token'])) return new WP_Error('publitio_credentials', 'Add a Publit.io Bearer Access Token in Settings → Phisk Videos.');
            $headers[] = 'Authorization: Bearer ' . trim($o['bearer_token']);
        } else {
            if (empty($o['api_key']) || empty($o['api_secret'])) return new WP_Error('publitio_credentials', 'Add both your Publit.io API Key and API Secret in Settings → Phisk Videos.');
            $timestamp = (string) time();
            $nonce = (string) random_int(10000000, 99999999);
            $signature = sha1($timestamp . $nonce . $o['api_secret']);
            $url = add_query_arg(['api_key'=>$o['api_key'], 'api_timestamp'=>$timestamp, 'api_nonce'=>$nonce, 'api_signature'=>$signature], $url);
        }
        if (!function_exists('curl_init') || !class_exists('CURLFile')) return new WP_Error('publitio_curl', 'This server needs PHP cURL enabled to upload videos directly to Publit.io.');
        $post_fields = [
            'file' => new CURLFile($file['tmp_name'], $file['type'] ?: 'application/octet-stream', basename($file['name'])),
            'title' => sanitize_text_field($title),
            'privacy' => isset($o['privacy']) ? (string)$o['privacy'] : '1',
            'option_hls' => !empty($o['option_hls']) ? '1' : '0',
        ];
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_POST=>true, CURLOPT_POSTFIELDS=>$post_fields, CURLOPT_HTTPHEADER=>$headers, CURLOPT_RETURNTRANSFER=>true, CURLOPT_CONNECTTIMEOUT=>30, CURLOPT_TIMEOUT=>0, CURLOPT_FOLLOWLOCATION=>false]);
        $body = curl_exec($ch);
        $curl_error = curl_error($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($body === false) return new WP_Error('publitio_request', 'Publit.io upload request failed: ' . sanitize_text_field($curl_error));
        $data = json_decode($body, true);
        if ($status < 200 || $status >= 300 || !is_array($data) || (isset($data['success']) && !$data['success'])) {
            $message = is_array($data) ? ($data['message'] ?? $data['error'] ?? '') : '';
            return new WP_Error('publitio_api', 'Publit.io rejected the upload (HTTP ' . $status . '). ' . sanitize_text_field(is_string($message) ? $message : 'Check credentials and upload permissions.'));
        }
        $file_data = isset($data['file']) && is_array($data['file']) ? $data['file'] : $data;
        $source_url = '';
        foreach (['url_download','url_preview','url','secure_url'] as $key) {
            if (!empty($file_data[$key]) && is_string($file_data[$key]) && strpos($file_data[$key], 'https://') === 0) { $source_url = $file_data[$key]; break; }
        }
        if (!$source_url) return new WP_Error('publitio_response', 'Publit.io accepted the upload but returned no usable video URL. Check the file in your Publit.io dashboard.');
        return ['id'=>(string)($file_data['id'] ?? $file_data['public_id'] ?? ''), 'url'=>esc_url_raw($source_url), 'data'=>$file_data];
    }

    /** Create separate monetization tables without altering existing Phisk content data. */
    public function ensure_monetization_tables() {
        if (get_option('phisk_monetization_schema_version') === '1') return;
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $ledger = $wpdb->prefix . 'phisk_monetization_ledger';
        $payouts = $wpdb->prefix . 'phisk_monetization_payouts';
        $sql1 = "CREATE TABLE $ledger (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            content_id bigint(20) unsigned NOT NULL DEFAULT 0,
            content_type varchar(20) NOT NULL,
            event_key varchar(191) NOT NULL,
            amount_micros bigint(20) NOT NULL DEFAULT 0,
            status varchar(20) NOT NULL DEFAULT 'accrued',
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY event_key (event_key),
            KEY user_status (user_id,status),
            KEY content_type (content_id,content_type)
        ) $charset;";
        $sql2 = "CREATE TABLE $payouts (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            amount_micros bigint(20) unsigned NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'requested',
            payment_reference varchar(191) NOT NULL DEFAULT '',
            admin_note text NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY user_status (user_id,status)
        ) $charset;";
        dbDelta($sql1); dbDelta($sql2);
        update_option('phisk_monetization_schema_version', '1', false);
    }

    private function monetization_table($name) { global $wpdb; return $wpdb->prefix . 'phisk_monetization_' . $name; }

    private function format_monetization_amount($micros) {
        return '$' . number_format(((int)$micros) / 1000000, 6, '.', ',');
    }

    private function get_creator_monetization_summary($user_id) {
        global $wpdb; $table = $this->monetization_table('ledger');
        $rows = $wpdb->get_results($wpdb->prepare("SELECT content_type, status, SUM(amount_micros) AS total FROM $table WHERE user_id=%d GROUP BY content_type,status", $user_id), ARRAY_A);
        $out = ['total_micros'=>0,'video_micros'=>0,'article_micros'=>0,'available_micros'=>0];
        foreach ((array)$rows as $row) {
            $amount = (int)$row['total'];
            if ($row['status'] === 'reversed') continue;
            $out['total_micros'] += $amount;
            if ($row['content_type'] === 'video') $out['video_micros'] += $amount;
            if ($row['content_type'] === 'article') $out['article_micros'] += $amount;
            if ($row['status'] === 'accrued') $out['available_micros'] += $amount;
        }
        $reserved = (int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount_micros),0) FROM {$this->monetization_table('payouts')} WHERE user_id=%d AND status IN ('requested','approved','processing','paid')", $user_id));
        $out['available_micros'] = max(0, $out['available_micros'] - $reserved);
        return $out;
    }

    private function get_creator_eligibility($user_id) {
        $cutoff = gmdate('Y-m-d H:i:s', time() - (90 * DAY_IN_SECONDS));
        global $wpdb; $table = $this->monetization_table('ledger');
        $mode = get_option('phisk_monetization_video_mode', 'verified');
        $post_mode = get_option('phisk_monetization_post_mode', 'verified');
        $types = ($mode === 'regular' || $post_mode === 'regular') ? "('video','article')" : "('video')";
        $views = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE user_id=%d AND content_type IN $types AND status='accrued' AND created_at >= %s", $user_id, $cutoff));
        $subs = (int)$this->phisk_subscriber_count($user_id);
        $user = get_userdata($user_id); $age = $user ? max(0, (int)floor((time() - strtotime($user->user_registered . ' UTC')) / DAY_IN_SECONDS)) : 0;
        return ['views'=>$views,'subscribers'=>$subs,'account_days'=>$age,'eligible'=>($views >= (int)get_option('phisk_monetization_min_views',100) && $subs >= (int)get_option('phisk_monetization_min_subscribers',100) && $age >= (int)get_option('phisk_monetization_min_days',30))];
    }

    /**
     * Give anonymous visitors a random, first-party identifier so guest views can
     * be deduplicated without requiring a WordPress account.
     */
    public function ensure_guest_monetization_id() {
        if (is_admin() || is_user_logged_in() || headers_sent()) return;
        if (!empty($_COOKIE['phisk_guest_view_id']) && preg_match('/^[a-f0-9]{64}$/', (string)$_COOKIE['phisk_guest_view_id'])) return;
        $token = bin2hex(random_bytes(32));
        $path = defined('COOKIEPATH') && COOKIEPATH ? COOKIEPATH : '/';
        setcookie('phisk_guest_view_id', $token, [
            'expires' => time() + YEAR_IN_SECONDS,
            'path' => $path,
            'secure' => is_ssl(),
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        $_COOKIE['phisk_guest_view_id'] = $token;
    }

    /** AJAX endpoint credits eligible logged-in or anonymous engagement events. */
    public function ajax_monetization_event() {
        $logged_in = is_user_logged_in();
        check_ajax_referer('phisk_monetization_event', 'nonce');
        $viewer_id = $logged_in ? get_current_user_id() : 0;
        $post_id = isset($_POST['content_id']) ? absint($_POST['content_id']) : 0;
        if (!(int)get_option('phisk_monetization_enabled', 1)) wp_send_json_success(['credited'=>false,'reason'=>'disabled']);
        $kind = isset($_POST['content_type']) ? sanitize_key(wp_unslash($_POST['content_type'])) : '';
        $seconds = isset($_POST['watched_seconds']) ? max(0, (int)$_POST['watched_seconds']) : 0;
        $duration = isset($_POST['duration']) ? max(0, (int)$_POST['duration']) : 0;
        $post = get_post($post_id);
        if (!$post || $post->post_status !== 'publish' || ($logged_in && (int)$post->post_author === $viewer_id) || !in_array($kind,['video','article'],true)) wp_send_json_error(['message'=>'Invalid content'], 400);
        $creator_id = (int)$post->post_author;
        if (get_user_meta($creator_id, '_phisk_strike_monetization_paused', true)) wp_send_json_success(['credited'=>false,'reason'=>'creator_monetization_paused']);
        if (($kind === 'video' && $post->post_type !== 'phisk_video') || ($kind === 'article' && $post->post_type !== 'post')) wp_send_json_error(['message'=>'Content type mismatch'], 400);
        $mode_option = $kind === 'video' ? 'phisk_monetization_video_mode' : 'phisk_monetization_post_mode';
        $mode = get_option($mode_option, 'verified');
        $regular_mode = ($mode === 'regular');
        if (!$regular_mode) {
            if ($kind === 'video') {
                $threshold = (int)get_option('phisk_monetization_watch_percent', 50);
                if ($threshold < 1 || $duration < 1 || $seconds < 1 || ($seconds / $duration * 100) < $threshold) wp_send_json_success(['credited'=>false]);
            } else {
                $threshold = max(1, (int)get_option('phisk_monetization_article_seconds', 30));
                if ($seconds < $threshold) wp_send_json_success(['credited'=>false]);
            }
        }

        if ($logged_in) {
            $identity = 'user:' . $viewer_id;
            if (!$regular_mode) {
                $cooldown_key = '_phisk_monetized_' . $kind . '_' . $post_id;
                $last = (int)get_user_meta($viewer_id, $cooldown_key, true);
                if ($last && (time() - $last) < DAY_IN_SECONDS) wp_send_json_success(['credited'=>false,'reason'=>'cooldown']);
            } else {
                // Regular mode allows repeated views without a per-content daily cooldown,
                // while bounding automated abuse across the account.
                $rate_key = 'phisk_user_regular_monetization_rate_' . hash('sha256', $identity . ':' . gmdate('Y-m-d'));
                $rate = (int)get_transient($rate_key);
                if ($rate >= 300) wp_send_json_success(['credited'=>false,'reason'=>'rate_limit']);
                set_transient($rate_key, $rate + 1, DAY_IN_SECONDS);
            }
        } else {
            $guest_token = isset($_COOKIE['phisk_guest_view_id']) ? (string)$_COOKIE['phisk_guest_view_id'] : '';
            if (preg_match('/^[a-f0-9]{64}$/', $guest_token)) {
                $identity = 'guest:' . $guest_token;
            } else {
                // Full-page caches may prevent the first-party cookie from being set.
                // Fall back to a salted, non-reversible IP + user-agent fingerprint.
                $ip = isset($_SERVER['REMOTE_ADDR']) ? (string)$_SERVER['REMOTE_ADDR'] : '';
                $ua = isset($_SERVER['HTTP_USER_AGENT']) ? (string)$_SERVER['HTTP_USER_AGENT'] : '';
                if ($ip === '' || $ua === '') wp_send_json_success(['credited'=>false,'reason'=>'guest_id_missing']);
                $identity = 'guest-fallback:' . hash_hmac('sha256', $ip . '|' . $ua, wp_salt('auth'));
            }
            $guest_cooldown = 'phisk_guest_monetized_' . hash('sha256', $identity . ':' . $kind . ':' . $post_id);
            if (!$regular_mode && get_transient($guest_cooldown)) wp_send_json_success(['credited'=>false,'reason'=>'cooldown']);
            // Rate-limit guest credits, but do not impose a per-content/day rule in regular mode.
            $rate_key = 'phisk_guest_monetization_rate_' . hash('sha256', $identity . ':' . gmdate('Y-m-d'));
            $rate = (int)get_transient($rate_key);
            $rate_limit = $regular_mode ? 300 : 100;
            if ($rate >= $rate_limit) wp_send_json_success(['credited'=>false,'reason'=>'guest_rate_limit']);
            set_transient($rate_key, $rate + 1, DAY_IN_SECONDS);
        }

        // Verified mode keeps one credit per viewer/content/day. Regular mode assigns
        // a unique request key so repeated legitimate page views can earn separately.
        $request_id = isset($_POST['view_event_id']) ? sanitize_text_field(wp_unslash($_POST['view_event_id'])) : '';
        if ($regular_mode && !preg_match('/^[a-f0-9]{32}$/', $request_id)) wp_send_json_error(['message'=>'Invalid view event'], 400);
        $event_key = $regular_mode
            ? hash('sha256', $identity . ':' . $creator_id . ':' . $kind . ':' . $post_id . ':' . $request_id)
            : hash('sha256', $identity . ':' . $creator_id . ':' . $kind . ':' . $post_id . ':' . gmdate('Y-m-d', time()));
        global $wpdb;
        $table = $this->monetization_table('ledger');
        $inserted = $wpdb->insert($table, ['user_id'=>$creator_id,'content_id'=>$post_id,'content_type'=>$kind,'event_key'=>$event_key,'amount_micros'=>600,'status'=>'accrued','created_at'=>current_time('mysql', true)], ['%d','%d','%s','%s','%d','%s','%s']);
        if ($inserted) {
            if (!$regular_mode) {
                if ($logged_in) update_user_meta($viewer_id, $cooldown_key, time());
                else set_transient($guest_cooldown, 1, DAY_IN_SECONDS);
            }
        }
        wp_send_json_success(['credited'=>(bool)$inserted]);
    }

    public function monetization_tracking_script() {
        if (!is_singular(['phisk_video','post']) || is_admin()) return;
        $post_id = get_queried_object_id();
        $post = get_post($post_id);
        if (!$post || (is_user_logged_in() && (int)$post->post_author === get_current_user_id())) return;
        $kind = $post->post_type === 'phisk_video' ? 'video' : 'article';
        $nonce = wp_create_nonce('phisk_monetization_event');
        $ajax = admin_url('admin-ajax.php');
        ?>
        <script>
        (function(){var sent=false,seconds=0,last=Date.now(),visible=!document.hidden;var id=<?php echo (int)$post_id; ?>,kind=<?php echo wp_json_encode($kind); ?>,nonce=<?php echo wp_json_encode($nonce); ?>,url=<?php echo wp_json_encode($ajax); ?>;var video=document.querySelector('video');
        var regular=(kind==='video' ? <?php echo wp_json_encode(get_option('phisk_monetization_video_mode','verified') === 'regular'); ?> : <?php echo wp_json_encode(get_option('phisk_monetization_post_mode','verified') === 'regular'); ?>);
        function sendEvent(duration){var data=new URLSearchParams({action:'phisk_monetization_event',nonce:nonce,content_id:String(id),content_type:kind,watched_seconds:String(Math.floor(seconds)),duration:String(duration),view_event_id:regular?Array.from(crypto.getRandomValues(new Uint8Array(16))).map(function(b){return b.toString(16).padStart(2,'0');}).join(''):''});fetch(url,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:data.toString()}).then(function(r){return r.json();}).then(function(r){if(!r||!r.success)sent=false;}).catch(function(){sent=false;});}
        if(regular){sent=true;sendEvent(0);return;}
        function tick(){var now=Date.now(),delta=Math.min(5,Math.max(0,(now-last)/1000));last=now;if(visible){if(kind==='article')seconds+=delta;else if(video&&!video.paused&&!video.ended&&video.readyState>=2)seconds+=delta;}if(sent)return;var duration=(kind==='video'&&video&&isFinite(video.duration))?Math.floor(video.duration):0;var threshold=kind==='article'?<?php echo max(1,(int)get_option('phisk_monetization_article_seconds',30)); ?>:Math.max(1,Math.floor(duration*<?php echo max(1,min(100,(int)get_option('phisk_monetization_watch_percent',50))); ?>/100));if((kind==='article'&&seconds>=threshold)||(kind==='video'&&duration>0&&seconds>=threshold)){sent=true;sendEvent(duration);}}
        document.addEventListener('visibilitychange',function(){visible=!document.hidden;last=Date.now();});setInterval(tick,1000);})();
        </script>
        <?php
    }

    public function handle_monetization_frontend_actions() {
        if (!is_user_logged_in() || empty($_POST['phisk_monetization_action'])) return;
        $action = sanitize_key(wp_unslash($_POST['phisk_monetization_action']));
        $uid_for_strikes = get_current_user_id();
        $this->recalculate_user_strike_enforcement($uid_for_strikes, true);
        if (!isset($_POST['phisk_monetization_nonce'])) return;
        if ($action === 'apply') {
            if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['phisk_monetization_nonce'])), 'phisk_monetization_apply')) return;
            $uid = get_current_user_id(); $status = get_user_meta($uid, '_phisk_monetization_status', true);
            if (get_user_meta($uid, '_phisk_strike_monetization_paused', true)) { wp_safe_redirect(add_query_arg('monetization_notice', 'strike_paused', wp_get_referer() ?: $this->creator_studio_url())); exit; }
            if ($status === 'pending' || $status === 'approved' || $status === 'suspended') {
                wp_safe_redirect(add_query_arg('monetization_notice', 'already_submitted', wp_get_referer() ?: $this->creator_studio_url())); exit;
            }
            if (!$status || $status === 'not_applied' || $status === 'rejected') update_user_meta($uid, '_phisk_monetization_status', 'pending');
            wp_safe_redirect(add_query_arg('monetization_notice','applied', wp_get_referer() ?: $this->creator_studio_url())); exit;
        }
        if ($action === 'payout') {
            if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['phisk_monetization_nonce'])), 'phisk_monetization_payout')) return;
            $uid = get_current_user_id(); $summary = $this->get_creator_monetization_summary($uid); $elig = $this->get_creator_eligibility($uid);
            if (get_user_meta($uid, '_phisk_strike_monetization_paused', true) || get_user_meta($uid, '_phisk_monetization_status', true) !== 'approved' || !$elig['eligible'] || $summary['available_micros'] < 50000000) { wp_safe_redirect(add_query_arg('monetization_notice','locked', wp_get_referer() ?: $this->creator_studio_url())); exit; }
            global $wpdb; $now = current_time('mysql', true); $amount = (int) $summary['available_micros'];
            $inserted = $wpdb->insert($this->monetization_table('payouts'), ['user_id'=>$uid,'amount_micros'=>$amount,'status'=>'requested','created_at'=>$now,'updated_at'=>$now], ['%d','%d','%s','%s','%s']);
            if ($inserted) {
                $amount_text = $this->format_monetization_amount($amount);
                $this->send_strike_system_message($uid, 'Payout request received', 'We have received your payout request for ' . $amount_text . '. Its status is Pending review. Our administration team will review and update you when the request moves to processing, is paid, or is rejected.');
            }
            wp_safe_redirect(add_query_arg('monetization_notice','requested', wp_get_referer() ?: $this->creator_studio_url())); exit;
        }
    }

    public function handle_monetization_admin_actions() {
        if (!is_admin() || !current_user_can('manage_options')) return;
        if (!empty($_POST['phisk_monetization_save'])) {
            check_admin_referer('phisk_monetization_settings','phisk_monetization_settings_nonce');
            $percent = isset($_POST['watch_percent']) ? absint($_POST['watch_percent']) : 0;
            update_option('phisk_monetization_watch_percent', min(100, $percent), false);
            update_option('phisk_monetization_article_seconds', max(1, absint($_POST['article_seconds'] ?? 30)), false);
            update_option('phisk_monetization_min_views', max(0, absint($_POST['min_views'] ?? 100)), false);
            update_option('phisk_monetization_min_subscribers', max(0, absint($_POST['min_subscribers'] ?? 100)), false);
            update_option('phisk_monetization_min_days', max(0, absint($_POST['min_days'] ?? 30)), false);
            update_option('phisk_monetization_min_payout_micros', 50000000, false);
            $ad_share = isset($_POST['ad_share']) && $_POST['ad_share'] !== '' ? min(100, absint($_POST['ad_share'])) : '';
            update_option('phisk_monetization_ad_share', $ad_share, false);
            update_option('phisk_monetization_enabled', !empty($_POST['enabled']) ? 1 : 0, false);
            update_option('phisk_monetization_video_mode', in_array($_POST['video_mode'] ?? 'verified', ['verified','regular'], true) ? sanitize_key(wp_unslash($_POST['video_mode'] ?? 'verified')) : 'verified', false);
            update_option('phisk_monetization_post_mode', in_array($_POST['post_mode'] ?? 'verified', ['verified','regular'], true) ? sanitize_key(wp_unslash($_POST['post_mode'] ?? 'verified')) : 'verified', false);
            wp_safe_redirect(add_query_arg(['page'=>'phiskvideos-monetization','saved'=>'1'], admin_url('options-general.php'))); exit;
        }
        if (!empty($_POST['phisk_monetization_review'])) {
            check_admin_referer('phisk_monetization_review','phisk_monetization_review_nonce');
            $uid=absint($_POST['user_id'] ?? 0); $decision=sanitize_key(wp_unslash($_POST['decision'] ?? ''));
            if ($uid && get_userdata($uid) && in_array($decision,['approved','rejected','suspended'],true)) { $previous_status=get_user_meta($uid,'_phisk_monetization_status',true); if (get_user_meta($uid,'_phisk_strike_monetization_paused',true)) update_user_meta($uid,'_phisk_strike_saved_monetization_status',$decision); update_user_meta($uid,'_phisk_monetization_status',$decision); if ($decision === 'rejected') update_user_meta($uid,'_phisk_monetization_rejection_reason', sanitize_textarea_field(wp_unslash($_POST['rejection_reason'] ?? ''))); else delete_user_meta($uid,'_phisk_monetization_rejection_reason'); if ($decision === 'approved' && $previous_status !== 'approved' && !get_user_meta($uid,'_phisk_strike_monetization_paused',true)) $this->notify_monetization_approved($uid); $this->recalculate_user_strike_enforcement($uid, true); }
            wp_safe_redirect(add_query_arg(['page'=>'phiskvideos-monetization','reviewed'=>'1'],admin_url('options-general.php'))); exit;
        }
        if (!empty($_POST['phisk_payout_review'])) {
            check_admin_referer('phisk_payout_review','phisk_payout_review_nonce');
            global $wpdb; $pid=absint($_POST['payout_id'] ?? 0); $decision=sanitize_key(wp_unslash($_POST['decision'] ?? '')); $ref=sanitize_text_field(wp_unslash($_POST['payment_reference'] ?? ''));
            if ($pid && in_array($decision,['paid','rejected','processing'],true)) {
                $payout = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . $this->monetization_table('payouts') . ' WHERE id=%d', $pid));
                if ($payout && $payout->status !== $decision) {
                    $updated = $wpdb->update($this->monetization_table('payouts'),['status'=>$decision,'payment_reference'=>$ref,'updated_at'=>current_time('mysql',true)],['id'=>$pid],['%s','%s','%s'],['%d']);
                    if ($updated !== false) {
                        $amount_text = $this->format_monetization_amount((int) $payout->amount_micros);
                        if ($decision === 'processing') {
                            $subject = 'Your payout is being processed';
                            $body = 'Your payout request for ' . $amount_text . ' is now being processed by the PhiskVideos administration team. We will notify you again when the payment is completed.';
                        } elseif ($decision === 'paid') {
                            $subject = 'Your payout has been paid';
                            $body = 'Your payout of ' . $amount_text . ' has been marked as paid by the PhiskVideos administration team.';
                            if ($ref !== '') $body .= ' Payment reference: ' . $ref . '.';
                        } else {
                            $subject = 'Your payout request was rejected';
                            $body = 'Your payout request for ' . $amount_text . ' was rejected by the PhiskVideos administration team. Please contact PhiskVideos support if you need more information.';
                        }
                        $this->send_strike_system_message((int) $payout->user_id, $subject, $body);
                    }
                }
            }
            wp_safe_redirect(add_query_arg(['page'=>'phiskvideos-monetization','payout_updated'=>'1'],admin_url('options-general.php'))); exit;
        }
    }

    public function monetization_admin_page() {
        if (!current_user_can('manage_options')) return;
        global $wpdb; $users=get_users(['meta_key'=>'_phisk_monetization_status','meta_value'=>'pending','number'=>100]);
        $payouts=$wpdb->get_results("SELECT * FROM {$this->monetization_table('payouts')} WHERE status IN ('requested','processing') ORDER BY created_at ASC LIMIT 100");
        echo '<div class="wrap"><h1>Phisk Monetization</h1>';
        if (!empty($_GET['saved'])) echo '<div class="notice notice-success"><p>Monetization settings saved.</p></div>'; if (!empty($_GET['reviewed'])) echo '<div class="notice notice-success is-dismissible"><p>Creator monetization status updated successfully.</p></div>';
        echo '<p>Choose verified engagement or regular page-view monetization independently for videos and Stories. Verified Views remains the default. Advertising revenue sharing itself remains separate from these creator-reward counting modes.</p><form method="post">';
        wp_nonce_field('phisk_monetization_settings','phisk_monetization_settings_nonce'); echo '<input type="hidden" name="phisk_monetization_save" value="1"><table class="form-table"><tr><th>Enable monetization tracking</th><td><label><input type="checkbox" name="enabled" value="1" '.checked((int)get_option('phisk_monetization_enabled',1),1,false).'> Enable creator reward tracking</label></td></tr>';
        echo '<tr><th>Video monetization view mode</th><td><select name="video_mode"><option value="verified" '.selected(get_option('phisk_monetization_video_mode','verified'),'verified',false).'>Verified Views (default)</option><option value="regular" '.selected(get_option('phisk_monetization_video_mode','verified'),'regular',false).'>Regular Views</option></select><p class="description">Regular Views credits eligible published video page views without requiring playback. Repeat views can count; daily per-content cooldown is not applied.</p></td></tr>';
        echo '<tr><th>Story/post monetization view mode</th><td><select name="post_mode"><option value="verified" '.selected(get_option('phisk_monetization_post_mode','verified'),'verified',false).'>Verified Views (default)</option><option value="regular" '.selected(get_option('phisk_monetization_post_mode','verified'),'regular',false).'>Regular Views</option></select><p class="description">Regular Views credits eligible published Story/post page views without requiring a reading-time threshold. Repeat views can count; daily per-content cooldown is not applied.</p></td></tr>';
        echo '<tr><th>Video watch-time threshold</th><td><input type="number" name="watch_percent" min="0" max="100" value="'.esc_attr((int)get_option('phisk_monetization_watch_percent',50)).'"> % <p class="description">Set to 0 to disable video reward credits until configured. Default is 50% of video duration.</p></td></tr>';
        echo '<tr><th>Article read threshold</th><td><input type="number" name="article_seconds" min="1" value="'.esc_attr((int)get_option('phisk_monetization_article_seconds',30)).'"> seconds</td></tr>';
        echo '<tr><th>Minimum eligible views (last 90 days)</th><td><input type="number" name="min_views" min="0" value="'.esc_attr((int)get_option('phisk_monetization_min_views',100)).'"></td></tr><tr><th>Minimum subscribers</th><td><input type="number" name="min_subscribers" min="0" value="'.esc_attr((int)get_option('phisk_monetization_min_subscribers',100)).'"></td></tr><tr><th>Minimum account age</th><td><input type="number" name="min_days" min="0" value="'.esc_attr((int)get_option('phisk_monetization_min_days',30)).'"> days</td></tr><tr><th>Reward rate</th><td>$0.60 per 1,000 eligible video views and Story reads. Fixed in this release.</td></tr><tr><th>Minimum payout</th><td>$50.00 USD. Manual payouts only; advertising earnings disabled until configured.</td></tr><tr><th>Creator advertising share</th><td><input type="number" name="ad_share" min="0" max="100" value="'.esc_attr(get_option('phisk_monetization_ad_share','')).'" placeholder="Unset"> % <p class="description">Leave blank to keep advertising earnings disabled. Advertising source integration is not active in this release.</p></td></tr></table>'; submit_button('Save monetization settings'); echo '</form><hr><h2>Pending creator applications</h2>';
        if (!$users) echo '<p>No pending applications.</p>';
        foreach($users as $u){$e=$this->get_creator_eligibility($u->ID);echo '<div style="padding:12px 0;border-bottom:1px solid #ddd"><strong>'.esc_html($u->display_name).'</strong> (@'.esc_html($u->user_login).') — '.$e['views'].'/100 views, '.$e['subscribers'].'/100 subscribers, '.$e['account_days'].'/30 days';echo '<form method="post" style="margin-top:8px">';wp_nonce_field('phisk_monetization_review','phisk_monetization_review_nonce');echo '<input type="hidden" name="phisk_monetization_review" value="1"><input type="hidden" name="user_id" value="'.absint($u->ID).'"><input type="text" name="rejection_reason" placeholder="Reason if rejecting (optional)" style="min-width:240px"> <button class="button button-primary" name="decision" value="approved">Approve</button> <button class="button" name="decision" value="rejected">Reject</button> <button class="button" name="decision" value="suspended">Suspend</button></form></div>';}
        echo '<hr><h2>Pending payout requests</h2>';
        if (!$payouts) echo '<p>No pending payout requests.</p>';
        foreach($payouts as $pay){$u=get_userdata($pay->user_id);echo '<div style="padding:12px 0;border-bottom:1px solid #ddd"><strong>'.esc_html($u?$u->display_name:'Deleted user').'</strong> — '.$this->format_monetization_amount($pay->amount_micros).' — '.esc_html($pay->status).'<form method="post" style="margin-top:8px">';wp_nonce_field('phisk_payout_review','phisk_payout_review_nonce');echo '<input type="hidden" name="phisk_payout_review" value="1"><input type="hidden" name="payout_id" value="'.absint($pay->id).'"><input type="text" name="payment_reference" placeholder="Payment reference (optional)" value="'.esc_attr($pay->payment_reference).'"> <button class="button" name="decision" value="processing">Mark processing</button> <button class="button button-primary" name="decision" value="paid">Mark paid</button> <button class="button" name="decision" value="rejected">Reject</button></form></div>';}
        echo '</div>';
    }

    /** Notification schema and preferences. Notifications live in the plugin; the theme only displays the unread count. */
    public function ensure_notification_tables() {
        if (get_option('phisk_notifications_schema_version') === '2') return;
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $table = $wpdb->prefix . 'phisk_notifications';
        $charset = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            event_key varchar(150) NOT NULL,
            type varchar(40) NOT NULL,
            title varchar(190) NOT NULL,
            message text NOT NULL,
            target_url text NULL,
            inbox_enabled tinyint(1) NOT NULL DEFAULT 1,
            is_read tinyint(1) NOT NULL DEFAULT 0,
            email_sent tinyint(1) NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY user_event (user_id,event_key),
            KEY user_inbox (user_id,inbox_enabled,is_read,created_at),
            KEY created_at (created_at)
        ) {$charset};";
        dbDelta($sql);
        $messages_table = $wpdb->prefix . 'phisk_admin_messages';
        $messages_sql = "CREATE TABLE {$messages_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            sender_id bigint(20) unsigned NOT NULL,
            subject varchar(190) NOT NULL,
            message longtext NOT NULL,
            is_read tinyint(1) NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY user_inbox (user_id,is_read,created_at),
            KEY created_at (created_at)
        ) {$charset};";
        dbDelta($messages_sql);
        update_option('phisk_notifications_schema_version', '2', false);
    }

    private function notification_table() { global $wpdb; return $wpdb->prefix . 'phisk_notifications'; }
    private function admin_messages_table() { global $wpdb; return $wpdb->prefix . 'phisk_admin_messages'; }

    /** Native app session and device tables. Push delivery itself is added in Stage 2. */
    public function ensure_app_notification_tables() {
        if (get_option('phisk_app_notification_schema_version') === '1') return;
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $sessions = $wpdb->prefix . 'phisk_app_sessions';
        $sessions_sql = "CREATE TABLE {$sessions} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            token_hash char(64) NOT NULL,
            device_id varchar(100) NOT NULL DEFAULT '',
            expires_at datetime NOT NULL,
            revoked_at datetime NULL,
            created_at datetime NOT NULL,
            last_used_at datetime NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY token_hash (token_hash),
            KEY user_device (user_id,device_id),
            KEY expires_at (expires_at)
        ) {$charset};";
        dbDelta($sessions_sql);
        $devices = $wpdb->prefix . 'phisk_app_devices';
        $devices_sql = "CREATE TABLE {$devices} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            device_id varchar(100) NOT NULL,
            fcm_token text NOT NULL,
            token_hash char(64) NOT NULL,
            platform varchar(20) NOT NULL DEFAULT 'android',
            app_version varchar(40) NOT NULL DEFAULT '',
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            last_seen_at datetime NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY token_hash (token_hash),
            KEY user_device (user_id,device_id),
            KEY user_id (user_id)
        ) {$charset};";
        dbDelta($devices_sql);
        update_option('phisk_app_notification_schema_version', '1', false);
    }

    private function app_device_table() { global $wpdb; return $wpdb->prefix . 'phisk_app_devices'; }
    private function app_session_table() { global $wpdb; return $wpdb->prefix . 'phisk_app_sessions'; }

    private function app_device_id($value) {
        $value = preg_replace('/[^A-Za-z0-9._-]/', '', (string) $value);
        return substr($value, 0, 100);
    }

    private function create_app_session($user_id, $device_id = '') {
        global $wpdb;
        $this->ensure_app_notification_tables();
        try { $plain_token = bin2hex(random_bytes(32)); }
        catch (Exception $e) { return new WP_Error('phisk_app_session_failed', 'Unable to create a secure app session.', ['status' => 500]); }
        $now = current_time('mysql', true);
        $expires = gmdate('Y-m-d H:i:s', time() + (30 * DAY_IN_SECONDS));
        $ok = $wpdb->insert($this->app_session_table(), [
            'user_id' => absint($user_id), 'token_hash' => hash('sha256', $plain_token),
            'device_id' => $this->app_device_id($device_id), 'expires_at' => $expires,
            'revoked_at' => null, 'created_at' => $now, 'last_used_at' => $now,
        ], ['%d','%s','%s','%s','%s','%s','%s']);
        if (!$ok) return new WP_Error('phisk_app_session_failed', 'Unable to create a secure app session.', ['status' => 500]);
        return ['access_token' => $plain_token, 'token_type' => 'Bearer', 'expires_in' => 30 * DAY_IN_SECONDS];
    }

    private function app_bearer_value($request = null) {
        $header = $request instanceof WP_REST_Request ? (string) $request->get_header('authorization') : '';
        if ($header === '' && isset($_SERVER['HTTP_AUTHORIZATION'])) $header = (string) wp_unslash($_SERVER['HTTP_AUTHORIZATION']);
        if ($header === '' && isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) $header = (string) wp_unslash($_SERVER['REDIRECT_HTTP_AUTHORIZATION']);
        return preg_match('/^Bearer\s+([A-Fa-f0-9]{64})$/', trim($header), $m) ? $m[1] : '';
    }

    private function app_session_for_request($request = null) {
        $token = $this->app_bearer_value($request);
        if (!$token) return null;
        global $wpdb;
        $this->ensure_app_notification_tables();
        $row = $wpdb->get_row($wpdb->prepare(
            'SELECT id,user_id,device_id FROM ' . $this->app_session_table() . ' WHERE token_hash=%s AND revoked_at IS NULL AND expires_at>%s LIMIT 1',
            hash('sha256', $token), current_time('mysql', true)
        ));
        return $row ?: null;
    }

    /** Allows native requests to use short-lived-in-practice, revocable bearer sessions; browser cookie auth remains supported. */
    public function app_api_permission_callback($request) {
        $secure = $this->app_auth_require_https();
        if (is_wp_error($secure)) return $secure;
        if (is_user_logged_in()) return true;
        $session = $this->app_session_for_request($request);
        if (!$session || !get_userdata((int) $session->user_id)) return new WP_Error('phisk_app_auth_required', 'Please sign in to continue.', ['status' => 401]);
        wp_set_current_user((int) $session->user_id);
        global $wpdb;
        $wpdb->update($this->app_session_table(), ['last_used_at' => current_time('mysql', true)], ['id' => (int) $session->id], ['%s'], ['%d']);
        return true;
    }

    /** Public native reads may be anonymous, but resolve a supplied app bearer token for personalised fields. */
    public function app_api_optional_permission_callback($request) {
        if (is_user_logged_in()) return true;
        $authorization = (string) $request->get_header('authorization');
        if ($authorization === '') return true;
        return $this->app_api_permission_callback($request);
    }

    private function get_notification_preferences($user_id) {
        $defaults = [
            'video_inbox' => true, 'video_email' => true,
            'story_inbox' => true, 'story_email' => true,
            'story_approved_email' => true, 'monetization_approved_email' => true,
        ];
        $saved = get_user_meta(absint($user_id), '_phisk_notification_preferences', true);
        if (!is_array($saved)) $saved = [];
        foreach ($defaults as $key => $default) $defaults[$key] = array_key_exists($key, $saved) ? (bool) $saved[$key] : $default;
        return $defaults;
    }

    public function handle_notification_preferences_submission() {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || empty($_POST['phisk_notification_preferences_submit']) || !is_user_logged_in()) return;
        if (!isset($_POST['phisk_notification_preferences_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['phisk_notification_preferences_nonce'])), 'phisk_notification_preferences_save')) return;
        $keys = ['video_inbox','video_email','story_inbox','story_email','story_approved_email','monetization_approved_email'];
        $prefs = [];
        foreach ($keys as $key) $prefs[$key] = !empty($_POST[$key]);
        update_user_meta(get_current_user_id(), '_phisk_notification_preferences', $prefs);
        $url = wp_get_referer() ?: $this->account_settings_url();
        $url = remove_query_arg(['phisk_notification_saved'], $url);
        wp_safe_redirect(add_query_arg(['phisk_settings_tab'=>'notifications','phisk_notification_saved'=>'1'], $url));
        exit;
    }

    /** Create an in-app notification linked to a newly-created administration message.
     * The notification is an alert only; the full message remains in the existing admin-message inbox.
     */
    private function create_admin_message_notification($user_id, $message_id, $subject) {
        $user_id = absint($user_id);
        $message_id = absint($message_id);
        if (!$user_id || !$message_id || !get_userdata($user_id)) return 0;

        $messages_page_id = absint(get_option('phiskvideos_messages_page_id'));
        $target_url = $messages_page_id ? get_permalink($messages_page_id) : '';
        if (!$target_url) $target_url = home_url('/phisk-messages/');
        $target_url = add_query_arg('phisk_native_message', $message_id, $target_url);

        $subject = sanitize_text_field($subject);
        $preview = $subject !== '' ? 'You have received a new message: ' . $subject : 'You have received a new message from the PhiskVideos administration team.';

        return $this->create_notification(
            $user_id,
            'admin-message:' . $message_id,
            'admin_message',
            'New message from PhiskVideos',
            $preview,
            $target_url,
            true,
            false
        );
    }

    private function create_notification($user_id, $event_key, $type, $title, $message, $target_url = '', $inbox_enabled = true, $email_enabled = false) {
        global $wpdb;
        $user_id = absint($user_id);
        if (!$user_id || !get_userdata($user_id)) return 0;
        if (!$inbox_enabled && !$email_enabled) return 0;
        $this->ensure_notification_tables();
        $table = $this->notification_table();
        $now = current_time('mysql', true);
        $inserted = $wpdb->insert($table, [
            'user_id' => $user_id, 'event_key' => substr(sanitize_text_field($event_key), 0, 150),
            'type' => sanitize_key($type), 'title' => sanitize_text_field($title),
            'message' => sanitize_textarea_field($message), 'target_url' => esc_url_raw($target_url),
            'inbox_enabled' => $inbox_enabled ? 1 : 0, 'is_read' => 0, 'email_sent' => 0, 'created_at' => $now,
        ], ['%d','%s','%s','%s','%s','%s','%d','%d','%d','%s']);
        if (!$inserted) {
            // A unique user/event key prevents duplicate records if a WordPress hook runs twice.
            return 0;
        }
        $notification_id = (int) $wpdb->insert_id;
        if ($email_enabled) {
            $user = get_userdata($user_id);
            if ($user && is_email($user->user_email)) {
                $subject = '[' . wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES) . '] ' . sanitize_text_field($title);
                $body = sanitize_text_field($title) . "\n\n" . sanitize_textarea_field($message);
                if ($target_url) $body .= "\n\nOpen: " . esc_url_raw($target_url);
                $sent = wp_mail($user->user_email, $subject, $body, ['Content-Type: text/plain; charset=UTF-8']);
                if ($sent) $wpdb->update($table, ['email_sent'=>1], ['id'=>$notification_id], ['%d'], ['%d']);
            }
        }
        // Push is sent only after the in-app notification is safely stored.
        if ($inbox_enabled) $this->send_fcm_to_user_devices($user_id, $title, $message, $target_url, $notification_id);
        return $notification_id;
    }

    /** Send channel-update notifications only on first publication. */
    public function handle_notification_content_publication($new_status, $old_status, $post) {
        if ($new_status !== 'publish' || $old_status === 'publish' || !($post instanceof WP_Post)) return;
        if (!in_array($post->post_type, ['phisk_video', 'post'], true)) return;
        $author_id = absint($post->post_author);
        if (!$author_id) return;
        $is_video = $post->post_type === 'phisk_video';
        // Stories created by the Phisk Story composer are pending for review; only notify on their public approval.
        if (!$is_video && !metadata_exists('post', $post->ID, '_phisk_article_gallery_ids')) return;
        $prefs_key = $is_video ? 'video' : 'story';
        $type = $is_video ? 'new_video' : 'new_story';
        $label = $is_video ? 'video' : 'Story';
        $title = $is_video ? 'New video from a channel you follow' : 'New Story from a channel you follow';
        $message = $is_video ? get_the_title($post) . ' has been published.' : get_the_title($post) . ' has been published by a channel you follow.';
        $target = get_permalink($post->ID);
        $prefs_query = new WP_User_Query([
            'fields' => 'ID', 'number' => 10000,
            'meta_query' => [['key'=>'phisk_following','value'=>'i:' . $author_id . ';','compare'=>'LIKE']],
        ]);
        $followers = $prefs_query->get_results();
        if (!is_array($followers)) return;
        foreach ($followers as $follower_id) {
            $follower_id = absint($follower_id);
            if (!$follower_id || $follower_id === $author_id) continue;
            $prefs = $this->get_notification_preferences($follower_id);
            $this->create_notification($follower_id, $prefs_key . ':' . $post->ID, $type, $title, $message, $target, $prefs[$prefs_key . '_inbox'], $prefs[$prefs_key . '_email']);
        }
        // Approval is a mandatory inbox event for the Story's author; email is optional.
        if (!$is_video && in_array($old_status, ['pending','draft'], true)) {
            $prefs = $this->get_notification_preferences($author_id);
            $this->create_notification($author_id, 'story-approved:' . $post->ID, 'story_approved', 'Your Story has been approved', 'Your Story “' . get_the_title($post) . '” has been approved and is now published on PhiskVideos.', $target, true, $prefs['story_approved_email']);
        }
    }

    /** Create the mandatory inbox event when an administrator approves monetization. */
    private function notify_monetization_approved($user_id) {
        $prefs = $this->get_notification_preferences($user_id);
        $event = 'monetization-approved:' . absint($user_id) . ':' . gmdate('YmdHis');
        $target = $this->creator_studio_url();
        $this->create_notification($user_id, $event, 'monetization_approved', 'Monetization approved', 'Congratulations! Your PhiskVideos monetization application has been approved.', $target, true, $prefs['monetization_approved_email']);
    }

    public function theme_mobile_unread_total($current = 0) {
        if (!is_user_logged_in()) return 0;
        global $wpdb;
        $this->ensure_notification_tables();
        $notification_count = (int) $wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM ' . $this->notification_table() . ' WHERE user_id = %d AND inbox_enabled = 1 AND is_read = 0', get_current_user_id()));
        $message_count = (int) $wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM ' . $this->admin_messages_table() . ' WHERE user_id = %d AND is_read = 0', get_current_user_id()));
        return max(0, $notification_count + $message_count);
    }

    public function ajax_unread_notification_count() {
        if (!is_user_logged_in()) wp_send_json_error(['message'=>'Login required.'], 401);
        check_ajax_referer('phisk_notifications_count', 'nonce');
        wp_send_json_success(['count'=>$this->theme_mobile_unread_total()]);
    }

    /** Native Android app authentication endpoints. Passwords are sent only over HTTPS. */
    public function register_app_auth_rest_routes() {
        register_rest_route('phisk/v1', '/app-auth/login', [
            'methods' => 'POST', 'callback' => [$this, 'app_auth_login'], 'permission_callback' => '__return_true',
        ]);
        register_rest_route('phisk/v1', '/app-auth/register', [
            'methods' => 'POST', 'callback' => [$this, 'app_auth_register'], 'permission_callback' => '__return_true',
        ]);
        register_rest_route('phisk/v1', '/app-auth/password-reset', [
            'methods' => 'POST', 'callback' => [$this, 'app_auth_password_reset'], 'permission_callback' => '__return_true',
        ]);
        register_rest_route('phisk/v1', '/app-auth/me', [
            'methods' => 'GET', 'callback' => [$this, 'app_auth_me'], 'permission_callback' => [$this, 'app_api_permission_callback'],
        ]);
        register_rest_route('phisk/v1', '/app-auth/logout', [
            'methods' => 'POST', 'callback' => [$this, 'app_auth_logout'], 'permission_callback' => [$this, 'app_api_permission_callback'],
        ]);
    }

    private function app_auth_throttle($action) {
        $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : 'unknown';
        $key = 'phisk_app_auth_' . md5($action . '|' . $ip);
        $count = (int) get_transient($key);
        if ($count >= 10) return new WP_Error('phisk_auth_rate_limited', 'Too many attempts. Please wait 15 minutes and try again.', ['status' => 429]);
        set_transient($key, $count + 1, 15 * MINUTE_IN_SECONDS);
        return true;
    }

    private function app_auth_require_https() {
        if (!is_ssl() && ! (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower(sanitize_text_field(wp_unslash($_SERVER['HTTP_X_FORWARDED_PROTO']))) === 'https')) {
            return new WP_Error('phisk_auth_https_required', 'Secure HTTPS connection required.', ['status' => 403]);
        }
        return true;
    }

    public function app_auth_login(WP_REST_Request $request) {
        $secure = $this->app_auth_require_https(); if (is_wp_error($secure)) return $secure;
        $limited = $this->app_auth_throttle('login'); if (is_wp_error($limited)) return $limited;
        $identity = sanitize_text_field((string) $request->get_param('username'));
        $password = (string) $request->get_param('password');
        if ($identity === '' || $password === '' || strlen($password) > 4096) return new WP_Error('phisk_auth_missing_fields', 'Enter your username/email and password.', ['status' => 400]);
        $user = wp_signon(['user_login' => $identity, 'user_password' => $password, 'remember' => true], is_ssl());
        if (is_wp_error($user)) return new WP_Error('phisk_auth_invalid', 'The username/email or password is incorrect.', ['status' => 401]);
        wp_set_current_user($user->ID); wp_set_auth_cookie($user->ID, true, is_ssl());
        $session = $this->create_app_session($user->ID, $request->get_param('device_id'));
        if (is_wp_error($session)) return $session;
        return rest_ensure_response(['success' => true, 'user' => $this->app_auth_user_payload($user)] + $session);
    }

    public function app_auth_register(WP_REST_Request $request) {
        $secure = $this->app_auth_require_https(); if (is_wp_error($secure)) return $secure;
        $limited = $this->app_auth_throttle('register'); if (is_wp_error($limited)) return $limited;
        if (get_option('users_can_register') != 1) return new WP_Error('phisk_registration_closed', 'Registration is currently unavailable.', ['status' => 403]);
        $email = sanitize_email((string) $request->get_param('email'));
        $username = sanitize_user((string) $request->get_param('username'), true);
        $password = (string) $request->get_param('password');
        $name = sanitize_text_field((string) $request->get_param('name'));
        if (!is_email($email) || $username === '' || strlen($username) < 3 || strlen($password) < 10 || strlen($password) > 4096) return new WP_Error('phisk_registration_invalid', 'Enter a valid email, username (at least 3 characters) and password (at least 10 characters).', ['status' => 400]);
        if (username_exists($username)) return new WP_Error('phisk_username_exists', 'That username is already taken.', ['status' => 409]);
        if (email_exists($email)) return new WP_Error('phisk_email_exists', 'An account already exists with that email address. Try signing in or resetting your password.', ['status' => 409]);
        $user_id = wp_create_user($username, $password, $email);
        if (is_wp_error($user_id)) return new WP_Error('phisk_registration_failed', $user_id->get_error_message(), ['status' => 400]);
        if ($name !== '') wp_update_user(['ID' => $user_id, 'display_name' => $name, 'first_name' => $name]);
        $user = get_user_by('id', $user_id);
        wp_set_current_user($user_id); wp_set_auth_cookie($user_id, true, is_ssl());
        $session = $this->create_app_session($user_id, $request->get_param('device_id'));
        if (is_wp_error($session)) return $session;
        return new WP_REST_Response(['success' => true, 'user' => $this->app_auth_user_payload($user)] + $session, 201);
    }

    public function app_auth_password_reset(WP_REST_Request $request) {
        $secure = $this->app_auth_require_https(); if (is_wp_error($secure)) return $secure;
        $limited = $this->app_auth_throttle('reset'); if (is_wp_error($limited)) return $limited;
        $login = sanitize_text_field((string) $request->get_param('login'));
        if ($login === '') return new WP_Error('phisk_reset_missing', 'Enter your email address or username.', ['status' => 400]);
        $result = retrieve_password($login);
        if (is_wp_error($result)) return new WP_Error('phisk_reset_failed', 'We could not send a reset email for those details. Check them and try again.', ['status' => 400]);
        return rest_ensure_response(['success' => true, 'message' => 'If an account matches those details, a password reset email has been sent.']);
    }

    public function app_auth_me() {
        $user = wp_get_current_user();
        return rest_ensure_response(['success' => true, 'user' => $this->app_auth_user_payload($user)]);
    }

    public function app_auth_logout() {
        $session = $this->app_session_for_request();
        if ($session) {
            global $wpdb;
            $now = current_time('mysql', true);
            $wpdb->update($this->app_session_table(), ['revoked_at' => $now], ['id' => (int) $session->id], ['%s'], ['%d']);
            if (!empty($session->device_id)) {
                $wpdb->delete($this->app_device_table(), ['user_id' => (int) $session->user_id, 'device_id' => $session->device_id], ['%d','%s']);
            }
        }
        wp_logout();
        return rest_ensure_response(['success' => true]);
    }

    private function app_auth_user_payload($user) {
        return ['id' => (int) $user->ID, 'username' => $user->user_login, 'name' => $user->display_name, 'email' => $user->user_email];
    }

    /** Attach the same revocable app Bearer session used by password login to native Google login. */
    public function attach_mobile_google_app_session($response, $user, $request) {
        if (!is_array($response) || !($user instanceof WP_User) || !($request instanceof WP_REST_Request)) return $response;
        $secure = $this->app_auth_require_https();
        if (is_wp_error($secure)) return $response;
        $session = $this->create_app_session($user->ID, $request->get_param('device_id'));
        if (is_wp_error($session)) {
            $response['app_session_error'] = 'Unable to create the native app session. Please sign in again.';
            return $response;
        }
        return array_merge($response, $session);
    }

    /** Native Android watch-page API. Uses the same video/provider and creator data as the website. */
    public function register_native_watch_rest_routes() {
        register_rest_route('phisk/v1', '/videos/(?P<id>\d+)', [
            'methods' => WP_REST_Server::READABLE,
            'permission_callback' => [$this, 'app_api_optional_permission_callback'],
            'callback' => [$this, 'rest_native_video_detail'],
            'args' => ['id' => ['required' => true, 'sanitize_callback' => 'absint']],
        ]);
        register_rest_route('phisk/v1', '/videos/(?P<id>\d+)/related', [
            'methods' => WP_REST_Server::READABLE,
            'permission_callback' => [$this, 'app_api_optional_permission_callback'],
            'callback' => [$this, 'rest_native_video_related'],
        ]);
        register_rest_route('phisk/v1', '/videos/(?P<id>\d+)/comments', [
            [ 'methods' => WP_REST_Server::READABLE, 'permission_callback' => [$this, 'app_api_optional_permission_callback'], 'callback' => [$this, 'rest_native_video_comments'] ],
            [ 'methods' => WP_REST_Server::CREATABLE, 'permission_callback' => [$this, 'app_api_permission_callback'], 'callback' => [$this, 'rest_native_add_video_comment'] ],
        ]);
        register_rest_route('phisk/v1', '/videos/(?P<id>\d+)/like', [
            'methods' => WP_REST_Server::CREATABLE, 'permission_callback' => [$this, 'app_api_permission_callback'],
            'callback' => [$this, 'rest_native_video_like'],
        ]);
        register_rest_route('phisk/v1', '/videos/(?P<id>\d+)/report', [
            'methods' => WP_REST_Server::CREATABLE, 'permission_callback' => [$this, 'app_api_permission_callback'],
            'callback' => [$this, 'rest_native_video_report'],
        ]);
        register_rest_route('phisk/v1', '/videos/(?P<id>\d+)/download', [
            'methods' => WP_REST_Server::CREATABLE, 'permission_callback' => [$this, 'app_api_permission_callback'],
            'callback' => [$this, 'rest_native_video_download'],
        ]);
        register_rest_route('phisk/v1', '/videos/(?P<id>\d+)/view', [
            'methods' => WP_REST_Server::CREATABLE, 'permission_callback' => '__return_true',
            'callback' => [$this, 'rest_native_video_view'],
        ]);
    }

    /** Native creator channel and Creator Studio APIs. */
    public function register_native_creator_rest_routes() {
        register_rest_route('phisk/v1', '/search', [
            'methods' => WP_REST_Server::READABLE,
            'permission_callback' => '__return_true',
            'callback' => [$this, 'rest_native_search'],
            'args' => [
                'q' => ['required' => true, 'sanitize_callback' => 'sanitize_text_field'],
                'type' => ['required' => true, 'sanitize_callback' => 'sanitize_key'],
                'page' => ['default' => 1, 'sanitize_callback' => 'absint'],
                'per_page' => ['default' => 10, 'sanitize_callback' => 'absint'],
            ],
        ]);
        register_rest_route('phisk/v1', '/creator-studio', [
            'methods' => WP_REST_Server::READABLE, 'permission_callback' => [$this, 'app_api_permission_callback'],
            'callback' => [$this, 'rest_native_creator_studio'],
        ]);
        register_rest_route('phisk/v1', '/creator-studio/monetization', [
            'methods' => WP_REST_Server::CREATABLE, 'permission_callback' => [$this, 'app_api_permission_callback'],
            'callback' => [$this, 'rest_native_creator_studio_apply'],
        ]);
        register_rest_route('phisk/v1', '/creator-studio/payout', [
            'methods' => WP_REST_Server::CREATABLE, 'permission_callback' => [$this, 'app_api_permission_callback'],
            'callback' => [$this, 'rest_native_creator_studio_payout'],
        ]);
        register_rest_route('phisk/v1', '/creators/(?P<id>\d+)', [
            'methods' => WP_REST_Server::READABLE, 'permission_callback' => [$this, 'app_api_permission_callback'],
            'callback' => [$this, 'rest_native_creator_detail'],
        ]);
        register_rest_route('phisk/v1', '/creators/(?P<id>\d+)/videos', [
            'methods' => WP_REST_Server::READABLE, 'permission_callback' => [$this, 'app_api_permission_callback'],
            'callback' => [$this, 'rest_native_creator_videos'],
        ]);
        register_rest_route('phisk/v1', '/creators/(?P<id>\d+)/stories', [
            'methods' => WP_REST_Server::READABLE, 'permission_callback' => [$this, 'app_api_permission_callback'],
            'callback' => [$this, 'rest_native_creator_stories'],
        ]);
        register_rest_route('phisk/v1', '/creators/(?P<id>\d+)/subscribe', [
            'methods' => WP_REST_Server::CREATABLE, 'permission_callback' => [$this, 'app_api_permission_callback'],
            'callback' => [$this, 'rest_native_creator_subscribe'],
        ]);
        register_rest_route('phisk/v1', '/creator-channel', [
            ['methods' => WP_REST_Server::READABLE, 'permission_callback' => [$this, 'app_api_permission_callback'], 'callback' => [$this, 'rest_native_creator_channel_edit'] ],
            ['methods' => WP_REST_Server::CREATABLE, 'permission_callback' => [$this, 'app_api_permission_callback'], 'callback' => [$this, 'rest_native_creator_channel_save'] ],
        ]);
        register_rest_route('phisk/v1', '/creator-channel/image', [
            'methods' => WP_REST_Server::CREATABLE, 'permission_callback' => [$this, 'app_api_permission_callback'],
            'callback' => [$this, 'rest_native_creator_channel_image'],
        ]);
        register_rest_route('phisk/v1', '/creator-studio/story-interests', [
            'methods' => WP_REST_Server::READABLE, 'permission_callback' => [$this, 'app_api_permission_callback'],
            'callback' => [$this, 'rest_native_story_interests'],
        ]);
        register_rest_route('phisk/v1', '/creator-studio/stories/images', [
            'methods' => WP_REST_Server::CREATABLE, 'permission_callback' => [$this, 'app_api_permission_callback'],
            'callback' => [$this, 'rest_native_upload_story_image'],
        ]);
        register_rest_route('phisk/v1', '/creator-studio/stories/publish', [
            'methods' => WP_REST_Server::CREATABLE, 'permission_callback' => [$this, 'app_api_permission_callback'],
            'callback' => [$this, 'rest_native_publish_story'],
        ]);
        register_rest_route('phisk/v1', '/creator-studio/videos/upload', [
            'methods' => WP_REST_Server::CREATABLE, 'permission_callback' => [$this, 'app_api_permission_callback'],
            'callback' => [$this, 'rest_native_upload_video_draft'],
        ]);
        register_rest_route('phisk/v1', '/creator-studio/videos/(?P<id>\d+)/details', [
            'methods' => WP_REST_Server::CREATABLE, 'permission_callback' => [$this, 'app_api_permission_callback'],
            'callback' => [$this, 'rest_native_update_video_draft'],
            'args' => ['id' => ['required' => true, 'sanitize_callback' => 'absint']],
        ]);
        register_rest_route('phisk/v1', '/creator-studio/videos/(?P<id>\d+)/publish', [
            'methods' => WP_REST_Server::CREATABLE, 'permission_callback' => [$this, 'app_api_permission_callback'],
            'callback' => [$this, 'rest_native_publish_video_draft'],
            'args' => ['id' => ['required' => true, 'sanitize_callback' => 'absint']],
        ]);
    }

    /** Return the existing Story interest taxonomy for the native composer. */
    public function rest_native_story_interests($request) {
        $user_id = get_current_user_id();
        if (!$user_id || !$this->user_has_phisk_channel($user_id)) return new WP_Error('phisk_channel_required', 'Create a Channel to write a Story.', ['status'=>403]);
        $terms = get_terms(['taxonomy'=>'phisk_interest','hide_empty'=>false]);
        if (is_wp_error($terms)) return new WP_Error('phisk_story_interests_failed', 'Story interests could not be loaded.', ['status'=>500]);
        $items = [];
        foreach ($terms as $term) $items[] = ['id'=>(int)$term->term_id,'name'=>(string)$term->name];
        return new WP_REST_Response(['interests'=>$items]);
    }

    /** Upload one Story image into the existing WordPress media library for the authenticated creator. */
    public function rest_native_upload_story_image($request) {
        $user_id = get_current_user_id();
        if (!$user_id || !$this->user_has_phisk_channel($user_id)) return new WP_Error('phisk_channel_required', 'Create a Channel to write a Story.', ['status'=>403]);
        if ($this->user_strike_blocks_publishing($user_id)) return new WP_Error('phisk_publishing_restricted', 'Publishing is restricted on your account. Visit Account Standing to review your strikes or appeal.', ['status'=>403]);
        $files = $request->get_file_params();
        $file = isset($files['image']) ? $files['image'] : null;
        if (!$file || empty($file['tmp_name']) || !empty($file['error'])) return new WP_Error('phisk_story_image_missing', 'Choose a Story image to upload.', ['status'=>400]);
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        $checked = wp_check_filetype_and_ext($file['tmp_name'], $file['name'] ?? 'story-image');
        if (empty($checked['type']) || !in_array($checked['type'], ['image/jpeg','image/png','image/webp','image/gif'], true)) return new WP_Error('phisk_story_image_format', 'Please upload a JPG, PNG, WebP or GIF image.', ['status'=>400]);
        $attachment_id = media_handle_sideload($file, 0);
        if (is_wp_error($attachment_id)) return new WP_Error('phisk_story_image_upload', 'The Story image could not be saved: '.$attachment_id->get_error_message(), ['status'=>500]);
        wp_update_post(['ID'=>$attachment_id,'post_author'=>$user_id]);
        return new WP_REST_Response(['success'=>true,'id'=>(int)$attachment_id,'url'=>wp_get_attachment_image_url($attachment_id,'medium'),'full'=>wp_get_attachment_image_url($attachment_id,'full'),'message'=>'Story image uploaded.'], 201);
    }

    /** Create a Story using the same post type, taxonomy, gallery metadata and moderation rules as the website composer. */
    public function rest_native_publish_story($request) {
        $user_id = get_current_user_id();
        if (!$user_id || !$this->user_has_phisk_channel($user_id)) return new WP_Error('phisk_channel_required', 'Create a Channel to write a Story.', ['status'=>403]);
        if ($this->user_strike_blocks_publishing($user_id)) return new WP_Error('phisk_publishing_restricted', 'Publishing is restricted on your account. Visit Account Standing to review your strikes or appeal.', ['status'=>403]);
        $title = sanitize_text_field((string)$request->get_param('title'));
        $content = wp_kses_post((string)$request->get_param('content'));
        $excerpt = sanitize_textarea_field((string)$request->get_param('excerpt'));
        $interest_id = absint($request->get_param('interest_id'));
        $action = sanitize_key((string)$request->get_param('action'));
        $image_ids = $request->get_param('image_ids');
        if (!is_array($image_ids)) $image_ids = [];
        $image_ids = array_values(array_unique(array_filter(array_map('absint', $image_ids))));
        $length = function_exists('mb_strlen') ? mb_strlen($title, 'UTF-8') : strlen($title);
        if ($title === '' || $length > 100) return new WP_Error('phisk_story_title_invalid', 'Enter a Story title of no more than 100 characters.', ['status'=>400]);
        if (trim(wp_strip_all_tags($content)) === '') return new WP_Error('phisk_story_content_required', 'Write some content for your Story.', ['status'=>400]);
        if (!$interest_id || !term_exists($interest_id, 'phisk_interest')) return new WP_Error('phisk_story_interest_required', 'Please choose an interest for your Story.', ['status'=>400]);
        if (!$image_ids) return new WP_Error('phisk_story_images_required', 'Please add at least one Story image.', ['status'=>400]);
        foreach ($image_ids as $image_id) {
            if (!wp_attachment_is_image($image_id) || (int)get_post_field('post_author', $image_id) !== $user_id) return new WP_Error('phisk_story_image_invalid', 'One of the selected images is not available to your account.', ['status'=>403]);
        }
        $auto = (bool)get_option('phiskvideos_story_auto_approval', 0);
        $status = $action === 'draft' ? 'draft' : ($auto ? 'publish' : 'pending');
        $post_id = wp_insert_post(['post_type'=>'post','post_status'=>$status,'post_title'=>$title,'post_content'=>$content,'post_excerpt'=>$excerpt,'post_author'=>$user_id], true);
        if (is_wp_error($post_id) || !$post_id) return new WP_Error('phisk_story_save_failed', 'Your Story could not be saved. Please try again.', ['status'=>500]);
        wp_set_object_terms($post_id, [$interest_id], 'phisk_interest', false);
        if ($excerpt !== '') update_post_meta($post_id, '_phisk_article_short_intro', $excerpt);
        update_post_meta($post_id, '_phisk_article_gallery_ids', $image_ids);
        set_post_thumbnail($post_id, $image_ids[0]);
        if ($status === 'pending') { delete_post_meta($post_id, '_phisk_article_review_status'); delete_post_meta($post_id, '_phisk_article_rejection_reason'); delete_post_meta($post_id, '_phisk_article_rejection_note'); }
        $message = $status === 'draft' ? 'Your Story has been saved as a draft.' : ($status === 'publish' ? 'Your Story has been published successfully.' : 'Your Story has been submitted and is awaiting review.');
        return new WP_REST_Response(['success'=>true,'story_id'=>(int)$post_id,'status'=>$status,'url'=>get_permalink($post_id),'message'=>$message], 201);
    }

    /** Native Android upload: uses the same channel, strike, aspect-ratio and storage rules as the website uploader. */
    public function rest_native_upload_video_draft($request) {
        $user_id = get_current_user_id();
        if (!$user_id || !$this->user_has_phisk_channel($user_id)) return new WP_Error('phisk_channel_required', 'Create a Channel to upload videos.', ['status' => 403]);
        if ($this->user_strike_blocks_publishing($user_id)) return new WP_Error('phisk_publishing_restricted', 'Publishing is restricted on your account. Visit Account Standing to review your strikes or appeal.', ['status' => 403]);
        $files = $request->get_file_params();
        $file = isset($files['video_file']) ? $files['video_file'] : null;
        if (!$file || empty($file['tmp_name']) || !empty($file['error'])) return new WP_Error('phisk_video_file_missing', 'Choose a video file before uploading.', ['status' => 400]);
        $allowed_mimes = ['mp4'=>'video/mp4','m4v'=>'video/mp4','webm'=>'video/webm','ogv'=>'video/ogg','ogg'=>'video/ogg','mov'=>'video/quicktime'];
        $ext = strtolower(pathinfo((string)($file['name'] ?? ''), PATHINFO_EXTENSION));
        if (!isset($allowed_mimes[$ext])) return new WP_Error('phisk_video_format', 'Unsupported video format. Use MP4, WebM, OGG, M4V or MOV.', ['status' => 400]);
        $aspect = $this->phisk_validate_video_aspect_ratio($file['tmp_name']);
        if (is_wp_error($aspect)) return $aspect;
        $title = sanitize_text_field(pathinfo((string)$file['name'], PATHINFO_FILENAME));
        $publitio_options = get_option('phiskvideos_publitio_settings', []);
        $publitio_enabled = !empty($publitio_options['enabled']);
        $attachment_id = 0;
        if ($publitio_enabled) {
            $uploaded = $this->publitio_upload_video($file, $title ?: 'Untitled Video');
            if (is_wp_error($uploaded)) return new WP_Error($uploaded->get_error_code(), $uploaded->get_error_message(), ['status' => 500]);
        } else {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
            $attachment_id = media_handle_sideload($file, 0);
            if (is_wp_error($attachment_id)) return new WP_Error('phisk_video_media_upload', 'The video could not be saved to WordPress media: ' . $attachment_id->get_error_message(), ['status' => 500]);
        }
        $post_id = wp_insert_post(['post_type'=>'phisk_video','post_status'=>'draft','post_title'=>$title ?: 'Untitled Video','post_content'=>'','post_author'=>$user_id], true);
        if (is_wp_error($post_id) || !$post_id) {
            if ($attachment_id) wp_delete_attachment($attachment_id, true);
            return new WP_Error('phisk_video_draft_failed', 'The video uploaded, but its draft could not be created.', ['status' => 500]);
        }
        if ($publitio_enabled) {
            update_post_meta($post_id, '_phisk_video_provider', 'publitio');
            update_post_meta($post_id, '_phisk_video_attachment_id', 0);
            update_post_meta($post_id, '_phisk_video_source_id', (string)$uploaded['id']);
            update_post_meta($post_id, '_phisk_video_source_url', $uploaded['url']);
            $runtime = ['seconds'=>0,'formatted'=>''];
            if (!empty($uploaded['data']['duration'])) {
                $seconds = (int)round((float)$uploaded['data']['duration']);
                $runtime = ['seconds'=>$seconds,'formatted'=>($seconds >= 3600 ? sprintf('%d:%02d:%02d', floor($seconds/3600), floor(($seconds%3600)/60), $seconds%60) : sprintf('%d:%02d', floor($seconds/60), $seconds%60))];
            }
        } else {
            wp_update_post(['ID'=>$attachment_id,'post_parent'=>$post_id]);
            update_post_meta($post_id, '_phisk_video_provider', 'wordpress');
            update_post_meta($post_id, '_phisk_video_attachment_id', (int)$attachment_id);
            update_post_meta($post_id, '_phisk_video_source_id', (string)$attachment_id);
            update_post_meta($post_id, '_phisk_video_source_url', esc_url_raw(wp_get_attachment_url($attachment_id)));
            $runtime = $this->phisk_video_runtime_from_file(get_attached_file($attachment_id));
        }
        if (!empty($runtime['formatted'])) update_post_meta($post_id, 'phisk_runtime', $runtime['formatted']);
        if (!empty($runtime['seconds'])) update_post_meta($post_id, '_phisk_video_duration_seconds', (int)$runtime['seconds']);
        return new WP_REST_Response(['success'=>true,'draft_id'=>(int)$post_id,'title'=>get_the_title($post_id),'runtime'=>$runtime['formatted'],'message'=>'Video uploaded. Add its details and thumbnail to continue.'], 201);
    }

    public function rest_native_update_video_draft($request) {
        $user_id = get_current_user_id();
        if (!$user_id || !$this->user_has_phisk_channel($user_id)) return new WP_Error('phisk_channel_required', 'Create a Channel to upload videos.', ['status'=>403]);
        if ($this->user_strike_blocks_publishing($user_id)) return new WP_Error('phisk_publishing_restricted', 'Publishing is restricted on your account.', ['status'=>403]);
        $post_id = absint($request['id']);
        $post = $this->phisk_owned_video_draft($post_id);
        if (!$post) return new WP_Error('phisk_video_draft_not_found', 'That video draft could not be found.', ['status'=>404]);
        $title = sanitize_text_field((string)$request->get_param('title'));
        $description = wp_kses_post((string)$request->get_param('description'));
        $age = sanitize_text_field((string)$request->get_param('age_restriction'));
        $length = function_exists('mb_strlen') ? mb_strlen($title, 'UTF-8') : strlen($title);
        if ($title === '' || $length > 100) return new WP_Error('phisk_video_title_invalid', 'Enter a title of no more than 100 characters.', ['status'=>400]);
        if (trim(wp_strip_all_tags($description)) === '') return new WP_Error('phisk_video_description_required', 'Enter a video description.', ['status'=>400]);
        if (!in_array($age, ['No its not for kids','Yes its for kids'], true)) return new WP_Error('phisk_video_age_required', 'Choose whether this video is for kids.', ['status'=>400]);
        $updated = wp_update_post(['ID'=>$post_id,'post_title'=>$title,'post_content'=>$description], true);
        if (is_wp_error($updated)) return new WP_Error('phisk_video_details_failed', $updated->get_error_message(), ['status'=>500]);
        update_post_meta($post_id, 'phisk_age_rating', $age);
        return new WP_REST_Response(['success'=>true,'draft_id'=>$post_id,'message'=>'Video details saved. Choose a thumbnail to continue.']);
    }

    public function rest_native_publish_video_draft($request) {
        $user_id = get_current_user_id();
        if (!$user_id || !$this->user_has_phisk_channel($user_id)) return new WP_Error('phisk_channel_required', 'Create a Channel to upload videos.', ['status'=>403]);
        if ($this->user_strike_blocks_publishing($user_id)) return new WP_Error('phisk_publishing_restricted', 'Publishing is restricted on your account.', ['status'=>403]);
        $post_id = absint($request['id']);
        $post = $this->phisk_owned_video_draft($post_id);
        if (!$post) return new WP_Error('phisk_video_draft_not_found', 'That video draft could not be found.', ['status'=>404]);
        $files = $request->get_file_params();
        $thumbnail = isset($files['thumbnail']) ? $files['thumbnail'] : null;
        if ($thumbnail && !empty($thumbnail['tmp_name']) && empty($thumbnail['error'])) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
            $checked = wp_check_filetype_and_ext($thumbnail['tmp_name'], $thumbnail['name'] ?? 'thumbnail');
            if (empty($checked['type']) || !in_array($checked['type'], ['image/jpeg','image/png','image/webp','image/gif'], true)) return new WP_Error('phisk_thumbnail_format', 'Choose a JPG, PNG, WebP or GIF thumbnail.', ['status'=>400]);
            $attachment_id = media_handle_sideload($thumbnail, $post_id);
            if (is_wp_error($attachment_id)) return new WP_Error('phisk_thumbnail_upload', 'The thumbnail could not be uploaded: ' . $attachment_id->get_error_message(), ['status'=>500]);
            set_post_thumbnail($post_id, $attachment_id);
        }
        if (!has_post_thumbnail($post_id)) return new WP_Error('phisk_thumbnail_required', 'Please choose a video thumbnail.', ['status'=>400]);
        if (trim((string)$post->post_title) === '' || trim(wp_strip_all_tags((string)$post->post_content)) === '' || !get_post_meta($post_id, 'phisk_age_rating', true)) return new WP_Error('phisk_video_details_required', 'Complete the video title, description and audience setting before publishing.', ['status'=>400]);
        $newly_published = ($post->post_status !== 'publish');
        if ($newly_published) {
            $updated = wp_update_post(['ID'=>$post_id,'post_status'=>'publish'], true);
            if (is_wp_error($updated)) return new WP_Error('phisk_video_publish_failed', 'Changes were saved, but the video could not be published.', ['status'=>500]);
        }
        return new WP_REST_Response(['success'=>true,'draft_id'=>$post_id,'url'=>get_permalink($post_id),'newly_published'=>$newly_published,'message'=>$newly_published ? 'Your video has been published successfully.' : 'Your video changes have been saved successfully.']);
    }

    /** Return authenticated creator-only dashboard data, calculated from the existing ledger and posts. */
    public function rest_native_creator_studio($request) {
        $uid = get_current_user_id();
        if (!$uid || !$this->user_has_phisk_channel($uid)) return new WP_Error('creator_channel_required', 'Create a channel to use Creator Studio.', ['status'=>403]);
        $published_video_ids = get_posts(['post_type'=>'phisk_video','post_status'=>'publish','author'=>$uid,'posts_per_page'=>-1,'fields'=>'ids','no_found_rows'=>true]);
        $draft_video_ids = get_posts(['post_type'=>'phisk_video','post_status'=>['draft','pending','private','future'],'author'=>$uid,'posts_per_page'=>-1,'fields'=>'ids','no_found_rows'=>true]);
        $published_story_ids = get_posts(['post_type'=>'post','post_status'=>'publish','author'=>$uid,'posts_per_page'=>-1,'fields'=>'ids','no_found_rows'=>true]);
        $draft_story_ids = get_posts(['post_type'=>'post','post_status'=>['draft','pending','private','future'],'author'=>$uid,'posts_per_page'=>-1,'fields'=>'ids','no_found_rows'=>true]);
        $views=0; $likes=0; $comments=0; $top=[];
        foreach ($published_video_ids as $vid) {
            $v=max(0,(int)get_post_meta($vid,'_phisk_views',true)); $views += $v;
            $likes += max(0,(int)get_post_meta($vid,'_phisk_video_like_count',true));
            $comments += (int)get_comments(['post_id'=>$vid,'status'=>'approve','type'=>'comment','count'=>true]);
            $top[]=['id'=>(int)$vid,'title'=>get_the_title($vid),'views'=>$v,'permalink'=>get_permalink($vid),'thumbnail_url'=>esc_url_raw(get_the_post_thumbnail_url($vid,'medium') ?: '')];
        }
        usort($top,function($a,$b){return $b['views'] <=> $a['views'];}); $top=array_slice($top,0,5);
        $summary=$this->get_creator_monetization_summary($uid); $elig=$this->get_creator_eligibility($uid);
        $status=get_user_meta($uid,'_phisk_monetization_status',true); if(!$status)$status='not_applied';
        global $wpdb; $ledger=$this->monetization_table('ledger');
        $cutoff=gmdate('Y-m-d H:i:s',time()-(365*DAY_IN_SECONDS));
        $rows=$wpdb->get_results($wpdb->prepare("SELECT DATE(created_at) AS event_day, content_type, status, COUNT(*) AS event_count, COALESCE(SUM(amount_micros),0) AS amount_total FROM {$ledger} WHERE user_id=%d AND created_at >= %s GROUP BY DATE(created_at),content_type,status ORDER BY event_day ASC",$uid,$cutoff),ARRAY_A);
        $history=[];
        for($i=364;$i>=0;$i--){$day=gmdate('Y-m-d',time()-($i*DAY_IN_SECONDS));$history[$day]=['date'=>$day,'label'=>wp_date('M j',strtotime($day.' 12:00:00 UTC')),'video'=>0,'article'=>0,'earnings'=>0];}
        foreach((array)$rows as $row){$day=(string)$row['event_day'];if(!isset($history[$day])||$row['status']==='reversed')continue;if($row['status']==='accrued'){if($row['content_type']==='video')$history[$day]['video']+=(int)$row['event_count'];if($row['content_type']==='article')$history[$day]['article']+=(int)$row['event_count'];}$history[$day]['earnings']+=(int)$row['amount_total'];}
        $pending=(int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount_micros),0) FROM {$ledger} WHERE user_id=%d AND status IN ('pending','processing')",$uid));
        $payouts=$this->monetization_table('payouts');
        $last_payout=$wpdb->get_row($wpdb->prepare("SELECT status,amount_micros,created_at FROM {$payouts} WHERE user_id=%d ORDER BY id DESC LIMIT 1",$uid),ARRAY_A);
        return rest_ensure_response([
            'creator'=>['id'=>$uid,'name'=>$this->phisk_creator_display_name($uid)],
            'metrics'=>['verified_video_views'=>$views,'published_videos'=>count($published_video_ids),'video_drafts'=>count($draft_video_ids),'video_likes'=>$likes,'video_comments'=>$comments,'published_stories'=>count($published_story_ids),'story_drafts'=>count($draft_story_ids)],
            'earnings'=>['total_micros'=>(int)$summary['total_micros'],'pending_micros'=>$pending,'available_micros'=>(int)$summary['available_micros'],'video_micros'=>(int)$summary['video_micros'],'story_micros'=>(int)$summary['article_micros']],
            'eligibility'=>['views'=>(int)$elig['views'],'subscribers'=>(int)$elig['subscribers'],'account_days'=>(int)$elig['account_days'],'eligible'=>(bool)$elig['eligible'],'required_views'=>(int)get_option('phisk_monetization_min_views',100),'required_subscribers'=>(int)get_option('phisk_monetization_min_subscribers',100),'required_days'=>(int)get_option('phisk_monetization_min_days',30)],
            'monetization'=>['status'=>$status,'paused'=>(bool)get_user_meta($uid,'_phisk_strike_monetization_paused',true),'rejection_reason'=>(string)get_user_meta($uid,'_phisk_monetization_rejection_reason',true),'can_apply'=>in_array($status,['not_applied','rejected'],true)&&!get_user_meta($uid,'_phisk_strike_monetization_paused',true),'can_request_payout'=>$status==='approved'&&!get_user_meta($uid,'_phisk_strike_monetization_paused',true)&&!empty($elig['eligible'])&&(int)$summary['available_micros']>=50000000],
            'last_payout'=>$last_payout?:null,'chart_history'=>array_values($history),'top_videos'=>$top,
            'shortcuts'=>['upload_url'=>esc_url_raw($this->creator_page_url('phiskvideos_upload_page_id','upload-video')),'write_story_url'=>esc_url_raw($this->creator_page_url('phiskvideos_article_submit_page_id','write-article')),'channel_url'=>esc_url_raw($this->phisk_channel_url($uid)),'manage_videos_url'=>esc_url_raw(add_query_arg('phisk_dashboard_tab','videos',$this->phisk_channel_url($uid))),'my_stories_url'=>esc_url_raw(add_query_arg('phisk_dashboard_tab','articles',$this->phisk_channel_url($uid)))]
        ]);
    }

    /** Apply for monetization using the same eligibility/status rules as the website. */
    public function rest_native_creator_studio_apply($request) {
        $uid=get_current_user_id(); if(!$uid||!$this->user_has_phisk_channel($uid))return new WP_Error('creator_channel_required','Create a channel to use Creator Studio.',['status'=>403]);
        $this->recalculate_user_strike_enforcement($uid,true);
        if(get_user_meta($uid,'_phisk_strike_monetization_paused',true))return new WP_Error('monetization_paused','Monetization is paused for this account.',['status'=>403]);
        $status=get_user_meta($uid,'_phisk_monetization_status',true);
        if(in_array($status,['pending','approved','suspended'],true))return new WP_Error('application_exists','A monetization application is already active.',['status'=>409]);
        update_user_meta($uid,'_phisk_monetization_status','pending');
        return rest_ensure_response(['success'=>true,'status'=>'pending','message'=>'Your monetization application has been submitted.']);
    }

    /** Request payout using the exact existing eligibility and $50 minimum rules. */
    public function rest_native_creator_studio_payout($request) {
        $uid=get_current_user_id(); if(!$uid||!$this->user_has_phisk_channel($uid))return new WP_Error('creator_channel_required','Create a channel to use Creator Studio.',['status'=>403]);
        $this->recalculate_user_strike_enforcement($uid,true); $summary=$this->get_creator_monetization_summary($uid); $elig=$this->get_creator_eligibility($uid);
        if(get_user_meta($uid,'_phisk_strike_monetization_paused',true)||get_user_meta($uid,'_phisk_monetization_status',true)!=='approved'||empty($elig['eligible'])||(int)$summary['available_micros']<50000000)return new WP_Error('payout_locked','Payout requirements have not been met.',['status'=>403]);
        global $wpdb; $now=current_time('mysql',true); $amount=(int)$summary['available_micros'];
        $inserted=$wpdb->insert($this->monetization_table('payouts'),['user_id'=>$uid,'amount_micros'=>$amount,'status'=>'requested','created_at'=>$now,'updated_at'=>$now],['%d','%d','%s','%s','%s']);
        if(!$inserted)return new WP_Error('payout_failed','We could not submit your payout request. Please try again.',['status'=>500]);
        $this->send_strike_system_message($uid,'Payout request received','We have received your payout request for '.$this->format_monetization_amount($amount).'. Its status is Pending review. Our administration team will review and update you when the request moves to processing, is paid, or is rejected.');
        return rest_ensure_response(['success'=>true,'status'=>'requested','amount_micros'=>$amount,'message'=>'Your payout request has been submitted for review.']);
    }

    /** Public, paginated search API for the native app's Videos, Stories and Channels tabs. */
    public function rest_native_search($request) {
        $term = trim(sanitize_text_field((string) $request->get_param('q')));
        $type = sanitize_key((string) $request->get_param('type'));
        $page = max(1, absint($request->get_param('page')));
        $per_page = min(20, max(1, absint($request->get_param('per_page') ?: 10)));
        if ($term === '' || function_exists('mb_strlen') && mb_strlen($term) < 2 || (!function_exists('mb_strlen') && strlen($term) < 2)) {
            return new WP_Error('phisk_search_term_short', 'Enter at least two characters to search.', ['status' => 400]);
        }
        if (!in_array($type, ['videos', 'stories', 'channels'], true)) {
            return new WP_Error('phisk_search_type_invalid', 'Choose Videos, Stories or Channels.', ['status' => 400]);
        }

        $items = [];
        $total = 0;
        $total_pages = 0;

        if ($type === 'videos' || $type === 'stories') {
            $query = new WP_Query([
                'post_type' => ($type === 'videos' ? 'phisk_video' : 'post'),
                'post_status' => 'publish',
                's' => $term,
                'posts_per_page' => $per_page,
                'paged' => $page,
                'ignore_sticky_posts' => true,
                'no_found_rows' => false,
            ]);
            $total = (int) $query->found_posts;
            $total_pages = (int) $query->max_num_pages;
            foreach ($query->posts as $post) {
                if ($type === 'videos') {
                    $card = $this->native_watch_video_card($post->ID);
                    if ($card) $items[] = $card;
                    continue;
                }
                $author_id = (int) $post->post_author;
                $avatar_id = absint(get_user_meta($author_id, 'phisk_profile_image_id', true));
                $avatar = $avatar_id ? wp_get_attachment_image_url($avatar_id, 'thumbnail') : get_avatar_url($author_id, ['size' => 96]);
                $gallery = get_post_meta($post->ID, '_phisk_article_gallery_ids', true);
                if (!is_array($gallery)) $gallery = [];
                $first = !empty($gallery) ? absint(reset($gallery)) : 0;
                $thumbnail = $first ? wp_get_attachment_image_url($first, 'large') : get_the_post_thumbnail_url($post->ID, 'large');
                $items[] = [
                    'id' => (int) $post->ID,
                    'title' => get_the_title($post->ID),
                    'excerpt' => wp_trim_words(wp_strip_all_tags(strip_shortcodes($post->post_content)), 28),
                    'permalink' => get_permalink($post->ID),
                    'thumbnail_url' => esc_url_raw($thumbnail ?: ''),
                    'published_at' => get_post_time('c', true, $post->ID),
                    'creator' => [
                        'id' => $author_id,
                        'name' => $this->phisk_creator_display_name($author_id),
                        'avatar_url' => esc_url_raw($avatar),
                        'profile_url' => esc_url_raw($this->phisk_channel_url($author_id)),
                    ],
                    'type' => 'story',
                ];
            }
            wp_reset_postdata();
        } else {
            $users = new WP_User_Query([
                'number' => $per_page,
                'paged' => $page,
                'orderby' => 'display_name',
                'order' => 'ASC',
                'search' => '*' . $term . '*',
                'search_columns' => ['user_login', 'user_nicename', 'display_name'],
                'fields' => 'all',
                'count_total' => true,
                'meta_query' => [
                    'relation' => 'AND',
                    ['relation' => 'OR',
                        ['key' => 'phisk_has_channel', 'compare' => 'NOT EXISTS'],
                        ['key' => 'phisk_has_channel', 'value' => '1', 'compare' => '='],
                    ],
                    ['relation' => 'OR',
                        ['key' => '_phisk_strike_channel_restricted', 'compare' => 'NOT EXISTS'],
                        ['key' => '_phisk_strike_channel_restricted', 'value' => '1', 'compare' => '!='],
                    ],
                ],
            ]);
            $total = (int) $users->get_total();
            $total_pages = (int) ceil($total / $per_page);
            foreach ((array) $users->get_results() as $user) {
                if (!$user instanceof WP_User || !$this->user_has_phisk_channel($user->ID)) continue;
                $avatar_id = absint(get_user_meta($user->ID, 'phisk_profile_image_id', true));
                $avatar = $avatar_id ? wp_get_attachment_image_url($avatar_id, 'medium') : get_avatar_url($user->ID, ['size' => 120]);
                $items[] = [
                    'id' => (int) $user->ID,
                    'name' => $this->phisk_creator_display_name($user->ID),
                    'username' => (string) $user->user_nicename,
                    'description' => (string) (get_user_meta($user->ID, 'description', true) ?: get_user_meta($user->ID, 'phisk_bio', true)),
                    'avatar_url' => esc_url_raw($avatar),
                    'profile_url' => esc_url_raw($this->phisk_channel_url($user->ID)),
                    'subscriber_count' => (int) $this->phisk_display_subscriber_count($user->ID),
                    'verified' => (bool) get_user_meta($user->ID, 'phisk_verified_creator', true),
                ];
            }
        }

        return rest_ensure_response([
            'success' => true,
            'type' => $type,
            'query' => $term,
            'items' => $items,
            'page' => $page,
            'per_page' => $per_page,
            'total' => $total,
            'total_pages' => $total_pages,
            'has_more' => ($page < $total_pages),
        ]);
    }

    private function native_creator_user($id) {
        $user = get_userdata(absint($id));
        if (!$user || !$this->user_has_phisk_channel($user->ID)) return false;
        return $user;
    }

    public function rest_native_creator_detail($request) {
        $user = $this->native_creator_user($request['id']);
        if (!$user) return new WP_Error('creator_not_found', 'Creator channel not found.', ['status'=>404]);
        $uid = (int) $user->ID; $viewer = get_current_user_id();
        $profile_id = absint(get_user_meta($uid, 'phisk_profile_image_id', true));
        $cover_id = absint(get_user_meta($uid, 'phisk_cover_image_id', true));
        $avatar = $profile_id ? wp_get_attachment_image_url($profile_id, 'medium') : get_avatar_url($uid, ['size'=>160]);
        $cover = $cover_id ? wp_get_attachment_image_url($cover_id, 'large') : '';
        $following = $viewer ? $this->phisk_following_ids($viewer) : [];
        $user_obj = get_userdata($uid);
        $restricted = (bool) get_user_meta($uid, '_phisk_strike_channel_restricted', true);
        return rest_ensure_response([
            'id'=>$uid, 'name'=>$this->phisk_creator_display_name($uid),
            'username'=>(string)$user_obj->user_nicename, 'description'=>(string)get_user_meta($uid, 'description', true),
            'avatar_url'=>esc_url_raw($avatar), 'has_custom_avatar'=>(bool)$profile_id, 'cover_url'=>esc_url_raw($cover),
            'profile_url'=>esc_url_raw($this->phisk_channel_url($uid)),
            'subscriber_count'=>(int)$this->phisk_display_subscriber_count($uid),
            'subscribed'=>($viewer && $viewer !== $uid && in_array($uid, $following, true)),
            'is_owner'=>($viewer === $uid), 'has_channel'=>true, 'restricted'=>$restricted,
            'verified'=>(bool)get_user_meta($uid, 'phisk_verified_creator', true),
            'can_edit'=>($viewer === $uid),
            'social_links'=>[
                'facebook'=>(string)get_user_meta($uid, 'phisk_social_facebook', true),
                'youtube'=>(string)get_user_meta($uid, 'phisk_social_youtube', true),
                'x'=>(string)get_user_meta($uid, 'phisk_social_x', true),
                'linkedin'=>(string)get_user_meta($uid, 'phisk_social_linkedin', true),
            ],
            'name_history'=>is_array(get_user_meta($uid, 'phisk_channel_name_history', true)) ? get_user_meta($uid, 'phisk_channel_name_history', true) : [],
            'created_at'=>absint(get_user_meta($uid, 'phisk_channel_created_at', true)),
            'created_year'=>($created_at = absint(get_user_meta($uid, 'phisk_channel_created_at', true))) ? (int)wp_date('Y', $created_at) : null,
        ]);
    }

    /** Return the signed-in member's channel editor data, including policy metadata. */
    public function rest_native_creator_channel_edit($request) {
        $uid = get_current_user_id();
        if (!$uid) return new WP_Error('authentication_required', 'Please sign in to continue.', ['status'=>401]);
        $has_channel = $this->user_has_phisk_channel($uid);
        $history = get_user_meta($uid, 'phisk_channel_name_history', true);
        if (!is_array($history)) $history = [];
        $social = [];
        foreach (['facebook','youtube','x','linkedin'] as $platform) $social[$platform] = (string)get_user_meta($uid, 'phisk_social_'.$platform, true);
        $profile_id = absint(get_user_meta($uid, 'phisk_profile_image_id', true));
        $cover_id = absint(get_user_meta($uid, 'phisk_cover_image_id', true));
        $created = absint(get_user_meta($uid, 'phisk_channel_created_at', true));
        $last_changed = absint(get_user_meta($uid, 'phisk_channel_name_last_changed', true));
        return rest_ensure_response([
            'has_channel'=>$has_channel, 'restricted'=>(bool)get_user_meta($uid, '_phisk_strike_channel_restricted', true),
            'name'=>$has_channel ? $this->phisk_creator_display_name($uid) : '',
            'description'=>(string)get_user_meta($uid, 'description', true), 'social_links'=>$social,
            'avatar_url'=>$profile_id ? wp_get_attachment_image_url($profile_id, 'medium') : get_avatar_url($uid, ['size'=>160]),
            'cover_url'=>$cover_id ? wp_get_attachment_image_url($cover_id, 'large') : '',
            'created_at'=>$created, 'created_year'=>$created ? (int)wp_date('Y', $created) : null,
            'name_history'=>$history, 'name_change_available_at'=>$last_changed ? $last_changed + (90 * DAY_IN_SECONDS) : 0,
            'name_max_length'=>30, 'description_max_length'=>500, 'name_change_cooldown_days'=>90,
        ]);
    }

    /** Create or update the authenticated member's channel using the website's channel policy. */
    public function rest_native_creator_channel_save($request) {
        $uid = get_current_user_id();
        if (!$uid) return new WP_Error('authentication_required', 'Please sign in to continue.', ['status'=>401]);
        $this->recalculate_user_strike_enforcement($uid, true);
        if (get_user_meta($uid, '_phisk_strike_channel_restricted', true)) return new WP_Error('phisk_channel_restricted', 'Your channel is restricted under the PhiskVideos strike policy.', ['status'=>403]);
        $has_channel = $this->user_has_phisk_channel($uid);
        $name = sanitize_text_field((string)$request->get_param('name'));
        $description = sanitize_textarea_field((string)$request->get_param('description'));
        $length = function_exists('mb_strlen') ? mb_strlen($name, 'UTF-8') : strlen($name);
        $bio_length = function_exists('mb_strlen') ? mb_strlen($description, 'UTF-8') : strlen($description);
        if ($name === '' || $length > 30) return new WP_Error('phisk_channel_name_invalid', 'Channel name must contain 1 to 30 characters.', ['status'=>400]);
        if ($bio_length > 500) return new WP_Error('phisk_channel_description_invalid', 'Channel description must be 500 characters or fewer.', ['status'=>400]);
        $old_name = $has_channel ? $this->phisk_creator_display_name($uid) : '';
        if ($has_channel && $name !== $old_name) {
            $last_changed = absint(get_user_meta($uid, 'phisk_channel_name_last_changed', true));
            if ($last_changed && time() < ($last_changed + 90 * DAY_IN_SECONDS)) {
                return new WP_Error('phisk_channel_name_cooldown', 'Your channel name cannot be changed yet. You can still edit your description, images and social links.', ['status'=>403, 'available_at'=>$last_changed + 90 * DAY_IN_SECONDS]);
            }
        }
        if (!$has_channel) {
            $user = get_userdata($uid);
            if (!$user) return new WP_Error('phisk_member_missing', 'Your account could not be found.', ['status'=>404]);
            if (get_user_meta($uid, 'phisk_personal_display_name', true) === '') update_user_meta($uid, 'phisk_personal_display_name', (string)($user->display_name ?: $user->user_login));
            update_user_meta($uid, 'phisk_has_channel', '1');
            update_user_meta($uid, 'phisk_channel_created_at', time());
            update_user_meta($uid, 'phisk_channel_name_history', []);
        }
        update_user_meta($uid, 'phisk_channel_name', $name);
        if ($has_channel && $name !== $old_name) {
            $history = get_user_meta($uid, 'phisk_channel_name_history', true);
            if (!is_array($history)) $history = [];
            $history[] = ['old_name'=>$old_name, 'new_name'=>$name, 'changed_at'=>time()];
            update_user_meta($uid, 'phisk_channel_name_history', $history);
            update_user_meta($uid, 'phisk_channel_name_last_changed', time());
        }
        update_user_meta($uid, 'description', $description);
        $social = $request->get_param('social_links');
        if (is_string($social)) $social = json_decode($social, true);
        if (is_array($social)) {
            foreach (['facebook','youtube','x','linkedin'] as $platform) {
                $raw = trim((string)($social[$platform] ?? ''));
                $key = 'phisk_social_'.$platform;
                if ($raw === '') { delete_user_meta($uid, $key); continue; }
                $url = esc_url_raw($raw, ['https']);
                $parts = $url ? wp_parse_url($url) : false;
                if (!$url || !is_array($parts) || strtolower((string)($parts['scheme'] ?? '')) !== 'https' || empty($parts['host'])) return new WP_Error('phisk_social_link_invalid', 'Social profile links must be valid HTTPS URLs.', ['status'=>400, 'platform'=>$platform]);
                update_user_meta($uid, $key, $url);
            }
        }
        return rest_ensure_response(['success'=>true, 'has_channel'=>true, 'message'=>$has_channel ? 'Channel updated.' : 'Channel created.', 'channel'=> $this->rest_native_creator_channel_edit($request)->get_data()]);
    }

    /** Upload a creator-owned avatar or cover image and assign it to the channel. */
    public function rest_native_creator_channel_image($request) {
        $uid = get_current_user_id();
        if (!$uid || !$this->user_has_phisk_channel($uid)) return new WP_Error('phisk_channel_required', 'Create your channel before uploading channel images.', ['status'=>403]);
        $kind = sanitize_key((string)$request->get_param('kind'));
        if (!in_array($kind, ['avatar','cover'], true)) return new WP_Error('phisk_channel_image_kind', 'Choose either avatar or cover.', ['status'=>400]);
        $files = $request->get_file_params(); $file = $files['image'] ?? null;
        if (!$file || empty($file['tmp_name']) || !empty($file['error'])) return new WP_Error('phisk_channel_image_missing', 'Choose an image to upload.', ['status'=>400]);
        require_once ABSPATH . 'wp-admin/includes/file.php'; require_once ABSPATH . 'wp-admin/includes/media.php'; require_once ABSPATH . 'wp-admin/includes/image.php';
        $checked = wp_check_filetype_and_ext($file['tmp_name'], $file['name'] ?? 'channel-image');
        if (empty($checked['type']) || !in_array($checked['type'], ['image/jpeg','image/png','image/webp'], true)) return new WP_Error('phisk_channel_image_format', 'Upload a JPG, PNG or WebP image.', ['status'=>400]);
        $attachment_id = media_handle_sideload($file, 0);
        if (is_wp_error($attachment_id)) return new WP_Error('phisk_channel_image_upload', 'The image could not be saved. Please try again.', ['status'=>500]);
        wp_update_post(['ID'=>$attachment_id, 'post_author'=>$uid]);
        $meta_key = $kind === 'avatar' ? 'phisk_profile_image_id' : 'phisk_cover_image_id';
        update_user_meta($uid, $meta_key, (int)$attachment_id);
        return rest_ensure_response(['success'=>true, 'kind'=>$kind, 'id'=>(int)$attachment_id, 'url'=>wp_get_attachment_image_url($attachment_id, $kind === 'avatar' ? 'medium' : 'large')]);
    }

    private function native_creator_content_page($request, $type) {
        $user = $this->native_creator_user($request['id']);
        if (!$user) return new WP_Error('creator_not_found', 'Creator channel not found.', ['status'=>404]);
        $page = max(1, absint($request->get_param('page')));
        $per_page = min(20, max(1, absint($request->get_param('per_page') ?: 10)));
        $args = ['post_type'=>($type === 'videos' ? 'phisk_video' : 'post'), 'post_status'=>'publish',
            'author'=>(int)$user->ID, 'posts_per_page'=>$per_page, 'paged'=>$page, 'orderby'=>'date', 'order'=>'DESC'];
        if ($type === 'stories') $args['meta_query'] = [['key'=>'_phisk_article_gallery_ids','compare'=>'EXISTS']];
        $query = new WP_Query($args); $items = [];
        foreach ($query->posts as $post) {
            if ($type === 'videos') { $card = $this->native_watch_video_card($post->ID); if ($card) $items[] = $card; continue; }
            $gallery = get_post_meta($post->ID, '_phisk_article_gallery_ids', true);
            if (!is_array($gallery)) $gallery = [];
            $first = !empty($gallery) ? absint(reset($gallery)) : 0;
            $thumb = $first ? wp_get_attachment_image_url($first, 'large') : get_the_post_thumbnail_url($post->ID, 'large');
            $items[] = ['id'=>(int)$post->ID, 'title'=>get_the_title($post->ID),
                'excerpt'=>wp_trim_words(wp_strip_all_tags(strip_shortcodes($post->post_content)), 28),
                'permalink'=>get_permalink($post->ID), 'thumbnail_url'=>esc_url_raw($thumb ?: ''),
                'published_at'=>get_post_time('c', true, $post->ID), 'type'=>'story'];
        }
        return rest_ensure_response(['items'=>$items, 'page'=>$page, 'per_page'=>$per_page,
            'total'=>(int)$query->found_posts, 'total_pages'=>(int)$query->max_num_pages,
            'has_more'=>($page < (int)$query->max_num_pages)]);
    }

    public function rest_native_creator_videos($request) { return $this->native_creator_content_page($request, 'videos'); }
    public function rest_native_creator_stories($request) { return $this->native_creator_content_page($request, 'stories'); }

    public function rest_native_creator_subscribe($request) {
        $target = absint($request['id']); $viewer = get_current_user_id();
        if (!$viewer) return new WP_Error('authentication_required', 'Please sign in to subscribe.', ['status'=>401]);
        if ($target === $viewer) return new WP_Error('invalid_subscription', 'You cannot subscribe to your own channel.', ['status'=>400]);
        if (!$this->native_creator_user($target)) return new WP_Error('creator_not_found', 'Creator channel not found.', ['status'=>404]);
        $action = sanitize_key((string)$request->get_param('action'));
        if (!in_array($action, ['subscribe','unsubscribe','toggle'], true)) $action = 'toggle';
        $following = $this->phisk_following_ids($viewer); $exists = in_array($target, $following, true);
        $subscribed = ($action === 'subscribe') ? true : (($action === 'unsubscribe') ? false : !$exists);
        if ($subscribed !== $exists) {
            if ($subscribed) $following[] = $target; else $following = array_values(array_diff($following, [$target]));
            update_user_meta($viewer, 'phisk_following', array_values(array_unique(array_map('absint', $following))));
            $count = $this->phisk_subscriber_count($target);
            update_user_meta($target, 'phisk_subscriber_count', $subscribed ? $count + 1 : max(0, $count - 1));
        }
        return rest_ensure_response(['subscribed'=>$subscribed,
            'subscriber_count'=>(int)$this->phisk_display_subscriber_count($target)]);
    }

    private function native_watch_video_card($post_id) {
        $post = get_post($post_id);
        if (!$post || $post->post_type !== 'phisk_video' || $post->post_status !== 'publish') return null;
        $author_id = (int) $post->post_author;
        $avatar_id = absint(get_user_meta($author_id, 'phisk_profile_image_id', true));
        $avatar = $avatar_id ? wp_get_attachment_image_url($avatar_id, 'thumbnail') : get_avatar_url($author_id, ['size' => 96]);
        $thumbnail = get_the_post_thumbnail_url($post_id, 'large');
        if (!$thumbnail) $thumbnail = get_post_meta($post_id, 'phisk_video_thumbnail', true) ?: get_post_meta($post_id, '_phisk_video_thumbnail', true);
        $provider = sanitize_key((string) get_post_meta($post_id, '_phisk_video_provider', true));
        $source = method_exists($this, 'video_provider_data') ? $this->video_provider_data($post_id) : [];
        $playback_url = is_array($source) && !empty($source['source_url']) ? esc_url_raw($source['source_url']) : '';
        $youtube_id = (string) get_post_meta($post_id, '_phisk_youtube_video_id', true);
        return [
            'id' => (int) $post_id, 'title' => get_the_title($post_id),
            'description' => wp_strip_all_tags(strip_shortcodes($post->post_content)),
            'excerpt' => get_the_excerpt($post_id), 'permalink' => get_permalink($post_id),
            'thumbnail_url' => esc_url_raw($thumbnail), 'duration' => (string) get_post_meta($post_id, '_phisk_video_duration', true),
            'views' => method_exists($this, 'phisk_video_view_count') ? (int) $this->phisk_video_view_count($post_id) : (int) get_post_meta($post_id, '_phisk_views', true),
            'like_count' => $this->phisk_video_like_count($post_id),
            'liked' => is_user_logged_in() ? $this->phisk_user_liked_video(get_current_user_id(), $post_id) : false,
            'published_at' => get_post_time('c', true, $post_id),
            'creator' => ['id'=>$author_id, 'name'=>method_exists($this,'phisk_creator_display_name') ? $this->phisk_creator_display_name($author_id) : get_the_author_meta('display_name',$author_id), 'avatar_url'=>esc_url_raw($avatar), 'has_custom_avatar'=>(bool)$avatar_id, 'profile_url'=>method_exists($this,'phisk_channel_url') ? $this->phisk_channel_url($author_id) : get_author_posts_url($author_id)],
            'provider' => $provider ?: 'wordpress', 'playback_url' => $playback_url,
            'youtube_video_id' => preg_match('/^[A-Za-z0-9_-]{11}$/', $youtube_id) ? $youtube_id : '',
            'playback_type' => ($provider === 'youtube_embed' ? 'youtube_embed' : (substr(strtolower((string) parse_url($playback_url, PHP_URL_PATH)), -5) === '.m3u8' ? 'hls' : ($playback_url ? 'progressive' : 'unavailable'))),
            'download_available' => ($provider !== 'youtube_embed' && (bool) $this->phisk_video_download_url($post_id)),
            'monetization_enabled' => (bool) get_option('phisk_monetization_enabled', 1),
            'monetization_mode' => get_option('phisk_monetization_video_mode', 'verified') === 'regular' ? 'regular' : 'verified',
            'watch_percent' => max(1, min(100, (int) get_option('phisk_monetization_watch_percent', 50))),
            'comment_count' => (int) get_comments_number($post_id),
        ];
    }

    public function rest_native_video_detail($request) {
        $id = absint($request['id']);
        $item = $this->native_watch_video_card($id);
        if (!$item) return new WP_Error('video_not_found', 'Published video not found.', ['status'=>404]);
        return rest_ensure_response($item);
    }

    public function rest_native_video_related($request) {
        $id = absint($request['id']);
        $post = get_post($id);
        if (!$post || $post->post_type !== 'phisk_video' || $post->post_status !== 'publish') return new WP_Error('video_not_found', 'Published video not found.', ['status'=>404]);
        $items = [];
        if (method_exists($this, 'watch_also_videos')) {
            foreach ((array) $this->watch_also_videos($id) as $related) {
                $related_id = !empty($related['id']) ? absint($related['id']) : (!empty($related['post_id']) ? absint($related['post_id']) : 0);
                if ($related_id) { $card = $this->native_watch_video_card($related_id); if ($card) $items[] = $card; }
            }
        }
        if (!$items) {
            $posts = get_posts(['post_type'=>'phisk_video','post_status'=>'publish','posts_per_page'=>8,'post__not_in'=>[$id],'orderby'=>'date','order'=>'DESC']);
            foreach ($posts as $related) { $card = $this->native_watch_video_card($related->ID); if ($card) $items[] = $card; }
        }
        return rest_ensure_response(['videos'=>$items]);
    }

    /** Native likes use the same user-meta and post-meta counters as the website. */
    public function rest_native_video_like($request) {
        $video_id = absint($request['id']);
        if (get_post_type($video_id) !== 'phisk_video' || get_post_status($video_id) !== 'publish') return new WP_Error('invalid_video', 'This video is unavailable.', ['status'=>404]);
        $user_id = get_current_user_id();
        if (!$user_id) return new WP_Error('authentication_required', 'Please sign in to like videos.', ['status'=>401]);
        $liked = get_user_meta($user_id, 'phisk_liked_videos', true);
        if (!is_array($liked)) $liked = [];
        $liked = array_values(array_unique(array_filter(array_map('absint', $liked))));
        $index = array_search($video_id, $liked, true);
        if ($index !== false) { unset($liked[$index]); $liked = array_values($liked); $is_liked = false; }
        else { $liked[] = $video_id; $is_liked = true; }
        update_user_meta($user_id, 'phisk_liked_videos', $liked);
        // Keep the same stored counter used by the existing web action.
        $stored = max(0, (int) get_post_meta($video_id, '_phisk_video_like_count', true));
        $stored = $is_liked ? $stored + 1 : max(0, $stored - 1);
        update_post_meta($video_id, '_phisk_video_like_count', $stored);
        return rest_ensure_response(['liked'=>$is_liked, 'like_count'=>$stored]);
    }

    /** Native report submissions enter the exact same phisk_report moderation queue. */
    public function rest_native_video_report($request) {
        $video_id = absint($request['id']);
        if (!get_current_user_id()) return new WP_Error('authentication_required', 'Please sign in to report a video.', ['status'=>401]);
        if (get_post_type($video_id) !== 'phisk_video' || get_post_status($video_id) !== 'publish') return new WP_Error('invalid_video', 'This video is unavailable.', ['status'=>404]);
        $reason = sanitize_text_field((string) $request->get_param('reason'));
        $details = sanitize_textarea_field((string) $request->get_param('details'));
        $allowed = ['Spam or misleading','Hateful or abusive content','Harassment or bullying','Violence or dangerous content','Sexual or inappropriate content','Copyright infringement','Scam or fraud','Privacy violation','Something else'];
        if (!in_array($reason, $allowed, true)) return new WP_Error('invalid_report_reason', 'Please select a valid reason.', ['status'=>400]);
        $report_id = wp_insert_post(['post_type'=>'phisk_report','post_status'=>'publish','post_title'=>'Report: '.(get_the_title($video_id) ?: ('Video #'.$video_id)),'post_author'=>get_current_user_id()], true);
        if (is_wp_error($report_id) || !$report_id) return new WP_Error('report_failed','Unable to submit the report. Please try again.',['status'=>500]);
        update_post_meta($report_id, '_phisk_report_video_id', $video_id);
        update_post_meta($report_id, '_phisk_reporter_id', get_current_user_id());
        update_post_meta($report_id, '_phisk_report_reason', $reason);
        update_post_meta($report_id, '_phisk_report_details', $details);
        update_post_meta($report_id, '_phisk_report_status', 'pending');
        update_post_meta($report_id, '_phisk_report_submitted_at', current_time('mysql'));
        return rest_ensure_response(['success'=>true,'message'=>'Report submitted. Thank you for helping keep Phisk safe.']);
    }

    /** Return only the authorised downloadable original URL configured by the plugin. */
    public function rest_native_video_download($request) {
        $video_id = absint($request['id']);
        if (!get_current_user_id()) return new WP_Error('authentication_required','Please sign in to download this video.',['status'=>401]);
        if (get_post_type($video_id) !== 'phisk_video' || get_post_status($video_id) !== 'publish') return new WP_Error('invalid_video','This video is unavailable.',['status'=>404]);
        $url = $this->phisk_video_download_url($video_id);
        if (!$url) return new WP_Error('download_unavailable','A downloadable original file is not available for this video.',['status'=>409]);
        $creator = get_userdata((int)get_post_field('post_author',$video_id));
        return rest_ensure_response(['url'=>$url,'filename'=>sanitize_file_name(get_the_title($video_id)).'.mp4','title'=>get_the_title($video_id),'thumbnail'=>get_the_post_thumbnail_url($video_id,'large') ?: '','channel'=>$creator ? $this->phisk_creator_display_name($creator->ID) : get_bloginfo('name')]);
    }

    /**
     * Native page views preserve the plugin's 30-minute genuine-view cooldown.
     * Regular monetization credits a page view; verified monetization credits only
     * after the configured playback percentage has been watched.
     */
    public function rest_native_video_view($request) {
        $video_id = absint($request['id']);
        if (get_post_type($video_id) !== 'phisk_video' || get_post_status($video_id) !== 'publish') return new WP_Error('invalid_video','This video is unavailable.',['status'=>404]);
        $authorization = (string) $request->get_header('authorization');
        if ($authorization !== '') { $auth = $this->app_api_permission_callback($request); if (is_wp_error($auth)) return $auth; }
        $install = strtolower(sanitize_text_field((string)$request->get_param('install_id')));
        if (!preg_match('/^[a-f0-9]{32}$/', $install)) return new WP_Error('invalid_install','Invalid app installation identifier.',['status'=>400]);
        $user_id = get_current_user_id();
        $identity = $user_id ? 'user:'.$user_id : 'app:'.$install;
        // A secondary IP/day ceiling limits abuse from repeatedly rotating install IDs.
        if (!$user_id) {
            $ip = isset($_SERVER['REMOTE_ADDR']) ? (string) $_SERVER['REMOTE_ADDR'] : '';
            if ($ip !== '') {
                $ip_rate_key = 'phisk_native_ip_rate_'.hash('sha256',$ip.':'.gmdate('Y-m-d'));
                $ip_rate = (int) get_transient($ip_rate_key);
                if ($ip_rate >= 1000) return rest_ensure_response(['view_counted'=>false,'monetization_credited'=>false,'reason'=>'ip_rate_limit']);
                set_transient($ip_rate_key,$ip_rate+1,DAY_IN_SECONDS);
            }
        }
        $type = sanitize_key((string)$request->get_param('event_type'));
        if (!in_array($type,['page','watch'],true)) return new WP_Error('invalid_view_event','Invalid view event.',['status'=>400]);
        $credited_view = false;
        if ($type === 'page') {
            $cooldown_key = 'phisk_native_page_view_'.hash('sha256','app:'.$install.':'.$video_id);
            if (!get_transient($cooldown_key)) {
                $total = max(0,(int)get_post_meta($video_id,'_phisk_views',true));
                update_post_meta($video_id,'_phisk_views',$total+1);
                set_transient($cooldown_key,1,30*MINUTE_IN_SECONDS);
                $credited_view = true;
            }
        }
        $monetization_credited = false;
        if (!(int)get_option('phisk_monetization_enabled',1)) return rest_ensure_response(['view_counted'=>$credited_view,'monetization_credited'=>false,'reason'=>'disabled']);
        $creator_id = (int)get_post_field('post_author',$video_id);
        if (($user_id && $creator_id === $user_id) || get_user_meta($creator_id,'_phisk_strike_monetization_paused',true)) return rest_ensure_response(['view_counted'=>$credited_view,'monetization_credited'=>false]);
        $mode = get_option('phisk_monetization_video_mode','verified') === 'regular' ? 'regular' : 'verified';
        if ($mode === 'regular' && $type !== 'page') return rest_ensure_response(['view_counted'=>$credited_view,'monetization_credited'=>false,'mode'=>$mode]);
        if ($mode === 'verified' && $type !== 'watch') return rest_ensure_response(['view_counted'=>$credited_view,'monetization_credited'=>false,'mode'=>$mode]);
        $seconds = max(0,(int)$request->get_param('watched_seconds'));
        $duration = max(0,(int)$request->get_param('duration'));
        $threshold = max(1,min(100,(int)get_option('phisk_monetization_watch_percent',50)));
        if ($mode === 'verified' && ($duration < 1 || $seconds < 1 || ($seconds / $duration * 100) < $threshold)) return rest_ensure_response(['view_counted'=>$credited_view,'monetization_credited'=>false,'mode'=>$mode]);
        $event_id = strtolower(sanitize_text_field((string)$request->get_param('view_event_id')));
        if (!preg_match('/^[a-f0-9]{32}$/',$event_id)) return new WP_Error('invalid_view_event','Invalid view event identifier.',['status'=>400]);
        if ($mode === 'regular' || !$user_id) {
            $rate_key = 'phisk_native_monetization_rate_'.hash('sha256',$identity.':'.gmdate('Y-m-d'));
            $rate = (int)get_transient($rate_key);
            $rate_limit = ($mode === 'regular') ? 300 : 100;
            if ($rate >= $rate_limit) return rest_ensure_response(['view_counted'=>$credited_view,'monetization_credited'=>false,'reason'=>'rate_limit']);
            set_transient($rate_key,$rate+1,DAY_IN_SECONDS);
        }
        if ($mode === 'verified') {
            $cooldown = 'phisk_native_verified_'.hash('sha256',$identity.':'.$video_id);
            if (get_transient($cooldown)) return rest_ensure_response(['view_counted'=>$credited_view,'monetization_credited'=>false,'reason'=>'cooldown','mode'=>$mode]);
        }
        $this->ensure_monetization_tables();
        global $wpdb;
        $event_key = $mode === 'regular' ? hash('sha256',$identity.':'.$creator_id.':video:'.$video_id.':'.$event_id) : hash('sha256',$identity.':'.$creator_id.':video:'.$video_id.':'.gmdate('Y-m-d'));
        $inserted = $wpdb->insert($this->monetization_table('ledger'),['user_id'=>$creator_id,'content_id'=>$video_id,'content_type'=>'video','event_key'=>$event_key,'amount_micros'=>600,'status'=>'accrued','created_at'=>current_time('mysql',true)],['%d','%d','%s','%s','%d','%s','%s']);
        if ($inserted) { $monetization_credited = true; if ($mode === 'verified') set_transient($cooldown,1,DAY_IN_SECONDS); }
        return rest_ensure_response(['view_counted'=>$credited_view,'monetization_credited'=>$monetization_credited,'mode'=>$mode]);
    }

    public function rest_native_video_comments($request) {
        $video_id = absint($request['id']);
        if (get_post_type($video_id) !== 'phisk_video' || get_post_status($video_id) !== 'publish') return new WP_Error('video_not_found','Published video not found.',['status'=>404]);
        $page = max(1, absint($request->get_param('page')));
        $per_page = min(50, max(1, absint($request->get_param('per_page') ?: 20)));
        $comments = get_comments(['post_id'=>$video_id,'status'=>'approve','number'=>$per_page,'offset'=>($page-1)*$per_page,'orderby'=>'comment_date_gmt','order'=>'DESC','parent'=>0]);
        $items = [];
        foreach ($comments as $comment) {
            $user = $comment->user_id ? get_userdata($comment->user_id) : false;
            $items[] = ['id'=>(int)$comment->comment_ID,'parent_id'=>(int)$comment->comment_parent,'author'=>($user ? $user->display_name : $comment->comment_author),'avatar_url'=>get_avatar_url($comment,['size'=>72]),'content'=>wp_strip_all_tags($comment->comment_content),'created_at'=>mysql_to_rfc3339($comment->comment_date),'like_count'=>0,'replies'=>[]];
        }
        return rest_ensure_response(['comments'=>$items,'page'=>$page,'per_page'=>$per_page,'total'=>(int)get_comments(['post_id'=>$video_id,'status'=>'approve','count'=>true,'parent'=>0])]);
    }

    public function rest_native_add_video_comment($request) {
        $video_id = absint($request['id']);
        if (get_post_type($video_id) !== 'phisk_video' || get_post_status($video_id) !== 'publish') return new WP_Error('video_not_found','Published video not found.',['status'=>404]);
        $user_id = get_current_user_id();
        if (!$user_id) return new WP_Error('authentication_required','Please sign in to comment.',['status'=>401]);
        $content = trim((string) $request->get_param('content'));
        if ($content === '' || strlen($content) > 5000) return new WP_Error('invalid_comment','Comment must contain 1–5000 characters.',['status'=>400]);
        $parent = absint($request->get_param('parent_id'));
        if ($parent) { $parent_comment = get_comment($parent); if (!$parent_comment || (int)$parent_comment->comment_post_ID !== $video_id || $parent_comment->comment_approved !== '1') return new WP_Error('invalid_parent','Reply target is invalid.',['status'=>400]); }
        $comment_id = wp_new_comment(['comment_post_ID'=>$video_id,'comment_content'=>wp_kses_post($content),'user_id'=>$user_id,'comment_parent'=>$parent,'comment_type'=>'comment'], true);
        if (is_wp_error($comment_id)) return $comment_id;
        $comment = get_comment($comment_id);
        return rest_ensure_response(['submitted'=>true,'status'=>$comment->comment_approved,'comment'=>['id'=>(int)$comment_id,'parent_id'=>(int)$parent,'author'=>wp_get_current_user()->display_name,'avatar_url'=>get_avatar_url($user_id,['size'=>72]),'content'=>wp_strip_all_tags($comment->comment_content),'created_at'=>mysql_to_rfc3339($comment->comment_date)]]);
    }

    public function register_notification_rest_routes() {
        register_rest_route('phisk/v1', '/notifications', [
            'methods' => WP_REST_Server::READABLE, 'permission_callback' => [$this, 'app_api_permission_callback'],
            'callback' => function($request) {
                global $wpdb; $this->ensure_notification_tables();
                $page = max(1, absint($request->get_param('page'))); $per_page = min(50, max(1, absint($request->get_param('per_page') ?: 20)));
                $rows = $wpdb->get_results($wpdb->prepare('SELECT id,event_key,type,title,message,target_url,is_read,created_at FROM ' . $this->notification_table() . ' WHERE user_id=%d AND inbox_enabled=1 ORDER BY created_at DESC,id DESC LIMIT %d OFFSET %d', get_current_user_id(), $per_page, ($page-1)*$per_page), ARRAY_A);
                foreach ($rows as &$row) $row['thumbnail_url'] = $this->notification_thumbnail_url($row['event_key'], $row['type'], 'medium');
                unset($row);
                $count = (int) $wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM ' . $this->notification_table() . ' WHERE user_id=%d AND inbox_enabled=1 AND is_read=0', get_current_user_id()));
                return rest_ensure_response(['notifications'=>$rows, 'unread_count'=>$count, 'page'=>$page, 'per_page'=>$per_page]);
            }
        ]);
        register_rest_route('phisk/v1', '/notifications/read', [
            'methods' => WP_REST_Server::CREATABLE, 'permission_callback' => [$this, 'app_api_permission_callback'],
            'callback' => function($request) {
                global $wpdb; $id=absint($request->get_param('id')); if (!$id) return new WP_Error('invalid_notification','A notification ID is required',['status'=>400]);
                $updated=$wpdb->update($this->notification_table(), ['is_read'=>1], ['id'=>$id,'user_id'=>get_current_user_id()], ['%d'], ['%d','%d']);
                return rest_ensure_response(['updated'=>(bool)$updated,'unread_count'=>$this->theme_mobile_unread_total()]);
            }
        ]);
        register_rest_route('phisk/v1', '/notifications/delete', [
            'methods' => WP_REST_Server::CREATABLE, 'permission_callback' => [$this, 'app_api_permission_callback'],
            'callback' => function($request) {
                global $wpdb;
                $id = absint($request->get_param('id'));
                if (!$id) return new WP_Error('invalid_notification', 'A notification ID is required.', ['status' => 400]);
                $deleted = $wpdb->delete($this->notification_table(), ['id' => $id, 'user_id' => get_current_user_id()], ['%d','%d']);
                return rest_ensure_response(['deleted' => (bool) $deleted, 'unread_count' => $this->theme_mobile_unread_total()]);
            }
        ]);
        register_rest_route('phisk/v1', '/notifications/read-all', [
            'methods' => WP_REST_Server::CREATABLE, 'permission_callback' => [$this, 'app_api_permission_callback'],
            'callback' => function() { global $wpdb; $wpdb->update($this->notification_table(), ['is_read'=>1], ['user_id'=>get_current_user_id(),'inbox_enabled'=>1], ['%d'], ['%d','%d']); return rest_ensure_response(['unread_count'=>0]); }
        ]);
        register_rest_route('phisk/v1', '/notification-preferences', [
            'methods' => WP_REST_Server::READABLE, 'permission_callback' => [$this, 'app_api_permission_callback'],
            'callback' => function(){ return rest_ensure_response($this->get_notification_preferences(get_current_user_id())); }
        ]);
        register_rest_route('phisk/v1', '/notification-preferences', [
            'methods' => WP_REST_Server::CREATABLE, 'permission_callback' => [$this, 'app_api_permission_callback'],
            'callback' => function($request) { $allowed=['video_inbox','video_email','story_inbox','story_email','story_approved_email','monetization_approved_email']; $input=$request->get_json_params(); if (!is_array($input)) $input=[]; $prefs=$this->get_notification_preferences(get_current_user_id()); foreach($allowed as $key) if (array_key_exists($key,$input)) $prefs[$key]=(bool)$input[$key]; update_user_meta(get_current_user_id(),'_phisk_notification_preferences',$prefs); return rest_ensure_response($prefs); }
        ]);
        register_rest_route('phisk/v1', '/app-devices/register', [
            'methods' => WP_REST_Server::CREATABLE, 'permission_callback' => [$this, 'app_api_permission_callback'],
            'callback' => function($request) {
                global $wpdb;
                $this->ensure_app_notification_tables();
                $token = trim((string) $request->get_param('fcm_token'));
                $device_id = $this->app_device_id($request->get_param('device_id'));
                $platform = sanitize_key((string) ($request->get_param('platform') ?: 'android'));
                $app_version = sanitize_text_field((string) $request->get_param('app_version'));
                if ($token === '' || strlen($token) > 4096 || $device_id === '') return new WP_Error('phisk_device_fields_required', 'A valid FCM token and device ID are required.', ['status' => 400]);
                if (!in_array($platform, ['android'], true)) return new WP_Error('phisk_device_platform_invalid', 'Unsupported device platform.', ['status' => 400]);
                $uid = get_current_user_id(); $now = current_time('mysql', true); $hash = hash('sha256', $token);
                $existing_id = (int) $wpdb->get_var($wpdb->prepare('SELECT id FROM ' . $this->app_device_table() . ' WHERE token_hash=%s LIMIT 1', $hash));
                $data = ['user_id'=>$uid,'device_id'=>$device_id,'fcm_token'=>$token,'token_hash'=>$hash,'platform'=>$platform,'app_version'=>substr($app_version,0,40),'updated_at'=>$now,'last_seen_at'=>$now];
                if ($existing_id) $wpdb->update($this->app_device_table(), $data, ['id'=>$existing_id]);
                else { $data['created_at']=$now; $wpdb->insert($this->app_device_table(), $data); }
                return rest_ensure_response(['registered'=>true,'device_id'=>$device_id]);
            }
        ]);
        register_rest_route('phisk/v1', '/app-devices/unregister', [
            'methods' => WP_REST_Server::CREATABLE, 'permission_callback' => [$this, 'app_api_permission_callback'],
            'callback' => function($request) {
                global $wpdb;
                $device_id = $this->app_device_id($request->get_param('device_id'));
                $token = trim((string) $request->get_param('fcm_token'));
                if ($device_id === '' && $token === '') return new WP_Error('phisk_device_identifier_required', 'A device ID or FCM token is required.', ['status' => 400]);
                if ($token !== '') $deleted = $wpdb->delete($this->app_device_table(), ['user_id'=>get_current_user_id(),'token_hash'=>hash('sha256',$token)], ['%d','%s']);
                else $deleted = $wpdb->delete($this->app_device_table(), ['user_id'=>get_current_user_id(),'device_id'=>$device_id], ['%d','%s']);
                return rest_ensure_response(['unregistered'=>(bool)$deleted]);
            }
        ]);
        register_rest_route('phisk/v1', '/messages', [
            'methods' => WP_REST_Server::READABLE, 'permission_callback' => [$this, 'app_api_permission_callback'],
            'callback' => function($request) { global $wpdb; $page=max(1,absint($request->get_param('page'))); $per_page=min(50,max(1,absint($request->get_param('per_page') ?: 20))); $rows=$wpdb->get_results($wpdb->prepare('SELECT id,subject,message,is_read,created_at FROM ' . $this->admin_messages_table() . ' WHERE user_id=%d ORDER BY created_at DESC,id DESC LIMIT %d OFFSET %d',get_current_user_id(),$per_page,($page-1)*$per_page),ARRAY_A); $unread=(int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM ' . $this->admin_messages_table() . ' WHERE user_id=%d AND is_read=0',get_current_user_id())); return rest_ensure_response(['messages'=>$rows,'unread_count'=>$unread,'page'=>$page,'per_page'=>$per_page]); }
        ]);
        register_rest_route('phisk/v1', '/messages/read', [
            'methods' => WP_REST_Server::CREATABLE, 'permission_callback' => [$this, 'app_api_permission_callback'],
            'callback' => function($request) { global $wpdb; $id=absint($request->get_param('id')); if(!$id) return new WP_Error('invalid_message','A message ID is required',['status'=>400]); $updated=$wpdb->update($this->admin_messages_table(),['is_read'=>1],['id'=>$id,'user_id'=>get_current_user_id()],['%d'],['%d','%d']); $unread=(int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM ' . $this->admin_messages_table() . ' WHERE user_id=%d AND is_read=0',get_current_user_id())); return rest_ensure_response(['updated'=>(bool)$updated,'unread_count'=>$unread]); }
        ]);
    }

    public function handle_notification_open_action() {
        if (!is_user_logged_in() || empty($_GET['phisk_notification_open'])) return;
        $id=absint($_GET['phisk_notification_open']);
        if (!$id || !wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'] ?? '')), 'phisk_notification_open_' . $id)) return;
        global $wpdb; $row=$wpdb->get_row($wpdb->prepare('SELECT target_url FROM ' . $this->notification_table() . ' WHERE id=%d AND user_id=%d AND inbox_enabled=1', $id, get_current_user_id()));
        if (!$row) return;
        $wpdb->delete($this->notification_table(), ['id'=>$id,'user_id'=>get_current_user_id()], ['%d','%d']);
        $target=$row->target_url ? $row->target_url : home_url('/phisk-notifications/');
        wp_safe_redirect($target); exit;
    }

    public function handle_notification_mark_all_action() {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || empty($_POST['phisk_notifications_mark_all']) || !is_user_logged_in()) return;
        if (!isset($_POST['phisk_notifications_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['phisk_notifications_nonce'])), 'phisk_notifications_mark_all')) return;
        global $wpdb; $wpdb->update($this->notification_table(), ['is_read'=>1], ['user_id'=>get_current_user_id(),'inbox_enabled'=>1], ['%d'], ['%d','%d']);
        wp_safe_redirect(remove_query_arg(['phisk_notifications_mark_all'])); exit;
    }

    /** Resolve the content image for a notification. Reply events point to a comment ID, not a post ID. */
    private function notification_thumbnail_url($event_key, $type = '', $size = 'medium') {
        $parts = explode(':', (string) $event_key);
        $reference_id = absint(end($parts));
        $post_id = $reference_id;
        if ($type === 'video_comment_reply') {
            $comment = get_comment($reference_id);
            if (!$comment) return '';
            $post_id = absint($comment->comment_post_ID);
        }
        $post = $post_id ? get_post($post_id) : null;
        if (!$post) return '';

        // Stories use the first uploaded gallery image as their featured feed image.
        if ($post->post_type === 'post' && metadata_exists('post', $post_id, '_phisk_article_gallery_ids')) {
            $gallery_ids = $this->article_gallery_ids($post_id);
            if (!empty($gallery_ids[0])) {
                $gallery_url = wp_get_attachment_image_url((int) $gallery_ids[0], $size);
                if ($gallery_url) return $gallery_url;
            }
        }
        if (has_post_thumbnail($post_id)) {
            $featured = get_the_post_thumbnail_url($post_id, $size);
            if ($featured) return $featured;
        }
        if ($post->post_type === 'phisk_video') {
            $custom = get_post_meta($post_id, 'phisk_video_thumbnail', true);
            if (!$custom) $custom = get_post_meta($post_id, '_phisk_video_thumbnail', true);
            if ($custom && wp_http_validate_url($custom)) return esc_url_raw($custom);
            $youtube_id = (string) get_post_meta($post_id, '_phisk_youtube_video_id', true);
            if (preg_match('/^[A-Za-z0-9_-]{11}$/', $youtube_id)) return 'https://i.ytimg.com/vi/' . $youtube_id . '/hqdefault.jpg';
        }
        return '';
    }

    public function notifications_inbox_shortcode() {
        $this->enqueue_style();
        if (!is_user_logged_in()) return '<section class="phisk-dashboard-login"><h2>Notifications</h2><p>Please log in to view your notifications.</p></section>';
        global $wpdb; $this->ensure_notification_tables(); $uid=get_current_user_id();
        $rows=$wpdb->get_results($wpdb->prepare('SELECT id,event_key,type,title,message,target_url,is_read,created_at FROM ' . $this->notification_table() . ' WHERE user_id=%d AND inbox_enabled=1 ORDER BY created_at DESC,id DESC LIMIT 50', $uid));
        $unread=$this->theme_mobile_unread_total();
        $settings=add_query_arg('phisk_settings_tab','notifications',$this->account_settings_url());
        ob_start(); ?>
        <section class="phisk-notifications-inbox phisk-user-dashboard"><style>
        .phisk-notifications-inbox{max-width:900px;margin:24px auto}.phisk-notifications-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:20px 0 18px}.phisk-notifications-head form{margin:0}.phisk-notifications-settings{width:42px;height:42px;display:inline-flex;align-items:center;justify-content:center;border:1px solid #e5e7eb;border-radius:10px;color:#555;background:#fff;text-decoration:none!important}.phisk-notifications-settings svg{width:21px;height:21px;fill:currentColor;stroke:none}.phisk-notifications-mark-all{border:0;background:#7C3AED;color:#fff;padding:11px 17px;border-radius:9px;font:inherit;font-weight:650;cursor:pointer}.phisk-notifications-mark-all:hover{background:#6D28D9}.phisk-notification-list{display:grid;gap:12px;border:0}.phisk-notification-item{display:grid;grid-template-columns:104px minmax(0,1fr);align-items:center;gap:14px;padding:14px;border:1px solid #e8e9ed;border-radius:12px;background:#fff;color:#171717;text-decoration:none!important;box-shadow:0 2px 8px rgba(20,25,35,.035)}.phisk-notification-item.is-unread{border-color:#d8c9fb;background:#fff}.phisk-notification-dot{display:none}.phisk-notification-thumb{display:block;width:104px;aspect-ratio:16/9;object-fit:cover;border-radius:7px;background:#f0f0f0}.phisk-notification-thumb-placeholder{display:flex;align-items:center;justify-content:center;color:#777;font-size:12px}.phisk-notification-copy{min-width:0}.phisk-notification-copy strong{display:block;margin:2px 0 5px;font-size:16px;line-height:1.35;font-weight:650;text-decoration:none!important}.phisk-notification-copy p{margin:0 0 5px;line-height:1.25;font-size:12px;color:#16803c;font-weight:650;text-decoration:none!important}.phisk-notification-copy time{font-size:12px;opacity:.65;text-decoration:none!important}.phisk-notification-item:hover,.phisk-notification-item:hover .phisk-notification-copy strong{text-decoration:none!important;color:#171717}@media(max-width:480px){.phisk-notification-item{grid-template-columns:88px minmax(0,1fr);gap:11px;padding:11px}.phisk-notification-thumb{width:88px}.phisk-notification-copy strong{font-size:14px}}.phisk-notifications-empty{padding:24px 18px;text-align:center;background:#f7f7f8;border-radius:10px;color:#555}.phisk-empty-mascot{display:block;width:130px;height:130px;max-width:100%;object-fit:contain;margin:0 auto 10px}.phisk-notifications-caught-up{display:flex;align-items:center;justify-content:center;gap:14px;margin:0 0 16px;padding:14px 16px;border-radius:10px;background:#fafafa;color:#555}.phisk-notifications-caught-up .phisk-empty-mascot{width:90px;height:90px;flex:0 0 90px;margin:0}.phisk-notifications-caught-up p{margin:0;line-height:1.45}@media(max-width:480px){.phisk-notifications-caught-up{flex-direction:column;text-align:center}.phisk-notifications-caught-up .phisk-empty-mascot{width:100px;height:100px;flex-basis:100px}}@media(prefers-color-scheme:dark){.phisk-notification-item,.phisk-notifications-empty{background:#242424;color:#f5f5f5}.phisk-notification-item.is-unread{background:#302443}}
        </style><nav class="phisk-inbox-tabs" aria-label="Inbox sections" style="display:flex;gap:18px;margin-bottom:18px;border-bottom:1px solid #e5e5e5;padding-bottom:10px"><a href="<?php echo esc_url(get_permalink(get_option('phiskvideos_notifications_page_id')) ?: home_url('/phisk-notifications/')); ?>" aria-current="page" style="font-weight:700;color:#7C3AED;text-decoration:none">Notifications</a><a href="<?php echo esc_url(get_permalink(get_option('phiskvideos_messages_page_id')) ?: home_url('/phisk-messages/')); ?>" style="color:inherit;text-decoration:none">Messages</a></nav><header class="phisk-notifications-head"><a class="phisk-notifications-settings" href="<?php echo esc_url($settings); ?>" aria-label="Notification settings" title="Notification settings"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M9.8,9.802c-.755,.753-1.122,1.476-1.122,2.208,0,.957,.64,1.706,1.122,2.187,.74,.739,1.47,1.108,2.2,1.108s1.46-.37,2.2-1.108c.755-.753,1.122-1.476,1.122-2.208,0-.957-.64-1.706-1.122-2.187-1.48-1.478-2.92-1.478-4.4,0Zm3.694,3.688c-1.251,1.248-2.042,.944-2.988,0-.565-.564-.828-1.034-.828-1.479,0-.454,.271-.944,.828-1.5,.583-.582,1.065-.826,1.511-.826,.511,0,.972,.322,1.478,.826,.565,.564,.828,1.034,.828,1.479,0,.454-.271,.944-.828,1.5Z"/>
  <g>
    <path fill="currentColor" d="M9.8,9.802c-.755,.753-1.122,1.476-1.122,2.208,0,.957,.64,1.706,1.122,2.187,.74,.739,1.47,1.108,2.2,1.108s1.46-.37,2.2-1.108c.755-.753,1.122-1.476,1.122-2.208,0-.957-.64-1.706-1.122-2.187-1.48-1.478-2.92-1.478-4.4,0Zm3.694,3.688c-1.251,1.248-2.042,.944-2.988,0-.565-.564-.828-1.034-.828-1.479,0-.454,.271-.944,.828-1.5,.583-.582,1.065-.826,1.511-.826,.511,0,.972,.322,1.478,.826,.565,.564,.828,1.034,.828,1.479,0,.454-.271,.944-.828,1.5Z"/>
    <path fill="currentColor" d="M23.019,11.948c.008-1.595-.817-2.481-2.521-2.7-.188-.394-.417-.787-.694-1.188,1.205-1.456,1.21-2.694,.026-3.876-1.183-1.181-2.425-1.175-3.884,.029-.401-.274-.794-.501-1.188-.688-.217-1.706-1.134-2.524-2.705-2.524-1.602,.008-2.495,.849-2.725,2.569-.392,.189-.791,.421-1.19,.691-1.451-1.197-2.694-1.194-3.89,0-1.178,1.175-1.18,2.448-.001,3.882-.273,.4-.506,.798-.696,1.189-1.719,.229-2.56,1.122-2.568,2.721-.008,1.595,.817,2.481,2.521,2.7,.188,.394,.417,.787,.694,1.188-1.205,1.456-1.21,2.694-.026,3.876,1.184,1.182,2.425,1.176,3.884-.029,.401,.274,.794,.501,1.188,.688,.216,1.697,1.113,2.524,2.682,2.524,1.605,0,2.519-.849,2.749-2.569,.392-.189,.791-.421,1.19-.691,1.451,1.197,2.694,1.193,3.89,0,1.178-1.175,1.18-2.448,.001-3.882,.273-.4,.506-.798,.696-1.189,1.719-.229,2.56-1.122,2.568-2.721Zm-3.36,2.053c-.227,.515-.544,1.051-.942,1.594-.142,.193-.127,.459,.036,.635,1.373,1.487,.898,2.2,.295,2.802-.63,.628-1.321,1.078-2.812-.295-.175-.162-.44-.176-.634-.036-.541,.395-1.077,.71-1.595,.937-.167,.073-.282,.232-.297,.415-.139,1.615-.779,1.942-1.766,1.947-1.008-.027-1.609-.304-1.734-1.9-.015-.186-.131-.348-.302-.421-.521-.222-1.041-.526-1.588-.929-.089-.065-.193-.097-.296-.097-.122,0-.243,.044-.338,.132-1.503,1.383-2.211,.919-2.807,.324-.595-.594-1.06-1.299,.323-2.797,.163-.177,.178-.444,.035-.637-.4-.541-.716-1.075-.937-1.588-.073-.17-.234-.286-.419-.301-1.587-.126-1.903-.755-1.898-1.729,.005-.984,.333-1.622,1.946-1.761,.182-.016,.341-.129,.415-.296,.227-.515,.544-1.051,.942-1.594,.142-.193,.127-.459-.036-.635-1.373-1.487-.898-2.2-.295-2.802,.606-.604,1.321-1.08,2.812,.295,.176,.163,.441,.178,.634,.036,.541-.395,1.077-.71,1.595-.937,.167-.073,.282-.232,.297-.415,.139-1.615,.779-1.942,1.766-1.947,.99-.027,1.608,.304,1.734,1.9,.015,.186,.131,.348,.302,.421,.521,.222,1.041,.526,1.588,.929,.193,.142,.458,.127,.635-.035,1.504-1.382,2.212-.918,2.807-.324,.595,.594,1.06,1.299-.323,2.797-.163,.177-.178,.444-.035,.637,.4,.541,.716,1.075,.937,1.588,.073,.17,.234,.286,.419,.301,1.587,.126,1.903,.755,1.898,1.729-.005,.984-.333,1.622-1.946,1.761-.182,.016-.341,.129-.415,.296Z"/>
  </g></svg></a><?php if ($unread > 0) : ?><form method="post"><?php wp_nonce_field('phisk_notifications_mark_all','phisk_notifications_nonce'); ?><input type="hidden" name="phisk_notifications_mark_all" value="1"><button class="phisk-notifications-mark-all" type="submit">Mark all as read</button></form><?php endif; ?></header>
        <?php if (!$rows) : ?><div class="phisk-notifications-empty"><img class="phisk-empty-mascot" src="<?php echo esc_url(plugins_url('assets/phisk-mascot-empty-state.webp', __FILE__)); ?>" width="130" height="130" alt="Purple Phisk mascot reading a newspaper" loading="lazy" decoding="async"><p>You're all caught up. New channel updates and important account notifications will appear here.</p></div><?php else : ?><?php if ($unread === 0) : ?><div class="phisk-notifications-caught-up"><img class="phisk-empty-mascot" src="<?php echo esc_url(plugins_url('assets/phisk-mascot-empty-state.webp', __FILE__)); ?>" width="90" height="90" alt="Purple Phisk mascot reading a newspaper" loading="lazy" decoding="async"><p><strong>You're all caught up!</strong><br>There are no unread notifications. Your previous notifications are still listed below.</p></div><?php endif; ?><div class="phisk-notification-list"><?php foreach($rows as $row) : $open_url=add_query_arg(['phisk_notification_open'=>$row->id,'_wpnonce'=>wp_create_nonce('phisk_notification_open_' . $row->id)], get_permalink(get_option('phiskvideos_notifications_page_id')) ?: home_url('/phisk-notifications/')); $is_channel_update=in_array($row->type,['new_video','new_story'],true); $event_parts=explode(':',(string)$row->event_key); $content_id=absint(end($event_parts)); $content_title=$content_id ? get_the_title($content_id) : ''; $thumb_url=$this->notification_thumbnail_url($row->event_key, $row->type, 'medium'); ?><a class="phisk-notification-item <?php echo $row->is_read ? 'is-read' : 'is-unread'; ?>" href="<?php echo esc_url($open_url); ?>"><?php if($thumb_url) : ?><img class="phisk-notification-thumb" src="<?php echo esc_url($thumb_url); ?>" alt="" loading="lazy" decoding="async"><?php else : ?><span class="phisk-notification-thumb phisk-notification-thumb-placeholder" aria-hidden="true"><?php echo $is_channel_update ? 'PhiskVideos' : 'Update'; ?></span><?php endif; ?><span class="phisk-notification-copy"><?php if($is_channel_update) : ?><p><?php echo esc_html($row->title); ?></p><strong><?php echo esc_html($content_title ?: $row->message); ?></strong><?php else : ?><strong><?php echo esc_html($row->title); ?></strong><p><?php echo esc_html($row->message); ?></p><?php endif; ?><time datetime="<?php echo esc_attr(mysql2date('c',$row->created_at,true)); ?>"><?php echo esc_html(human_time_diff(strtotime($row->created_at . ' UTC'), current_time('timestamp', true)) . ' ago'); ?></time></div></a><?php endforeach; ?></div><?php endif; ?></section>
        <?php return ob_get_clean();
    }

    /** Strike management schema. Strike dates are stored in UTC and expire on a rolling 90-day basis. */
    public function ensure_user_strike_tables() {
        if (get_option('phisk_user_strikes_schema_version') === '1') return;
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $strikes = $wpdb->prefix . 'phisk_user_strikes';
        $appeals = $wpdb->prefix . 'phisk_user_strike_appeals';
        dbDelta("CREATE TABLE {$strikes} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            issued_by bigint(20) unsigned NOT NULL,
            category varchar(100) NOT NULL DEFAULT 'policy_violation',
            reason text NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'active',
            issued_at datetime NOT NULL,
            expires_at datetime NOT NULL,
            revoked_at datetime NULL,
            revoked_by bigint(20) unsigned NOT NULL DEFAULT 0,
            revoke_reason text NULL,
            PRIMARY KEY  (id),
            KEY user_status_expiry (user_id,status,expires_at),
            KEY issued_at (issued_at)
        ) {$charset};");
        dbDelta("CREATE TABLE {$appeals} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            strike_id bigint(20) unsigned NOT NULL,
            user_id bigint(20) unsigned NOT NULL,
            explanation longtext NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'pending',
            submitted_at datetime NOT NULL,
            reviewed_at datetime NULL,
            reviewed_by bigint(20) unsigned NOT NULL DEFAULT 0,
            admin_response text NULL,
            PRIMARY KEY  (id),
            KEY strike_status (strike_id,status),
            KEY user_status (user_id,status),
            KEY submitted_at (submitted_at)
        ) {$charset};");
        update_option('phisk_user_strikes_schema_version', '1', false);
    }

    private function user_strike_table() { global $wpdb; return $wpdb->prefix . 'phisk_user_strikes'; }
    private function user_strike_appeals_table() { global $wpdb; return $wpdb->prefix . 'phisk_user_strike_appeals'; }

    /** Insert an administration-to-user message using the existing inbox. */
    private function send_strike_system_message($user_id, $subject, $message) {
        global $wpdb;
        $user_id = absint($user_id);
        if (!$user_id || !get_userdata($user_id)) return false;
        $this->ensure_notification_tables();
        $inserted = $wpdb->insert($this->admin_messages_table(), [
            'user_id' => $user_id, 'sender_id' => get_current_user_id() ?: 0,
            'subject' => sanitize_text_field($subject), 'message' => wp_kses_post($message),
            'is_read' => 0, 'created_at' => current_time('mysql', true),
        ], ['%d','%d','%s','%s','%d','%s']);
        if ($inserted) {
            $message_id = (int) $wpdb->insert_id;
            $this->create_admin_message_notification($user_id, $message_id, $subject);
            $wpdb->query($wpdb->prepare('DELETE FROM ' . $this->admin_messages_table() . ' WHERE user_id=%d AND id NOT IN (SELECT id FROM (SELECT id FROM ' . $this->admin_messages_table() . ' WHERE user_id=%d ORDER BY created_at DESC,id DESC LIMIT 10) AS phisk_latest_messages)', $user_id, $user_id));
        }
        return (bool)$inserted;
    }

    private function active_user_strikes($user_id) {
        global $wpdb;
        $now = current_time('mysql', true);
        return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$this->user_strike_table()} WHERE user_id=%d AND status='active' AND expires_at>%s ORDER BY issued_at ASC,id ASC", absint($user_id), $now));
    }

    public function user_strike_blocks_publishing($user_id) {
        $user_id = absint($user_id);
        if (!$user_id || user_can($user_id, 'manage_options')) return false;
        $this->recalculate_user_strike_enforcement($user_id);
        return (bool)get_user_meta($user_id, '_phisk_strike_channel_restricted', true);
    }

    /** Recalculate restrictions after issue, revocation, appeal, or scheduled expiry. */
    private function recalculate_user_strike_enforcement($user_id, $notify = true) {
        global $wpdb;
        $user_id = absint($user_id);
        if (!$user_id || !get_userdata($user_id)) return 0;
        $now = current_time('mysql', true);
        $expired = $wpdb->get_results($wpdb->prepare("SELECT id FROM {$this->user_strike_table()} WHERE user_id=%d AND status='active' AND expires_at<=%s", $user_id, $now));
        if ($expired) {
            foreach ($expired as $row) {
                $wpdb->update($this->user_strike_table(), ['status'=>'expired'], ['id'=>(int)$row->id,'user_id'=>$user_id], ['%s'], ['%d','%d']);
                if ($notify) $this->send_strike_system_message($user_id, 'A PhiskVideos strike has expired', 'One of your account strikes has expired after 90 days. Your account standing has been recalculated. Visit ' . esc_url(get_permalink(absint(get_option('phiskvideos_strike_appeal_page_id'))) ?: home_url('/account-standing/')) . ' to review your current status.');
            }
        }
        $strikes = $this->active_user_strikes($user_id);
        $count = count($strikes);

        // Two active strikes pause monetization without overwriting the previous application state.
        $paused = (bool)get_user_meta($user_id, '_phisk_strike_monetization_paused', true);
        if ($count >= 2 && !$paused) {
            $current = get_user_meta($user_id, '_phisk_monetization_status', true);
            update_user_meta($user_id, '_phisk_strike_saved_monetization_status', $current !== '' ? $current : 'not_applied');
            update_user_meta($user_id, '_phisk_strike_monetization_paused', '1');
            if ($current !== 'suspended') update_user_meta($user_id, '_phisk_monetization_status', 'suspended');
            if ($notify) $this->send_strike_system_message($user_id, 'Monetization temporarily paused', 'Your account has reached two active strikes within the 90-day policy window. Monetization has been paused automatically. It will be reviewed again when your active strike count falls below two.');
        } elseif ($count >= 2 && $paused) {
            // Keep a later manual approval from bypassing an active strike suspension.
            $current = get_user_meta($user_id, '_phisk_monetization_status', true);
            if ($current !== 'suspended') update_user_meta($user_id, '_phisk_monetization_status', 'suspended');
        } elseif ($count < 2 && $paused) {
            $restore = get_user_meta($user_id, '_phisk_strike_saved_monetization_status', true);
            if (get_user_meta($user_id, '_phisk_monetization_status', true) === 'suspended' && $restore !== '') update_user_meta($user_id, '_phisk_monetization_status', $restore);
            delete_user_meta($user_id, '_phisk_strike_monetization_paused');
            delete_user_meta($user_id, '_phisk_strike_saved_monetization_status');
            if ($notify) $this->send_strike_system_message($user_id, 'Monetization restriction lifted', 'Your active strike count is now below two. The strike-related monetization pause has been lifted. Any separate eligibility or administrative restrictions still apply.');
        }

        // Three active strikes disable creator-channel access while preserving the channel and all content.
        $channel_restricted = (bool)get_user_meta($user_id, '_phisk_strike_channel_restricted', true);
        if ($count >= 3 && !$channel_restricted) {
            $previous = get_user_meta($user_id, 'phisk_has_channel', true);
            update_user_meta($user_id, '_phisk_strike_saved_channel_flag', $previous === '' ? '__legacy_default__' : (string)$previous);
            update_user_meta($user_id, '_phisk_strike_channel_restricted', '1');
            update_user_meta($user_id, 'phisk_has_channel', '0');
            if ($notify) $this->send_strike_system_message($user_id, 'Creator channel disabled', 'Your account has reached three active strikes within 90 days. Your channel has been disabled and your videos, Stories, channel details and other content data have been preserved. You cannot publish videos or Stories or create another channel while this restriction is active. You may submit an appeal from Account Standing.');
        } elseif ($count < 3 && $channel_restricted) {
            $previous = get_user_meta($user_id, '_phisk_strike_saved_channel_flag', true);
            if ($previous === '__legacy_default__' || $previous === '') delete_user_meta($user_id, 'phisk_has_channel');
            else update_user_meta($user_id, 'phisk_has_channel', $previous);
            delete_user_meta($user_id, '_phisk_strike_channel_restricted');
            delete_user_meta($user_id, '_phisk_strike_saved_channel_flag');
            if ($notify) $this->send_strike_system_message($user_id, 'Creator channel restriction lifted', 'Your active strike count has fallen below three. Your existing channel has been re-enabled. Your channel and content data remained preserved.');
        }
        update_user_meta($user_id, '_phisk_active_strike_count', $count);
        return $count;
    }

    public function schedule_user_strike_maintenance() {
        if (!wp_next_scheduled('phisk_user_strike_daily_maintenance')) wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', 'phisk_user_strike_daily_maintenance');
    }

    public function run_user_strike_maintenance() {
        global $wpdb;
        $users = $wpdb->get_col("SELECT DISTINCT user_id FROM {$this->user_strike_table()} WHERE status='active'");
        foreach ((array)$users as $user_id) $this->recalculate_user_strike_enforcement((int)$user_id, true);
    }

    public function register_user_strikes_menu() {
        add_submenu_page('options-general.php', 'Phisk User Strikes', 'User Strikes', 'manage_options', 'phisk-user-strikes', [$this, 'user_strikes_admin_page']);
    }

    public function handle_user_strike_admin_actions() {
        if (!is_admin() || !current_user_can('manage_options')) return;
        global $wpdb;
        if (!empty($_POST['phisk_issue_user_strike'])) {
            check_admin_referer('phisk_issue_user_strike', 'phisk_strike_nonce');
            $uid = absint($_POST['strike_user_id'] ?? 0);
            $category = sanitize_text_field(wp_unslash($_POST['strike_category'] ?? 'policy_violation'));
            $reason = sanitize_textarea_field(wp_unslash($_POST['strike_reason'] ?? ''));
            if ($uid && get_userdata($uid) && $reason !== '') {
                $now = current_time('timestamp', true);
                $wpdb->insert($this->user_strike_table(), ['user_id'=>$uid,'issued_by'=>get_current_user_id(),'category'=>$category,'reason'=>$reason,'status'=>'active','issued_at'=>gmdate('Y-m-d H:i:s',$now),'expires_at'=>gmdate('Y-m-d H:i:s',$now + (90 * DAY_IN_SECONDS))], ['%d','%d','%s','%s','%s','%s','%s']);
                if ($wpdb->insert_id) {
                    $strike_no = count($this->active_user_strikes($uid));
                    $appeal_url = get_permalink(absint(get_option('phiskvideos_strike_appeal_page_id'))) ?: home_url('/account-standing/');
                    $this->send_strike_system_message($uid, 'PhiskVideos account strike issued', "An administrator has issued a strike to your account.\n\nCategory: {$category}\nReason: {$reason}\nActive strikes: {$strike_no} of 3.\nThis strike expires 90 days after it was issued unless revoked earlier.\n\nYou may appeal this decision here: {$appeal_url}");
                    // Threshold messages are sent by a fresh enforcement pass after the strike notice.
                    $this->recalculate_user_strike_enforcement($uid, true);
                }
            }
            wp_safe_redirect(add_query_arg(['page'=>'phisk-user-strikes','strike_saved'=>'1'], admin_url('options-general.php'))); exit;
        }
        if (!empty($_POST['phisk_revoke_user_strike'])) {
            check_admin_referer('phisk_revoke_user_strike', 'phisk_revoke_nonce');
            $strike_id = absint($_POST['strike_id'] ?? 0);
            $reason = sanitize_textarea_field(wp_unslash($_POST['revoke_reason'] ?? 'Administrative review'));
            $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->user_strike_table()} WHERE id=%d AND status='active'", $strike_id));
            if ($row) {
                $wpdb->update($this->user_strike_table(), ['status'=>'revoked','revoked_at'=>current_time('mysql',true),'revoked_by'=>get_current_user_id(),'revoke_reason'=>$reason], ['id'=>$strike_id], ['%s','%s','%d','%s'], ['%d']);
                $this->send_strike_system_message((int)$row->user_id, 'A PhiskVideos strike was revoked', 'An administrator has revoked strike #' . $strike_id . '. Reason: ' . $reason . '. Your account restrictions have been recalculated.');
                $this->recalculate_user_strike_enforcement((int)$row->user_id, true);
            }
            wp_safe_redirect(add_query_arg(['page'=>'phisk-user-strikes','strike_revoked'=>'1'], admin_url('options-general.php'))); exit;
        }
        if (!empty($_POST['phisk_review_strike_appeal'])) {
            check_admin_referer('phisk_review_strike_appeal', 'phisk_appeal_review_nonce');
            $appeal_id = absint($_POST['appeal_id'] ?? 0);
            $decision = sanitize_key(wp_unslash($_POST['appeal_decision'] ?? ''));
            $response = sanitize_textarea_field(wp_unslash($_POST['appeal_response'] ?? ''));
            $appeal = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->user_strike_appeals_table()} WHERE id=%d AND status='pending'", $appeal_id));
            if ($appeal && in_array($decision, ['approved','rejected'], true)) {
                $wpdb->update($this->user_strike_appeals_table(), ['status'=>$decision,'reviewed_at'=>current_time('mysql',true),'reviewed_by'=>get_current_user_id(),'admin_response'=>$response], ['id'=>$appeal_id], ['%s','%s','%d','%s'], ['%d']);
                if ($decision === 'approved') {
                    $strike = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->user_strike_table()} WHERE id=%d", (int)$appeal->strike_id));
                    if ($strike && $strike->status === 'active') {
                        $wpdb->update($this->user_strike_table(), ['status'=>'revoked','revoked_at'=>current_time('mysql',true),'revoked_by'=>get_current_user_id(),'revoke_reason'=>'Appeal approved'], ['id'=>(int)$strike->id], ['%s','%s','%d','%s'], ['%d']);
                    }
                    $this->send_strike_system_message((int)$appeal->user_id, 'Your PhiskVideos appeal was approved', 'Your appeal has been approved and the related strike has been revoked. ' . $response);
                } else {
                    $this->send_strike_system_message((int)$appeal->user_id, 'Your PhiskVideos appeal was reviewed', 'Your appeal was not approved. The strike remains active unless it expires or is separately revoked. ' . $response);
                }
                $this->recalculate_user_strike_enforcement((int)$appeal->user_id, true);
            }
            wp_safe_redirect(add_query_arg(['page'=>'phisk-user-strikes','appeal_reviewed'=>'1'], admin_url('options-general.php'))); exit;
        }
    }

    public function user_strikes_admin_page() {
        if (!current_user_can('manage_options')) return;
        global $wpdb;
        $users = get_users(['orderby'=>'display_name','order'=>'ASC','number'=>1000,'fields'=>['ID','display_name','user_email','user_login']]);
        $strikes = $wpdb->get_results("SELECT * FROM {$this->user_strike_table()} ORDER BY issued_at DESC,id DESC LIMIT 100");
        $appeals = $wpdb->get_results("SELECT * FROM {$this->user_strike_appeals_table()} WHERE status='pending' ORDER BY submitted_at ASC LIMIT 100");
        echo '<div class="wrap"><h1>PhiskVideos User Strikes</h1><p>Issue and review account strikes. Strikes expire automatically 90 days after issuance. Two active strikes pause monetization; three active strikes disable creator publishing and the channel while preserving all data.</p>';
        if (isset($_GET['strike_saved'])) echo '<div class="notice notice-success"><p>Strike issued and user notified.</p></div>';
        if (isset($_GET['strike_revoked'])) echo '<div class="notice notice-success"><p>Strike revoked and account restrictions recalculated.</p></div>';
        if (isset($_GET['appeal_reviewed'])) echo '<div class="notice notice-success"><p>Appeal decision saved and user notified.</p></div>';
        echo '<h2>Issue a strike</h2><form method="post" style="max-width:760px;background:#fff;padding:18px;border:1px solid #ddd">';
        wp_nonce_field('phisk_issue_user_strike','phisk_strike_nonce');
        echo '<input type="hidden" name="phisk_issue_user_strike" value="1"><p><label><strong>User</strong><br><select name="strike_user_id" required style="width:100%;max-width:600px"><option value="">Select a user</option>';
        foreach ($users as $u) echo '<option value="'.absint($u->ID).'">'.esc_html($u->display_name.' (@'.$u->user_login.') — '.$u->user_email).'</option>';
        echo '</select></label></p><p><label><strong>Violation category</strong><br><select name="strike_category"><option value="community_guidelines">Community Guidelines</option><option value="copyright">Copyright</option><option value="spam">Spam or deceptive activity</option><option value="harassment">Harassment or abuse</option><option value="dangerous_content">Dangerous or harmful content</option><option value="other">Other policy violation</option></select></label></p><p><label><strong>Reason shown to user</strong><br><textarea name="strike_reason" rows="5" required style="width:100%;max-width:600px"></textarea></label></p><p><button class="button button-primary">Issue Strike</button></p></form>';
        echo '<h2 style="margin-top:30px">Pending appeals</h2>';
        if (!$appeals) echo '<p>No pending appeals.</p>';
        foreach ((array)$appeals as $a) {
            $u = get_userdata($a->user_id); $strike = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->user_strike_table()} WHERE id=%d", $a->strike_id));
            echo '<div style="background:#fff;border:1px solid #ddd;padding:16px;margin:12px 0;max-width:900px"><strong>'.esc_html($u ? $u->display_name.' (@'.$u->user_login.')' : 'Deleted user').'</strong> — Appeal #'.absint($a->id).' for strike #'.absint($a->strike_id).'<p>'.nl2br(esc_html($a->explanation)).'</p>';
            if ($strike) echo '<p><strong>Original reason:</strong> '.esc_html($strike->reason).'</p>';
            echo '<form method="post">'; wp_nonce_field('phisk_review_strike_appeal','phisk_appeal_review_nonce'); echo '<input type="hidden" name="phisk_review_strike_appeal" value="1"><input type="hidden" name="appeal_id" value="'.absint($a->id).'"><textarea name="appeal_response" rows="2" placeholder="Optional response to the user" style="width:100%;max-width:700px"></textarea><p><button class="button button-primary" name="appeal_decision" value="approved">Approve appeal and revoke strike</button> <button class="button" name="appeal_decision" value="rejected">Reject appeal</button></p></form></div>';
        }
        echo '<h2 style="margin-top:30px">Recent strikes</h2><table class="widefat striped"><thead><tr><th>User</th><th>Category</th><th>Reason</th><th>Status</th><th>Issued</th><th>Expires</th><th>Action</th></tr></thead><tbody>';
        foreach ((array)$strikes as $st) {
            $u = get_userdata($st->user_id); echo '<tr><td>'.esc_html($u ? $u->display_name.' (@'.$u->user_login.')' : 'Deleted user').'</td><td>'.esc_html($st->category).'</td><td>'.esc_html(wp_trim_words($st->reason,18)).'</td><td>'.esc_html($st->status).'</td><td>'.esc_html($st->issued_at).'</td><td>'.esc_html($st->expires_at).'</td><td>';
            if ($st->status === 'active') { echo '<form method="post">'; wp_nonce_field('phisk_revoke_user_strike','phisk_revoke_nonce'); echo '<input type="hidden" name="phisk_revoke_user_strike" value="1"><input type="hidden" name="strike_id" value="'.absint($st->id).'"><input type="text" name="revoke_reason" placeholder="Reason for revocation" style="width:150px"> <button class="button">Revoke</button></form>'; }
            echo '</td></tr>';
        }
        echo '</tbody></table></div>';
    }

    public function handle_user_strike_appeal_submission() {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || empty($_POST['phisk_strike_appeal_submit']) || !is_user_logged_in()) return;
        if (!isset($_POST['phisk_strike_appeal_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['phisk_strike_appeal_nonce'])), 'phisk_strike_appeal_submit')) return;
        global $wpdb;
        $user_id = get_current_user_id(); $strike_id = absint($_POST['strike_id'] ?? 0); $explanation = sanitize_textarea_field(wp_unslash($_POST['appeal_explanation'] ?? ''));
        $strike = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->user_strike_table()} WHERE id=%d AND user_id=%d AND status='active' AND expires_at>%s", $strike_id, $user_id, current_time('mysql',true)));
        if (!$strike || strlen($explanation) < 20) {
            wp_safe_redirect(add_query_arg('appeal_status','invalid', wp_get_referer() ?: home_url('/account-standing/'))); exit;
        }
        $pending = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$this->user_strike_appeals_table()} WHERE strike_id=%d AND user_id=%d AND status='pending'", $strike_id, $user_id));
        if ($pending) { wp_safe_redirect(add_query_arg('appeal_status','pending', wp_get_referer() ?: home_url('/account-standing/'))); exit; }
        $wpdb->insert($this->user_strike_appeals_table(), ['strike_id'=>$strike_id,'user_id'=>$user_id,'explanation'=>$explanation,'status'=>'pending','submitted_at'=>current_time('mysql',true)], ['%d','%d','%s','%s','%s']);
        if ($wpdb->insert_id) $this->send_strike_system_message($user_id, 'Your strike appeal was received', 'We have received your appeal for strike #' . $strike_id . '. The PhiskVideos team will review it and send you a decision through Messages.');
        wp_safe_redirect(add_query_arg('appeal_status', $wpdb->insert_id ? 'submitted' : 'error', wp_get_referer() ?: home_url('/account-standing/'))); exit;
    }

    public function user_strike_appeal_shortcode() {
        if (!is_user_logged_in()) return '<section><h2>Account Standing</h2><p>Please log in to view your account standing.</p></section>';
        global $wpdb; $user_id = get_current_user_id();
        $this->recalculate_user_strike_enforcement($user_id, true);
        $strikes = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$this->user_strike_table()} WHERE user_id=%d ORDER BY issued_at DESC,id DESC LIMIT 20", $user_id));
        $count = (int)get_user_meta($user_id, '_phisk_active_strike_count', true);
        $url = get_permalink();
        ob_start();
        echo '<section class="phisk-account-standing" style="max-width:820px;margin:24px auto"><h1>Account Standing</h1><p>Active strikes: <strong>'.absint($count).' of 3</strong>. Each strike expires 90 days after it is issued unless revoked earlier.</p>';
        if (isset($_GET['appeal_status'])) { $status=sanitize_key(wp_unslash($_GET['appeal_status'])); $msg=$status==='submitted'?'Your appeal has been submitted. We will send our decision through Messages.':($status==='pending'?'An appeal for this strike is already awaiting review.':($status==='invalid'?'Please choose an active strike and provide an explanation of at least 20 characters.':'We could not submit your appeal. Please try again.')); echo '<p role="status">'.esc_html($msg).'</p>'; }
        if (get_user_meta($user_id, '_phisk_strike_monetization_paused', true)) echo '<p><strong>Monetization:</strong> Temporarily paused due to active strikes.</p>';
        if (get_user_meta($user_id, '_phisk_strike_channel_restricted', true)) echo '<p><strong>Creator access:</strong> Your channel is disabled. Your content data is preserved. You may appeal an active strike below.</p>';
        if (!$strikes) echo '<p>You have no strike history.</p>';
        foreach ((array)$strikes as $st) {
            echo '<article style="border:1px solid #ddd;padding:14px;margin:12px 0"><strong>Strike #'.absint($st->id).' — '.esc_html(ucwords(str_replace('_',' ',$st->category))).'</strong><p>'.nl2br(esc_html($st->reason)).'</p><small>Status: '.esc_html($st->status).' · Issued: '.esc_html($st->issued_at).' UTC · Expires: '.esc_html($st->expires_at).' UTC</small>';
            if ($st->status === 'active') {
                $pending=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$this->user_strike_appeals_table()} WHERE strike_id=%d AND user_id=%d AND status='pending'", $st->id, $user_id));
                if ($pending) echo '<p>Your appeal for this strike is awaiting review.</p>';
                else { echo '<form method="post" action="'.esc_url($url).'" style="margin-top:12px">'; wp_nonce_field('phisk_strike_appeal_submit','phisk_strike_appeal_nonce'); echo '<input type="hidden" name="phisk_strike_appeal_submit" value="1"><input type="hidden" name="strike_id" value="'.absint($st->id).'"><label><strong>Appeal this strike</strong><textarea name="appeal_explanation" rows="4" minlength="20" required style="display:block;width:100%;margin:8px 0" placeholder="Explain why you believe this strike should be reviewed."></textarea></label><button type="submit">Submit Appeal</button></form>'; }
            }
            echo '</article>';
        }
        echo '</section>';
        return ob_get_clean();
    }

    public function register_admin_messages_menu() {
        add_submenu_page('options-general.php', 'Phisk Admin Messages', 'Phisk Messages', 'manage_options', 'phisk-admin-messages', [$this, 'admin_messages_admin_page']);
    }

    public function handle_admin_message_submission() {
        if (!is_admin() || empty($_POST['phisk_admin_message_send'])) return;
        if (!current_user_can('manage_options')) wp_die('You do not have permission to send Phisk messages.');
        check_admin_referer('phisk_admin_message_send', 'phisk_admin_message_nonce');
        $user_id = absint($_POST['recipient_user_id'] ?? 0);
        $subject = sanitize_text_field(wp_unslash($_POST['message_subject'] ?? ''));
        $message = sanitize_textarea_field(wp_unslash($_POST['message_body'] ?? ''));
        if (!$user_id || !get_userdata($user_id) || $subject === '' || $message === '') {
            wp_safe_redirect(add_query_arg(['page'=>'phisk-admin-messages','sent'=>'invalid'], admin_url('options-general.php'))); exit;
        }
        global $wpdb;
        $wpdb->insert($this->admin_messages_table(), ['user_id'=>$user_id,'sender_id'=>get_current_user_id(),'subject'=>$subject,'message'=>$message,'is_read'=>0,'created_at'=>current_time('mysql',true)], ['%d','%d','%s','%s','%d','%s']);
        $message_id = (int) $wpdb->insert_id;
        $status = $message_id ? '1' : 'error';
        if ($message_id) {
            $this->create_admin_message_notification($user_id, $message_id, $subject);
            $wpdb->query($wpdb->prepare('DELETE FROM ' . $this->admin_messages_table() . ' WHERE user_id=%d AND id NOT IN (SELECT id FROM (SELECT id FROM ' . $this->admin_messages_table() . ' WHERE user_id=%d ORDER BY created_at DESC,id DESC LIMIT 10) AS phisk_latest_messages)', $user_id, $user_id));
        }
        wp_safe_redirect(add_query_arg(['page'=>'phisk-admin-messages','sent'=>$status], admin_url('options-general.php'))); exit;
    }

    public function admin_messages_admin_page() {
        if (!current_user_can('manage_options')) return;
        $users = get_users(['orderby'=>'display_name','order'=>'ASC','number'=>1000,'fields'=>['ID','display_name','user_email','user_login']]);
        echo '<div class="wrap"><h1>Phisk Messages</h1><p>Send a message from the Phisk administration team to one user. Messages appear in that user’s PhiskVideos inbox.</p>';
        if (isset($_GET['sent'])) { $sent=sanitize_key(wp_unslash($_GET['sent'])); echo '<div class="notice notice-'.($sent==='1'?'success':'warning').' is-dismissible"><p>'.($sent==='1'?'Message sent.':($sent==='invalid'?'Please select a user and enter both a subject and message.':'The message could not be saved.')).'</p></div>'; }
        echo '<form method="post" style="max-width:720px;background:#fff;padding:20px;border:1px solid #ddd;border-radius:8px">'; wp_nonce_field('phisk_admin_message_send','phisk_admin_message_nonce'); echo '<input type="hidden" name="phisk_admin_message_send" value="1"><p><label for="phisk-message-recipient"><strong>Recipient</strong></label><br><select id="phisk-message-recipient" name="recipient_user_id" required style="width:100%;max-width:560px"><option value="">Choose a user…</option>';
        foreach($users as $user) echo '<option value="'.absint($user->ID).'">'.esc_html($user->display_name.' (@'.$user->user_login.') — '.$user->user_email).'</option>';
        echo '</select></p><p><label for="phisk-message-subject"><strong>Subject</strong></label><br><input id="phisk-message-subject" type="text" name="message_subject" maxlength="190" required style="width:100%;max-width:560px"></p><p><label for="phisk-message-body"><strong>Message</strong></label><br><textarea id="phisk-message-body" name="message_body" rows="6" required style="width:100%;max-width:560px"></textarea></p><p><button class="button button-primary">Send Message</button></p></form></div>';
    }

    public function handle_admin_message_open_action() {
        if (!is_user_logged_in() || empty($_GET['phisk_message_open'])) return;
        $id=absint($_GET['phisk_message_open']);
        if (!$id || !wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'] ?? '')), 'phisk_message_open_' . $id)) return;
        global $wpdb; $row=$wpdb->get_row($wpdb->prepare('SELECT id FROM ' . $this->admin_messages_table() . ' WHERE id=%d AND user_id=%d', $id, get_current_user_id()));
        if (!$row) return;
        $wpdb->update($this->admin_messages_table(), ['is_read'=>1], ['id'=>$id,'user_id'=>get_current_user_id()], ['%d'], ['%d','%d']);
        $url=get_permalink(get_option('phiskvideos_messages_page_id')) ?: home_url('/phisk-messages/');
        wp_safe_redirect($url); exit;
    }

    public function admin_messages_inbox_shortcode() {
        $this->enqueue_style();
        if (!is_user_logged_in()) return '<section class="phisk-dashboard-login"><h2>Messages</h2><p>Please log in to view your messages.</p></section>';
        global $wpdb; $this->ensure_notification_tables(); $uid=get_current_user_id();
        $rows=$wpdb->get_results($wpdb->prepare('SELECT id,subject,message,is_read,created_at FROM ' . $this->admin_messages_table() . ' WHERE user_id=%d ORDER BY created_at DESC,id DESC LIMIT 10', $uid));
        $notifications_url=get_permalink(get_option('phiskvideos_notifications_page_id')) ?: home_url('/phisk-notifications/');
        ob_start(); ?>
        <section class="phisk-notifications-inbox phisk-user-dashboard"><style>
        .phisk-messages-list{display:block!important;width:100%!important;max-width:100%!important;min-width:0!important;box-sizing:border-box!important;border-top:1px solid #e5e5e5;overflow:visible!important}
        .phisk-messages-empty{padding:24px 18px;text-align:center;background:#f7f7f8;border-radius:10px;color:#555}.phisk-messages-empty .phisk-empty-mascot{display:block;width:130px;height:130px;max-width:100%;object-fit:contain;margin:0 auto 10px}
        .phisk-admin-message-item{display:flex!important;flex-direction:row!important;align-items:flex-start!important;gap:12px!important;width:100%!important;min-width:0!important;max-width:100%!important;box-sizing:border-box!important;padding:16px 12px!important;border:0!important;border-bottom:1px solid #e5e5e5!important;border-radius:0!important;background:transparent!important;color:#171717!important;text-decoration:none!important;overflow:visible!important;writing-mode:horizontal-tb!important;text-orientation:mixed!important}
        .phisk-admin-message-item.is-unread{background:#f3edff!important}.phisk-admin-message-item>.phisk-notification-dot{display:block!important;flex:0 0 8px!important;width:8px!important;min-width:8px!important;height:8px!important;border-radius:50%;background:#7C3AED;margin-top:8px}
        .phisk-admin-message-copy{display:block!important;flex:1 1 auto!important;min-width:0!important;width:calc(100% - 20px)!important;max-width:100%!important;box-sizing:border-box!important;overflow:visible!important;writing-mode:horizontal-tb!important;text-orientation:mixed!important;white-space:normal!important;overflow-wrap:anywhere!important;word-break:normal!important;float:none!important;position:static!important}
        .phisk-admin-message-copy strong{display:block!important;width:100%!important;max-width:100%!important;margin:0 0 8px!important;white-space:normal!important;overflow-wrap:anywhere!important;word-break:normal!important;text-decoration:none!important;writing-mode:horizontal-tb!important}
        .phisk-message-open-link{display:inline!important;color:inherit!important;font:inherit!important;font-weight:700!important;text-decoration:none!important;white-space:normal!important;overflow-wrap:anywhere!important}
        .phisk-admin-message-body{display:block!important;position:static!important;float:none!important;clear:both!important;width:100%!important;min-width:0!important;max-width:100%!important;margin:0!important;padding:0!important;box-sizing:border-box!important;background:transparent!important;color:inherit!important;white-space:normal!important;overflow-wrap:anywhere!important;word-break:normal!important;text-decoration:none!important;writing-mode:horizontal-tb!important;text-orientation:mixed!important;line-height:1.55!important;letter-spacing:normal!important}
        .phisk-admin-message-body p{display:block!important;position:static!important;float:none!important;clear:both!important;width:100%!important;min-width:0!important;max-width:100%!important;margin:0 0 10px!important;padding:0!important;box-sizing:border-box!important;background:transparent!important;color:inherit!important;line-height:1.55!important;white-space:normal!important;overflow-wrap:anywhere!important;word-break:normal!important;text-decoration:none!important;writing-mode:horizontal-tb!important}
        .phisk-admin-message-body a{display:inline!important;width:auto!important;max-width:100%!important;white-space:normal!important;overflow-wrap:anywhere!important;word-break:normal!important;text-decoration:underline!important}
        .phisk-admin-message-body .phisk-appeal-action{display:inline-flex!important;align-items:center!important;justify-content:center!important;width:auto!important;max-width:100%!important;min-height:42px!important;margin:4px 0 8px!important;padding:10px 17px!important;box-sizing:border-box!important;border:0!important;border-radius:5px!important;background:#7C3AED!important;color:#fff!important;font-size:14px!important;font-weight:700!important;line-height:1.25!important;text-align:center!important;text-decoration:none!important;white-space:normal!important;overflow-wrap:anywhere!important}
        .phisk-admin-message-copy time{display:block!important;width:auto!important;margin-top:7px!important;font-size:12px;opacity:.65;text-decoration:none!important}
        .phisk-admin-message-item *{writing-mode:horizontal-tb!important;text-orientation:mixed!important;max-inline-size:100%!important}
        @media(max-width:600px){.phisk-admin-message-item{gap:10px!important;padding:14px 8px!important}.phisk-admin-message-copy{flex:1 1 auto!important;width:calc(100% - 18px)!important;min-width:0!important;max-width:100%!important}.phisk-admin-message-body,.phisk-admin-message-body p{width:100%!important;min-width:0!important;max-width:100%!important;white-space:normal!important;overflow-wrap:anywhere!important;word-break:normal!important}.phisk-admin-message-body .phisk-appeal-action{min-height:40px!important}}
        @media(prefers-color-scheme:dark){.phisk-admin-message-item{background:#242424!important;color:#f5f5f5!important}.phisk-admin-message-item.is-unread{background:#302443!important}}
        </style>
        <nav class="phisk-inbox-tabs" aria-label="Inbox sections" style="display:flex;gap:18px;margin-bottom:18px;border-bottom:1px solid #e5e5e5;padding-bottom:10px"><a href="<?php echo esc_url($notifications_url); ?>" style="color:inherit;text-decoration:none">Notifications</a><a href="<?php echo esc_url(get_permalink(get_option('phiskvideos_messages_page_id')) ?: home_url('/phisk-messages/')); ?>" aria-current="page" style="font-weight:700;color:#7C3AED;text-decoration:none">Messages</a></nav>
        <header class="phisk-notifications-head"><div><h1>Messages</h1><p>Messages sent to you by the Phisk administration team.</p></div></header>
        <?php if (!$rows) : ?>
            <div class="phisk-messages-empty"><img class="phisk-empty-mascot" src="<?php echo esc_url(plugins_url('assets/phisk-mascot-empty-state.webp', __FILE__)); ?>" width="130" height="130" alt="Purple Phisk mascot reading a newspaper" loading="lazy" decoding="async"><p>You don't have any messages yet.</p></div>
        <?php else : ?>
            <div class="phisk-messages-list">
            <?php foreach ($rows as $row) :
                $open_url = add_query_arg(['phisk_message_open'=>$row->id,'_wpnonce'=>wp_create_nonce('phisk_message_open_' . $row->id)], get_permalink(get_option('phiskvideos_messages_page_id')) ?: home_url('/phisk-messages/'));
                // Older strike messages stored literal backslash-n sequences; normalize them for display.
                $message_text = str_replace(["\\r\\n", "\\n", "\\r"], "\n", (string)$row->message);
                $message_html = '';
                if ($row->subject === 'PhiskVideos account strike issued') {
                    $appeal_url = '';
                    if (preg_match('~https?://[^\s<>]+~i', $message_text, $url_match)) {
                        $appeal_url = rtrim($url_match[0], '.,;:)');
                        $message_text = str_replace($url_match[0], '', $message_text);
                    }
                    $message_html = wpautop(esc_html(trim($message_text)));
                    if ($appeal_url && wp_http_validate_url($appeal_url)) {
                        $message_html .= '<p><a class="phisk-appeal-action" href="' . esc_url($appeal_url) . '">View account standing &amp; appeal</a></p>';
                    }
                } else {
                    $message_html = wpautop(make_clickable(esc_html($message_text)));
                }
            ?>
                <div class="phisk-admin-message-item <?php echo $row->is_read ? 'is-read' : 'is-unread'; ?>">
                    <span class="phisk-notification-dot" aria-hidden="true"></span>
                    <div class="phisk-admin-message-copy">
                        <strong><a class="phisk-message-open-link" href="<?php echo esc_url($open_url); ?>"><?php echo esc_html($row->subject); ?></a></strong>
                        <div class="phisk-admin-message-body"><?php echo wp_kses_post($message_html); ?></div>
                        <time datetime="<?php echo esc_attr(mysql2date('c',$row->created_at,true)); ?>"><?php echo esc_html(human_time_diff(strtotime($row->created_at . ' UTC'), current_time('timestamp', true)) . ' ago'); ?></time>
                    </div>
                </div>
            <?php endforeach; ?>
            </div>
        <?php endif; ?>
        </section>
        <?php return ob_get_clean();
    }

    public function activate() {
        $this->ensure_monetization_tables();
        $this->ensure_notification_tables();
        $this->ensure_user_strike_tables();
        $this->register_content();
        $this->ensure_dashboard_page();
        $this->ensure_creator_pages();
        flush_rewrite_rules();
    }
    public function deactivate() { flush_rewrite_rules(); }

    /**
     * Updating a plugin does not run the activation hook. Flush once when the
     * installed plugin version changes so new CPT rewrite slugs (including
     * Movie, TV, and Video URLs become available immediately instead of returning a 404.
     */
    public function maybe_flush_rewrites() {
        $stored = get_option('phiskvideos_rewrite_version');
        if ($stored !== self::VERSION) {
            flush_rewrite_rules(false);
            update_option('phiskvideos_rewrite_version', self::VERSION, false);
            $this->ensure_dashboard_page();
            $this->ensure_creator_pages();
        }
    }

    /**
     * Ensure there is one public Phisk dashboard/profile page that can be used
     * as the destination for creator links in video feeds.
     */
    private function ensure_dashboard_page() {
        $existing = get_pages([
            'post_type' => 'page',
            'post_status' => ['publish', 'draft', 'private'],
            'number' => 100,
        ]);
        foreach ($existing as $page) {
            if (has_shortcode($page->post_content, 'phisk_user_dashboard')) {
                // Keep the existing profile page, but always use "Channel" as
                // its public WordPress page title. This also fixes sites where
                // an earlier version created the page as "Phisk Dashboard".
                if ($page->post_title !== 'Channel') {
                    wp_update_post([
                        'ID' => (int)$page->ID,
                        'post_title' => 'Channel',
                    ]);
                }
                update_option('phiskvideos_dashboard_page_id', (int)$page->ID, false);
                return (int)$page->ID;
            }
        }

        $page_id = wp_insert_post([
            'post_title'   => 'Channel',
            'post_name'    => 'phisk-dashboard',
            'post_content' => '[phisk_user_dashboard]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
        ], true);
        if (!is_wp_error($page_id) && $page_id) {
            update_option('phiskvideos_dashboard_page_id', (int)$page_id, false);
            return (int)$page_id;
        }
        return 0;
    }

    /**
     * Return the public Phisk profile/dashboard URL for a WordPress user.
     */
    private function phisk_user_dashboard_url($user_id) {
        $user_id = absint($user_id);
        if (!$user_id || !get_userdata($user_id)) return home_url('/');
        $page_id = absint(get_option('phiskvideos_dashboard_page_id'));
        if (!$page_id) $page_id = $this->ensure_dashboard_page();
        // Public profile links use the stable WordPress nicename as a clean root-level slug.
        $user = get_userdata($user_id);
        if ($user && !empty($user->user_nicename)) {
            return home_url('/' . rawurlencode($user->user_nicename) . '/');
        }
        $url = $page_id ? get_permalink($page_id) : home_url('/phisk-dashboard/');
        return add_query_arg(['phisk_profile_user' => $user_id], $url);
    }

    /**
     * Create or reuse dedicated frontend creator pages without overwriting existing page content.
     * Existing pages are discovered by shortcode, so updates do not create duplicates.
     */
    private function ensure_shortcode_page($shortcode, $title, $option_key, $slug) {
        $pages = get_pages(['post_type'=>'page', 'post_status'=>['publish','draft','private'], 'number'=>200]);
        foreach ($pages as $page) {
            if (has_shortcode($page->post_content, $shortcode)) {
                update_option($option_key, (int)$page->ID, false);
                return (int)$page->ID;
            }
        }
        $page_id = wp_insert_post([
            'post_title' => $title,
            'post_name' => $slug,
            'post_content' => '[' . $shortcode . ']',
            'post_status' => 'publish',
            'post_type' => 'page',
        ], true);
        if (!is_wp_error($page_id) && $page_id) {
            update_option($option_key, (int)$page_id, false);
            return (int)$page_id;
        }
        return 0;
    }

    private function ensure_creator_pages() {
        $this->ensure_shortcode_page('phisk_video_submit', 'Upload Video', 'phiskvideos_upload_page_id', 'upload-video');
        $this->ensure_shortcode_page('phisk_article_submit', 'Write a Story', 'phiskvideos_article_submit_page_id', 'write-article');
        $this->ensure_shortcode_page('phisk_creator_studio', 'Creator Studio', 'phiskvideos_creator_studio_page_id', 'creator-studio');
        $this->ensure_shortcode_page('phisk_account_settings', 'Settings', 'phiskvideos_settings_page_id', 'settings');
        $this->ensure_shortcode_page('phisk_notifications', 'Notifications', 'phiskvideos_notifications_page_id', 'phisk-notifications');
        $this->ensure_shortcode_page('phisk_messages', 'Messages', 'phiskvideos_messages_page_id', 'phisk-messages');
        $this->ensure_shortcode_page('phisk_strike_appeal', 'Account Standing', 'phiskvideos_strike_appeal_page_id', 'account-standing');
    }

    /** Return the dedicated frontend settings page URL. */
    private function account_settings_url() {
        $id = absint(get_option('phiskvideos_settings_page_id'));
        if (!$id || !get_post_status($id)) $id = $this->ensure_shortcode_page('phisk_account_settings', 'Settings', 'phiskvideos_settings_page_id', 'settings');
        $url = $id ? get_permalink($id) : home_url('/settings/');
        return $url ?: home_url('/settings/');
    }

    private function creator_page_url($option_key, $fallback_path) {
        $id = absint(get_option($option_key));
        if ($id && get_post_status($id)) {
            $url = get_permalink($id);
            if ($url) return $url;
        }
        return home_url('/' . trim($fallback_path, '/') . '/');
    }

    /**
     * New accounts start as members. Accounts that existed before this feature
     * and have no flag are treated as creators to preserve current access.
     */
    public function initialize_new_member_channel_state($user_id) {
        $user_id = absint($user_id);
        if (!$user_id) return;
        if (get_user_meta($user_id, 'phisk_has_channel', true) === '') {
            update_user_meta($user_id, 'phisk_has_channel', '0');
        }
        $user = get_userdata($user_id);
        if ($user && get_user_meta($user_id, 'phisk_personal_display_name', true) === '') {
            update_user_meta($user_id, 'phisk_personal_display_name', (string)($user->display_name ?: $user->user_login));
        }
    }

    /** Whether this account currently has creator-channel access. Legacy accounts remain enabled. */
    public function user_has_phisk_channel($user_id = 0) {
        $user_id = $user_id ? absint($user_id) : get_current_user_id();
        if (!$user_id || !get_userdata($user_id)) return false;
        if (user_can($user_id, 'manage_options')) return true;
        if (get_user_meta($user_id, '_phisk_strike_channel_restricted', true)) return false;
        $flag = get_user_meta($user_id, 'phisk_has_channel', true);
        return $flag === '' || (string)$flag === '1';
    }

    /** Return the member's personal display name without changing the WordPress username. */
    public function phisk_personal_display_name($user_id) {
        $user_id = absint($user_id);
        $user = $user_id ? get_userdata($user_id) : false;
        if (!$user) return 'Phisk member';
        $name = get_user_meta($user_id, 'phisk_personal_display_name', true);
        return (string)($name !== '' ? $name : ($user->display_name ?: $user->user_login));
    }

    /** Resolve the name shown when an account is acting as a creator. */
    public function phisk_creator_display_name($user_id) {
        $user_id = absint($user_id);
        $user = $user_id ? get_userdata($user_id) : false;
        if (!$user) return 'Phisk member';
        if (!$this->user_has_phisk_channel($user_id)) return $this->phisk_personal_display_name($user_id);
        $channel_name = get_user_meta($user_id, 'phisk_channel_name', true);
        return (string)($channel_name !== '' ? $channel_name : ($user->display_name ?: $user->user_login));
    }

    /** Reusable channel creation gate shown on creator-only pages. */
    private function channel_creation_gate($title = 'Create a Channel to use this page') {
        if (!is_user_logged_in()) return '<section class="phisk-channel-gate"><h2>' . esc_html($title) . '</h2><p>Please log in to create a channel.</p></section>';
        $user_id = get_current_user_id();
        $this->recalculate_user_strike_enforcement($user_id, true);
        if ($this->user_has_phisk_channel($user_id)) return '';
        if (get_user_meta($user_id, '_phisk_strike_channel_restricted', true)) {
            $appeal_url = get_permalink(absint(get_option('phiskvideos_strike_appeal_page_id'))) ?: home_url('/account-standing/');
            return '<section class="phisk-channel-gate"><h2>Creator access temporarily restricted</h2><p>Your channel has been disabled under the PhiskVideos three-strike policy. Your channel and content data are preserved. You cannot create another channel while this restriction is active.</p><p><a href="' . esc_url($appeal_url) . '">View account standing or submit an appeal</a></p></section>';
        }
        $error = isset($_GET['phisk_channel_error']) ? sanitize_text_field(wp_unslash($_GET['phisk_channel_error'])) : '';
        $message = isset($_GET['phisk_channel_message']) ? sanitize_text_field(wp_unslash($_GET['phisk_channel_message'])) : '';
        $return_url = wp_get_referer() ?: (is_singular() ? get_permalink() : home_url('/'));
        if (isset($_SERVER['REQUEST_URI'])) $return_url = home_url(wp_unslash($_SERVER['REQUEST_URI']));
        $return_url = wp_validate_redirect($return_url, home_url('/'));
        ob_start(); ?>
        <section class="phisk-channel-gate" style="max-width:720px;margin:36px auto;padding:28px 22px;text-align:center;border-radius:14px;background:rgba(127,127,127,.08)">
          <h2><?php echo esc_html($title); ?></h2>
          <p>Create a channel to upload videos, publish Stories, and use Creator Studio. You can keep using PhiskVideos to watch, like, and comment without a channel.</p>
          <?php if ($error) : ?><p role="alert" style="color:#c62828"><?php echo esc_html($error); ?></p><?php endif; ?>
          <?php if ($message) : ?><p role="status"><?php echo esc_html($message); ?></p><?php endif; ?>
          <form method="post" class="phisk-create-channel-form" style="max-width:440px;margin:22px auto 0;text-align:left;display:grid;gap:12px">
            <?php wp_nonce_field('phisk_create_channel', 'phisk_create_channel_nonce'); ?>
            <input type="hidden" name="phisk_create_channel_submit" value="1">
            <input type="hidden" name="phisk_channel_return_url" value="<?php echo esc_url($return_url); ?>">
            <label for="phisk-new-channel-name"><strong>Channel name</strong></label>
            <input id="phisk-new-channel-name" type="text" name="phisk_new_channel_name" maxlength="30" required autocomplete="organization" placeholder="Choose a name for your channel" style="box-sizing:border-box;width:100%;padding:12px;border:1px solid #aaa;border-radius:8px;background:transparent;color:inherit">
            <small>Maximum 30 characters. Your personal profile name and username will remain unchanged.</small>
            <button type="submit" style="justify-self:start;padding:11px 18px;border:0;border-radius:7px;background:#111;color:#fff;font-weight:700;cursor:pointer">Create Channel</button>
          </form>
        </section>
        <?php return ob_get_clean();
    }

    /** Create a channel only after an explicit, nonce-protected user action. */
    public function handle_channel_creation() {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || empty($_POST['phisk_create_channel_submit'])) return;
        if (!is_user_logged_in()) wp_die('Please log in before creating a channel.');
        $return_url = isset($_POST['phisk_channel_return_url']) ? wp_validate_redirect(esc_url_raw(wp_unslash($_POST['phisk_channel_return_url'])), home_url('/')) : home_url('/');
        if (!isset($_POST['phisk_create_channel_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['phisk_create_channel_nonce'])), 'phisk_create_channel')) {
            wp_safe_redirect(add_query_arg('phisk_channel_error', 'Security check failed. Please try again.', $return_url)); exit;
        }
        $user_id = get_current_user_id();
        $this->recalculate_user_strike_enforcement($user_id, true);
        if (get_user_meta($user_id, '_phisk_strike_channel_restricted', true)) {
            wp_safe_redirect(add_query_arg('phisk_channel_error', 'Your channel is disabled under the PhiskVideos strike policy. You cannot create another channel while the restriction is active.', $return_url)); exit;
        }
        if ($this->user_has_phisk_channel($user_id)) {
            wp_safe_redirect($return_url); exit;
        }
        $name = isset($_POST['phisk_new_channel_name']) ? sanitize_text_field(wp_unslash($_POST['phisk_new_channel_name'])) : '';
        $length = function_exists('mb_strlen') ? mb_strlen($name, 'UTF-8') : strlen($name);
        if ($name === '' || $length > 30) {
            wp_safe_redirect(add_query_arg('phisk_channel_error', 'Please enter a channel name of 1 to 30 characters.', $return_url)); exit;
        }
        $user = get_userdata($user_id);
        if (!$user) wp_die('Your account could not be found.');
        if (get_user_meta($user_id, 'phisk_personal_display_name', true) === '') {
            update_user_meta($user_id, 'phisk_personal_display_name', (string)($user->display_name ?: $user->user_login));
        }
        update_user_meta($user_id, 'phisk_channel_name', $name);
        update_user_meta($user_id, 'phisk_has_channel', '1');
        update_user_meta($user_id, 'phisk_channel_name_history', []);
        update_user_meta($user_id, 'phisk_channel_created_at', time());
        delete_user_meta($user_id, 'phisk_channel_name_last_changed');
        wp_safe_redirect(add_query_arg('phisk_channel_message', 'Your channel has been created. You can now use creator features.', $return_url));
        exit;
    }

    /** Use personal names for members and channel names for creators in Story/video bylines. */
    public function filter_phisk_author_display_name($display_name, $user_id = 0) {
        global $post;
        if (!$user_id && $post instanceof WP_Post) $user_id = (int)$post->post_author;
        if (!$user_id || !($post instanceof WP_Post) || !in_array($post->post_type, ['phisk_video', 'post'], true)) return $display_name;
        return $this->phisk_creator_display_name($user_id);
    }

    /** Set the displayed author name for video and Story comments. */
    public function filter_phisk_comment_author_name($commentdata) {
        if (!is_user_logged_in() || !is_array($commentdata)) return $commentdata;
        $post_id = absint($commentdata['comment_post_ID'] ?? 0);
        $post = $post_id ? get_post($post_id) : false;
        if (!$post || !in_array($post->post_type, ['phisk_video', 'post'], true)) return $commentdata;
        $commentdata['comment_author'] = $this->phisk_creator_display_name(get_current_user_id());
        $commentdata['user_id'] = get_current_user_id();
        return $commentdata;
    }

    /** Public channel URL helper for front-end templates. */
    public function phisk_channel_url($user_id) {
        return $this->phisk_user_dashboard_url($user_id);
    }

    /**
     * Keep single Video URLs working even when a site already has a page
     * using the /videos path. The explicit rule targets the Video CPT query
     * and is refreshed automatically with the plugin rewrite version.
     */
    public function register_video_rewrite_rules() {
        // Use the standard WordPress post_type/name query instead of the CPT
        // query_var. This is more reliable when another page or stale rewrite
        // rules are already using the /videos path.
        add_rewrite_rule('^videos/([^/]+)/?$', 'index.php?post_type=phisk_video&name=$matches[1]', 'top');
        add_rewrite_rule('^phisk-embed/([0-9]+)/?$', 'index.php?phisk_embed=$matches[1]', 'top');
        // Last-resort single-segment route: only resolves to a profile when normal WordPress
        // page/post rules did not claim the path and the slug matches a real user nicename.
        add_rewrite_rule('^([^/]+)/?$', 'index.php?phisk_profile_slug=$matches[1]', 'bottom');
    }

    /** Register the query variable used by compact, third-party video embeds. */
    public function register_embed_query_var($vars) {
        $vars[] = 'phisk_embed';
        $vars[] = 'phisk_profile_slug';
        $vars[] = 'phisk_profile_user';
        return $vars;
    }

    /** Render a lightweight, responsive standalone embed page for a published video. */
    public function render_video_embed_page() {
        $video_id = absint(get_query_var('phisk_embed'));
        if (!$video_id) return;
        $post = get_post($video_id);
        if (!$post || $post->post_type !== 'phisk_video' || $post->post_status !== 'publish') {
            status_header(404);
            nocache_headers();
            wp_die('This PhiskVideos video is unavailable.', 'Video unavailable', ['response' => 404]);
        }

        $title = get_the_title($video_id);
        $permalink = get_permalink($video_id);
        $author_id = (int) $post->post_author;
        $author = $this->phisk_creator_display_name($author_id);
        $avatar_id = absint(get_user_meta($author_id, 'phisk_profile_image_id', true));
        $avatar = $avatar_id ? wp_get_attachment_image_url($avatar_id, 'thumbnail') : '';
        if (!$avatar) $avatar = get_avatar_url($author_id, ['size' => 80]);
        $published = get_the_date(get_option('date_format'), $video_id);
        $poster = get_the_post_thumbnail_url($video_id, 'large');
        $data = $this->video_provider_data($video_id);
        $provider = isset($data['provider']) ? (string) $data['provider'] : '';
        $source = isset($data['source_url']) ? (string) $data['source_url'] : '';
        $player = '';

        if ($provider === 'youtube_embed') {
            $youtube_id = (string) get_post_meta($video_id, '_phisk_youtube_video_id', true);
            if (preg_match('/^[A-Za-z0-9_-]{11}$/', $youtube_id)) {
                $player = '<iframe class="phisk-embed-youtube" src="https://www.youtube-nocookie.com/embed/' . esc_attr($youtube_id) . '?rel=0" title="' . esc_attr($title) . '" loading="lazy" referrerpolicy="strict-origin-when-cross-origin" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>';
            }
        } elseif ($source && wp_http_validate_url($source)) {
            $poster_attr = $poster ? ' poster="' . esc_url($poster) . '"' : '';
            $player = '<video controls playsinline preload="metadata"' . $poster_attr . '><source src="' . esc_url($source) . '"></video>';
            if ($provider === 'cloudflare_stream') {
                $player .= '<script src="https://cdn.jsdelivr.net/npm/hls.js@1.5.18/dist/hls.min.js"></script><script>(function(){var v=document.querySelector(".phisk-embed-player video"),src=' . wp_json_encode($source) . ';if(!v)return;if(v.canPlayType("application/vnd.apple.mpegurl")){v.src=src;}else if(window.Hls&&window.Hls.isSupported()){var h=new Hls({enableWorker:true});h.loadSource(src);h.attachMedia(v);}})();</script>';
            }
        }
        if (!$player) $player = '<div class="phisk-embed-unavailable">This video cannot be embedded right now. <a href="' . esc_url($permalink) . '" target="_blank" rel="noopener noreferrer">Watch on PhiskVideos</a></div>';

        nocache_headers();
        header('Content-Type: text/html; charset=' . get_bloginfo('charset'));
        echo '<!doctype html><html lang="' . esc_attr(get_bloginfo('language')) . '"><head><meta charset="' . esc_attr(get_bloginfo('charset')) . '"><meta name="viewport" content="width=device-width, initial-scale=1"><title>' . esc_html($title) . ' - PhiskVideos</title><style>
        *{box-sizing:border-box}html,body{margin:0;padding:0;background:#fff;color:#17191d;font:14px/1.45 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif}.phisk-embed{width:100%;max-width:900px;margin:0 auto;background:#fff}.phisk-embed-player{position:relative;width:100%;aspect-ratio:16/9;background:#090909;overflow:hidden}.phisk-embed-player video,.phisk-embed-player iframe{display:block;width:100%;height:100%;position:absolute;inset:0;border:0;object-fit:contain}.phisk-embed-unavailable{padding:28px 16px;color:#555}.phisk-embed-unavailable a{color:#111;font-weight:700}.phisk-embed-meta{display:flex;gap:10px;align-items:center;padding:12px 14px 13px}.phisk-embed-avatar{width:38px;height:38px;border-radius:50%;object-fit:cover;flex:0 0 38px;background:#eee}.phisk-embed-copy{min-width:0;flex:1}.phisk-embed-title{display:block;font-size:15px;font-weight:750;line-height:1.35;color:#17191d;text-decoration:none;overflow-wrap:anywhere;margin:0 0 4px}.phisk-embed-byline{display:flex;flex-wrap:wrap;gap:5px;color:#777e88;font-size:12px}.phisk-embed-byline a{color:inherit;text-decoration:none}.phisk-embed-brand{align-self:flex-start;white-space:nowrap;font-size:11px;font-weight:800;color:#17191d;text-decoration:none;border:1px solid #e7e8eb;border-radius:999px;padding:6px 9px;margin-left:4px}.phisk-embed-brand:hover,.phisk-embed-title:hover{opacity:.75}@media(max-width:420px){.phisk-embed-meta{padding:10px;gap:8px}.phisk-embed-avatar{width:32px;height:32px;flex-basis:32px}.phisk-embed-title{font-size:13px}.phisk-embed-brand{font-size:10px;padding:5px 7px}}
        </style></head><body><main class="phisk-embed"><div class="phisk-embed-player">' . $player . '</div><div class="phisk-embed-meta"><img class="phisk-embed-avatar" src="' . esc_url($avatar) . '" alt="' . esc_attr($author) . '" loading="lazy"><div class="phisk-embed-copy"><a class="phisk-embed-title" href="' . esc_url($permalink) . '" target="_blank" rel="noopener noreferrer">' . esc_html($title) . '</a><div class="phisk-embed-byline"><a href="' . esc_url($this->phisk_channel_url($author_id)) . '" target="_blank" rel="noopener noreferrer">' . esc_html($author) . '</a><span>·</span><time>' . esc_html($published) . '</time></div></div><a class="phisk-embed-brand" href="' . esc_url($permalink) . '" target="_blank" rel="noopener noreferrer">Watch on PhiskVideos ↗</a></div></main></body></html>';
        exit;
    }

    /**
     * Last-resort resolver for installations that still have stale rewrite
     * rules after an update. It lets /videos/video-slug/ resolve directly to
     * the Video CPT without requiring the administrator to save Permalinks.
     */
    public function resolve_video_request($vars) {
        // The clean profile rewrite is deliberately a bottom-priority fallback, so existing
        // WordPress pages, posts, and registered content keep their normal URLs. WordPress's
        // generic page rule can still capture an unknown slug as pagename, so check that case too.
        $profile_slug = !empty($vars['phisk_profile_slug']) ? (string)$vars['phisk_profile_slug'] : '';
        if ($profile_slug === '' && !empty($vars['pagename']) && strpos((string)$vars['pagename'], '/') === false) {
            $candidate_page = get_page_by_path((string)$vars['pagename'], OBJECT, 'page');
            if (!$candidate_page) $profile_slug = (string)$vars['pagename'];
        }
        if ($profile_slug !== '') {
            $slug = sanitize_title($profile_slug);
            $user = $slug !== '' ? get_user_by('slug', $slug) : false;
            if ($user instanceof WP_User) {
                $page_id = absint(get_option('phiskvideos_dashboard_page_id'));
                if (!$page_id) $page_id = $this->ensure_dashboard_page();
                unset($vars['phisk_profile_slug']);
                $vars['phisk_profile_user'] = (int)$user->ID;
                if ($page_id) {
                    unset($vars['name'], $vars['pagename'], $vars['error']);
                    $vars['page_id'] = $page_id;
                }
                return $vars;
            }
            // Unknown single-segment URLs must remain normal WordPress 404s.
            unset($vars['phisk_profile_slug']);
        }
        if (!empty($vars['post_type']) || !empty($vars['name']) || !empty($vars['p']) || !empty($vars['page_id']) || !empty($vars['pagename'])) {
            $path = isset($vars['pagename']) ? trim((string)$vars['pagename'], '/') : '';
            if ($path !== '' && preg_match('#^videos/([^/]+)$#', $path, $match)) {
                $slug = sanitize_title(rawurldecode($match[1]));
                $video = get_page_by_path($slug, OBJECT, 'phisk_video');
                if ($video instanceof WP_Post) {
                    return ['post_type' => 'phisk_video', 'name' => $video->post_name];
                }
            }
            return $vars;
        }
        return $vars;
    }

    public function register_content() {
        $common = [
            'public' => true,
            'show_in_rest' => true,
            'has_archive' => true,
            'rewrite' => ['with_front' => false],
            'supports' => ['title', 'editor', 'thumbnail', 'excerpt', 'author', 'revisions', 'comments'],
            'menu_icon' => 'dashicons-format-video',
            'show_in_menu' => true,
        ];
        register_post_type('phisk_movie', array_merge($common, [
            'labels' => ['name' => 'Movies', 'singular_name' => 'Movie', 'add_new_item' => 'Add New Movie', 'edit_item' => 'Edit Movie', 'all_items' => 'All Movies'],
            'rewrite' => ['slug' => 'movies', 'with_front' => false],
        ]));
        register_post_type('phisk_tvshow', array_merge($common, [
            'labels' => ['name' => 'TV Shows', 'singular_name' => 'TV Show', 'add_new_item' => 'Add New TV Show', 'edit_item' => 'Edit TV Show', 'all_items' => 'All TV Shows'],
            'rewrite' => ['slug' => 'tv-shows', 'with_front' => false],
        ]));
        register_post_type('phisk_video', array_merge($common, [
            'labels' => ['name' => 'Videos', 'singular_name' => 'Video', 'add_new_item' => 'Add New Video', 'edit_item' => 'Edit Video', 'all_items' => 'All Videos'],
            'rewrite' => ['slug' => 'videos', 'with_front' => false],
            'publicly_queryable' => true, 'query_var' => 'phisk_video',
            'menu_icon' => 'dashicons-video-alt3',
        ]));
        register_post_type('phisk_report', [
            'labels' => [
                'name' => 'Reports', 'singular_name' => 'Report', 'all_items' => 'Reports',
                'edit_item' => 'View Report', 'menu_name' => 'Reports',
            ],
            'public' => false, 'show_ui' => true,
            'show_in_menu' => 'edit.php?post_type=phisk_video',
            'supports' => ['title'], 'capability_type' => 'post', 'map_meta_cap' => true,
        ]);

        register_post_type('phisk_person', [
            'labels' => ['name' => 'People', 'singular_name' => 'Person', 'add_new' => 'Add Person', 'add_new_item' => 'Add New Person', 'edit_item' => 'Edit Person', 'all_items' => 'All People'],
            'public' => false, 'show_ui' => true, 'show_in_menu' => 'edit.php?post_type=phisk_movie', 'show_in_rest' => true,
            'supports' => ['title', 'thumbnail'], 'menu_icon' => 'dashicons-groups',
        ]);
        // Movie/TV Genre taxonomy. Videos use a separate taxonomy.
        register_taxonomy('phisk_genre', ['phisk_movie', 'phisk_tvshow'], [
            'labels' => [
                'name' => 'Genres',
                'singular_name' => 'Genre',
                'search_items' => 'Search Genres',
                'all_items' => 'All Genres',
                'edit_item' => 'Edit Genre',
                'add_new_item' => 'Add New Genre',
                'menu_name' => 'Genres',
            ],
            'public' => true,
            'hierarchical' => true,
            'show_in_rest' => true,
            'show_admin_column' => true,
            'rewrite' => ['slug' => 'movie-genre'],
        ]);

        register_taxonomy('phisk_video_genre', ['phisk_video'], [
            'labels' => [
                'name' => 'Video Genres', 'singular_name' => 'Video Genre',
                'search_items' => 'Search Video Genres', 'all_items' => 'All Video Genres',
                'edit_item' => 'Edit Video Genre', 'add_new_item' => 'Add New Video Genre',
                'menu_name' => 'Video Genres',
            ],
            'public' => true, 'hierarchical' => true, 'show_in_rest' => true,
            'show_admin_column' => true, 'rewrite' => ['slug' => 'video-genre'],
        ]);
        register_taxonomy('phisk_country', ['phisk_movie', 'phisk_tvshow', 'phisk_video'], [
            'labels' => ['name' => 'Countries', 'singular_name' => 'Country', 'search_items' => 'Search Countries', 'all_items' => 'All Countries', 'edit_item' => 'Edit Country', 'add_new_item' => 'Add New Country', 'menu_name' => 'Countries'],
            'public' => true, 'hierarchical' => true, 'show_in_rest' => true, 'show_admin_column' => true,
            'rewrite' => ['slug' => 'country'],
        ]);
        register_taxonomy('phisk_interest', ['post'], [
            'labels' => ['name' => 'Interests', 'singular_name' => 'Interest', 'search_items' => 'Search Interests', 'all_items' => 'All Interests', 'edit_item' => 'Edit Interest', 'add_new_item' => 'Add New Interest', 'menu_name' => 'Interests'],
            'public' => true, 'hierarchical' => true, 'show_in_rest' => true, 'show_admin_column' => true,
            'rewrite' => ['slug' => 'interest'],
        ]);
    }

    public function seed_african_countries() {
        if (get_option('phisk_african_countries_seeded')) return;
        $countries = ['Algeria','Angola','Benin','Botswana','Burkina Faso','Burundi','Cabo Verde','Cameroon','Central African Republic','Chad','Comoros','Democratic Republic of the Congo','Republic of the Congo','Côte d’Ivoire','Djibouti','Egypt','Equatorial Guinea','Eritrea','Eswatini','Ethiopia','Gabon','Gambia','Ghana','Guinea','Guinea-Bissau','Kenya','Lesotho','Liberia','Libya','Madagascar','Malawi','Mali','Mauritania','Mauritius','Morocco','Mozambique','Namibia','Niger','Nigeria','Rwanda','São Tomé and Príncipe','Senegal','Seychelles','Sierra Leone','Somalia','South Africa','South Sudan','Sudan','Tanzania','Togo','Tunisia','Uganda','Zambia','Zimbabwe'];
        foreach ($countries as $country) {
            if (!term_exists($country, 'phisk_country')) wp_insert_term($country, 'phisk_country');
        }
        update_option('phisk_african_countries_seeded', 1, false);
    }

    /** Stamp the real publication time when a Story is first published or approved. */
    public function stamp_article_publication_time($new_status, $old_status, $post) {
        if (!$post || $post->post_type !== 'post' || $new_status !== 'publish' || $old_status === 'publish') return;
        update_post_meta($post->ID, '_phisk_article_published_at_gmt', gmdate('Y-m-d H:i:s'));
        if (!metadata_exists('post', $post->ID, '_phisk_article_upvotes')) update_post_meta($post->ID, '_phisk_article_upvotes', 0);
        delete_transient('phisk_top_stories_ids_24h');
    }

    public function seed_article_interests() {
        if (get_option('phisk_article_interests_seeded')) return;
        $interests = ['Technology','Sports','News','Business','Gaming','Entertainment','Education','Science','Health','Lifestyle','Politics','Travel','Food','Personal Stories'];
        foreach ($interests as $interest) if (!term_exists($interest, 'phisk_interest')) wp_insert_term($interest, 'phisk_interest');
        update_option('phisk_article_interests_seeded', 1, false);
    }

    public function seed_video_genres() {
        if (get_option('phiskvideos_video_genres_seeded') === self::VERSION) return;
        $genres = ['Entertainment','Comedy','Music','News','Sports','Documentary','Education','Lifestyle','Interview','Tutorial','Short Film','Technology','Faith','Drama','Other'];
        foreach ($genres as $genre) if (!term_exists($genre, 'phisk_video_genre')) wp_insert_term($genre, 'phisk_video_genre');
        update_option('phiskvideos_video_genres_seeded', self::VERSION, false);
    }

    private function frontend_people_from_lines($raw, $type) {
        $lines = preg_split('/\r\n|\r|\n/', (string)$raw);
        $out = [];
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '') continue;
            $parts = array_map('trim', explode('|', $line, 2));
            $name = sanitize_text_field($parts[0] ?? '');
            $role = sanitize_text_field($parts[1] ?? '');
            if ($name === '') continue;
            $existing = get_page_by_title($name, OBJECT, 'phisk_person');
            $pid = $existing ? $existing->ID : wp_insert_post(['post_type'=>'phisk_person','post_status'=>'publish','post_title'=>$name], true);
            if (is_wp_error($pid)) continue;
            $photo = get_the_post_thumbnail_url($pid, 'thumbnail') ?: get_post_meta($pid, 'phisk_person_photo', true);
            $out[] = ['person_id'=>(int)$pid, 'name'=>get_the_title($pid), 'role'=>$role, 'photo'=>$photo];
        }
        return $out;
    }

    /**
     * Movie/TV frontend submission flow.
     */
    public function handle_frontend_submission() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['phisk_front_submit'])) return;
        if (!is_user_logged_in() || !$this->user_has_phisk_channel(get_current_user_id())) $this->redirect_submission_result('error', 'Create a Channel to use this page.');
        if ($this->user_strike_blocks_publishing(get_current_user_id())) $this->redirect_submission_result('error', 'Publishing is restricted on your account. Visit Account Standing to review your strikes or appeal.');
        if (!isset($_POST['phisk_front_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['phisk_front_nonce'])), 'phisk_front_submit')) {
            $this->redirect_submission_result('error', 'Security check failed. Please try again.');
        }

        $kind = isset($_POST['phisk_content_type']) ? sanitize_key(wp_unslash($_POST['phisk_content_type'])) : 'movie';
        $type = in_array($kind, ['movie', 'tvshow'], true) ? 'phisk_' . $kind : 'phisk_movie';
        $title = isset($_POST['phisk_front_title']) ? sanitize_text_field(wp_unslash($_POST['phisk_front_title'])) : '';
        if ($title === '') $this->redirect_submission_result('error', 'Please enter a title.');

        $content = isset($_POST['phisk_front_content']) ? wp_kses_post(wp_unslash($_POST['phisk_front_content'])) : '';
        $post_id = wp_insert_post([
            'post_type' => $type,
            'post_status' => 'pending',
            'post_title' => $title,
            'post_content' => $content,
            'post_author' => get_current_user_id()
        ], true);
        if (is_wp_error($post_id)) $this->redirect_submission_result('error', $post_id->get_error_message());

        $fields = ['phisk_year','phisk_runtime','phisk_age_rating','phisk_watch_url','phisk_watch_label'];
        foreach ($fields as $key) {
            if (!isset($_POST[$key])) continue;
            $value = wp_unslash($_POST[$key]);
            $value = $key === 'phisk_watch_url' ? esc_url_raw($value) : sanitize_text_field($value);
            if ($value !== '') update_post_meta($post_id, $key, $value);
        }

        $country = isset($_POST['phisk_front_country']) ? sanitize_text_field(wp_unslash($_POST['phisk_front_country'])) : '';
        if ($country !== '') {
            update_post_meta($post_id, 'phisk_country', $country);
            $term = term_exists($country, 'phisk_country');
            if (!$term) $term = wp_insert_term($country, 'phisk_country');
            if (!is_wp_error($term)) {
                wp_set_post_terms($post_id, [(int)(is_array($term) ? $term['term_id'] : $term)], 'phisk_country', false);
            }
        }

        $genres = isset($_POST['phisk_front_genres']) && is_array($_POST['phisk_front_genres'])
            ? array_map('absint', wp_unslash($_POST['phisk_front_genres'])) : [];
        if ($genres) wp_set_post_terms($post_id, $genres, 'phisk_genre', false);

        $cast = $this->frontend_people_from_lines(isset($_POST['phisk_front_cast']) ? wp_unslash($_POST['phisk_front_cast']) : '', 'cast');
        $crew = $this->frontend_people_from_lines(isset($_POST['phisk_front_crew']) ? wp_unslash($_POST['phisk_front_crew']) : '', 'crew');
        if ($cast) update_post_meta($post_id, 'phisk_cast', $cast);
        if ($crew) update_post_meta($post_id, 'phisk_crew', $crew);

        if (!empty($_FILES['phisk_front_poster']['name']) && !empty($_FILES['phisk_front_poster']['tmp_name'])) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
            $attachment_id = media_handle_upload('phisk_front_poster', $post_id);
            if (!is_wp_error($attachment_id)) set_post_thumbnail($post_id, $attachment_id);
        }

        $this->redirect_submission_result('success', 'Thanks! Your submission has been received and is waiting for review.');
    }

    private function redirect_submission_result($status, $message) {
        $url = wp_get_referer() ?: home_url('/');
        $url = add_query_arg(['phisk_submit_status'=>$status,'phisk_submit_message'=>rawurlencode($message)], $url);
        wp_safe_redirect($url);
        exit;
    }

    private function redirect_video_submission_result($status, $message) {
        $url = wp_get_referer() ?: home_url('/');
        $url = add_query_arg(['phisk_video_submit_status'=>$status,'phisk_video_submit_message'=>rawurlencode($message)], $url);
        wp_safe_redirect($url);
        exit;
    }

    private function video_provider_data($post_id) {
        $provider = get_post_meta($post_id, '_phisk_video_provider', true) ?: 'wordpress';
        $source_url = get_post_meta($post_id, '_phisk_video_source_url', true);
        $source_id = get_post_meta($post_id, '_phisk_video_source_id', true);
        if ($provider === 'wordpress' && !$source_url) {
            $attachment_id = absint(get_post_meta($post_id, '_phisk_video_attachment_id', true));
            if ($attachment_id) $source_url = wp_get_attachment_url($attachment_id);
        }
        if ($provider === 'cloudflare_stream' && $source_id) {
            $source_url = 'https://videodelivery.net/' . rawurlencode((string)$source_id) . '/manifest/video.m3u8';
        }
        return ['provider'=>$provider, 'source_url'=>$source_url, 'source_id'=>$source_id];
    }

    public function handle_video_frontend_submission() {
        // The new video submission flow is AJAX-driven so the browser can show
        // upload progress and create a draft immediately after the video lands
        // in the site's own WordPress media library. Keep the legacy POST route
        // only for old forms/links that may still exist in cached pages.
        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['phisk_video_front_submit'])) return;
        if (!is_user_logged_in()) $this->redirect_video_submission_result('error', 'Please log in before submitting or editing a video.');
        if (!$this->user_has_phisk_channel(get_current_user_id())) $this->redirect_video_submission_result('error', 'Create a Channel to use this page.');
        if ($this->user_strike_blocks_publishing(get_current_user_id())) $this->redirect_video_submission_result('error', 'Publishing is restricted on your account. Visit Account Standing to review your strikes or appeal.');
        if (!isset($_POST['phisk_video_front_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['phisk_video_front_nonce'])), 'phisk_video_front_submit')) {
            $this->redirect_video_submission_result('error', 'Security check failed. Please try again.');
        }
        $this->redirect_video_submission_result('error', 'Please use the new step-by-step video uploader.');
    }

    /**
     * Enforce PhiskVideos' landscape upload policy before the file is sent to
     * WordPress Media Library or an external video host.
     *
     * Accepted aspect ratios are standard 16:9 and cinematic 21:9. A small
     * tolerance accommodates common encoder/display rounding differences.
     */
    private function phisk_validate_video_aspect_ratio($file_path) {
        if (!$file_path || !is_file($file_path) || !is_readable($file_path)) {
            return new WP_Error('phisk_video_dimensions_unavailable', 'We could not verify this video’s dimensions. Please try another video file.');
        }

        require_once ABSPATH . 'wp-admin/includes/media.php';
        if (!function_exists('wp_read_video_metadata')) {
            return new WP_Error('phisk_video_dimensions_unavailable', 'We could not verify this video’s dimensions on the server. Please try again later.');
        }

        $metadata = wp_read_video_metadata($file_path);
        $width = is_array($metadata) && isset($metadata['width']) ? (int) $metadata['width'] : 0;
        $height = is_array($metadata) && isset($metadata['height']) ? (int) $metadata['height'] : 0;

        if ($width < 1 || $height < 1) {
            return new WP_Error('phisk_video_dimensions_unavailable', 'PhiskVideos could not read this video’s dimensions. Please use a supported MP4, WebM, OGG, M4V or MOV file and try again.');
        }

        $ratio = $width / $height;
        $is_16_9 = abs($ratio - (16 / 9)) <= 0.06;
        $is_21_9 = abs($ratio - (21 / 9)) <= 0.08;

        if (!$is_16_9 && !$is_21_9) {
            return new WP_Error(
                'phisk_video_aspect_ratio_not_allowed',
                sprintf(
                    'This video format isn’t supported. PhiskVideos accepts landscape videos in 16:9 or 21:9 format only. Your video is %d × %d. Please upload a supported landscape video.',
                    $width,
                    $height
                )
            );
        }

        return true;
    }

    private function phisk_video_runtime_from_file($file) {
        if (!$file || !file_exists($file) || !function_exists('wp_read_video_metadata')) return ['seconds'=>0,'formatted'=>''];
        $meta = wp_read_video_metadata($file);
        if (!is_array($meta)) return ['seconds'=>0,'formatted'=>''];
        $seconds = isset($meta['length']) ? (float)$meta['length'] : 0;
        $formatted = !empty($meta['length_formatted']) ? (string)$meta['length_formatted'] : '';
        if (!$formatted && $seconds > 0) {
            $seconds_int = (int)round($seconds);
            $h = floor($seconds_int / 3600);
            $m = floor(($seconds_int % 3600) / 60);
            $sec = $seconds_int % 60;
            $formatted = $h > 0 ? sprintf('%d:%02d:%02d', $h, $m, $sec) : sprintf('%d:%02d', $m, $sec);
        }
        return ['seconds'=>(int)round($seconds),'formatted'=>$formatted];
    }

    public function ajax_upload_video_draft() {
        if (!is_user_logged_in()) wp_send_json_error(['message'=>'Please log in before uploading a video.'], 401);
        check_ajax_referer('phisk_video_upload_nonce', 'nonce');
        if (!$this->user_has_phisk_channel(get_current_user_id())) wp_send_json_error(['message'=>'Create a Channel to use this page.'], 403);
        if ($this->user_strike_blocks_publishing(get_current_user_id())) wp_send_json_error(['message'=>'Publishing is restricted on your account. Visit Account Standing to review your strikes or appeal.'], 403);
        if (empty($_FILES['video_file']) || empty($_FILES['video_file']['tmp_name'])) wp_send_json_error(['message'=>'Please select a video file.'], 400);

        $file = $_FILES['video_file'];
        $allowed_mimes = ['mp4'=>'video/mp4','m4v'=>'video/mp4','webm'=>'video/webm','ogv'=>'video/ogg','ogg'=>'video/ogg','mov'=>'video/quicktime'];
        $ext = strtolower(pathinfo((string)$file['name'], PATHINFO_EXTENSION));
        if (!isset($allowed_mimes[$ext])) wp_send_json_error(['message'=>'Unsupported video format. Please use MP4, WebM, OGG, M4V or MOV.'], 400);

        // Validate actual media dimensions before uploading to WordPress or Publitio.
        // This applies to both new uploads and replacement videos during editing.
        $aspect_validation = $this->phisk_validate_video_aspect_ratio($file['tmp_name']);
        if (is_wp_error($aspect_validation)) {
            wp_send_json_error(['message'=>$aspect_validation->get_error_message()], 400);
        }

        // When editing, update the existing post instead of creating a duplicate.
        $existing_id = isset($_POST['draft_id']) ? absint($_POST['draft_id']) : 0;
        $existing = $existing_id ? $this->phisk_owned_video_draft($existing_id) : null;
        if ($existing_id && !$existing) wp_send_json_error(['message'=>'That video could not be found or you do not have permission to edit it.'], 404);
        $is_edit = (bool)$existing;
        $title_from_file = sanitize_text_field(pathinfo((string)$file['name'], PATHINFO_FILENAME));
        $publitio_enabled = !empty(get_option('phiskvideos_publitio_settings', [])['enabled']);
        $attachment_id = 0;
        $publitio = null;
        if ($publitio_enabled) {
            $publitio = $this->publitio_upload_video($file, $title_from_file ?: 'Untitled Video');
            if (is_wp_error($publitio)) wp_send_json_error(['message'=>$publitio->get_error_message()], 500);
        } else {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
            $attachment_id = media_handle_upload('video_file', 0, [], ['test_form'=>false]);
            if (is_wp_error($attachment_id)) wp_send_json_error(['message'=>'The video could not be uploaded: '.$attachment_id->get_error_message()], 500);
        }

        $post_id = $is_edit ? (int)$existing->ID : wp_insert_post([
            'post_type'=>'phisk_video', 'post_status'=>'draft',
            'post_title'=>$title_from_file ?: 'Untitled Video', 'post_content'=>'',
            'post_author'=>get_current_user_id(),
        ], true);
        if (is_wp_error($post_id) || !$post_id) {
            if ($attachment_id) wp_delete_attachment($attachment_id, true);
            wp_send_json_error(['message'=>'The video uploaded, but the video record could not be saved. Please try again.'], 500);
        }

        $old_attachment = absint(get_post_meta($post_id, '_phisk_video_attachment_id', true));
        if ($publitio_enabled) {
            update_post_meta($post_id, '_phisk_video_provider', 'publitio');
            update_post_meta($post_id, '_phisk_video_attachment_id', 0);
            update_post_meta($post_id, '_phisk_video_source_id', (string)$publitio['id']);
            update_post_meta($post_id, '_phisk_video_source_url', $publitio['url']);
            $runtime = ['seconds'=>0, 'formatted'=>''];
            if (!empty($publitio['data']['duration'])) {
                $seconds = (int) round((float)$publitio['data']['duration']);
                $runtime = ['seconds'=>$seconds, 'formatted'=>($seconds >= 3600 ? sprintf('%d:%02d:%02d', floor($seconds/3600), floor(($seconds%3600)/60), $seconds%60) : sprintf('%d:%02d', floor($seconds/60), $seconds%60))];
            }
        } else {
            wp_update_post(['ID'=>$attachment_id,'post_parent'=>$post_id]);
            update_post_meta($post_id, '_phisk_video_provider', 'wordpress');
            update_post_meta($post_id, '_phisk_video_attachment_id', (int)$attachment_id);
            update_post_meta($post_id, '_phisk_video_source_id', (string)$attachment_id);
            update_post_meta($post_id, '_phisk_video_source_url', esc_url_raw(wp_get_attachment_url($attachment_id)));
            $runtime = $this->phisk_video_runtime_from_file(get_attached_file($attachment_id));
            if ($old_attachment && $old_attachment !== (int)$attachment_id) wp_delete_attachment($old_attachment, true);
        }
        if ($runtime['formatted'] !== '') update_post_meta($post_id, 'phisk_runtime', $runtime['formatted']);
        if ($runtime['seconds'] > 0) update_post_meta($post_id, '_phisk_video_duration_seconds', $runtime['seconds']);
        $source_url = $publitio_enabled ? $publitio['url'] : esc_url_raw(wp_get_attachment_url($attachment_id));

        wp_send_json_success([
            'draft_id'=>(int)$post_id, 'attachment_id'=>(int)$attachment_id,
            'title'=>get_the_title($post_id), 'runtime'=>$runtime['formatted'], 'source_url'=>$source_url,
            'message'=>$is_edit ? 'Video replaced on the existing post. Continue to the next step.' : 'Video uploaded and draft created. Continue to the next step.',
        ]);
    }

    /** Import a creator-owned YouTube video as an embed; never downloads the video itself. */
    public function ajax_import_youtube_draft() {
        if (!is_user_logged_in()) wp_send_json_error(['message'=>'Please log in before importing a video.'], 401);
        check_ajax_referer('phisk_video_submit_nonce', 'nonce');
        if (!$this->user_has_phisk_channel(get_current_user_id())) wp_send_json_error(['message'=>'Create a Channel to use this page.'], 403);
        if ($this->user_strike_blocks_publishing(get_current_user_id())) wp_send_json_error(['message'=>'Publishing is restricted on your account. Visit Account Standing to review your strikes or appeal.'], 403);
        if (empty($_POST['ownership_confirmed']) || sanitize_text_field(wp_unslash($_POST['ownership_confirmed'])) !== '1') {
            wp_send_json_error(['message'=>'Please confirm that you own the rights to this video and understand the reduced-earnings policy.'], 400);
        }
        $raw_url = isset($_POST['youtube_url']) ? esc_url_raw(trim(wp_unslash($_POST['youtube_url']))) : '';
        $video_id = $this->phisk_extract_youtube_id($raw_url);
        if (!$video_id) wp_send_json_error(['message'=>'Please enter a valid YouTube video link.'], 400);

        // Use an atomic option lock plus a persistent ID lookup to stop the same
        // YouTube video being imported by multiple Phisk accounts.
        $lock_key = 'phisk_yt_import_lock_' . $video_id;
        if (!add_option($lock_key, time(), '', false)) wp_send_json_error(['message'=>'This YouTube video is currently being imported. Please try again shortly.'], 409);
        try {
            $import_registry = get_option('phisk_youtube_import_registry', []);
            if (!is_array($import_registry)) $import_registry = [];
            $existing = get_posts([
                'post_type'=>'phisk_video', 'post_status'=>['publish','draft','pending','private','future','trash'],
                'posts_per_page'=>1, 'fields'=>'ids', 'meta_key'=>'_phisk_youtube_video_id',
                'meta_value'=>$video_id, 'no_found_rows'=>true,
            ]);
            if (isset($import_registry[$video_id]) || $existing) {
                delete_option($lock_key);
                wp_send_json_error(['message'=>'This YouTube video has already been imported to Phisk and cannot be submitted by another account.'], 409);
            }

            // YouTube's official oEmbed endpoint supplies public embed metadata without
            // downloading the video or scraping the watch page.
            $oembed_url = add_query_arg(['url'=>'https://www.youtube.com/watch?v='.$video_id, 'format'=>'json'], 'https://www.youtube.com/oembed');
            $response = wp_safe_remote_get($oembed_url, ['timeout'=>12, 'redirection'=>2, 'limit_response_size'=>100000]);
            if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
                delete_option($lock_key);
                wp_send_json_error(['message'=>'YouTube could not provide details for this video. Check that the video is public and try again.'], 400);
            }
            $meta = json_decode(wp_remote_retrieve_body($response), true);
            if (!is_array($meta) || empty($meta['title']) || empty($meta['thumbnail_url'])) {
                delete_option($lock_key);
                wp_send_json_error(['message'=>'YouTube did not return usable metadata for this video. It may be private, removed, or unavailable for embedding.'], 400);
            }
            $post_id = wp_insert_post([
                'post_type'=>'phisk_video', 'post_status'=>'draft',
                'post_title'=>sanitize_text_field($meta['title']),
                'post_content'=>'',
                'post_author'=>get_current_user_id(),
            ], true);
            if (is_wp_error($post_id) || !$post_id) {
                delete_option($lock_key);
                wp_send_json_error(['message'=>'The imported video record could not be created. Please try again.'], 500);
            }
            $import_registry[$video_id] = ['post_id'=>(int)$post_id, 'user_id'=>get_current_user_id(), 'imported_at'=>current_time('mysql')];
            update_option('phisk_youtube_import_registry', $import_registry, false);

            update_post_meta($post_id, '_phisk_video_provider', 'youtube_embed');
            update_post_meta($post_id, '_phisk_youtube_video_id', $video_id);
            update_post_meta($post_id, '_phisk_youtube_channel_name', sanitize_text_field($meta['author_name'] ?? ''));
            update_post_meta($post_id, '_phisk_youtube_thumbnail_url', esc_url_raw($meta['thumbnail_url']));
            update_post_meta($post_id, '_phisk_video_source_id', $video_id);
            update_post_meta($post_id, '_phisk_video_source_url', 'https://www.youtube.com/watch?v='.$video_id);
            update_post_meta($post_id, '_phisk_video_earnings_rate', 'reduced');
            update_post_meta($post_id, '_phisk_youtube_ownership_confirmed', 1);
            update_post_meta($post_id, '_phisk_youtube_ownership_confirmed_at', current_time('mysql'));

            // Set a local featured image from the metadata thumbnail when available.
            // The video itself remains hosted and played by YouTube.
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
            $thumb_id = media_sideload_image(esc_url_raw($meta['thumbnail_url']), $post_id, sanitize_text_field($meta['title']), 'id');
            if (!is_wp_error($thumb_id) && $thumb_id) set_post_thumbnail($post_id, (int)$thumb_id);

            delete_option($lock_key);
            wp_send_json_success([
                'draft_id'=>(int)$post_id,
                'title'=>sanitize_text_field($meta['title']),
                'channel'=>sanitize_text_field($meta['author_name'] ?? ''),
                'message'=>'YouTube video imported as an embed. Add a description and finish the remaining steps to publish.',
            ]);
        } finally {
            delete_option($lock_key);
        }
    }

    private function phisk_extract_youtube_id($url) {
        if (!$url) return '';
        $parts = wp_parse_url($url);
        if (!is_array($parts) || empty($parts['host']) || empty($parts['scheme']) || strtolower($parts['scheme']) !== 'https') return '';
        $host = strtolower(preg_replace('/^www\\./', '', $parts['host']));
        $id = '';
        if ($host === 'youtu.be') {
            $id = isset($parts['path']) ? trim($parts['path'], '/') : '';
        } elseif (in_array($host, ['youtube.com','m.youtube.com','music.youtube.com'], true)) {
            if (($parts['path'] ?? '') === '/watch') {
                parse_str($parts['query'] ?? '', $query);
                $id = $query['v'] ?? '';
            } elseif (preg_match('~^/(?:embed|shorts|live)/([^/?]+)~', $parts['path'] ?? '', $m)) {
                $id = $m[1];
            }
        }
        return preg_match('/^[A-Za-z0-9_-]{11}$/', $id) ? $id : '';
    }

    private function phisk_owned_video_draft($post_id) {
        $post_id = absint($post_id);
        $post = $post_id ? get_post($post_id) : null;
        if (!$post || $post->post_type !== 'phisk_video' || (int)$post->post_author !== get_current_user_id() || !in_array($post->post_status, ['draft','pending','publish'], true)) return null;
        return $post;
    }

    public function ajax_update_video_draft() {
        if (!is_user_logged_in()) wp_send_json_error(['message'=>'Please log in.'], 401);
        check_ajax_referer('phisk_video_submit_nonce', 'nonce');
        if (!$this->user_has_phisk_channel(get_current_user_id())) wp_send_json_error(['message'=>'Create a Channel to use this page.'], 403);
        if ($this->user_strike_blocks_publishing(get_current_user_id())) wp_send_json_error(['message'=>'Publishing is restricted on your account. Visit Account Standing to review your strikes or appeal.'], 403);
        $post_id = isset($_POST['draft_id']) ? absint($_POST['draft_id']) : 0;
        $post = $this->phisk_owned_video_draft($post_id);
        if (!$post) wp_send_json_error(['message'=>'That video draft could not be found.'], 404);
        $title = isset($_POST['title']) ? sanitize_text_field(wp_unslash($_POST['title'])) : '';
        $description = isset($_POST['description']) ? wp_kses_post(wp_unslash($_POST['description'])) : '';
        $age = isset($_POST['age_restriction']) ? sanitize_text_field(wp_unslash($_POST['age_restriction'])) : '';
        if ($title === '') wp_send_json_error(['message'=>'Please enter a video title.'], 400);
        $title_length = function_exists('mb_strlen') ? mb_strlen($title, 'UTF-8') : strlen($title);
        if ($title_length > 100) wp_send_json_error(['message'=>'Video titles can be no longer than 100 characters.'], 400);
        $allowed_age = ['No its not for kids','Yes its for kids'];
        if (!in_array($age, $allowed_age, true)) wp_send_json_error(['message'=>'Please choose whether this video is for kids.'], 400);
        $updated = wp_update_post(['ID'=>$post_id,'post_title'=>$title,'post_content'=>$description], true);
        if (is_wp_error($updated)) wp_send_json_error(['message'=>$updated->get_error_message()], 500);
        update_post_meta($post_id, 'phisk_age_rating', $age);
        wp_send_json_success(['draft_id'=>$post_id,'message'=>'Details saved. Continue to the thumbnail step.']);
    }

    public function ajax_finalize_video_draft() {
        if (!is_user_logged_in()) wp_send_json_error(['message'=>'Please log in.'], 401);
        check_ajax_referer('phisk_video_submit_nonce', 'nonce');
        if (!$this->user_has_phisk_channel(get_current_user_id())) wp_send_json_error(['message'=>'Create a Channel to use this page.'], 403);
        if ($this->user_strike_blocks_publishing(get_current_user_id())) wp_send_json_error(['message'=>'Publishing is restricted on your account. Visit Account Standing to review your strikes or appeal.'], 403);
        $post_id = isset($_POST['draft_id']) ? absint($_POST['draft_id']) : 0;
        $post = $this->phisk_owned_video_draft($post_id);
        if (!$post) wp_send_json_error(['message'=>'That video draft could not be found.'], 404);
        $has_new_thumbnail = !empty($_FILES['thumbnail']) && !empty($_FILES['thumbnail']['tmp_name']);
        if (!$has_new_thumbnail && !has_post_thumbnail($post_id)) wp_send_json_error(['message'=>'Please choose a thumbnail.'], 400);

        if ($has_new_thumbnail) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
            $attachment_id = media_handle_upload('thumbnail', $post_id, [], ['test_form'=>false]);
            if (is_wp_error($attachment_id)) wp_send_json_error(['message'=>'The thumbnail could not be uploaded: '.$attachment_id->get_error_message()], 500);
            set_post_thumbnail($post_id, $attachment_id);
        }
        // Only new drafts are published here. Editing an already-published video must
        // keep its existing status, ID, views, likes, comments and canonical permalink.
        $newly_published = ($post->post_status !== 'publish');
        if ($newly_published) {
            $updated = wp_update_post(['ID'=>$post_id,'post_status'=>'publish'], true);
            if (is_wp_error($updated)) wp_send_json_error(['message'=>'Changes were saved, but the video could not be published.'], 500);
        }
        $video_url = get_permalink($post_id);
        if ($newly_published) $video_url = add_query_arg('phisk_video_published', '1', $video_url);
        wp_send_json_success(['draft_id'=>$post_id,'url'=>$video_url,'newly_published'=>$newly_published,'message'=>$newly_published ? 'Your video has been published successfully.' : 'Your video changes have been saved successfully.']);
    }

    /** Process an authenticated frontend article draft or review submission. */
    public function handle_article_frontend_submission() {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || empty($_POST['phisk_article_submit'])) return;
        if (!is_user_logged_in()) $this->article_submission_redirect('error', 'Please log in before writing a story.');
        $user_id = get_current_user_id();
        if (!$this->user_has_phisk_channel($user_id)) $this->article_submission_redirect('error', 'Create a Channel to use this page.');
        if ($this->user_strike_blocks_publishing($user_id)) $this->article_submission_redirect('error', 'Publishing is restricted on your account. Visit Account Standing to review your strikes or appeal.');
        $nonce = isset($_POST['phisk_article_nonce']) ? sanitize_text_field(wp_unslash($_POST['phisk_article_nonce'])) : '';
        if (!$nonce || !wp_verify_nonce($nonce, 'phisk_article_frontend_submit')) $this->article_submission_redirect('error', 'Security check failed. Please try again.');
        $edit_id = isset($_POST['phisk_article_edit_id']) ? absint($_POST['phisk_article_edit_id']) : 0;
        $editing = $edit_id ? get_post($edit_id) : null;
        if ($edit_id && (!$editing || $editing->post_type !== 'post' || (int)$editing->post_author !== $user_id)) $this->article_submission_redirect('error', 'You cannot edit this Story.');
        $title = isset($_POST['phisk_article_title']) ? sanitize_text_field(wp_unslash($_POST['phisk_article_title'])) : '';
        $content = isset($_POST['phisk_article_content']) ? wp_kses_post(wp_unslash($_POST['phisk_article_content'])) : '';
        $excerpt = isset($_POST['phisk_article_excerpt']) ? sanitize_textarea_field(wp_unslash($_POST['phisk_article_excerpt'])) : ($editing ? (string)get_post_meta($edit_id, '_phisk_article_short_intro', true) : '');
        $interest_id = isset($_POST['phisk_article_interest']) ? absint($_POST['phisk_article_interest']) : 0;
        if (!$interest_id || !term_exists($interest_id, 'phisk_interest')) $this->article_submission_redirect('error', 'Please choose an interest for your story.');
        if ($title === '' || trim(wp_strip_all_tags($content)) === '') $this->article_submission_redirect('error', 'Please enter both a story title and story content.');
        $title_length = function_exists('mb_strlen') ? mb_strlen($title, 'UTF-8') : strlen($title);
        if ($title_length > 100) $this->article_submission_redirect('error', 'Story titles can be no longer than 100 characters.');
        $requested = isset($_POST['phisk_article_action']) ? sanitize_key(wp_unslash($_POST['phisk_article_action'])) : 'submit';
        $ids = isset($_POST['phisk_article_image_ids']) ? array_values(array_unique(array_filter(array_map('absint', (array)$_POST['phisk_article_image_ids'])))) : [];
        if ($editing) {
            $old_ids = $this->article_gallery_ids($edit_id);
            foreach ($ids as $id) if (!wp_attachment_is_image($id) || (!in_array($id, $old_ids, true) && (int)get_post_field('post_author',$id) !== $user_id)) $this->article_submission_redirect('error', 'One of the selected images is not available to your account.');
        } else {
            foreach ($ids as $id) if ((int)get_post_field('post_author',$id) !== $user_id || !wp_attachment_is_image($id)) $this->article_submission_redirect('error', 'One of the selected images is not available to your account.');
        }
        if (!$ids && $editing) $ids = $this->article_gallery_ids($edit_id);
        if (!$ids) $this->article_submission_redirect('error', 'Please add at least one Story image.');
        $auto = (bool)get_option('phiskvideos_story_auto_approval', 0);
        $status = $requested === 'draft' ? 'draft' : ($auto ? 'publish' : 'pending');
        $post_data = ['post_type'=>'post','post_status'=>$status,'post_title'=>$title,'post_content'=>$content,'post_excerpt'=>$excerpt,'post_author'=>$user_id];
        if ($editing) $post_data['ID'] = $edit_id;
        $post_id = wp_insert_post($post_data, true);
        if (is_wp_error($post_id) || !$post_id) $this->article_submission_redirect('error', 'Your Story could not be saved. Please try again.');
        wp_set_object_terms($post_id, [$interest_id], 'phisk_interest', false);
        if ($excerpt !== '') update_post_meta($post_id, '_phisk_article_short_intro', $excerpt); else delete_post_meta($post_id, '_phisk_article_short_intro');
        update_post_meta($post_id, '_phisk_article_gallery_ids', $ids);
        set_post_thumbnail($post_id, $ids[0]);
        if ($status === 'pending') { delete_post_meta($post_id, '_phisk_article_review_status'); delete_post_meta($post_id, '_phisk_article_rejection_reason'); delete_post_meta($post_id, '_phisk_article_rejection_note'); }
        if ($status === 'publish') {
            $target = add_query_arg('phisk_story_published', '1', get_permalink($post_id));
            wp_safe_redirect($target); exit;
        }
        $message = $status === 'draft' ? 'Your Story has been saved as a draft.' : ($editing ? 'Your changes have been submitted and are awaiting review.' : 'Your Story has been submitted and is awaiting review.');
        $this->article_submission_redirect('success', $message);
    }

    private function article_submission_redirect($status, $message) {
        $url = $this->creator_page_url('phiskvideos_article_submit_page_id', 'write-article');
        $url = add_query_arg(['phisk_article_status'=>sanitize_key($status), 'phisk_article_message'=>rawurlencode($message)], $url);
        wp_safe_redirect($url);
        exit;
    }

    /** Frontend article composer for creators. Articles are submitted for review by default. */
    public function article_submit_shortcode() {
        if (!is_user_logged_in()) return '<section class="phisk-article-submit phisk-auth-gate phisk-story-auth-gate"><h2>Share your story.</h2></section>';
        $channel_gate = $this->channel_creation_gate(); if ($channel_gate !== '') return $channel_gate;
        $this->enqueue_style();
        $edit_id = isset($_GET['edit_story']) ? absint($_GET['edit_story']) : 0;
        $editing = $edit_id ? get_post($edit_id) : null;
        if ($edit_id && (!$editing || $editing->post_type !== 'post' || (int)$editing->post_author !== get_current_user_id())) return '<p>You cannot edit this Story.</p>';
        $status = isset($_GET['phisk_article_status']) ? sanitize_key(wp_unslash($_GET['phisk_article_status'])) : '';
        $message = isset($_GET['phisk_article_message']) ? sanitize_text_field(rawurldecode(wp_unslash($_GET['phisk_article_message']))) : '';
        $gallery = $editing ? $this->article_gallery_ids($edit_id) : [];
        $terms = get_the_terms($edit_id, 'phisk_interest'); $selected_interest = ($terms && !is_wp_error($terms)) ? (int)$terms[0]->term_id : 0;
        ob_start(); ?>
        <section class="phisk-article-submit" data-phisk-story-composer>
          <style>
            .phisk-article-submit{width:100%;max-width:820px;box-sizing:border-box;margin:28px auto;padding:0;border:0!important;background:transparent;color:inherit}.phisk-article-submit h2{margin:0 0 6px;font-size:clamp(24px,3vw,32px)}.phisk-article-submit-intro{opacity:.75;margin:0 0 20px}.phisk-article-submit form{display:grid;gap:20px;background:transparent}.phisk-article-submit label{display:grid;gap:8px;font-weight:600;min-width:0}.phisk-article-submit input[type=text],.phisk-article-submit textarea,.phisk-article-submit select{width:100%;padding:12px;border:1px solid rgba(127,127,127,.4);border-radius:8px;background:transparent;color:inherit;font:inherit}.phisk-article-submit textarea{min-height:220px;resize:vertical}.phisk-article-image-picker{position:relative;display:inline-flex;align-items:center;gap:8px;padding:9px 13px;border-radius:5px;background:#e5e5e5;color:#222;font-size:13px;font-weight:600;cursor:pointer}.phisk-article-image-picker input{position:absolute;inset:0;width:100%;height:100%;opacity:0;cursor:pointer}.phisk-article-image-preview-list{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px;margin:12px 0}.phisk-article-image-preview{position:relative;min-width:0;border:1px solid #ddd;border-radius:10px;overflow:hidden}.phisk-article-image-preview img{width:100%;height:105px;object-fit:cover;display:block}.phisk-story-upload-track{height:5px;background:#ddd;margin:7px 8px;border-radius:9px;overflow:hidden}.phisk-story-upload-track span{display:block;height:100%;width:0;background:#159957;transition:width .15s}.phisk-story-upload-state{font-size:11px;padding:0 8px 7px;display:block}.phisk-article-image-remove{position:absolute;top:5px;right:5px;border:0;border-radius:50%;background:#111;color:#fff;width:25px;height:25px;cursor:pointer}.phisk-article-actions{display:flex;gap:12px}.phisk-article-actions button{min-height:44px;padding:11px 18px;border-radius:999px;border:1px solid #ddd;font:inherit;font-weight:700;cursor:pointer}.phisk-article-actions button[type=submit]{background:#000;color:#fff}.phisk-story-upload-message{font-size:13px}.phisk-story-upload-message.is-error{color:#c33}@media(max-width:700px){.phisk-article-submit{margin:22px 14px;width:auto;padding-bottom:calc(104px + env(safe-area-inset-bottom))}.phisk-article-actions{margin-bottom:8px}.phisk-article-actions button{flex:1}}
          </style>
          <h2><?php echo $editing ? 'Edit Story' : 'Write a Story'; ?></h2><p class="phisk-article-submit-intro">Share your knowledge, stories, and ideas with the Phisk community.</p>
          <?php if ($message) : ?><div class="phisk-article-message" role="status"><?php echo esc_html($message); ?></div><?php endif; ?>
          <form method="post" enctype="multipart/form-data" data-phisk-story-form>
            <?php wp_nonce_field('phisk_article_frontend_submit', 'phisk_article_nonce'); ?>
            <input type="hidden" name="phisk_article_submit" value="1"><input type="hidden" name="phisk_article_edit_id" value="<?php echo esc_attr($edit_id); ?>">
            <label>Story title<input type="text" name="phisk_article_title" maxlength="100" required value="<?php echo esc_attr($editing ? $editing->post_title : ''); ?>" placeholder="Give your Story a clear title"></label>
            <label>Interest<select name="phisk_article_interest" required><option value="">Choose an interest</option><?php foreach (get_terms(['taxonomy'=>'phisk_interest','hide_empty'=>false]) as $interest) : ?><option value="<?php echo esc_attr($interest->term_id); ?>" <?php selected($selected_interest,$interest->term_id); ?>><?php echo esc_html($interest->name); ?></option><?php endforeach; ?></select></label>
            <label>Story text<textarea name="phisk_article_content" rows="12" required placeholder="Write your Story here..."><?php echo esc_textarea($editing ? $editing->post_content : ''); ?></textarea></label>
            <label>Story images <span class="phisk-article-image-picker">Choose images<input type="file" name="phisk_article_images[]" accept="image/jpeg,image/png,image/webp,image/gif" aria-label="Choose Story images" multiple></span></label>
            <div class="phisk-article-image-preview-list" aria-live="polite"><?php foreach ($gallery as $index=>$image_id) : $url=wp_get_attachment_image_url($image_id,'medium'); ?><div class="phisk-article-image-preview" data-image-id="<?php echo esc_attr($image_id); ?>"><img src="<?php echo esc_url($url); ?>" alt=""><button type="button" class="phisk-article-image-remove" aria-label="Remove image">×</button><span class="phisk-story-upload-state">Uploaded</span></div><?php endforeach; ?></div>
            <div class="phisk-story-upload-message" aria-live="polite"></div><div class="phisk-story-hidden-ids"><?php foreach ($gallery as $image_id) : ?><input type="hidden" name="phisk_article_image_ids[]" value="<?php echo esc_attr($image_id); ?>"><?php endforeach; ?></div>
            <p class="phisk-article-submit-intro"><?php echo get_option('phiskvideos_story_auto_approval',0) ? 'Your Story will be published immediately after submission.' : 'Your Story will be reviewed before publication.'; ?> You can also save a draft.</p>
            <div class="phisk-article-actions"><button type="submit" name="phisk_article_action" value="submit"><?php echo $editing ? 'Republish Story' : 'Post'; ?></button><button type="submit" name="phisk_article_action" value="draft">Save</button></div>
          </form>
        </section>
        <?php return ob_get_clean();
    }

    private function video_form_value($post, $key) { return $post ? get_post_meta($post->ID, $key, true) : ''; }

    public function video_submit_shortcode() {
        $this->enqueue_style();
        $edit_id = isset($_GET['edit_video']) ? absint($_GET['edit_video']) : 0;
        $editing = $edit_id ? get_post($edit_id) : null;
        if ($editing && ($editing->post_type !== 'phisk_video' || !is_user_logged_in() || (int)$editing->post_author !== get_current_user_id())) $editing = null;
        $status = isset($_GET['phisk_video_submit_status']) ? sanitize_key(wp_unslash($_GET['phisk_video_submit_status'])) : '';
        $message = isset($_GET['phisk_video_submit_message']) ? sanitize_text_field(rawurldecode(wp_unslash($_GET['phisk_video_submit_message']))) : '';
        if (!is_user_logged_in()) {
            return '<section class="phisk-submit-wrap phisk-auth-gate phisk-video-auth-gate"><h2>Upload your video.</h2></section>';
        }
        $channel_gate = $this->channel_creation_gate();
        if ($channel_gate !== '') return $channel_gate;

        $draft_id = $editing ? (int)$editing->ID : 0;
        $video_data = $editing ? $this->video_provider_data($editing->ID) : ['provider'=>'wordpress','source_url'=>'','source_id'=>''];
        $age = $editing ? $this->video_form_value($editing, 'phisk_age_rating') : '';
        $runtime = $editing ? $this->video_form_value($editing, 'phisk_runtime') : '';
        ob_start(); ?>
        <section class="phisk-submit-wrap phisk-video-submit-wrap" data-phisk-video-submit>
          <?php if ($message) : ?><div class="phisk-submit-message phisk-submit-<?php echo esc_attr($status); ?>"><?php echo esc_html($message); ?></div><?php endif; ?>
          <div class="phisk-video-submit-message" aria-live="polite"></div>
          <form class="phisk-video-submit-wizard" enctype="multipart/form-data">
            <input type="hidden" name="phisk_video_front_nonce" value="<?php echo esc_attr(wp_create_nonce('phisk_video_front_submit')); ?>">
            <input type="hidden" name="draft_id" value="<?php echo esc_attr($draft_id); ?>">

            <section class="phisk-video-step phisk-video-step-1<?php echo $editing ? ' is-complete' : ' is-active'; ?>" data-step="1">
              <div class="phisk-video-upload-standalone">
                <div class="phisk-video-upload-icon" aria-hidden="true"><img src="<?php echo esc_url(plugins_url('assets/phisk-icon-film.svg', __FILE__)); ?>" width="52" height="52" alt=""></div>
                <h3><?php echo $editing ? 'Video' : 'Upload your video'; ?></h3>
                <?php if ($editing && $video_data['source_url']) : ?>
                  <p class="phisk-upload-current"><?php echo $video_data['provider'] === 'youtube_embed' ? 'This video is embedded from YouTube. You can continue to edit its details and thumbnail.' : 'Current video is already uploaded. You can continue to details or replace it.'; ?></p>
                  <?php if ($video_data['provider'] === 'youtube_embed') : ?><div class="phisk-youtube-embed-player"><iframe src="<?php echo esc_url('https://www.youtube-nocookie.com/embed/' . rawurlencode((string)$video_data['source_id'])); ?>" title="<?php echo esc_attr(get_the_title($edit_id)); ?>" loading="lazy" allowfullscreen></iframe></div>
                  <?php else : ?><video class="phisk-upload-preview" controls preload="metadata" src="<?php echo esc_url($video_data['source_url']); ?>"></video><?php endif; ?>
                <?php endif; ?>
                <label class="phisk-file-picker" <?php echo ($editing && $video_data['provider'] === 'youtube_embed') ? 'hidden' : ''; ?>><span class="phisk-file-picker-label"><?php echo $editing ? 'Choose a replacement video' : 'Choose video'; ?></span><span class="phisk-file-name" aria-live="polite"></span><input type="file" name="video_file" accept="video/mp4,video/webm,video/ogg,video/quicktime,.m4v,.mov" <?php echo $editing ? '' : 'required'; ?>></label>
                <p class="phisk-upload-hint" <?php echo ($editing && $video_data['provider'] === 'youtube_embed') ? 'hidden' : ''; ?>>MP4, WebM, OGG, M4V or MOV. The video is uploaded to your configured video storage provider.</p>
                <div class="phisk-upload-progress" hidden><div class="phisk-upload-progress-track"><span></span></div><div class="phisk-upload-progress-row"><strong>Uploading…</strong><span>0%</span></div></div>
                <button type="button" class="phisk-submit-button phisk-upload-video-button" <?php echo ($editing && $video_data['provider'] === 'youtube_embed') ? 'hidden' : ''; ?>><?php echo $editing ? 'Replace Video &amp; Continue' : 'Upload Video &amp; Continue'; ?></button>
                <?php if (!$editing) : ?>
                  <div class="phisk-youtube-import-option">
                    <p>Already uploaded your video to YouTube? <a href="#" class="phisk-youtube-import-reveal">Import it from YouTube</a></p>
                    <div class="phisk-youtube-import-panel" hidden>
                      <p class="phisk-youtube-import-warning">Only import videos you own or have the rights to use. YouTube-imported videos earn reduced revenue under the Phisk Creator Partnership Program compared with eligible videos uploaded directly to Phisk.</p>
                      <label class="phisk-youtube-ownership-check"><input type="checkbox" name="youtube_ownership_confirmed" value="1"> I understand and agree to these conditions.</label>
                      <label class="phisk-youtube-url-field" hidden><strong>YouTube video link</strong><input type="url" name="youtube_video_url" placeholder="https://www.youtube.com/watch?v=..." autocomplete="url"></label>
                      <button type="button" class="phisk-secondary-button phisk-youtube-import-button" hidden>Import YouTube Video</button>
                    </div>
                  </div>
                <?php endif; ?>
                <?php if ($editing) : ?><button type="button" class="phisk-wizard-next phisk-secondary-button" data-go-step="2">Continue to Details</button><?php endif; ?>
              </div>
            </section>

            <section class="phisk-video-step phisk-video-step-2" data-step="2" hidden>
              <h3>Video details</h3>
              <label><strong>Title</strong><input required type="text" name="phisk_video_title" maxlength="100" data-phisk-title-limit="100" value="<?php echo esc_attr($editing ? $editing->post_title : ''); ?>" placeholder="Give your video a title"><small class="phisk-character-help">Maximum 100 characters. <span class="phisk-character-count"><?php echo esc_html(function_exists('mb_strlen') ? mb_strlen((string)($editing ? $editing->post_title : ''), 'UTF-8') : strlen((string)($editing ? $editing->post_title : ''))); ?></span>/100 used.</small></label>
              <label><strong>Description</strong><textarea required name="phisk_video_description" rows="7" placeholder="Tell viewers about this video..."><?php echo esc_textarea($editing ? $editing->post_content : ''); ?></textarea></label>
              <fieldset class="phisk-age-choice"><legend><strong>Age Restrictions</strong></legend>
                <label><input type="radio" name="phisk_age_rating" value="No its not for kids" <?php checked($age, 'No its not for kids'); ?> required> No its not for kids</label>
                <label><input type="radio" name="phisk_age_rating" value="Yes its for kids" <?php checked($age, 'Yes its for kids'); ?>> Yes its for kids</label>
              </fieldset>
              <div class="phisk-wizard-actions"><button type="button" class="phisk-secondary-button phisk-wizard-back" data-go-step="1">Back</button><button type="button" class="phisk-submit-button phisk-save-details-button">Save &amp; Continue</button></div>
            </section>

            <section class="phisk-video-step phisk-video-step-3" data-step="3" hidden>
              <h3>Choose a thumbnail</h3>
              <p class="phisk-submit-intro">This image will be used on your video feed. The video runtime will be shown automatically on the thumbnail when available.</p>
              <label class="phisk-thumbnail-picker"><span class="phisk-thumbnail-picker-label">Select thumbnail</span><span class="phisk-thumbnail-file-name" aria-live="polite"></span><input <?php echo $editing ? '' : 'required'; ?> type="file" name="thumbnail" accept="image/jpeg,image/png,image/webp,image/gif" aria-label="Select thumbnail"></label>
              <div class="phisk-thumbnail-preview" hidden><img alt="Thumbnail preview"></div>
              <?php if ($editing && get_the_post_thumbnail_url($editing->ID, 'large')) : ?><div class="phisk-existing-thumbnail"><span>Current thumbnail</span><img src="<?php echo esc_url(get_the_post_thumbnail_url($editing->ID, 'large')); ?>" alt=""></div><?php endif; ?>
              <div class="phisk-wizard-actions"><button type="button" class="phisk-secondary-button phisk-wizard-back" data-go-step="2">Back</button><button type="button" class="phisk-submit-button phisk-finish-video-button"><?php echo $editing ? 'Save Changes' : 'Publish Video'; ?></button></div>
            </section>
          </form>
        </section>
        <?php return ob_get_clean();
    }

    public function my_videos_shortcode($atts) {
        $this->enqueue_style();
        if (!is_user_logged_in()) {
            return '<section class="phisk-submit-wrap"><h2>My Videos</h2><p>Please log in to see your submitted videos.</p></section>';
        }
        $channel_gate = $this->channel_creation_gate();
        if ($channel_gate !== '') return $channel_gate;
        if (!empty($_GET['edit_video'])) return $this->video_submit_shortcode();
        $atts = shortcode_atts(['limit'=>20,'title'=>'My Videos'], $atts, 'phisk_my_videos');
        $query = new WP_Query(['post_type'=>'phisk_video','post_status'=>['publish','draft','pending'],'author'=>get_current_user_id(),'posts_per_page'=>max(1,min(50,absint($atts['limit']))),'orderby'=>'date','order'=>'DESC','no_found_rows'=>true]);
        ob_start();
        echo '<section class="phisk-my-videos">';
        if ($atts['title'] !== '') echo '<h2 class="phisk-feed-heading">'.esc_html($atts['title']).'</h2>';
        if ($query->have_posts()) {
            echo '<div class="phisk-my-videos-list">';
            while ($query->have_posts()) { $query->the_post(); $id=get_the_ID(); $thumb=get_the_post_thumbnail_url($id,'large'); echo '<article class="phisk-my-video-item">';
                echo '<a class="phisk-my-video-thumb" href="'.esc_url(get_permalink()).'">';
                if ($thumb) echo '<img src="'.esc_url($thumb).'" alt="'.esc_attr(get_the_title()).'">'; else echo '<span class="phisk-poster-placeholder">PHISKVIDEOS</span>';
                echo '</a><div class="phisk-my-video-info"><h3><a href="'.esc_url(get_permalink()).'">'.esc_html(get_the_title()).'</a></h3><div class="phisk-card-meta"><span>'.esc_html(get_the_date()).'</span><span>'.esc_html(ucfirst(get_post_status())).'</span></div><a class="phisk-edit-video" href="'.esc_url(add_query_arg('edit_video',$id)).'">Edit Video</a></div></article>'; }
            echo '</div>';
        } else echo $this->render_creator_empty_state('video', 'No videos yet', 'Videos you upload will appear here.');
        echo '</section>';
        wp_reset_postdata(); return ob_get_clean();
    }


    /** Securely upload and assign a cropped creator cover/profile image. */
    public function ajax_update_channel_image() {
        if (!is_user_logged_in()) wp_send_json_error(['message' => 'Please log in to update your image.'], 401);
        check_ajax_referer('phisk_profile_image_upload', 'nonce');
        $user_id = get_current_user_id();
        $kind = isset($_POST['image_type']) ? sanitize_key(wp_unslash($_POST['image_type'])) : '';
        if (!in_array($kind, ['cover', 'profile'], true)) wp_send_json_error(['message' => 'Invalid image type.'], 400);
        if (empty($_FILES['image_file']['name']) || empty($_FILES['image_file']['tmp_name'])) wp_send_json_error(['message' => 'Please choose an image first.'], 400);
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        $checked = wp_check_filetype_and_ext($_FILES['image_file']['tmp_name'], $_FILES['image_file']['name']);
        $allowed = ['image/jpeg', 'image/png', 'image/webp'];
        if (empty($checked['type']) || !in_array($checked['type'], $allowed, true)) wp_send_json_error(['message' => 'Please choose a JPG, PNG or WebP image.'], 400);
        $attachment_id = media_handle_upload('image_file', 0);
        if (is_wp_error($attachment_id)) wp_send_json_error(['message' => $attachment_id->get_error_message()], 500);
        $meta_key = $kind === 'cover' ? 'phisk_cover_image_id' : 'phisk_profile_image_id';
        update_user_meta($user_id, $meta_key, absint($attachment_id));
        $url = wp_get_attachment_image_url($attachment_id, 'full');
        if (!$url) $url = wp_get_attachment_url($attachment_id);
        wp_send_json_success(['message' => 'Image updated successfully.', 'image_type' => $kind, 'attachment_id' => absint($attachment_id), 'url' => esc_url_raw($url)]);
    }

    /** Return the editable public username, migrating legacy accounts lazily. */
    private function get_public_username($user_id) {
        $user_id = absint($user_id);
        $username = (string) get_user_meta($user_id, 'phisk_username', true);
        if ($username === '') {
            $user = get_userdata($user_id);
            $username = $user ? sanitize_user($user->user_nicename, true) : '';
            if ($username === '') $username = $user ? sanitize_user($user->user_login, true) : '';
            $username = strtolower($username);
            if ($username === '') $username = 'member' . $user_id;
            update_user_meta($user_id, 'phisk_username', $username);
        }
        return $username;
    }

    /** Check public username availability while the member types. */
    public function ajax_check_public_username() {
        if (!is_user_logged_in()) wp_send_json_error(['message' => 'Please log in.'], 401);
        check_ajax_referer('phisk_public_username_check', 'nonce');
        $user_id = get_current_user_id();
        $raw = isset($_POST['username']) ? wp_unslash($_POST['username']) : '';
        $username = strtolower(trim((string) $raw));
        if (!preg_match('/^[a-zA-Z0-9_]{3,24}$/', $username)) {
            wp_send_json_success(['available' => false, 'message' => 'Use 3–24 letters, numbers or underscores.']);
        }
        if ($username === $this->get_public_username($user_id)) {
            wp_send_json_success(['available' => true, 'message' => '']);
        }
        $last_changed = absint(get_user_meta($user_id, 'phisk_username_last_changed', true));
        $cooldown = 30 * DAY_IN_SECONDS;
        if ($last_changed && (time() - $last_changed) < $cooldown) {
            wp_send_json_success(['available' => false, 'message' => 'Username changes are temporarily locked.']);
        }
        $conflict = get_users(['meta_key' => 'phisk_username', 'meta_value' => $username, 'number' => 1, 'fields' => 'ID', 'exclude' => [$user_id]]);
        $slug_owner = get_user_by('slug', $username);
        if (!empty($conflict) || ($slug_owner && (int) $slug_owner->ID !== $user_id)) {
            wp_send_json_success(['available' => false, 'message' => 'Username is already taken.']);
        }
        wp_send_json_success(['available' => true, 'message' => 'Username available.']);
    }

    /** Redirect historical public profile slugs to the member's current username URL. */
    /**
     * Keep Video Manager member pages in sync with Phisk Auth.
     * Public video, Story and public creator-profile pages are deliberately untouched.
     */
    public function redirect_guest_member_pages_to_phisk_auth() {
        if (is_admin() || is_user_logged_in() || wp_doing_ajax() || (defined('REST_REQUEST') && REST_REQUEST)) return;
        if (is_preview() || is_feed() || is_embed()) return;

        $protected_shortcodes = [
            'phisk_notifications',
            'phisk_messages',
            'phisk_strike_appeal',
            'phisk_video_submit',
            'phisk_article_submit',
            'phisk_creator_studio',
            'phisk_account_settings',
            'phisk_my_videos',
            'phisk_user_dashboard',
        ];

        $protected = false;
        $queried = get_queried_object();
        if ($queried instanceof WP_Post && $queried->post_type === 'page') {
            $content = (string) $queried->post_content;
            foreach ($protected_shortcodes as $shortcode) {
                if (has_shortcode($content, $shortcode)) { $protected = true; break; }
            }
            // Known Video Manager member-page slugs also cover pages whose shortcode was wrapped in a builder.
            if (!$protected) {
                $protected_slugs = [
                    'phisk-messages', 'messages', 'inbox',
                    'phisk-notifications', 'notifications',
                    'upload-video', 'write-article', 'upload-story', 'post-story',
                    'creator-studio', 'settings', 'account-settings',
                    'my-videos', 'phisk-dashboard', 'channel-management', 'manage-channel',
                ];
                $protected = in_array(sanitize_title($queried->post_name), $protected_slugs, true);
            }
        }

        if (!$protected) return;

        $request_uri = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '/';
        $destination = wp_validate_redirect(home_url($request_uri), home_url('/'));
        $login_url = add_query_arg('redirect_to', $destination, home_url('/login/'));
        wp_safe_redirect($login_url, 302, 'Phisk Video Manager / Phisk Auth');
        exit;
    }

    public function redirect_old_public_usernames() {
        if (is_admin() || is_preview() || (defined('REST_REQUEST') && REST_REQUEST)) return;
        $path = trim((string) wp_parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH), '/');
        if ($path === '' || strpos($path, '/') !== false) return;
        $redirects = get_option('phisk_username_redirects', []);
        if (!is_array($redirects) || empty($redirects[$path])) return;
        $user_id = absint($redirects[$path]);
        if (!$user_id || !get_userdata($user_id)) return;
        $target = $this->phisk_user_dashboard_url($user_id);
        if ($target && untrailingslashit($target) !== untrailingslashit(home_url('/' . $path . '/'))) {
            wp_safe_redirect($target, 301);
            exit;
        }
    }

    /**
     * Process the front-end creator profile form. The public display name is
     * stored in WordPress's native display_name field; profile and cover images
     * are stored as attachment IDs in user meta.
     */
    public function handle_dashboard_profile() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['phisk_dashboard_profile_submit'])) return;
        if (!is_user_logged_in()) $this->dashboard_redirect('error', 'Please log in before changing your profile.');
        if (!isset($_POST['phisk_dashboard_profile_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['phisk_dashboard_profile_nonce'])), 'phisk_dashboard_profile')) {
            $this->dashboard_redirect('error', 'Security check failed. Please try again.');
        }

        $user_id = get_current_user_id();
        $user = get_userdata($user_id);
        if (!$user) $this->dashboard_redirect('error', 'Your account could not be found.');

        if (isset($_POST['phisk_public_username'])) {
            $requested_username = strtolower(trim(sanitize_user(wp_unslash($_POST['phisk_public_username']), true)));
            $current_username = $this->get_public_username($user_id);
            if (!preg_match('/^[a-z0-9_]{3,24}$/', $requested_username)) {
                $this->dashboard_redirect('error', 'Choose a username between 3 and 24 characters using only letters, numbers and underscores.');
            }
            if ($requested_username !== $current_username) {
                $last_changed = absint(get_user_meta($user_id, 'phisk_username_last_changed', true));
                $cooldown = 30 * DAY_IN_SECONDS;
                if ($last_changed && (time() - $last_changed) < $cooldown) {
                    $available_at = $last_changed + $cooldown;
                    $this->dashboard_redirect('error', 'Your username can next be changed on ' . wp_date(get_option('date_format'), $available_at) . '.');
                }
                $conflict = get_users(['meta_key' => 'phisk_username', 'meta_value' => $requested_username, 'number' => 1, 'fields' => 'ID', 'exclude' => [$user_id]]);
                $slug_owner = get_user_by('slug', $requested_username);
                if (!empty($conflict) || ($slug_owner && (int)$slug_owner->ID !== $user_id)) {
                    $this->dashboard_redirect('error', 'That username is already taken. Please choose another.');
                }
                $history = get_user_meta($user_id, 'phisk_username_history', true);
                if (!is_array($history)) $history = [];
                $old_slug = (string) $user->user_nicename;
                if ($old_slug !== '') $history[] = $old_slug;
                $history = array_values(array_unique(array_filter($history)));
                update_user_meta($user_id, 'phisk_username_history', $history);
                $redirects = get_option('phisk_username_redirects', []);
                if (!is_array($redirects)) $redirects = [];
                foreach ($history as $previous_slug) {
                    if ($previous_slug !== $requested_username) $redirects[$previous_slug] = $user_id;
                }
                update_option('phisk_username_redirects', $redirects, false);
                update_user_meta($user_id, 'phisk_username', $requested_username);
                $updated = wp_update_user(['ID' => $user_id, 'user_nicename' => $requested_username]);
                if (is_wp_error($updated)) {
                    update_user_meta($user_id, 'phisk_username', $current_username);
                    $this->dashboard_redirect('error', 'We could not update your public username. Please try again.');
                }
                update_user_meta($user_id, 'phisk_username_last_changed', time());
                $user = get_userdata($user_id);
            }
        }

        // Update only fields included in the submitted form, so independent
        // channel, account, image and security forms cannot erase each other's data.
        if (isset($_POST['phisk_display_name']) && $this->user_has_phisk_channel($user_id)) {
            $channel_name = sanitize_text_field(wp_unslash($_POST['phisk_display_name']));
            $name_length = function_exists('mb_strlen') ? mb_strlen($channel_name, 'UTF-8') : strlen($channel_name);
            if ($name_length > 30) $this->dashboard_redirect('error', 'Channel names can be no longer than 30 characters.');
            if ($channel_name === '') $channel_name = $this->phisk_creator_display_name($user_id);
            $old_channel_name = $this->phisk_creator_display_name($user_id);
            if ($channel_name !== $old_channel_name) {
                $last_changed = absint(get_user_meta($user_id, 'phisk_channel_name_last_changed', true));
                $cooldown_seconds = 90 * DAY_IN_SECONDS;
                if ($last_changed && (time() - $last_changed) < $cooldown_seconds) {
                    $available_at = $last_changed + $cooldown_seconds;
                    $this->dashboard_redirect('error', 'Your channel name cannot be changed again until ' . wp_date(get_option('date_format'), $available_at) . '. You can still update your description and social links separately.');
                }
                update_user_meta($user_id, 'phisk_channel_name', $channel_name);
                $history = get_user_meta($user_id, 'phisk_channel_name_history', true);
                if (!is_array($history)) $history = [];
                $history[] = ['old_name' => $old_channel_name, 'new_name' => $channel_name, 'changed_at' => time()];
                update_user_meta($user_id, 'phisk_channel_name_history', $history);
                update_user_meta($user_id, 'phisk_channel_name_last_changed', time());
            }
        }
        if (isset($_POST['phisk_bio'])) {
            $bio = sanitize_textarea_field(wp_unslash($_POST['phisk_bio']));
            $existing_bio = (string)get_user_meta($user_id, 'description', true);
            if ((function_exists('mb_strlen') ? mb_strlen($bio) > 500 : strlen($bio) > 500) && $bio !== $existing_bio) {
                $this->dashboard_redirect('error', 'Your channel description must be 500 characters or fewer.');
            }
            if ($bio !== $existing_bio && (function_exists('mb_strlen') ? mb_strlen($bio) <= 500 : strlen($bio) <= 500)) update_user_meta($user_id, 'description', $bio);
        }
        $social_fields = ['facebook'=>'phisk_social_facebook', 'youtube'=>'phisk_social_youtube', 'x'=>'phisk_social_x', 'linkedin'=>'phisk_social_linkedin'];
        foreach ($social_fields as $platform => $meta_key) {
            if (!isset($_POST[$meta_key])) continue;
            $raw_url = trim((string)wp_unslash($_POST[$meta_key]));
            if ($raw_url === '') { delete_user_meta($user_id, $meta_key); continue; }
            $url = esc_url_raw($raw_url, ['https']);
            $parts = $url ? wp_parse_url($url) : false;
            if (!$url || !is_array($parts) || empty($parts['scheme']) || strtolower($parts['scheme']) !== 'https' || empty($parts['host'])) {
                $this->dashboard_redirect('error', 'Please enter valid HTTPS links for your social profiles.');
            }
            update_user_meta($user_id, $meta_key, $url);
        }
        if (isset($_POST['phisk_first_name']) || isset($_POST['phisk_last_name'])) {
            $first_name = isset($_POST['phisk_first_name']) ? sanitize_text_field(wp_unslash($_POST['phisk_first_name'])) : $user->first_name;
            $last_name = isset($_POST['phisk_last_name']) ? sanitize_text_field(wp_unslash($_POST['phisk_last_name'])) : $user->last_name;
            wp_update_user(['ID' => $user_id, 'first_name' => $first_name, 'last_name' => $last_name]);
        }
        if (isset($_POST['phisk_phone_number'])) {
            $phone = sanitize_text_field(wp_unslash($_POST['phisk_phone_number']));
            update_user_meta($user_id, 'phisk_phone_number', $phone);
        }

        $uploaded = [];
        foreach (['phisk_profile_image' => 'phisk_profile_image_id', 'phisk_cover_image' => 'phisk_cover_image_id'] as $field => $meta_key) {
            if (empty($_FILES[$field]['name']) || empty($_FILES[$field]['tmp_name'])) continue;
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';

            $filetype = wp_check_filetype_and_ext($_FILES[$field]['tmp_name'], $_FILES[$field]['name']);
            if (empty($filetype['type']) || strpos((string)$filetype['type'], 'image/') !== 0) {
                $this->dashboard_redirect('error', 'Please upload a valid image for your profile or cover photo.');
            }

            $attachment_id = media_handle_upload($field, 0);
            if (is_wp_error($attachment_id)) {
                $this->dashboard_redirect('error', $attachment_id->get_error_message());
            }
            update_user_meta($user_id, $meta_key, absint($attachment_id));
            $uploaded[] = $meta_key;
        }

        if (!empty($_POST['phisk_change_password'])) {
            $current_password = isset($_POST['phisk_current_password']) ? (string)wp_unslash($_POST['phisk_current_password']) : '';
            $new_password = isset($_POST['phisk_new_password']) ? (string)wp_unslash($_POST['phisk_new_password']) : '';
            $confirm_password = isset($_POST['phisk_confirm_password']) ? (string)wp_unslash($_POST['phisk_confirm_password']) : '';
            $google_password_setup = get_user_meta($user_id, 'phisk_auth_method', true) === 'google'
                && (string)get_user_meta($user_id, 'phisk_password_set', true) !== '1';

            if ($new_password === '' || $confirm_password === '' || (!$google_password_setup && $current_password === '')) {
                $this->dashboard_redirect('error', 'Please complete all required password fields.');
            }
            if (!$google_password_setup && !wp_check_password($current_password, $user->user_pass, $user_id)) {
                $this->dashboard_redirect('error', 'Your current password is incorrect.');
            }
            if (strlen($new_password) < 8) {
                $this->dashboard_redirect('error', 'Your new password must be at least 8 characters.');
            }
            if ($new_password !== $confirm_password) {
                $this->dashboard_redirect('error', 'The new passwords do not match.');
            }

            // WordPress hashes the password. Mark Google-created accounts as having a local password.
            wp_set_password($new_password, $user_id);
            if ($google_password_setup) {
                update_user_meta($user_id, 'phisk_password_set', 1);
            }
            wp_set_auth_cookie($user_id, true, is_ssl());
        }

        $this->dashboard_redirect('success', 'Your profile has been updated.');
    }

    public function handle_dashboard_content_action() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['phisk_dashboard_content_action'])) return;
        if (!is_user_logged_in()) wp_die('Please log in to manage your content.');
        if (!isset($_POST['phisk_dashboard_content_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['phisk_dashboard_content_nonce'])), 'phisk_dashboard_content_action')) {
            wp_die('Security check failed. Please try again.');
        }

        $user_id = get_current_user_id();
        if (!$this->user_has_phisk_channel($user_id)) wp_die('Create a Channel to use this page.');
        $post_id = isset($_POST['phisk_dashboard_post_id']) ? absint($_POST['phisk_dashboard_post_id']) : 0;
        $action = isset($_POST['phisk_dashboard_action']) ? sanitize_key(wp_unslash($_POST['phisk_dashboard_action'])) : '';
        $post = $post_id ? get_post($post_id) : null;
        $allowed_types = ['phisk_video', 'phisk_movie', 'phisk_tvshow', 'post'];

        if (!$post || !in_array($post->post_type, $allowed_types, true) || (int)$post->post_author !== (int)$user_id) {
            $this->dashboard_redirect('error', 'You do not have permission to delete this content.');
        }

        if ($action !== 'delete') {
            $this->dashboard_redirect('error', 'Invalid content action.');
        }

        if (!wp_trash_post($post_id)) {
            $this->dashboard_redirect('error', 'The content could not be deleted.');
        }

        $tab = $post->post_type === 'phisk_video' ? 'videos' : ($post->post_type === 'phisk_movie' ? 'movies' : ($post->post_type === 'phisk_tvshow' ? 'tvshows' : 'articles'));
        wp_safe_redirect(add_query_arg([
            'phisk_dashboard_tab' => $tab,
            'phisk_dashboard_status' => 'success',
            'phisk_dashboard_message' => rawurlencode('Content moved to the trash.'),
        ], wp_get_referer() ?: home_url('/')));
        exit;
    }

    private function dashboard_redirect($status, $message) {
        // Prefer the explicit channel return URL submitted by the dashboard form.
        // HTTP Referer is unreliable on mobile browsers and can send users home.
        $return_url = isset($_POST['phisk_dashboard_return_url'])
            ? esc_url_raw(wp_unslash($_POST['phisk_dashboard_return_url']))
            : '';
        if ($return_url) {
            $url = wp_validate_redirect($return_url, home_url('/'));
        } else {
            $url = wp_get_referer() ?: home_url('/');
        }
        $url = add_query_arg([
            'phisk_dashboard_tab' => 'profile',
            'phisk_dashboard_status' => sanitize_key($status),
            'phisk_dashboard_message' => rawurlencode($message),
        ], $url);
        wp_safe_redirect($url);
        exit;
    }

    private function dashboard_image_url($user_id, $meta_key, $size = 'large') {
        $attachment_id = absint(get_user_meta($user_id, $meta_key, true));
        return $attachment_id ? wp_get_attachment_image_url($attachment_id, $size) : '';
    }

    private function dashboard_status_label($status) {
        $labels = [
            'publish' => 'Published',
            'draft' => 'Draft',
            'pending' => 'Pending Review',
            'private' => 'Private',
            'future' => 'Scheduled',
        ];
        return $labels[$status] ?? ucfirst((string)$status);
    }

    private function dashboard_content_list($post_type, $user_id, $limit = 12, $page = 1) {
        $query = new WP_Query([
            'post_type' => $post_type,
            'post_status' => ['publish', 'draft', 'pending', 'private', 'future'],
            'author' => $user_id,
            'posts_per_page' => max(1, min(10, absint($limit))),
            'paged' => max(1, absint($page)),
            'orderby' => 'date',
            'order' => 'DESC',
            'no_found_rows' => false,
        ]);
        return $query;
    }

    private function dashboard_render_content_tab($post_type, $user_id, $label) {
        $page_key = $post_type === 'post' ? 'phisk_story_page' : 'phisk_video_page';
        $current_page = isset($_GET[$page_key]) ? max(1, absint(wp_unslash($_GET[$page_key]))) : 1;
        $query = $this->dashboard_content_list($post_type, $user_id, 10, $current_page);
        ob_start();
        echo '<section class="phisk-dashboard-panel phisk-dashboard-content-panel' . ($post_type === 'post' ? ' phisk-dashboard-stories-panel' : '') . '">';
        echo '<div class="phisk-dashboard-panel-head"><div><h2>' . esc_html($label) . '</h2><p>Your ' . esc_html(strtolower($label)) . ' on Phisk.</p></div></div>';
        if ($query->have_posts()) {
            echo '<div class="phisk-dashboard-content-list phisk-channel-compact-list">';
            while ($query->have_posts()) {
                $query->the_post();
                $id = get_the_ID();
                $status = get_post_status($id);
                $is_rejected_article = $post_type === 'post' && get_post_meta($id, '_phisk_article_review_status', true) === 'rejected';
                $thumb = get_the_post_thumbnail_url($id, 'medium');
                $published = $status === 'publish';
                $edit_url = $post_type === 'post' ? add_query_arg('edit_story', $id, $this->creator_page_url('phiskvideos_article_submit_page_id', 'write-article')) : get_edit_post_link($id, '');
                $view_url = $published ? get_permalink($id) : '';
                $status_label = $is_rejected_article ? 'Rejected' : $this->dashboard_status_label($status);
                $status_class = $is_rejected_article ? 'rejected' : $status;
                echo '<article class="phisk-channel-content-row">';
                echo '<div class="phisk-channel-content-thumb">';
                if ($thumb) {
                    echo '<img loading="lazy" src="' . esc_url($thumb) . '" alt="' . esc_attr(get_the_title()) . '">';
                } elseif ($post_type === 'post') {
                    echo '<span class="phisk-channel-story-placeholder" aria-label="Story image placeholder"></span>';
                } else {
                    echo '<span class="phisk-channel-video-placeholder">▶</span>';
                }
                echo '</div>';
                echo '<div class="phisk-channel-content-info"><h3>' . esc_html(get_the_title() ?: 'Untitled') . '</h3>';
                echo '<div class="phisk-channel-content-status"><span class="phisk-article-status-tag phisk-article-status-' . esc_attr($status_class) . '">' . esc_html($status_label) . '</span><span>' . esc_html(get_the_date('', $id)) . '</span></div>';
                if ($is_rejected_article) {
                    $reason_key = get_post_meta($id, '_phisk_article_rejection_reason', true);
                    $reason_labels = $this->article_rejection_reasons();
                    $reason_text = isset($reason_labels[$reason_key]) ? $reason_labels[$reason_key] : 'Please review your Story.';
                    $reason_note = get_post_meta($id, '_phisk_article_rejection_note', true);
                    echo '<details class="phisk-article-rejection-details"><summary>See reasons</summary><p>' . esc_html($reason_text) . '</p>';
                    if ($reason_note !== '') echo '<p>' . esc_html($reason_note) . '</p>';
                    echo '</details>';
                }
                echo '</div>';
                echo $this->dashboard_action_menu($id, $published ? $view_url : '', $edit_url, $published, $post_type === 'phisk_video' && $status === 'draft');
                echo '</article>';
            }
            echo '</div>';
            if ($query->max_num_pages > 1) {
                $base_url = remove_query_arg([$page_key]);
                echo '<nav class="phisk-channel-pagination" aria-label="' . esc_attr($label) . ' pagination">';
                if ($current_page > 1) echo '<a class="phisk-channel-page-link" href="' . esc_url(add_query_arg($page_key, $current_page - 1, $base_url)) . '">‹ Previous</a>';
                echo '<span class="phisk-channel-page-count">Page ' . esc_html($current_page) . ' of ' . esc_html($query->max_num_pages) . '</span>';
                if ($current_page < $query->max_num_pages) echo '<a class="phisk-channel-page-link" href="' . esc_url(add_query_arg($page_key, $current_page + 1, $base_url)) . '">Next ›</a>';
                echo '</nav>';
            }
        } else {
            $empty_kind = $post_type === 'post' ? 'story' : 'video';
            $empty_icon = $empty_kind === 'story' ? 'phisk-icon-story.svg' : 'phisk-icon-camera.svg';
            echo '<div class="phisk-dashboard-icon-empty"><img src="' . esc_url(plugins_url('assets/' . $empty_icon, __FILE__)) . '" width="48" height="48" alt="" aria-hidden="true"><p class="phisk-dashboard-empty">You have not uploaded any ' . esc_html(strtolower($label)) . ' yet.</p></div>';
        }
        echo '</section>';
        wp_reset_postdata();
        return ob_get_clean();
    }

        private function dashboard_action_menu($post_id, $view_url = '', $edit_url = '', $published = false, $video_draft = false) {
        $title = get_the_title($post_id) ?: 'Untitled';
        $post_author_id = (int) get_post_field('post_author', $post_id);
        $is_owner = is_user_logged_in() && $post_author_id === get_current_user_id();
        $share_url = $published ? get_permalink($post_id) : '';
        $continue_url = $video_draft ? add_query_arg(['phisk_dashboard_tab' => 'videos', 'edit_video' => $post_id]) : '';
        ob_start();
        ?>
        <details class="phisk-dashboard-actions">
          <summary class="phisk-dashboard-more" aria-label="More actions for <?php echo esc_attr($title); ?>" title="More actions"><span aria-hidden="true">⋮</span></summary>
          <div class="phisk-dashboard-action-menu">
            <?php if ($video_draft) : ?>
              <a href="<?php echo esc_url($continue_url); ?>">Continue Upload</a>
            <?php elseif ($published && $view_url) : ?>
              <a href="<?php echo esc_url($view_url); ?>">View</a>
            <?php endif; ?>
            <?php if ($edit_url && $is_owner) : ?>
              <a href="<?php echo esc_url($edit_url); ?>">Edit</a>
            <?php endif; ?>
            <?php if ($share_url) : ?>
              <button type="button" class="phisk-dashboard-share" data-share-url="<?php echo esc_url($share_url); ?>" data-share-title="<?php echo esc_attr($title); ?>">Share</button>
            <?php endif; ?>
            <?php if ($is_owner) : ?>
              <form method="post" onsubmit="return confirm('Delete this content? It will be moved to the trash.');">
                <?php wp_nonce_field('phisk_dashboard_content_action', 'phisk_dashboard_content_nonce'); ?>
                <input type="hidden" name="phisk_dashboard_content_action" value="1">
                <input type="hidden" name="phisk_dashboard_post_id" value="<?php echo esc_attr($post_id); ?>">
                <input type="hidden" name="phisk_dashboard_action" value="delete">
                <button type="submit" class="phisk-dashboard-delete">Delete</button>
              </form>
            <?php endif; ?>
          </div>
        </details>
        <?php
        return ob_get_clean();
    }

    /** Return the single Creator Studio page URL, creating the page when needed. */
    private function creator_studio_url() {
        $id = absint(get_option('phiskvideos_creator_studio_page_id'));
        if (!$id || !get_post_status($id) || !has_shortcode((string) get_post_field('post_content', $id), 'phisk_creator_studio')) {
            $id = $this->ensure_shortcode_page('phisk_creator_studio', 'Creator Studio', 'phiskvideos_creator_studio_page_id', 'creator-studio');
        $this->ensure_shortcode_page('phisk_account_settings', 'Settings', 'phiskvideos_settings_page_id', 'settings');
        $this->ensure_shortcode_page('phisk_notifications', 'Notifications', 'phiskvideos_notifications_page_id', 'phisk-notifications');
        $this->ensure_shortcode_page('phisk_messages', 'Messages', 'phiskvideos_messages_page_id', 'phisk-messages');
        $this->ensure_shortcode_page('phisk_strike_appeal', 'Account Standing', 'phiskvideos_strike_appeal_page_id', 'account-standing');
        }
        if ($id) {
            $url = get_permalink($id);
            if ($url) return $url;
        }
        return home_url('/creator-studio/');
    }

    /** A reusable link for the existing mobile menu or a WordPress navigation menu. */
    public function creator_studio_link_shortcode($atts = []) {
        if (!is_user_logged_in() || !$this->user_has_phisk_channel(get_current_user_id())) return '';
        $atts = shortcode_atts(['label' => 'Creator Studio', 'class' => 'phisk-creator-studio-menu-link'], $atts, 'phisk_creator_studio_link');
        $label = sanitize_text_field($atts['label']);
        $class = sanitize_html_class($atts['class']);
        return '<a class="' . esc_attr($class) . '" href="' . esc_url($this->creator_studio_url()) . '">' . esc_html($label ?: 'Creator Studio') . '</a>';
    }

    /**
     * Creator Studio v1: an analytics overview built from genuine platform data.
     * Promotional/demo display counts are deliberately excluded from analytics.
     */
    public function creator_studio_shortcode($atts = []) {
        if (!is_user_logged_in()) {
            return '<section class="phisk-creator-studio-login phisk-auth-gate phisk-dashboard-login"><h2>Your creator space.</h2><p>Please log in to view your creator analytics.</p></section>';
        }

        $channel_gate = $this->channel_creation_gate();
        if ($channel_gate !== '') return $channel_gate;
        $this->enqueue_style();
        $user_id = get_current_user_id();
        $published_video_ids = get_posts([
            'post_type' => 'phisk_video', 'post_status' => 'publish', 'author' => $user_id,
            'posts_per_page' => -1, 'fields' => 'ids', 'no_found_rows' => true,
        ]);
        $draft_video_ids = get_posts([
            'post_type' => 'phisk_video', 'post_status' => ['draft', 'pending', 'private', 'future'], 'author' => $user_id,
            'posts_per_page' => -1, 'fields' => 'ids', 'no_found_rows' => true,
        ]);
        $published_article_ids = get_posts([
            'post_type' => 'post', 'post_status' => 'publish', 'author' => $user_id,
            'posts_per_page' => -1, 'fields' => 'ids', 'no_found_rows' => true,
        ]);
        $draft_article_ids = get_posts([
            'post_type' => 'post', 'post_status' => ['draft', 'pending', 'private', 'future'], 'author' => $user_id,
            'posts_per_page' => -1, 'fields' => 'ids', 'no_found_rows' => true,
        ]);

        $genuine_views = 0;
        $likes = 0;
        $approved_comments = 0;
        $top_videos = [];
        foreach ($published_video_ids as $video_id) {
            // Do not call phisk_display_video_views(): it intentionally includes promotional figures.
            $genuine_views += max(0, (int) get_post_meta($video_id, '_phisk_views', true));
            $likes += max(0, (int) get_post_meta($video_id, '_phisk_video_like_count', true));
            $approved_comments += (int) get_comments(['post_id' => $video_id, 'status' => 'approve', 'type' => 'comment', 'count' => true]);
            $top_videos[] = [
                'id' => (int) $video_id,
                'title' => get_the_title($video_id),
                'views' => max(0, (int) get_post_meta($video_id, '_phisk_views', true)),
                'url' => get_permalink($video_id),
            ];
        }
        usort($top_videos, function ($a, $b) { return $b['views'] <=> $a['views']; });
        $top_videos = array_slice($top_videos, 0, 5);
        $channel_url = method_exists($this, 'phisk_channel_url') ? $this->phisk_channel_url($user_id) : home_url('/');
        $dashboard_url = add_query_arg('phisk_dashboard_tab', 'videos', $channel_url);
        $articles_url = add_query_arg('phisk_dashboard_tab', 'articles', $channel_url);
        $upload_url = $this->creator_page_url('phiskvideos_upload_page_id', 'upload-video');
        $article_submit_url = $this->creator_page_url('phiskvideos_article_submit_page_id', 'write-article');
        $article_url = add_query_arg('phisk_dashboard_tab', 'articles', $channel_url);
        $display_name = $this->phisk_creator_display_name(get_current_user_id());
        $monetization = $this->get_creator_monetization_summary($user_id);
        $monetization_status = get_user_meta($user_id, '_phisk_monetization_status', true);
        if (!$monetization_status) $monetization_status = 'not_applied';
        $eligibility = $this->get_creator_eligibility($user_id);

        // Build a private, creator-specific history from real monetization ledger events.
        // Historical per-day view totals cannot be reconstructed from the aggregate view counter,
        // so the chart uses verified, reward-eligible events recorded by the existing ledger.
        global $wpdb;
        $ledger_table = $this->monetization_table('ledger');
        $chart_cutoff = gmdate('Y-m-d H:i:s', time() - (365 * DAY_IN_SECONDS));
        $chart_rows = $wpdb->get_results($wpdb->prepare(
            "SELECT DATE(created_at) AS event_day, content_type, status, COUNT(*) AS event_count, COALESCE(SUM(amount_micros),0) AS amount_total
             FROM {$ledger_table} WHERE user_id=%d AND created_at >= %s
             GROUP BY DATE(created_at), content_type, status ORDER BY event_day ASC",
            $user_id, $chart_cutoff
        ), ARRAY_A);
        $chart_history = [];
        for ($offset = 364; $offset >= 0; $offset--) {
            $day_key = gmdate('Y-m-d', time() - ($offset * DAY_IN_SECONDS));
            $chart_history[$day_key] = ['date'=>$day_key, 'label'=>wp_date('M j', strtotime($day_key . ' 12:00:00 UTC')), 'video'=>0, 'article'=>0, 'earnings'=>0];
        }
        foreach ((array)$chart_rows as $row) {
            $day_key = (string)$row['event_day'];
            if (!isset($chart_history[$day_key]) || $row['status'] === 'reversed') continue;
            if ($row['status'] === 'accrued') {
                if ($row['content_type'] === 'video') $chart_history[$day_key]['video'] += (int)$row['event_count'];
                if ($row['content_type'] === 'article') $chart_history[$day_key]['article'] += (int)$row['event_count'];
            }
            $chart_history[$day_key]['earnings'] += (int)$row['amount_total'];
        }
        $chart_history_json = wp_json_encode(array_values($chart_history));
        $pending_earnings_micros = (int)$wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(amount_micros),0) FROM {$ledger_table} WHERE user_id=%d AND status IN ('pending','processing')",
            $user_id
        ));

        ob_start();
        ?>
        <section class="phisk-creator-studio">
          <style>
            .phisk-creator-studio{margin:20px auto;max-width:1180px;color:#202124;--phisk-violet:#7C3AED;--phisk-violet-hover:#6D28D9;--phisk-muted:#6b7280}
            .phisk-creator-studio .phisk-studio-back{display:inline-flex;align-items:center;gap:7px;margin:0 0 16px;color:#6D28D9;text-decoration:none;font-size:13px;font-weight:700}
            .phisk-creator-studio .phisk-studio-back:hover{color:#5B21B6;text-decoration:underline}
            .phisk-creator-studio *{box-sizing:border-box}
            .phisk-creator-studio-head{display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap;margin-bottom:22px}
            .phisk-creator-studio-head h2{margin:0 0 5px;font-size:clamp(24px,3vw,32px);line-height:1.2}
            .phisk-creator-studio-head p{margin:0;opacity:.72}
            .phisk-creator-studio-actions{display:flex;gap:8px;flex-wrap:wrap}
            .phisk-creator-studio .phisk-studio-link{display:inline-flex;align-items:center;justify-content:center;padding:11px 16px;border:0!important;border-radius:10px;text-decoration:none;font-weight:700;font-size:14px;color:#6D28D9;background:#fff;box-shadow:0 3px 0 #e5e7eb,0 5px 12px rgba(17,24,39,.07);transition:transform .16s ease,box-shadow .16s ease,background .16s ease}
            .phisk-creator-studio .phisk-studio-link:hover{transform:translateY(-1px);box-shadow:0 4px 0 #e5e7eb,0 8px 16px rgba(17,24,39,.09);background:#faf9ff}
            .phisk-creator-studio .phisk-studio-link:focus-visible{outline:2px solid #7C3AED!important;outline-offset:3px}
            .phisk-creator-studio .phisk-studio-link-primary{background:#7C3AED;color:#fff;border:0!important;box-shadow:0 3px 0 #6D28D9,0 5px 12px rgba(124,58,237,.16)}
            .phisk-creator-studio .phisk-studio-link-primary:hover{background:#6D28D9;box-shadow:0 4px 0 #5B21B6,0 8px 16px rgba(124,58,237,.2)}
            .phisk-studio-metrics{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;margin:0 0 24px}
            .phisk-studio-metric,.phisk-studio-panel{border:1px solid #ececf1;border-radius:15px;padding:18px;min-width:0;background:#fff;box-shadow:0 3px 14px rgba(17,24,39,.035)}.phisk-studio-metric{padding:16px 17px;transition:box-shadow .18s ease,transform .18s ease}.phisk-studio-metric:hover{box-shadow:0 7px 22px rgba(17,24,39,.07);transform:translateY(-1px)}
            .phisk-studio-metric span{display:block;font-size:13px;line-height:1.25;opacity:.72;margin-bottom:5px}.phisk-studio-metric .phisk-studio-metric-label{display:flex;align-items:center;gap:7px;min-height:18px;line-height:1.25;margin-bottom:5px}.phisk-studio-stat-icon{width:17px;height:17px;flex:0 0 17px;fill:none;stroke:currentColor;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round;opacity:.88;transition:transform .2s ease,opacity .2s ease}.phisk-studio-metric:hover .phisk-studio-stat-icon{transform:translateY(-1px);opacity:1}
            .phisk-studio-metric strong{display:block;font-size:clamp(23px,3vw,30px);line-height:1.15;overflow-wrap:anywhere}
            .phisk-studio-metric small{display:block;margin-top:4px;line-height:1.3;opacity:.68;font-size:12px}
            .phisk-studio-panels{display:grid;grid-template-columns:minmax(0,1.5fr) minmax(240px,1fr);gap:16px}
            .phisk-studio-panel h3{margin:0 0 14px;font-size:18px}
            .phisk-studio-top-video{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:11px 0;border-bottom:1px solid rgba(127,127,127,.18)}
            .phisk-studio-top-video:last-child{border-bottom:0;padding-bottom:0}
            .phisk-studio-top-video a{font-weight:600;text-decoration:none;overflow-wrap:anywhere}
            .phisk-studio-top-video span{white-space:nowrap;font-size:13px;opacity:.75}
            .phisk-studio-empty{opacity:.72;margin:0}
            .phisk-studio-monetization-panel{border:0!important;outline:0!important;box-shadow:none!important;padding:0!important;background:transparent!important}.phisk-studio-monetization-panel .phisk-studio-monetization-note{padding:0;border:0;outline:0;background:transparent;font-size:14px;line-height:1.5}.phisk-monetization-progress-list{display:grid;gap:15px;margin:18px 0}.phisk-monetization-progress-item{min-width:0}.phisk-monetization-progress-heading{display:flex;justify-content:space-between;align-items:baseline;gap:12px;margin-bottom:7px;font-size:14px;line-height:1.35}.phisk-monetization-progress-heading strong{font-weight:650;white-space:nowrap}.phisk-monetization-progress-track{height:9px;width:100%;overflow:hidden;background:#dedede;border-radius:99px}.phisk-monetization-progress-fill{height:100%;max-width:100%;background:#20a464;border-radius:99px;transition:width .25s ease}.phisk-monetization-status-row{display:flex;align-items:center;flex-wrap:wrap;gap:10px;margin:18px 0 10px}.phisk-monetization-status-label{font-size:14px;font-weight:650}.phisk-monetization-status{display:inline-flex;align-items:center;justify-content:center;padding:6px 11px;border-radius:5px;font-size:12px;font-weight:800;letter-spacing:.045em;line-height:1.2}.phisk-monetization-status-approved{background:#16834b;color:#fff}.phisk-monetization-status-rejected{background:#d62828;color:#fff}.phisk-monetization-status-pending{background:#111;color:#fff}
            .phisk-studio-shortcuts{display:flex;flex-wrap:wrap;gap:10px;margin-top:14px}
            .phisk-studio-earnings{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin:0 0 16px}
            .phisk-studio-earning{padding:13px 15px;border-bottom:1px solid rgba(127,127,127,.35);min-width:0}
            .phisk-studio-earning span{display:block;font-size:12px;line-height:1.3;opacity:.72;margin-bottom:5px}
            .phisk-studio-earning strong{display:block;font-size:clamp(18px,2.4vw,24px);line-height:1.2;overflow-wrap:anywhere}
            .phisk-studio-chart{padding:16px 0 8px;margin-bottom:22px;border-bottom:1px solid rgba(127,127,127,.25)}
            .phisk-studio-chart-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:12px}
            .phisk-studio-chart-head h3{margin:0 0 4px;font-size:19px}
            .phisk-studio-chart-head p{margin:0;font-size:13px;opacity:.7;line-height:1.4}
            .phisk-studio-chart-controls{display:flex;gap:6px;flex-wrap:wrap}
            .phisk-studio-chart-controls button,.phisk-studio-chart-controls select{font:inherit;font-size:12px;line-height:1.2;padding:9px 12px;border:0!important;border-radius:9px;background:#fff;color:#6D28D9;box-shadow:0 2px 0 #e5e7eb,0 3px 8px rgba(17,24,39,.05);cursor:pointer}
            .phisk-studio-chart-controls button[aria-pressed="true"]{background:#7C3AED;color:#fff;box-shadow:0 2px 0 #6D28D9,0 3px 8px rgba(124,58,237,.14)}
            .phisk-studio-chart-controls select{cursor:pointer}
            .phisk-studio-chart-value{font-size:24px;font-weight:700;line-height:1.2;margin:8px 0 2px}
            .phisk-studio-chart-caption{font-size:12px;opacity:.7}
            .phisk-studio-chart svg{display:block;width:100%;height:auto;min-height:190px;overflow:visible}
            .phisk-studio-chart .chart-grid{stroke:currentColor;opacity:.12;stroke-width:1}
            .phisk-studio-chart .chart-bar{fill:#7C3AED;opacity:.82;transition:opacity .15s ease}\n            .phisk-studio-chart .chart-separator{stroke:currentColor;stroke-width:.65;opacity:.13}
            .phisk-studio-chart .chart-bar:hover{opacity:1}
            .phisk-studio-chart .chart-label{fill:currentColor;font-size:11px;opacity:.65}
            @media(max-width:700px){.phisk-studio-metrics{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.phisk-studio-metric{padding:11px 12px}.phisk-studio-panels{grid-template-columns:1fr}.phisk-creator-studio .phisk-studio-link{padding:9px 11px}.phisk-studio-earnings{gap:4px}.phisk-studio-earning{padding:10px 7px}.phisk-studio-earning strong{font-size:17px}.phisk-studio-chart{padding-top:12px}.phisk-studio-chart-controls{width:100%}.phisk-studio-chart-controls button{padding:7px 8px}}
            @media(max-width:390px){.phisk-studio-metrics{grid-template-columns:1fr 1fr}.phisk-studio-metric strong{font-size:22px}}
          </style>
          <a class="phisk-studio-back" href="<?php echo esc_url(home_url('/')); ?>" data-phisk-previous-link>← Back</a>
          <div class="phisk-creator-studio-head">
            <div><h2>Creator Studio</h2><p>Welcome back, <?php echo esc_html($display_name); ?>. Here is your content performance.</p></div>
            <div class="phisk-creator-studio-actions"><a class="phisk-studio-link phisk-studio-link-primary" href="<?php echo esc_url($upload_url); ?>">Upload video</a><a class="phisk-studio-link" href="<?php echo esc_url($article_submit_url); ?>">Write a Story</a><a class="phisk-studio-link" href="<?php echo esc_url($article_url); ?>">Manage content</a></div>
          </div>
          <section class="phisk-studio-earnings" aria-label="Earnings summary">
            <div class="phisk-studio-earning"><span>Total earnings</span><strong><?php echo esc_html($this->format_monetization_amount($monetization['total_micros'])); ?></strong></div>
            <div class="phisk-studio-earning"><span>Pending earnings</span><strong><?php echo esc_html($this->format_monetization_amount($pending_earnings_micros)); ?></strong></div>
            <div class="phisk-studio-earning"><span>Available for withdrawal</span><strong><?php echo esc_html($this->format_monetization_amount($monetization['available_micros'])); ?></strong></div>
          </section>
          <section class="phisk-studio-chart" data-phisk-chart aria-label="Creator performance chart">
            <div class="phisk-studio-chart-head">
              <div><h3>Creator Performance</h3><p>Verified, reward-eligible activity recorded for your content.</p><div class="phisk-studio-chart-value" data-chart-value>0</div><div class="phisk-studio-chart-caption" data-chart-caption>Video views · Last 7 days</div></div>
              <div class="phisk-studio-chart-controls" aria-label="Chart options">
                <button type="button" data-metric="video" aria-pressed="true">Video Views</button>
                <button type="button" data-metric="article" aria-pressed="false">Story Views</button>
                <button type="button" data-metric="earnings" aria-pressed="false">Earnings</button>
                <select data-chart-period aria-label="Chart time period"><option value="7">7 days</option><option value="30">30 days</option><option value="90">90 days</option><option value="365">12 months</option></select>
              </div>
            </div>
            <svg viewBox="0 0 720 220" role="img" aria-label="Creator performance vertical bar chart" data-chart-svg></svg>
          </section>
          <div class="phisk-studio-metrics" aria-label="Creator analytics overview">
            <div class="phisk-studio-metric"><span class="phisk-studio-metric-label"><svg class="phisk-studio-stat-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>Verified video views</span><strong><?php echo esc_html(number_format_i18n($genuine_views)); ?></strong><small>Excludes promotional display figures</small></div>
            <div class="phisk-studio-metric"><span class="phisk-studio-metric-label"><svg class="phisk-studio-stat-icon" viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m10 9 5 3-5 3Z"/></svg>Published videos</span><strong><?php echo esc_html(number_format_i18n(count($published_video_ids))); ?></strong><small><?php echo esc_html(number_format_i18n(count($draft_video_ids))); ?> drafts or awaiting review</small></div>
            <div class="phisk-studio-metric"><span class="phisk-studio-metric-label"><svg class="phisk-studio-stat-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M7 10v10H4a2 2 0 0 1-2-2v-6a2 2 0 0 1 2-2h3Zm0 10h9.2a3 3 0 0 0 2.9-2.2l1.5-5.5A2.5 2.5 0 0 0 18.2 9H14l.7-3.1A2.4 2.4 0 0 0 12.4 3L7 10v10Z"/></svg>Video likes</span><strong><?php echo esc_html(number_format_i18n($likes)); ?></strong><small>Recorded on your published videos</small></div>
            <div class="phisk-studio-metric"><span class="phisk-studio-metric-label"><svg class="phisk-studio-stat-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M20 11.5a7.5 7.5 0 0 1-7.5 7.5H5l-3 2v-9.5A7.5 7.5 0 0 1 9.5 4H12a8 8 0 0 1 8 7.5Z"/><path d="M8 11h.01M12 11h.01M16 11h.01"/></svg>Video comments</span><strong><?php echo esc_html(number_format_i18n($approved_comments)); ?></strong><small>Approved comments</small></div>
            <div class="phisk-studio-metric"><span class="phisk-studio-metric-label"><svg class="phisk-studio-stat-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 3h9l4 4v14H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Z"/><path d="M14 3v5h5M8 12h8M8 16h8"/></svg>Published Stories</span><strong><?php echo esc_html(number_format_i18n(count($published_article_ids))); ?></strong><small><?php echo esc_html(number_format_i18n(count($draft_article_ids))); ?> drafts or awaiting review</small></div>
          </div>
          <section class="phisk-studio-panel phisk-studio-monetization-panel" style="margin-bottom:16px"><h3>Your monetization</h3>
            <div class="phisk-studio-monetization-note">Your estimated earnings can grow from your first eligible video view or Story read. Earnings are shown even before you qualify to withdraw. Withdrawal access requires the configured minimum eligible views in the last 90 days, 100 subscribers, an account age of at least 30 days, administrator approval, and a $50 available balance.</div>
            <div class="phisk-monetization-progress-list" aria-label="Monetization eligibility progress">
              <?php $phisk_views_progress = min(100, max(0, (int) $eligibility['views'])); $phisk_subscribers_progress = min(100, max(0, (int) $eligibility['subscribers'])); $phisk_days_progress = min(100, max(0, (int) $eligibility['account_days'] / 30 * 100)); ?>
              <div class="phisk-monetization-progress-item"><div class="phisk-monetization-progress-heading"><span>Recent eligible views</span><strong><?php echo esc_html(number_format_i18n($eligibility['views'])); ?>/100</strong></div><div class="phisk-monetization-progress-track" role="progressbar" aria-label="Recent eligible views" aria-valuemin="0" aria-valuemax="100" aria-valuenow="<?php echo esc_attr($phisk_views_progress); ?>"><div class="phisk-monetization-progress-fill" style="width:<?php echo esc_attr($phisk_views_progress); ?>%"></div></div></div>
              <div class="phisk-monetization-progress-item"><div class="phisk-monetization-progress-heading"><span>Subscribers</span><strong><?php echo esc_html(number_format_i18n($eligibility['subscribers'])); ?>/100</strong></div><div class="phisk-monetization-progress-track" role="progressbar" aria-label="Subscribers" aria-valuemin="0" aria-valuemax="100" aria-valuenow="<?php echo esc_attr($phisk_subscribers_progress); ?>"><div class="phisk-monetization-progress-fill" style="width:<?php echo esc_attr($phisk_subscribers_progress); ?>%"></div></div></div>
              <div class="phisk-monetization-progress-item"><div class="phisk-monetization-progress-heading"><span>Account age</span><strong><?php echo esc_html(number_format_i18n($eligibility['account_days'])); ?>/30 days</strong></div><div class="phisk-monetization-progress-track" role="progressbar" aria-label="Account age" aria-valuemin="0" aria-valuemax="100" aria-valuenow="<?php echo esc_attr($phisk_days_progress); ?>"><div class="phisk-monetization-progress-fill" style="width:<?php echo esc_attr($phisk_days_progress); ?>%"></div></div></div>
            </div>
            <?php if (in_array($monetization_status, ['pending', 'approved', 'rejected', 'suspended'], true)) : ?>
              <?php $phisk_status_label = $monetization_status === 'approved' ? 'APPROVED' : ($monetization_status === 'rejected' ? 'REJECTED' : ($monetization_status === 'suspended' ? 'SUSPENDED' : 'PENDING')); $phisk_status_class = $monetization_status === 'approved' ? 'approved' : ($monetization_status === 'rejected' || $monetization_status === 'suspended' ? 'rejected' : 'pending'); ?>
              <div class="phisk-monetization-status-row"><span class="phisk-monetization-status-label">Application status</span><span class="phisk-monetization-status phisk-monetization-status-<?php echo esc_attr($phisk_status_class); ?>"><?php echo esc_html($phisk_status_label); ?></span></div>
            <?php endif; ?>
            <?php if ($monetization_status === 'rejected' && get_user_meta($user_id, '_phisk_monetization_rejection_reason', true)) : ?><p class="phisk-studio-empty"><strong>Application feedback:</strong> <?php echo esc_html(get_user_meta($user_id, '_phisk_monetization_rejection_reason', true)); ?></p><?php endif; ?>
            <?php if ($monetization_status === 'not_applied' || $monetization_status === 'rejected') : ?><form method="post" style="margin-top:12px"><?php wp_nonce_field('phisk_monetization_apply','phisk_monetization_nonce'); ?><input type="hidden" name="phisk_monetization_action" value="apply"><button class="phisk-studio-link phisk-studio-link-primary" type="submit">Apply for monetization</button></form><?php elseif ($monetization_status === 'approved' && $monetization['available_micros'] >= 50000000 && $eligibility['eligible']) : ?><form method="post" style="margin-top:12px"><?php wp_nonce_field('phisk_monetization_payout','phisk_monetization_nonce'); ?><input type="hidden" name="phisk_monetization_action" value="payout"><button class="phisk-studio-link phisk-studio-link-primary" type="submit">Request payout</button></form><?php else : ?><p class="phisk-studio-empty" style="margin-top:10px">Withdrawals are currently locked until eligibility and approval requirements are satisfied and your available balance reaches $50.</p><?php endif; ?>
          </section>
          <div class="phisk-studio-panels">
            <section class="phisk-studio-panel"><h3>Your top videos by views</h3>
              <?php if ($top_videos) : foreach ($top_videos as $video) : ?>
                <div class="phisk-studio-top-video"><a href="<?php echo esc_url($video['url']); ?>"><?php echo esc_html($video['title']); ?></a><span><?php echo esc_html(number_format_i18n($video['views'])); ?> views</span></div>
              <?php endforeach; else : ?><?php echo $this->render_creator_empty_state('video', 'No videos yet', 'Your published videos will appear here when you upload and publish them.'); ?><?php endif; ?>
            </section>
            <section class="phisk-studio-panel"><h3>Next steps</h3>
              <p class="phisk-studio-empty">Keep your channel active by publishing useful videos and Stories. Earnings and payout information will be added after the platform's monetization rules and tracking are verified.</p>
              <div class="phisk-studio-shortcuts"><a class="phisk-studio-link" href="<?php echo esc_url($dashboard_url); ?>">Manage videos</a><a class="phisk-studio-link" href="<?php echo esc_url($article_submit_url); ?>">Write a Story</a><a class="phisk-studio-link" href="<?php echo esc_url($articles_url); ?>">My Stories</a><a class="phisk-studio-link" href="<?php echo esc_url($channel_url); ?>">View channel</a></div>
            </section>
          </div>
        </section>
        ?>
        <script>
        (function(){
          document.querySelectorAll('[data-phisk-previous-link]').forEach(function(link){
            if(link.dataset.previousReady==='1')return;link.dataset.previousReady='1';
            link.addEventListener('click',function(event){
              try{var ref=document.referrer;if(ref&&new URL(ref).origin===window.location.origin&&window.history.length>1){event.preventDefault();window.history.back();}}catch(e){}
            });
          });
          var root=document.currentScript&&document.currentScript.closest('.phisk-creator-studio');
          if(!root){var candidates=document.querySelectorAll('.phisk-creator-studio');root=candidates.length?candidates[candidates.length-1]:null;}
          if(!root||root.dataset.chartReady==='1')return;root.dataset.chartReady='1';
          var history=<?php echo $chart_history_json ? $chart_history_json : '[]'; ?>;
          var svg=root.querySelector('[data-chart-svg]'),valueEl=root.querySelector('[data-chart-value]'),caption=root.querySelector('[data-chart-caption]'),periodEl=root.querySelector('[data-chart-period]');
          var metric='video',period=7;
          var labels={video:'Video views',article:'Story views',earnings:'Earnings'};
          function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
          function money(micros){return '$'+(Number(micros||0)/1000000).toFixed(6);}
          function draw(){
            if(!svg)return;
            var rows=history.slice(-period),key=metric,vals=rows.map(function(r){return Number(r[key]||0);});
            var total=vals.reduce(function(a,b){return a+b;},0),latest=vals.length?vals[vals.length-1]:0;
            valueEl.textContent=metric==='earnings'?money(total):Math.round(total).toLocaleString();
            caption.textContent=labels[metric]+' · Last '+(period===365?'12 months':period+' days')+' · '+(metric==='earnings'?'total for period':'total for period');
            var W=720,H=220,L=42,R=12,T=16,B=34,innerW=W-L-R,innerH=H-T-B;
            var max=Math.max(1,Math.max.apply(null,vals)),slot=vals.length?innerW/vals.length:innerW,barW=Math.max(1,Math.min(58,slot*.94));
            function y(v){return T+innerH-(v/max)*innerH;}
            var out='';
            for(var g=0;g<4;g++){var gy=T+innerH*g/3;out+='<line class="chart-grid" x1="'+L+'" y1="'+gy.toFixed(2)+'" x2="'+(W-R)+'" y2="'+gy.toFixed(2)+'"></line>';}
            vals.forEach(function(v,i){
              var x=L+i*slot+(slot-barW)/2,top=y(v),height=Math.max(1,T+innerH-top),bottom=T+innerH;
              var radius=Math.min(7,barW/4,height/2),right=x+barW;
              var date=rows[i]?rows[i].label:'';
              var shown=metric==='earnings'?money(v):Math.round(v).toLocaleString();
              if(i>0){var sx=L+i*slot;out+='<line class="chart-separator" x1="'+sx.toFixed(2)+'" y1="'+(T+2)+'" x2="'+sx.toFixed(2)+'" y2="'+bottom.toFixed(2)+'"></line>';}
              var d='M '+x.toFixed(2)+' '+bottom.toFixed(2)+' L '+x.toFixed(2)+' '+(top+radius).toFixed(2)+' Q '+x.toFixed(2)+' '+top.toFixed(2)+' '+(x+radius).toFixed(2)+' '+top.toFixed(2)+' L '+(right-radius).toFixed(2)+' '+top.toFixed(2)+' Q '+right.toFixed(2)+' '+top.toFixed(2)+' '+right.toFixed(2)+' '+(top+radius).toFixed(2)+' L '+right.toFixed(2)+' '+bottom.toFixed(2)+' Z';
              out+='<path class="chart-bar" d="'+d+'"><title>'+esc(date)+': '+esc(shown)+'</title></path>';
            });
            var ticks=[0,Math.floor((rows.length-1)/2),rows.length-1].filter(function(v,i,a){return a.indexOf(v)===i&&v>=0;});
            ticks.forEach(function(i){var x=L+i*slot+slot/2;out+='<text class="chart-label" text-anchor="'+(i===0?'start':(i===rows.length-1?'end':'middle'))+'" x="'+x.toFixed(2)+'" y="'+(H-10)+'">'+esc(rows[i]?rows[i].label:'')+'</text>';});
            if(!vals.some(function(v){return v>0;}))out+='<text class="chart-label" x="'+(W/2)+'" y="'+(T+innerH/2)+'" text-anchor="middle">No recorded activity for this period yet</text>';
            svg.innerHTML=out;
          }
          root.querySelectorAll('[data-metric]').forEach(function(btn){btn.addEventListener('click',function(){metric=btn.getAttribute('data-metric');root.querySelectorAll('[data-metric]').forEach(function(other){other.setAttribute('aria-pressed',other===btn?'true':'false');});draw();});});
          if(periodEl)periodEl.addEventListener('change',function(){period=Math.max(1,parseInt(periodEl.value,10)||7);draw();});
          draw();
        })();
        </script>
        <?php
        return ob_get_clean();
    }

    /** Dedicated account settings page; account data remains tied to the logged-in user. */
    /** Remove only a device owned by the currently authenticated user. */
    public function handle_user_device_removal() {
        if (!is_user_logged_in() || empty($_POST['phisk_remove_my_device'])) return;
        if (!isset($_POST['phisk_my_devices_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['phisk_my_devices_nonce'])), 'phisk_remove_my_device')) return;
        global $wpdb;
        $device_id = absint($_POST['device_row_id'] ?? 0);
        if ($device_id) $wpdb->delete($this->app_device_table(), ['id'=>$device_id, 'user_id'=>get_current_user_id()], ['%d','%d']);
        $url = add_query_arg(['phisk_settings_tab'=>'security','phisk_devices_updated'=>'1'], $this->account_settings_url());
        wp_safe_redirect($url); exit;
    }

    /** FCM HTTP v1 configuration and delivery. The service-account JSON must remain outside the web root. */
    private function fcm_service_account_path() {
        return (string) get_option('phisk_fcm_service_account_path', '');
    }

    public function register_fcm_admin_menu() {
        add_submenu_page('options-general.php', 'Phisk FCM Settings', 'Phisk FCM', 'manage_options', 'phisk-fcm-settings', [$this, 'fcm_admin_page']);
    }

    public function fcm_admin_page() {
        if (!current_user_can('manage_options')) return;
        $path = $this->fcm_service_account_path();
        $notice = isset($_GET['phisk_fcm_test']) ? sanitize_key(wp_unslash($_GET['phisk_fcm_test'])) : '';
        echo '<div class="wrap"><h1>Phisk Firebase Cloud Messaging</h1>';
        if ($notice === 'success') echo '<div class="notice notice-success"><p>Firebase authentication successful. No push notification was sent.</p></div>';
        elseif ($notice === 'failed') { $msg = get_transient('phisk_fcm_last_test_error'); delete_transient('phisk_fcm_last_test_error'); echo '<div class="notice notice-error"><p>Firebase connection test failed: ' . esc_html($msg ?: 'Unknown error') . '</p></div>'; }
        echo '<p>Configure the private Firebase Admin SDK service-account file. Keep this file outside the public website directory and never paste its contents here.</p>';
        echo '<form method="post" action="options.php">';
        settings_fields('phisk_fcm_settings');
        echo '<table class="form-table"><tr><th scope="row"><label for="phisk_fcm_service_account_path">Service-account JSON path</label></th><td><input name="phisk_fcm_service_account_path" id="phisk_fcm_service_account_path" type="text" class="regular-text" value="' . esc_attr($path) . '" placeholder="/home/ACCOUNT/private/firebase-service-account.json" autocomplete="off"><p class="description">Enter the absolute server path. The file should have permissions 600 and must not be in public_html.</p></td></tr></table>';
        submit_button('Save Firebase settings'); echo '</form>';
        echo '<hr><h2>Connection test</h2><p>This verifies file access and obtains a Firebase OAuth access token. It does not send a notification.</p><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('phisk_fcm_test_connection');
        echo '<input type="hidden" name="action" value="phisk_fcm_test_connection">';
        submit_button('Test Firebase connection', 'secondary', 'submit', false);
        echo '</form><p><strong>Push delivery:</strong> ' . ($path ? 'Service-account path saved. Run the connection test before sending.' : 'Not configured.') . '</p>';
        $devices = $this->get_fcm_test_devices();
        $send_notice = isset($_GET['phisk_fcm_send']) ? sanitize_key(wp_unslash($_GET['phisk_fcm_send'])) : '';
        if ($send_notice === 'success') {
            $detail = get_transient('phisk_fcm_last_send_result'); delete_transient('phisk_fcm_last_send_result');
            echo '<div class="notice notice-success"><p>' . esc_html($detail ?: 'Firebase accepted the test message.') . '</p></div>';
        } elseif ($send_notice === 'failed') {
            $detail = get_transient('phisk_fcm_last_send_error'); delete_transient('phisk_fcm_last_send_error');
            echo '<div class="notice notice-error"><p>Test notification failed: ' . esc_html($detail ?: 'Unknown error') . '</p></div>';
        }
        echo '<hr><h2>Send a test push notification</h2><p>Sends one test notification to one selected registered Android device. Firebase acceptance does not guarantee that Android displayed it; confirm receipt on the phone. FCM tokens are never shown.</p>';
        if (!$devices) {
            echo '<p><em>No registered devices are available.</em></p>';
        } else {
            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
            wp_nonce_field('phisk_fcm_send_test');
            echo '<input type="hidden" name="action" value="phisk_fcm_send_test">';
            echo '<table class="form-table"><tr><th scope="row"><label for="phisk_fcm_device_id">Registered device</label></th><td><select required name="device_row_id" id="phisk_fcm_device_id">';
            foreach ($devices as $device) {
                $label = sprintf('%s — %s — %s — %s', $device->display_name ?: ($device->user_login ?: 'User #' . $device->user_id), strtoupper($device->platform), $device->app_version ?: 'Unknown version', $device->device_label);
                echo '<option value="' . absint($device->id) . '">' . esc_html($label) . '</option>';
            }
            echo '</select></td></tr><tr><th scope="row"><label for="phisk_fcm_test_title">Notification title</label></th><td><input required maxlength="100" class="regular-text" type="text" name="notification_title" id="phisk_fcm_test_title" value="PhiskVideos Test Notification"></td></tr><tr><th scope="row"><label for="phisk_fcm_test_message">Notification message</label></th><td><textarea required maxlength="300" class="large-text" rows="3" name="notification_message" id="phisk_fcm_test_message">Congratulations! Your PhiskVideos device has received a test push notification.</textarea></td></tr></table>';
            submit_button('Send Test Notification', 'primary');
            echo '</form>';
        }
        echo '</div>';
    }

    public function handle_fcm_test_connection() {
        if (!current_user_can('manage_options')) wp_die('You do not have permission to test Firebase.');
        check_admin_referer('phisk_fcm_test_connection');
        delete_transient('phisk_fcm_access_token');
        $result = $this->get_fcm_access_token(true);
        if (is_wp_error($result)) {
            set_transient('phisk_fcm_last_test_error', $result->get_error_message(), 60);
            wp_safe_redirect(add_query_arg(['page'=>'phisk-fcm-settings','phisk_fcm_test'=>'failed'], admin_url('options-general.php')));
        } else {
            wp_safe_redirect(add_query_arg(['page'=>'phisk-fcm-settings','phisk_fcm_test'=>'success'], admin_url('options-general.php')));
        }
        exit;
    }

    private function get_fcm_test_devices() {
        global $wpdb;
        $this->ensure_app_notification_tables();
        $sql = 'SELECT d.id,d.user_id,d.device_id,d.platform,d.app_version,u.user_login,u.display_name FROM ' . $this->app_device_table() . ' d LEFT JOIN ' . $wpdb->users . ' u ON u.ID=d.user_id WHERE d.fcm_token<>\'\' ORDER BY d.last_seen_at DESC,d.updated_at DESC LIMIT 200';
        $rows = $wpdb->get_results($sql);
        foreach ($rows as $row) $row->device_label = substr((string)$row->device_id, 0, 8) . '…';
        return $rows;
    }

    public function handle_fcm_send_test() {
        if (!current_user_can('manage_options')) wp_die('You do not have permission to send test notifications.');
        check_admin_referer('phisk_fcm_send_test');
        $device_id = absint($_POST['device_row_id'] ?? 0);
        $title = sanitize_text_field(wp_unslash($_POST['notification_title'] ?? ''));
        $message = sanitize_textarea_field(wp_unslash($_POST['notification_message'] ?? ''));
        $title = mb_substr($title, 0, 100); $message = mb_substr($message, 0, 300);
        if (!$device_id || $title === '' || $message === '') {
            set_transient('phisk_fcm_last_send_error', 'Select a registered device and provide both a title and message.', 60);
            wp_safe_redirect(add_query_arg(['page'=>'phisk-fcm-settings','phisk_fcm_send'=>'failed'], admin_url('options-general.php'))); exit;
        }
        global $wpdb;
        $device = $wpdb->get_row($wpdb->prepare('SELECT id,fcm_token FROM ' . $this->app_device_table() . ' WHERE id=%d LIMIT 1', $device_id));
        if (!$device || empty($device->fcm_token)) {
            set_transient('phisk_fcm_last_send_error', 'The selected device no longer has a valid registration. Refresh the page and try again.', 60);
            wp_safe_redirect(add_query_arg(['page'=>'phisk-fcm-settings','phisk_fcm_send'=>'failed'], admin_url('options-general.php'))); exit;
        }
        $result = $this->send_fcm_to_device($device, $title, $message);
        if (is_wp_error($result)) set_transient('phisk_fcm_last_send_error', $result->get_error_message(), 60);
        else set_transient('phisk_fcm_last_send_result', 'Firebase accepted the test message (message ID: ' . $result . '). Check the selected Android device to confirm it appeared.', 60);
        wp_safe_redirect(add_query_arg(['page'=>'phisk-fcm-settings','phisk_fcm_send'=>is_wp_error($result) ? 'failed' : 'success'], admin_url('options-general.php'))); exit;
    }

    private function send_fcm_to_device($device, $title, $message) {
        $auth = $this->get_fcm_access_token();
        if (is_wp_error($auth)) return $auth;
        $payload = ['message'=>['token'=>$device->fcm_token,'notification'=>['title'=>sanitize_text_field($title),'body'=>sanitize_textarea_field($message)],'data'=>['type'=>'phisk_test','url'=>home_url('/')],'android'=>['priority'=>'HIGH']]];
        $endpoint = 'https://fcm.googleapis.com/v1/projects/' . rawurlencode($auth['project_id']) . '/messages:send';
        $response = wp_remote_post($endpoint, ['timeout'=>20,'headers'=>['Authorization'=>'Bearer '.$auth['token'],'Content-Type'=>'application/json'],'body'=>wp_json_encode($payload)]);
        if (is_wp_error($response)) return new WP_Error('phisk_fcm_send_network', 'Could not contact Firebase: ' . $response->get_error_message());
        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($code < 200 || $code >= 300 || empty($body['name'])) {
            $api_message = sanitize_text_field($body['error']['message'] ?? 'Firebase rejected the message.');
            if ($code === 404 || $code === 410 || strpos((string)($body['error']['details'][0]['errorCode'] ?? ''), 'UNREGISTERED') !== false) {
                global $wpdb; $wpdb->delete($this->app_device_table(), ['id'=>(int)$device->id], ['%d']);
                $api_message = 'Firebase reports this device token is no longer registered. Its stale device record has been removed.';
            }
            return new WP_Error('phisk_fcm_send_rejected', 'Firebase returned HTTP ' . (int)$code . ': ' . $api_message);
        }
        return sanitize_text_field($body['name']);
    }

    public function register_fcm_settings() {
        register_setting('phisk_fcm_settings', 'phisk_fcm_service_account_path', [
            'type' => 'string', 'sanitize_callback' => function($value) {
                $value = trim((string) $value);
                // Accept only absolute filesystem paths; reject URL wrappers and control characters.
                if ($value !== '' && ($value[0] !== '/' || preg_match('/[\x00-\x1F]/', $value) || strpos($value, '://') !== false)) return '';
                return $value;
            }, 'default' => ''
        ]);
    }

    private function fcm_base64url($data) { return rtrim(strtr(base64_encode($data), '+/', '-_'), '='); }

    private function get_fcm_access_token($force_refresh = false) {
        if (!$force_refresh) { $cached = get_transient('phisk_fcm_access_token'); if (is_array($cached) && !empty($cached['token'])) return $cached; }
        $path = $this->fcm_service_account_path();
        if (!$path || !is_file($path) || !is_readable($path)) return new WP_Error('phisk_fcm_file_unavailable', 'The configured service-account file cannot be read. Check the absolute path and file permissions.');
        $json = file_get_contents($path);
        if ($json === false || strlen($json) > 65536) return new WP_Error('phisk_fcm_file_invalid', 'The service-account file could not be read or is unexpectedly large.');
        $account = json_decode($json, true);
        unset($json);
        if (!is_array($account) || empty($account['client_email']) || empty($account['private_key']) || empty($account['project_id']) || empty($account['token_uri'])) return new WP_Error('phisk_fcm_json_invalid', 'The service-account JSON is missing required Firebase fields.');
        $now = time();
        $header = $this->fcm_base64url(wp_json_encode(['alg'=>'RS256','typ'=>'JWT']));
        $claims = $this->fcm_base64url(wp_json_encode(['iss'=>$account['client_email'],'scope'=>'https://www.googleapis.com/auth/firebase.messaging','aud'=>$account['token_uri'],'iat'=>$now,'exp'=>$now+3600]));
        $unsigned = $header . '.' . $claims;
        $key = openssl_pkey_get_private($account['private_key']);
        if (!$key) return new WP_Error('phisk_fcm_private_key_invalid', 'The private key in the service-account file could not be loaded.');
        $signature = '';
        $signed = openssl_sign($unsigned, $signature, $key, OPENSSL_ALGO_SHA256);
        if (function_exists('openssl_free_key')) openssl_free_key($key);
        if (!$signed) return new WP_Error('phisk_fcm_jwt_failed', 'WordPress could not sign the Firebase authentication assertion.');
        $assertion = $unsigned . '.' . $this->fcm_base64url($signature);
        $response = wp_remote_post(esc_url_raw($account['token_uri']), ['timeout'=>20,'headers'=>['Content-Type'=>'application/x-www-form-urlencoded'],'body'=>['grant_type'=>'urn:ietf:params:oauth:grant-type:jwt-bearer','assertion'=>$assertion]]);
        unset($account['private_key']);
        if (is_wp_error($response)) return new WP_Error('phisk_fcm_oauth_network', 'Could not reach Google OAuth: ' . $response->get_error_message());
        $code = wp_remote_retrieve_response_code($response); $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($code < 200 || $code >= 300 || empty($body['access_token'])) return new WP_Error('phisk_fcm_oauth_rejected', 'Google OAuth rejected the service account (HTTP ' . (int)$code . '). Check that the Firebase Cloud Messaging API is enabled and the service account is valid.');
        $result = ['token'=>$body['access_token'],'project_id'=>sanitize_text_field($account['project_id'])];
        set_transient('phisk_fcm_access_token', $result, max(60, min(3300, absint($body['expires_in'] ?? 3600)-300)));
        return $result;
    }

    private function send_fcm_to_user_devices($user_id, $title, $message, $target_url = '', $notification_id = 0) {
        global $wpdb;
        $this->ensure_app_notification_tables();
        $devices = $wpdb->get_results($wpdb->prepare('SELECT id,fcm_token FROM ' . $this->app_device_table() . ' WHERE user_id=%d', absint($user_id)));
        if (!$devices) return;
        $auth = $this->get_fcm_access_token();
        if (is_wp_error($auth)) { error_log('[Phisk FCM] ' . $auth->get_error_message()); return; }
        foreach ($devices as $device) {
            $payload = ['message'=>['token'=>$device->fcm_token,'notification'=>['title'=>sanitize_text_field($title),'body'=>sanitize_textarea_field($message)],'data'=>['url'=>(string) esc_url_raw($target_url),'notification_id'=>(string) absint($notification_id),'type'=>'phisk_notification'],'android'=>['priority'=>'HIGH']]];
            $endpoint = 'https://fcm.googleapis.com/v1/projects/' . rawurlencode($auth['project_id']) . '/messages:send';
            $response = wp_remote_post($endpoint, ['timeout'=>15,'headers'=>['Authorization'=>'Bearer '.$auth['token'],'Content-Type'=>'application/json'],'body'=>wp_json_encode($payload)]);
            if (is_wp_error($response)) { error_log('[Phisk FCM] Delivery request failed for device row ' . (int)$device->id . ': ' . $response->get_error_message()); continue; }
            $code = wp_remote_retrieve_response_code($response);
            if ($code === 404 || $code === 410 || ($code === 400 && strpos(wp_remote_retrieve_body($response), 'UNREGISTERED') !== false)) {
                $wpdb->delete($this->app_device_table(), ['id'=>(int)$device->id], ['%d']);
            } elseif ($code < 200 || $code >= 300) {
                error_log('[Phisk FCM] Firebase returned HTTP ' . (int)$code . ' for device row ' . (int)$device->id);
            }
        }
    }

    public function register_app_devices_menu() {
        add_submenu_page('options-general.php', 'Phisk App Devices', 'Phisk App Devices', 'manage_options', 'phisk-app-devices', [$this, 'app_devices_admin_page']);
    }

    public function handle_admin_device_action() {
        if (!is_admin() || empty($_POST['phisk_admin_revoke_device'])) return;
        if (!current_user_can('manage_options')) wp_die('You do not have permission to manage app devices.');
        check_admin_referer('phisk_admin_revoke_device', 'phisk_admin_devices_nonce');
        global $wpdb; $id = absint($_POST['device_row_id'] ?? 0);
        if ($id) $wpdb->delete($this->app_device_table(), ['id'=>$id], ['%d']);
        wp_safe_redirect(add_query_arg(['page'=>'phisk-app-devices','revoked'=>'1'], admin_url('options-general.php'))); exit;
    }

    public function app_devices_admin_page() {
        if (!current_user_can('manage_options')) return;
        $this->ensure_app_notification_tables(); global $wpdb;
        $rows = $wpdb->get_results('SELECT d.id,d.user_id,d.device_id,d.platform,d.app_version,d.created_at,d.updated_at,d.last_seen_at,u.user_login,u.display_name,u.user_email FROM '.$this->app_device_table().' d LEFT JOIN '.$wpdb->users.' u ON u.ID=d.user_id ORDER BY d.last_seen_at DESC,d.updated_at DESC LIMIT 500');
        echo '<div class="wrap"><h1>Phisk App Devices</h1><p>Registered mobile app installations. FCM tokens are intentionally never displayed.</p>';
        if (!empty($_GET['revoked'])) echo '<div class="notice notice-success is-dismissible"><p>Device registration revoked.</p></div>';
        echo '<p><strong>'.count($rows).'</strong> device record(s) shown (maximum 500).</p><table class="widefat striped"><thead><tr><th>User</th><th>Device ID</th><th>Platform</th><th>App version</th><th>Registered</th><th>Last seen</th><th>Action</th></tr></thead><tbody>';
        if (!$rows) echo '<tr><td colspan="7">No registered app devices yet.</td></tr>';
        foreach ($rows as $r) { echo '<tr><td>'.esc_html(($r->display_name ?: $r->user_login ?: 'Deleted user').' (@'.($r->user_login ?: 'unknown').')'.($r->user_email ? ' — '.$r->user_email : '')).'</td><td><code>'.esc_html($r->device_id).'</code></td><td>'.esc_html(strtoupper($r->platform)).'</td><td>'.esc_html($r->app_version ?: 'Unknown').'</td><td>'.esc_html(get_date_from_gmt($r->created_at, 'Y-m-d H:i')).'</td><td>'.esc_html($r->last_seen_at ? get_date_from_gmt($r->last_seen_at, 'Y-m-d H:i') : 'Not recorded').'</td><td><form method="post" onsubmit="return confirm(\'Revoke this device registration?\')">'; wp_nonce_field('phisk_admin_revoke_device','phisk_admin_devices_nonce'); echo '<input type="hidden" name="device_row_id" value="'.absint($r->id).'"><button class="button button-secondary" name="phisk_admin_revoke_device" value="1">Revoke</button></form></td></tr>'; }
        echo '</tbody></table></div>';
    }

    public function account_settings_shortcode($atts = []) {
        $this->enqueue_style();
        if (!is_user_logged_in()) {
            return '<section class="phisk-dashboard-login"><h2>Settings</h2><p>Please log in to manage your account settings.</p></section>';
        }
        $user = wp_get_current_user();
        $active = isset($_GET['phisk_settings_tab']) ? sanitize_key(wp_unslash($_GET['phisk_settings_tab'])) : 'account';
        if (!in_array($active, ['account', 'security', 'notifications'], true)) $active = 'account';
        $base_url = $this->account_settings_url();
        $account_url = add_query_arg('phisk_settings_tab', 'account', remove_query_arg(['phisk_dashboard_status','phisk_dashboard_message','phisk_dashboard_tab'], $base_url));
        $security_url = add_query_arg('phisk_settings_tab', 'security', remove_query_arg(['phisk_dashboard_status','phisk_dashboard_message','phisk_dashboard_tab'], $base_url));
        $notifications_url = add_query_arg('phisk_settings_tab', 'notifications', remove_query_arg(['phisk_dashboard_status','phisk_dashboard_message','phisk_dashboard_tab'], $base_url));
        $status = isset($_GET['phisk_dashboard_status']) ? sanitize_key(wp_unslash($_GET['phisk_dashboard_status'])) : '';
        $message = isset($_GET['phisk_dashboard_message']) ? sanitize_text_field(rawurldecode(wp_unslash($_GET['phisk_dashboard_message']))) : '';
        ob_start(); ?>
        <section class="phisk-user-dashboard phisk-settings-page">
          <a class="phisk-settings-back" href="<?php echo esc_url(home_url('/')); ?>" data-phisk-previous-link>← Back</a>
          <script>(function(){var links=document.querySelectorAll('.phisk-settings-page [data-phisk-previous-link]');links.forEach(function(link){if(link.dataset.previousReady==='1')return;link.dataset.previousReady='1';link.addEventListener('click',function(event){try{var ref=document.referrer;if(ref&&new URL(ref).origin===window.location.origin&&window.history.length>1){event.preventDefault();window.history.back();}}catch(e){}});});})();</script>
          <div class="phisk-dashboard-panel phisk-dashboard-profile-panel">
            <div class="phisk-dashboard-panel-head"><div><h2>Settings</h2><p>Manage your account details and security.</p></div></div>
            <nav class="phisk-dashboard-tabs phisk-settings-tabs" aria-label="Settings sections">
              <a class="<?php echo $active === 'account' ? 'is-active' : ''; ?>" href="<?php echo esc_url($account_url); ?>">Account Settings</a>
              <a class="<?php echo $active === 'security' ? 'is-active' : ''; ?>" href="<?php echo esc_url($security_url); ?>">Security &amp; Privacy</a>
              <a class="<?php echo $active === 'notifications' ? 'is-active' : ''; ?>" href="<?php echo esc_url($notifications_url); ?>">Notifications</a>
            </nav>
            <?php if ($message) : ?><div class="phisk-dashboard-notice phisk-dashboard-notice-<?php echo esc_attr($status ?: 'success'); ?>"><?php echo esc_html($message); ?></div><?php endif; ?>
            <?php if ($active === 'notifications' && !empty($_GET['phisk_notification_saved'])) : ?><div class="phisk-dashboard-notice phisk-dashboard-notice-success" role="status">Notification preferences saved.</div><?php endif; ?>
            <?php if ($active === 'account') : ?>
              <section class="phisk-settings-section">
                <div class="phisk-dashboard-panel-head"><div><h2>Account Settings</h2><p>Manage your personal account information.</p></div></div>
                <div class="phisk-dashboard-accordions"><details class="phisk-account-accordion" open>
                  <summary><span><strong>Personal Information</strong><small>Review and update your account details</small></span><span class="phisk-accordion-chevron" aria-hidden="true"></span></summary>
                  <form class="phisk-dashboard-form phisk-account-settings-form" method="post">
                    <?php wp_nonce_field('phisk_dashboard_profile', 'phisk_dashboard_profile_nonce'); ?>
                    <input type="hidden" name="phisk_dashboard_profile_submit" value="1">
                    <input type="hidden" name="phisk_dashboard_return_url" value="<?php echo esc_url($account_url); ?>">
                    <div class="phisk-dashboard-form-grid">
                      <?php $public_username = $this->get_public_username($user->ID); ?>
                      <label class="phisk-dashboard-full"><strong>Username</strong><input class="phisk-public-username-input" type="text" name="phisk_public_username" value="<?php echo esc_attr($public_username); ?>" autocomplete="username" minlength="3" maxlength="24" pattern="[a-zA-Z0-9_]+" autocapitalize="off" spellcheck="false" required><small>Change username. Use 3–24 letters, numbers or underscores.</small><span class="phisk-username-availability" aria-live="polite"></span></label>
                      <label><strong>First Name</strong><input type="text" name="phisk_first_name" value="<?php echo esc_attr($user->first_name); ?>" autocomplete="given-name"></label>
                      <label><strong>Last Name</strong><input type="text" name="phisk_last_name" value="<?php echo esc_attr($user->last_name); ?>" autocomplete="family-name"></label>
                      <label class="phisk-dashboard-full"><strong>Phone Number <span class="phisk-optional-label">(optional)</span></strong><input type="tel" name="phisk_phone_number" value="<?php echo esc_attr(get_user_meta($user->ID, 'phisk_phone_number', true)); ?>" autocomplete="tel" placeholder="Add your phone number"></label>
                    </div>
                    <button class="phisk-submit-button" type="submit">Save Account Settings</button>
                  </form>
                </details></div>
              </section>
            <?php elseif ($active === 'notifications') : ?>
              <?php $prefs = $this->get_notification_preferences($user->ID); ?>
              <section class="phisk-settings-section phisk-notification-settings"><style>.phisk-notification-settings input[type=checkbox]{accent-color:#000!important}.phisk-notification-settings input[type=checkbox]:disabled{opacity:.65}</style>
                <div class="phisk-dashboard-panel-head"><div><h2>Notification Settings</h2><p>Choose which channel updates you receive by email and in your PhiskVideos inbox.</p></div></div>
                <form class="phisk-dashboard-form" method="post">
                  <?php wp_nonce_field('phisk_notification_preferences_save', 'phisk_notification_preferences_nonce'); ?>
                  <input type="hidden" name="phisk_notification_preferences_submit" value="1">
                  <div class="phisk-notification-preference-group"><h3>Channel updates</h3>
                    <label class="phisk-dashboard-checkbox"><input type="checkbox" name="video_inbox" value="1" <?php checked($prefs['video_inbox'], true); ?>> <span>New videos from channels I follow — website and app</span></label>
                    <label class="phisk-dashboard-checkbox"><input type="checkbox" name="video_email" value="1" <?php checked($prefs['video_email'], true); ?>> <span>Email me about new videos from channels I follow</span></label>
                    <label class="phisk-dashboard-checkbox"><input type="checkbox" name="story_inbox" value="1" <?php checked($prefs['story_inbox'], true); ?>> <span>New Stories from channels I follow — website and app</span></label>
                    <label class="phisk-dashboard-checkbox"><input type="checkbox" name="story_email" value="1" <?php checked($prefs['story_email'], true); ?>> <span>Email me about new Stories from channels I follow</span></label>
                  </div>
                  <div class="phisk-notification-preference-group"><h3>Important account updates</h3>
                    <label class="phisk-dashboard-checkbox"><input type="checkbox" checked disabled> <span>Story approval — always appears in your notification inbox</span></label>
                    <label class="phisk-dashboard-checkbox"><input type="checkbox" name="story_approved_email" value="1" <?php checked($prefs['story_approved_email'], true); ?>> <span>Email me when my Story is approved</span></label>
                    <label class="phisk-dashboard-checkbox"><input type="checkbox" checked disabled> <span>Monetization approval — always appears in your notification inbox</span></label>
                    <label class="phisk-dashboard-checkbox"><input type="checkbox" name="monetization_approved_email" value="1" <?php checked($prefs['monetization_approved_email'], true); ?>> <span>Email me when monetization is approved</span></label>
                  </div>
                  <button class="phisk-submit-button" type="submit">Save Notification Settings</button>
                </form>
              </section>
            <?php else : ?>
              <section class="phisk-settings-section">
                <div class="phisk-dashboard-panel-head"><div><h2>Security &amp; Privacy</h2><p>Keep your account secure and protect access to your profile.</p></div></div>
                <?php $phisk_google_needs_password = get_user_meta(get_current_user_id(), 'phisk_auth_method', true) === 'google' && (string)get_user_meta(get_current_user_id(), 'phisk_password_set', true) !== '1'; ?>
                <div class="phisk-dashboard-accordions"><details class="phisk-account-accordion" open>
                  <summary><span><strong><?php echo $phisk_google_needs_password ? 'Set Password' : 'Change Password'; ?></strong><small>Update the password you use to sign in</small></span><span class="phisk-accordion-chevron" aria-hidden="true"></span></summary>
                  <form class="phisk-dashboard-form phisk-security-settings-form" method="post">
                    <?php wp_nonce_field('phisk_dashboard_profile', 'phisk_dashboard_profile_nonce'); ?>
                    <input type="hidden" name="phisk_dashboard_profile_submit" value="1">
                    <input type="hidden" name="phisk_dashboard_return_url" value="<?php echo esc_url($security_url); ?>">
                    <div class="phisk-dashboard-password">
                      <p><?php echo $phisk_google_needs_password ? 'Set a password to also sign in with your email.' : 'Enter your current password and choose a new password of at least 8 characters.'; ?></p>
                      <?php if (!$phisk_google_needs_password) : ?>
                        <label><strong>Current Password</strong><input type="password" name="phisk_current_password" autocomplete="current-password" required></label>
                      <?php endif; ?>
                      <label><strong>New Password</strong><input type="password" name="phisk_new_password" autocomplete="new-password" minlength="8" required></label>
                      <label><strong>Confirm New Password</strong><input type="password" name="phisk_confirm_password" autocomplete="new-password" minlength="8" required></label>
                      <label class="phisk-dashboard-checkbox"><input type="checkbox" name="phisk_change_password" value="1" required> <span>I want to change my password</span></label>
                    </div>
                    <button class="phisk-submit-button" type="submit"><?php echo $phisk_google_needs_password ? 'Set Password' : 'Update Password'; ?></button>
                  </form>
                </details>
                <?php
                  $this->ensure_app_notification_tables(); global $wpdb;
                  $my_devices = $wpdb->get_results($wpdb->prepare('SELECT id,device_id,platform,app_version,created_at,last_seen_at FROM '.$this->app_device_table().' WHERE user_id=%d ORDER BY last_seen_at DESC,updated_at DESC', $user->ID));
                ?>
                <details class="phisk-account-accordion phisk-my-devices-accordion">
                  <summary><span><strong>My Devices</strong><small>View and remove devices connected to your PhiskVideos account</small></span><span class="phisk-accordion-chevron" aria-hidden="true"></span></summary>
                  <div class="phisk-dashboard-form">
                    <p>These are the app installations registered to your account. Removing a device disconnects its registration from PhiskVideos. Your actual FCM token is never shown.</p>
                    <?php if (!empty($_GET['phisk_devices_updated'])) : ?><div class="phisk-dashboard-notice phisk-dashboard-notice-success" role="status">Device registration removed.</div><?php endif; ?>
                    <?php if (empty($my_devices)) : ?><p>No app devices are registered to your account yet. Open PhiskVideos on your Android device and sign in to register it.</p>
                    <?php else : foreach ($my_devices as $device) : ?>
                      <div class="phisk-device-row" style="display:flex;align-items:center;justify-content:space-between;gap:14px;padding:14px 0;border-bottom:1px solid #eee;flex-wrap:wrap">
                        <div><strong><?php echo esc_html(strtoupper($device->platform)); ?> device</strong><br><small>App version: <?php echo esc_html($device->app_version ?: 'Unknown'); ?> · Last active: <?php echo esc_html($device->last_seen_at ? get_date_from_gmt($device->last_seen_at, 'M j, Y') : 'Not recorded'); ?></small></div>
                        <form method="post" onsubmit="return confirm('Remove this device from your account?')"><?php wp_nonce_field('phisk_remove_my_device','phisk_my_devices_nonce'); ?><input type="hidden" name="device_row_id" value="<?php echo absint($device->id); ?>"><button class="phisk-submit-button" type="submit" name="phisk_remove_my_device" value="1">Remove device</button></form>
                      </div>
                    <?php endforeach; endif; ?>
                  </div>
                </details></div>
              </section>
            <?php endif; ?>
          </div>
        </section>
        <?php return ob_get_clean();
    }

    public function user_dashboard_shortcode($atts) {
        $this->enqueue_style();

        $atts = shortcode_atts(['limit' => 30], $atts, 'phisk_user_dashboard');
        $requested_user = !empty($_GET['phisk_profile_user']) ? absint($_GET['phisk_profile_user']) : absint(get_query_var('phisk_profile_user'));
        $is_public_profile = $requested_user > 0 && $requested_user !== get_current_user_id();
        if (!is_user_logged_in() && !$requested_user) {
            return '<section class="phisk-dashboard-login phisk-auth-gate"><h2>Create your channel.</h2><p>Please log in to manage your profile and content.</p></section>';
        }

        $user_id = $requested_user ?: get_current_user_id();
        $user = get_userdata($user_id);
        if (!$user) return '<p class="phisk-empty">Unable to load this account.</p>';
        if (get_user_meta($user_id, '_phisk_strike_channel_restricted', true)) {
            if ($is_public_profile) return '<section class="phisk-channel-gate"><h2>Channel temporarily unavailable</h2><p>This PhiskVideos channel is currently disabled. Existing content data is preserved.</p></section>';
            return $this->channel_creation_gate();
        }

        $allowed_tabs = $is_public_profile ? ['profile', 'videos'] : ['profile', 'videos', 'articles', 'saved'];
        $active = isset($_GET['phisk_dashboard_tab']) ? sanitize_key(wp_unslash($_GET['phisk_dashboard_tab'])) : 'profile';
        if (!in_array($active, $allowed_tabs, true)) $active = 'profile';
        if (!$is_public_profile && !$this->user_has_phisk_channel($user_id) && in_array($active, ['videos', 'articles'], true)) return $this->channel_creation_gate();
        // Saved videos belong to the signed-in account only and never appear on public profiles.
        if ($is_public_profile && $active === 'saved') $active = 'profile';
        if (!$is_public_profile && $active === 'saved' && isset($_GET['remove_saved_video'])) {
            $remove_id = absint($_GET['remove_saved_video']);
            if ($remove_id && wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'] ?? '')), 'phisk_remove_saved_video_' . $remove_id)) {
                $saved_ids = get_user_meta($user_id, 'phisk_saved_videos', true);
                if (!is_array($saved_ids)) $saved_ids = [];
                $saved_ids = array_values(array_diff(array_map('absint', $saved_ids), [$remove_id]));
                update_user_meta($user_id, 'phisk_saved_videos', $saved_ids);
                $redirect = remove_query_arg(['remove_saved_video', '_wpnonce']);
                wp_safe_redirect($redirect);
                exit;
            }
        }
        $edit_video = (!$is_public_profile && $active === 'videos' && !empty($_GET['edit_video'])) ? absint($_GET['edit_video']) : 0;
        $new_video = ($active === 'videos' && !empty($_GET['new_video'])) ? 1 : 0;

        $profile_url = $this->dashboard_image_url($user_id, 'phisk_profile_image_id', 'medium');
        $cover_url = $this->dashboard_image_url($user_id, 'phisk_cover_image_id', 'full');
        $has_channel = $this->user_has_phisk_channel($user_id);
        // Public profiles only expose the Videos tab when at least one published video exists.
        // Owners keep their Videos tab so they can upload and manage drafts.
        $has_published_public_videos = false;
        if ($is_public_profile) {
            $public_video_check = get_posts([
                'post_type' => 'phisk_video',
                'post_status' => 'publish',
                'author' => $user_id,
                'numberposts' => 1,
                'fields' => 'ids',
                'no_found_rows' => true,
            ]);
            $has_published_public_videos = !empty($public_video_check);
        }
        // A profile without a published video should open on About, the first available tab.
        if ($is_public_profile && !$has_published_public_videos) {
            $active = 'profile';
        } elseif ($active === 'profile' && !$is_public_profile && $has_channel) {
            // Videos is the first tab for channel owners; make it the default unless a tab was explicitly requested.
            if (!isset($_GET['phisk_dashboard_tab'])) $active = 'videos';
        }
        $display_name = $has_channel ? $this->phisk_creator_display_name($user_id) : $this->phisk_personal_display_name($user_id);
        $bio = get_user_meta($user_id, 'description', true);
        $social_links = [
            'Facebook' => get_user_meta($user_id, 'phisk_social_facebook', true),
            'YouTube' => get_user_meta($user_id, 'phisk_social_youtube', true),
            'X' => get_user_meta($user_id, 'phisk_social_x', true),
            'LinkedIn' => get_user_meta($user_id, 'phisk_social_linkedin', true),
        ];
        $channel_created = absint(get_user_meta($user_id, 'phisk_channel_created_at', true));
        if (!$channel_created) $channel_created = $user->user_registered ? strtotime($user->user_registered) : 0;
        $name_history = get_user_meta($user_id, 'phisk_channel_name_history', true);
        if (!is_array($name_history)) $name_history = [];
        $name_last_changed = absint(get_user_meta($user_id, 'phisk_channel_name_last_changed', true));
        $name_change_available = $name_last_changed ? ($name_last_changed + 90 * DAY_IN_SECONDS) : 0;

        $tab_url = function($tab) {
            return add_query_arg(['phisk_dashboard_tab' => $tab], remove_query_arg(['edit_video', 'new_video', 'phisk_dashboard_status', 'phisk_dashboard_message']));
        };

        $status = isset($_GET['phisk_dashboard_status']) ? sanitize_key(wp_unslash($_GET['phisk_dashboard_status'])) : '';
        $message = isset($_GET['phisk_dashboard_message']) ? sanitize_text_field(rawurldecode(wp_unslash($_GET['phisk_dashboard_message']))) : '';

        ob_start();
        ?>
        <section class="phisk-user-dashboard<?php echo $is_public_profile ? " phisk-public-profile" : ""; ?>">
          <div class="phisk-dashboard-hero">
            <div class="phisk-dashboard-cover" <?php echo $cover_url ? 'style="background-image:url(' . esc_url($cover_url) . ')"' : ''; ?>>
              <?php if (!$cover_url) : ?><span class="phisk-dashboard-cover-placeholder">Your Phisk profile</span><?php endif; ?>
              <?php if (!$is_public_profile && is_user_logged_in() && get_current_user_id() === (int) $user_id) :
                // Existing accounts retain their current channel behavior until Phase 2 explicitly marks new accounts as channel-less.
                $has_channel = $this->user_has_phisk_channel($user_id);
                $profile_or_channel_label = $has_channel ? 'Channel Link' : 'Profile Link';
              ?>
                <details class="phisk-channel-menu">
                  <summary class="phisk-channel-menu-trigger" aria-label="Open profile menu" title="Menu"><span></span><span></span><span></span></summary>
                  <div class="phisk-channel-menu-dropdown">
                    <a href="<?php echo esc_url($this->account_settings_url()); ?>">Settings</a>
                    <button type="button" class="phisk-channel-menu-copy" data-copy-url="<?php echo esc_url($this->phisk_user_dashboard_url($user_id)); ?>"><?php echo esc_html($profile_or_channel_label); ?></button>
                  </div>
                </details>
              <?php endif; ?>
              <?php if (!$is_public_profile) : ?>
                <button type="button" class="phisk-channel-image-edit phisk-channel-cover-edit-form" data-phisk-open-image-editor="cover" aria-label="Edit cover image" title="Edit cover image"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L9 17l-4 1 1-4Z"/></svg></button>
              <?php endif; ?>
              <?php if ($is_public_profile) : ?>
                <div class="phisk-channel-cover-subscribe"><?php echo $this->phisk_subscribe_button($user_id); ?></div>
              <?php endif; ?>
            </div>
            <div class="phisk-dashboard-identity">
              <div class="phisk-dashboard-avatar-wrap">
                <div class="phisk-dashboard-avatar">
                  <?php if ($profile_url) : ?><img src="<?php echo esc_url($profile_url); ?>" alt="<?php echo esc_attr($display_name); ?>"><?php else : ?><span><?php echo esc_html(function_exists('mb_substr') ? mb_strtoupper(mb_substr($display_name, 0, 1)) : strtoupper(substr($display_name, 0, 1))); ?></span><?php endif; ?>
                </div>
                <?php if (!$is_public_profile) : ?>
                  <button type="button" class="phisk-channel-image-edit phisk-channel-avatar-edit-form" data-phisk-open-image-editor="profile" aria-label="Edit profile image" title="Edit profile image"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L9 17l-4 1 1-4Z"/></svg></button>
                <?php endif; ?>
              </div>
              <div class="phisk-dashboard-name"><h1><span class="phisk-dashboard-name-text"><?php echo esc_html($display_name); ?></span><?php if (!$is_public_profile && is_user_logged_in() && get_current_user_id() === (int) $user_id) : ?><a class="phisk-channel-logout" href="<?php echo esc_url(wp_logout_url(home_url('/'))); ?>" onclick="return window.confirm('Are you sure you want to log out?');" aria-label="Log out" title="Log out"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M10 17l5-5-5-5"/><path d="M15 12H3"/><path d="M12 3h6a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-6"/></svg></a><?php endif; ?></h1><p class="phisk-channel-subscriber-line"><span class="phisk-subscriber-count" data-author-id="<?php echo esc_attr($user_id); ?>"><?php $subscriber_count = $this->phisk_display_subscriber_count($user_id); echo esc_html($subscriber_count . ' ' . ($subscriber_count === 1 ? 'subscriber' : 'subscribers')); ?></span><?php if (get_user_meta($user_id, '_phisk_demo_stats_enabled', true)) : ?> <span class="phisk-demo-stats-label">Promotional Stats</span><?php endif; ?><?php if (get_user_meta($user_id, '_phisk_monetization_status', true) === 'approved') : ?><span class="phisk-monetized-channel-label">$ Monetized Channel</span><?php endif; ?></p></div>
            </div>
          </div>

          <nav class="phisk-dashboard-tabs" aria-label="Phisk account sections">
            <?php
            $tabs = $is_public_profile
              ? ($has_published_public_videos ? ['videos'=>'Videos', 'profile'=>'About'] : ['profile'=>'About'])
              : ($has_channel ? ['videos'=>'Videos', 'articles'=>'Stories', 'saved'=>'Saved Videos', 'profile'=>'About'] : ['saved'=>'Saved Videos', 'profile'=>'About']);
            foreach ($tabs as $key => $title) :
              $profile_tab_url = $tab_url($key);
              if ($is_public_profile) $profile_tab_url = add_query_arg('phisk_profile_user', $user_id, $profile_tab_url);
            ?>
              <a class="<?php echo $active === $key ? 'is-active' : ''; ?>" href="<?php echo esc_url($profile_tab_url); ?>"><?php echo esc_html($title); ?></a>
            <?php endforeach; ?>
            <?php if (!$is_public_profile && $this->user_has_phisk_channel($user_id)) : ?>
              <a class="phisk-dashboard-creator-studio" href="<?php echo esc_url($this->creator_studio_url()); ?>">Creator Studio</a>
            <?php endif; ?>
          </nav>

          <?php if ($message) : ?><div class="phisk-dashboard-notice phisk-dashboard-notice-<?php echo esc_attr($status ?: 'success'); ?>"><?php echo esc_html($message); ?></div><?php endif; ?>

          <?php if ($active === 'profile') : ?>
            <section class="phisk-dashboard-panel phisk-dashboard-profile-panel">
              <div class="phisk-dashboard-panel-head"><div><h2>About</h2><p><?php echo $is_public_profile ? 'About this profile.' : ($has_channel ? 'Manage your channel name and description.' : 'Manage your personal profile. Create a channel when you are ready to publish.'); ?></p></div></div>
              <?php if ($is_public_profile) : ?>
                <div class="phisk-public-profile-bio">
                  <?php if ($bio) : ?><p><?php echo nl2br(esc_html($bio)); ?></p><?php else : ?><p class="phisk-dashboard-empty"><?php echo $has_channel ? 'This creator has not added a channel description yet.' : 'This member has not added a profile description yet.'; ?></p><?php endif; ?>
                </div>
              <?php else : ?>
              <?php if (!$has_channel) : ?><p class="phisk-dashboard-empty">You can use PhiskVideos as a member without a channel. Ready to publish videos and Stories? <a href="<?php echo esc_url($this->creator_studio_url()); ?>">Create a Channel</a>.</p><?php endif; ?>
              <form class="phisk-dashboard-form phisk-channel-info-form" method="post">
                <?php wp_nonce_field('phisk_dashboard_profile', 'phisk_dashboard_profile_nonce'); ?>
                <input type="hidden" name="phisk_dashboard_profile_submit" value="1">
                <input type="hidden" name="phisk_dashboard_return_url" value="<?php echo esc_url($this->phisk_channel_url($user_id)); ?>">
                <div class="phisk-dashboard-form-grid">
                  <?php if ($has_channel) : ?><label class="phisk-dashboard-full"><strong>Channel Name</strong><input type="text" name="phisk_display_name" value="<?php echo esc_attr($display_name); ?>" maxlength="30" data-phisk-name-limit="30" required><small class="phisk-character-help">Maximum 30 characters. <span class="phisk-character-count"><?php echo esc_html(function_exists('mb_strlen') ? mb_strlen((string)$display_name, 'UTF-8') : strlen((string)$display_name)); ?></span>/30 used.</small>
                    <?php if ($name_change_available && time() < $name_change_available) : ?><small>Your channel name can next be changed on <?php echo esc_html(wp_date(get_option('date_format'), $name_change_available)); ?>.</small><?php else : ?><small>After a successful name change, the next change is available after 90 days.</small><?php endif; ?>
                  </label><?php endif; ?>
                  <label class="phisk-dashboard-full"><strong><?php echo $has_channel ? 'Channel Description' : 'About You'; ?> <span class="phisk-optional-label">(up to 500 characters)</span></strong><textarea name="phisk_bio" rows="4" maxlength="500" data-phisk-char-limit="500" placeholder="Tell people what your channel is about..."><?php echo esc_textarea($bio); ?></textarea><small><span class="phisk-channel-description-count"><?php echo esc_html(function_exists('mb_strlen') ? mb_strlen((string)$bio) : strlen((string)$bio)); ?></span> / 500 characters</small></label>
                  <div class="phisk-dashboard-full phisk-social-links-fields"><strong>Social Links</strong><p class="phisk-social-links-help">Add links to your other platforms. All fields are optional and must use HTTPS.</p>
                    <label><strong>Facebook</strong><input type="url" name="phisk_social_facebook" value="<?php echo esc_attr($social_links['Facebook']); ?>" placeholder="https://facebook.com/yourpage"></label>
                    <label><strong>YouTube</strong><input type="url" name="phisk_social_youtube" value="<?php echo esc_attr($social_links['YouTube']); ?>" placeholder="https://youtube.com/@yourchannel"></label>
                    <label><strong>X</strong><input type="url" name="phisk_social_x" value="<?php echo esc_attr($social_links['X']); ?>" placeholder="https://x.com/yourprofile"></label>
                    <label><strong>LinkedIn</strong><input type="url" name="phisk_social_linkedin" value="<?php echo esc_attr($social_links['LinkedIn']); ?>" placeholder="https://linkedin.com/in/yourprofile"></label>
                  </div>
                </div>
                <button class="phisk-submit-button" type="submit"><?php echo $has_channel ? 'Save Channel Info' : 'Save Profile'; ?></button>
              </form>

              <?php endif; ?>

              <?php if ($has_channel) : ?><div class="phisk-channel-public-details">
                <div class="phisk-channel-detail-item"><strong>Channel created</strong><span><?php echo $channel_created ? esc_html(wp_date(get_option('date_format'), $channel_created)) : 'Date unavailable'; ?></span></div>
                <?php $has_social_links = false; foreach ($social_links as $social_url) { if (!empty($social_url)) { $has_social_links = true; break; } } ?>
                <?php if ($has_social_links) : ?><div class="phisk-channel-social-public"><strong>Find this creator elsewhere</strong><div class="phisk-channel-social-list">
                  <?php foreach ($social_links as $platform => $social_url) : if (!$social_url) continue; ?><a href="<?php echo esc_url($social_url); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr($platform); ?> profile"><?php echo esc_html($platform); ?> <span aria-hidden="true">↗</span></a><?php endforeach; ?>
                </div></div><?php endif; ?>
                <details class="phisk-account-accordion phisk-channel-history-accordion">
                  <summary><span><strong>Channel Name History</strong><small>Creation date and recorded name changes</small></span><span class="phisk-accordion-chevron" aria-hidden="true"></span></summary>
                  <div class="phisk-channel-name-history">
                    <?php if ($name_history) : ?><ol><?php foreach (array_reverse($name_history) as $history_item) : if (!is_array($history_item)) continue; ?><li><span><strong><?php echo esc_html(isset($history_item['old_name']) ? $history_item['old_name'] : ''); ?></strong> <span aria-hidden="true">→</span> <strong><?php echo esc_html(isset($history_item['new_name']) ? $history_item['new_name'] : ''); ?></strong></span><small><?php echo !empty($history_item['changed_at']) ? esc_html(wp_date(get_option('date_format'), absint($history_item['changed_at']))) : ''; ?></small></li><?php endforeach; ?></ol><?php else : ?><p>No channel name changes have been recorded yet.</p><?php endif; ?>
                    <p class="phisk-channel-current-name">Current channel name: <strong><?php echo esc_html($display_name); ?></strong></p>
                  </div>
                </details>
              </div><?php else : ?><p class="phisk-dashboard-empty">Member since <?php echo $channel_created ? esc_html(wp_date(get_option('date_format'), $channel_created)) : 'date unavailable'; ?>.</p><?php endif; ?>

            </section>
          <?php elseif ($active === 'videos') : ?>
            <?php if ($edit_video) : ?>
              <div class="phisk-dashboard-editor">
                <a class="phisk-dashboard-back" href="<?php echo esc_url($tab_url('videos')); ?>">← Back to My Videos</a>
                <?php echo $this->video_submit_shortcode(); ?>
              </div>
            <?php else :
              $query = new WP_Query([
                  'post_type' => 'phisk_video',
                  'post_status' => $is_public_profile ? 'publish' : ['publish', 'draft', 'pending', 'private', 'future'],
                  'author' => $user_id,
                  'posts_per_page' => 10,
                  'paged' => isset($_GET['phisk_video_page']) ? max(1, absint($_GET['phisk_video_page'])) : 1,
                  'orderby' => 'date',
                  'order' => 'DESC',
                  'no_found_rows' => false,
              ]);
              ?>
              <section class="phisk-dashboard-panel phisk-dashboard-content-panel">
                <?php if ($query->have_posts()) : ?>
                  <div class="phisk-dashboard-content-list">
                    <?php while ($query->have_posts()) : $query->the_post(); $id=get_the_ID(); $status_post=get_post_status($id); $thumb=get_the_post_thumbnail_url($id,'medium'); ?>
                      <article class="phisk-dashboard-content-item phisk-channel-video-item">
                        <a class="phisk-dashboard-content-thumb phisk-channel-video-thumb" href="<?php echo esc_url($status_post === 'publish' ? get_permalink($id) : add_query_arg(['phisk_dashboard_tab'=>'videos','edit_video'=>$id], remove_query_arg(['phisk_dashboard_status','phisk_dashboard_message']))); ?>" aria-label="<?php echo esc_attr(get_the_title() ?: 'Untitled Video'); ?>"><?php if($thumb): ?><img loading="lazy" src="<?php echo esc_url(get_the_post_thumbnail_url($id, 'large')); ?>" alt="<?php echo esc_attr(get_the_title()); ?>"><?php else: ?><span class="phisk-poster-placeholder">PHISK</span><?php endif; ?></a>
                        <?php if (!$is_public_profile) :
                          $video_view_url = $status_post === 'publish' ? get_permalink($id) : '';
                          $video_edit_url = add_query_arg(['phisk_dashboard_tab'=>'videos','edit_video'=>$id], remove_query_arg(['phisk_dashboard_status','phisk_dashboard_message']));
                          echo $this->dashboard_action_menu($id, $video_view_url, $video_edit_url, $status_post === 'publish', $status_post === 'draft');
                        endif; ?>
                        <div class="phisk-dashboard-content-info">
                          <h3><?php echo esc_html(get_the_title() ?: 'Untitled Video'); ?></h3>
                          <div class="phisk-dashboard-content-meta"><span><?php echo esc_html($this->dashboard_status_label($status_post)); ?></span><span><?php echo esc_html(get_the_date('', $id)); ?></span></div>
                        </div>
                      </article>
                    <?php endwhile; ?>
                  </div>
                <?php else : ?><p class="phisk-dashboard-empty">You have not uploaded any videos yet.</p><?php endif; ?>
                <?php if ($query->max_num_pages > 1) : $video_page = isset($_GET['phisk_video_page']) ? max(1, absint($_GET['phisk_video_page'])) : 1; $video_base = remove_query_arg('phisk_video_page'); ?>
                  <nav class="phisk-channel-pagination" aria-label="Videos pagination"><?php if ($video_page > 1) : ?><a class="phisk-channel-page-link" href="<?php echo esc_url(add_query_arg('phisk_video_page', $video_page - 1, $video_base)); ?>">‹ Previous</a><?php endif; ?><span class="phisk-channel-page-count">Page <?php echo esc_html($video_page); ?> of <?php echo esc_html($query->max_num_pages); ?></span><?php if ($video_page < $query->max_num_pages) : ?><a class="phisk-channel-page-link" href="<?php echo esc_url(add_query_arg('phisk_video_page', $video_page + 1, $video_base)); ?>">Next ›</a><?php endif; ?></nav>
                <?php endif; ?>
              </section>
              <?php wp_reset_postdata(); endif; ?>
          <?php elseif ($active === 'saved') : ?>
            <?php
              $saved_ids = get_user_meta($user_id, 'phisk_saved_videos', true);
              if (!is_array($saved_ids)) $saved_ids = [];
              $saved_ids = array_values(array_unique(array_filter(array_map('absint', $saved_ids))));
              $saved_posts = [];
              if ($saved_ids) {
                $saved_posts = get_posts([
                  'post_type' => 'phisk_video',
                  'post_status' => 'publish',
                  'post__in' => $saved_ids,
                  'orderby' => 'post__in',
                  'numberposts' => min(500, count($saved_ids)),
                  'no_found_rows' => true,
                ]);
                // Drop videos that were deleted or are no longer published from the user's collection.
                $found_ids = array_map(static function($post) { return (int) $post->ID; }, $saved_posts);
                if (count($found_ids) !== count($saved_ids)) update_user_meta($user_id, 'phisk_saved_videos', $found_ids);
              }
            ?>
            <section class="phisk-dashboard-panel phisk-dashboard-content-panel phisk-saved-videos-panel">
              <?php if ($saved_posts) : ?>
                <div class="phisk-dashboard-content-list phisk-saved-videos-list">
                  <?php foreach ($saved_posts as $saved_post) :
                    $id = (int) $saved_post->ID;
                    $thumb = get_the_post_thumbnail_url($id, 'medium');
                    $view_url = get_permalink($id);
                    $remove_url = wp_nonce_url(add_query_arg(['phisk_dashboard_tab'=>'saved', 'remove_saved_video'=>$id], remove_query_arg(['_wpnonce','remove_saved_video','phisk_dashboard_status','phisk_dashboard_message'])), 'phisk_remove_saved_video_' . $id);
                  ?>
                    <article class="phisk-dashboard-content-item phisk-channel-video-item phisk-saved-video-item">
                      <a class="phisk-dashboard-content-thumb phisk-channel-video-thumb" href="<?php echo esc_url($view_url); ?>" aria-label="<?php echo esc_attr(get_the_title($id)); ?>"><?php if ($thumb) : ?><img loading="lazy" src="<?php echo esc_url($thumb); ?>" alt="<?php echo esc_attr(get_the_title($id)); ?>"><?php else : ?><span class="phisk-poster-placeholder">PHISK</span><?php endif; ?></a>
                      <details class="phisk-dashboard-actions phisk-saved-video-actions">
                        <summary class="phisk-dashboard-more" aria-label="Saved video options" title="Saved video options"><span aria-hidden="true">⋮</span></summary>
                        <div class="phisk-dashboard-action-menu">
                          <a href="<?php echo esc_url($view_url); ?>">View</a>
                          <a href="<?php echo esc_url($remove_url); ?>">Remove</a>
                        </div>
                      </details>
                      <div class="phisk-dashboard-content-info"><h3><a href="<?php echo esc_url($view_url); ?>"><?php echo esc_html(get_the_title($id)); ?></a></h3></div>
                    </article>
                  <?php endforeach; ?>
                </div>
              <?php else : ?>
                <div class="phisk-dashboard-icon-empty phisk-dashboard-icon-empty-saved">
                  <img src="<?php echo esc_url(plugins_url('assets/phisk-icon-saved.svg', __FILE__)); ?>" width="48" height="48" alt="" aria-hidden="true">
                  <p class="phisk-dashboard-empty">You haven't saved any videos yet. Save videos from the three-dot menu to find them here.</p>
                </div>
              <?php endif; ?>
            </section>
          <?php elseif ($active === 'articles') : ?>
            <?php echo $this->dashboard_render_content_tab('post', $user_id, 'Stories'); ?>
          <?php endif; ?>
        </section>
        <?php if (!$is_public_profile) : ?>
        <div class="phisk-image-editor-modal" id="phisk-image-editor-modal" hidden aria-hidden="true">
          <div class="phisk-image-editor-backdrop" data-phisk-image-close></div>
          <section class="phisk-image-editor-dialog" role="dialog" aria-modal="true" aria-labelledby="phisk-image-editor-title">
            <button type="button" class="phisk-image-editor-close" data-phisk-image-close aria-label="Close">×</button>
            <div class="phisk-image-editor-content">
              <div class="phisk-image-editor-intro">
                <img class="phisk-image-editor-illustration" id="phisk-image-editor-illustration" src="" alt="" aria-hidden="true">
                <h2 id="phisk-image-editor-title">Edit image</h2>
                <p id="phisk-image-editor-guidance">Choose an image to get started.</p>
              </div>
              <input type="file" id="phisk-image-editor-file" accept="image/jpeg,image/png,image/webp" hidden>
              <button type="button" class="phisk-image-editor-select" id="phisk-image-editor-select">Choose Image</button>
              <div class="phisk-image-editor-workspace" id="phisk-image-editor-workspace" hidden>
                <div class="phisk-image-editor-crop" id="phisk-image-editor-crop"><div class="phisk-image-editor-crop-image" id="phisk-image-editor-crop-image"></div></div>
                <p class="phisk-image-editor-hint">Drag to reposition · Use the slider to zoom</p>
                <label class="phisk-image-editor-zoom">Zoom <input type="range" id="phisk-image-editor-zoom" min="1" max="3" step="0.01" value="1"></label>
                <div class="phisk-image-editor-actions"><button type="button" class="phisk-image-editor-secondary" id="phisk-image-editor-change">Choose another</button><button type="button" class="phisk-image-editor-primary" id="phisk-image-editor-upload">Upload Image</button></div>
              </div>
              <div class="phisk-image-editor-progress" id="phisk-image-editor-progress" hidden role="status" aria-live="polite"><div class="phisk-image-editor-progress-track"><span></span></div><div class="phisk-image-editor-progress-meta"><strong>Uploading image…</strong><span>0%</span></div></div>
              <div class="phisk-image-editor-success" id="phisk-image-editor-success" hidden><span class="phisk-image-editor-success-icon">✓</span><strong>Image updated successfully!</strong><button type="button" class="phisk-image-editor-primary" id="phisk-image-editor-ok">OK</button></div>
              <p class="phisk-image-editor-error" id="phisk-image-editor-error" hidden role="alert"></p>
            </div>
          </section>
        </div>
        <?php endif; ?>
        <script>
        document.addEventListener('click', function(e) {
          var button = e.target.closest('.phisk-dashboard-share');
          if (!button) return;
          var url = button.getAttribute('data-share-url');
          var title = button.getAttribute('data-share-title') || document.title;
          var done = function() {
            var old = button.textContent;
            button.textContent = '✓ Link Copied';
            setTimeout(function(){ button.textContent = old; }, 1500);
          };
          if (navigator.share) {
            navigator.share({title: title, url: url}).catch(function(){});
          } else if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(url).then(done);
          } else {
            var input = document.createElement('input');
            input.value = url;
            document.body.appendChild(input);
            input.select();
            try { document.execCommand('copy'); done(); } catch(err) {}
            input.remove();
          }
        });
        document.addEventListener('click', function(e) {
          if (!e.target.closest('.phisk-dashboard-actions')) {
            document.querySelectorAll('.phisk-dashboard-actions[open]').forEach(function(menu){ menu.removeAttribute('open'); });
          }
        });
        </script>
        <?php
        return ob_get_clean();
    }

    /** Process administrator publish/reject decisions for submitted articles. */
    public function handle_article_review_action() {
        if (!is_admin() || empty($_POST['phisk_article_review_action'])) return;
        if (!current_user_can('edit_others_posts')) wp_die('You do not have permission to review articles.');
        check_admin_referer('phisk_article_review_action', 'phisk_article_review_nonce');
        $post_id = isset($_POST['article_id']) ? absint($_POST['article_id']) : 0;
        $decision = isset($_POST['decision']) ? sanitize_key(wp_unslash($_POST['decision'])) : '';
        $post = get_post($post_id);
        if (!$post || $post->post_type !== 'post' || !in_array($post->post_status, ['pending','draft'], true)) {
            wp_safe_redirect(add_query_arg('phisk_review_notice', 'invalid', admin_url('edit.php?page=phisk-article-review')));
            exit;
        }
        if ($decision === 'publish') {
            $updated = wp_update_post(['ID'=>$post_id, 'post_status'=>'publish'], true);
            if (!is_wp_error($updated)) {
                delete_post_meta($post_id, '_phisk_article_review_status');
                delete_post_meta($post_id, '_phisk_article_rejection_reason');
                delete_post_meta($post_id, '_phisk_article_rejection_note');
            }
            $notice = is_wp_error($updated) ? 'error' : 'published';
        } elseif ($decision === 'reject') {
            $reason = isset($_POST['rejection_reason']) ? sanitize_key(wp_unslash($_POST['rejection_reason'])) : '';
            $reasons = $this->article_rejection_reasons();
            $note = isset($_POST['rejection_note']) ? sanitize_textarea_field(wp_unslash($_POST['rejection_note'])) : '';
            if (!isset($reasons[$reason])) {
                wp_safe_redirect(add_query_arg('phisk_review_notice', 'reason', admin_url('edit.php?page=phisk-article-review')));
                exit;
            }
            update_post_meta($post_id, '_phisk_article_review_status', 'rejected');
            update_post_meta($post_id, '_phisk_article_rejection_reason', $reason);
            update_post_meta($post_id, '_phisk_article_rejection_note', $note);
            $updated = wp_update_post(['ID'=>$post_id, 'post_status'=>'draft'], true);
            $notice = is_wp_error($updated) ? 'error' : 'rejected';
        } else {
            $notice = 'invalid';
        }
        wp_safe_redirect(add_query_arg(['phisk_review_notice'=>$notice, 'article_id'=>$post_id], admin_url('edit.php?page=phisk-article-review')));
        exit;
    }

    private function article_rejection_reasons() {
        return [
            'inappropriate_content' => 'Inappropriate or offensive content',
            'spam' => 'Spam or promotional abuse',
            'copyright' => 'Copyright or ownership concerns',
            'misleading_information' => 'Misleading or inaccurate information',
            'formatting' => 'Poor formatting or unreadable content',
            'thumbnail' => 'Missing or unsuitable featured thumbnail',
            'guidelines' => 'Community guidelines violation',
            'other' => 'Other (see additional explanation)',
        ];
    }

    /** Administrator queue for articles awaiting review. */
    public function article_review_admin_page() {
        if (!current_user_can('edit_others_posts')) return;
        $notice = isset($_GET['phisk_review_notice']) ? sanitize_key(wp_unslash($_GET['phisk_review_notice'])) : '';
        $messages = ['published'=>'Article published successfully.', 'rejected'=>'Article rejected and the reason saved for the writer.', 'reason'=>'Please choose a valid rejection reason.', 'invalid'=>'That article could not be reviewed.', 'error'=>'The article could not be updated.'];
        echo '<div class="wrap"><h1>Story Review Queue</h1><p>Review submitted Stories, publish approved work, or reject it with a clear reason for the writer.</p>';
        if (isset($messages[$notice])) echo '<div class="notice notice-' . ($notice === 'published' || $notice === 'rejected' ? 'success' : 'warning') . ' is-dismissible"><p>' . esc_html($messages[$notice]) . '</p></div>';
        $query = new WP_Query(['post_type'=>'post', 'post_status'=>'pending', 'posts_per_page'=>50, 'orderby'=>'date', 'order'=>'ASC', 'no_found_rows'=>true]);
        if (!$query->have_posts()) { echo '<div class="notice notice-info"><p>No Stories are currently waiting for review.</p></div></div>'; return; }
        $reasons = $this->article_rejection_reasons();
        echo '<style>.phisk-review-list{display:grid;gap:18px;max-width:1100px}.phisk-review-card{display:grid;grid-template-columns:190px minmax(0,1fr);gap:18px;background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:16px}.phisk-review-card img{width:100%;height:125px;object-fit:cover;border-radius:6px}.phisk-review-card h2{font-size:18px;margin:0 0 6px}.phisk-review-meta{color:#646970;margin:0 0 12px}.phisk-review-actions{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:12px}.phisk-review-actions select,.phisk-review-actions textarea{max-width:100%}.phisk-review-reject{display:grid;grid-template-columns:minmax(200px,1fr) minmax(220px,1fr) auto;gap:8px;align-items:start;margin-top:10px}.phisk-review-reject textarea{min-height:36px}@media(max-width:700px){.phisk-review-card{grid-template-columns:1fr}.phisk-review-card img{height:auto;max-height:260px}.phisk-review-reject{grid-template-columns:1fr}}</style><div class="phisk-review-list">';
        while ($query->have_posts()) {
            $query->the_post(); $id=get_the_ID(); $author=get_userdata((int)get_post_field('post_author',$id)); $thumb=get_the_post_thumbnail_url($id,'large');
            echo '<article class="phisk-review-card"><div>';
            if ($thumb) echo '<img src="' . esc_url($thumb) . '" alt="' . esc_attr(get_the_title()) . '">'; else echo '<div style="background:#f0f0f1;padding:45px 10px;text-align:center;border-radius:6px">No thumbnail</div>';
            echo '</div><div><h2><a href="' . esc_url(get_edit_post_link($id)) . '">' . esc_html(get_the_title() ?: 'Untitled Story') . '</a></h2><p class="phisk-review-meta">By ' . esc_html($author ? $author->display_name : 'Unknown author') . ' · Submitted ' . esc_html(get_the_date('', $id) . ' ' . get_the_time('', $id)) . '</p><div>' . esc_html(wp_trim_words(wp_strip_all_tags(get_post_field('post_content',$id)), 45)) . '</div>';
            echo '<form method="post" class="phisk-review-actions">'; wp_nonce_field('phisk_article_review_action', 'phisk_article_review_nonce');
            echo '<input type="hidden" name="phisk_article_review_action" value="1"><input type="hidden" name="article_id" value="' . esc_attr($id) . '"><button class="button button-primary" name="decision" value="publish">Publish Story</button></form>';
            echo '<form method="post" class="phisk-review-reject">'; wp_nonce_field('phisk_article_review_action', 'phisk_article_review_nonce');
            echo '<input type="hidden" name="phisk_article_review_action" value="1"><input type="hidden" name="article_id" value="' . esc_attr($id) . '"><select name="rejection_reason" required><option value="">Choose rejection reason…</option>';
            foreach ($reasons as $key=>$label) echo '<option value="' . esc_attr($key) . '">' . esc_html($label) . '</option>';
            echo '</select><textarea name="rejection_note" placeholder="Optional explanation for the writer"></textarea><button class="button" name="decision" value="reject">Reject article</button></form></div></article>';
        }
        echo '</div></div>'; wp_reset_postdata();
    }

    public function add_meta_boxes() {
        add_meta_box('phisk_movie_details', 'PhiskVideos Details', [$this, 'movie_meta_box'], ['phisk_movie', 'phisk_tvshow'], 'normal', 'high');
        add_meta_box('phisk_video_details', 'PhiskVideos Video Details', [$this, 'video_meta_box'], 'phisk_video', 'normal', 'high');
        add_meta_box('phisk_video_report_details', 'Report Details', [$this, 'report_meta_box'], 'phisk_report', 'normal', 'high');
    }

    public function movie_meta_box($post) {
        wp_nonce_field(self::NONCE, self::NONCE);
        $fields = [
            'phisk_year' => ['Release Year', 'text', 'e.g. 2026'],
            'phisk_country' => ['Country', 'text', 'e.g. Nigeria'],
            'phisk_runtime' => ['Runtime', 'text', 'e.g. 1h 45m'],
            'phisk_age_rating' => ['Age Restriction', 'text', 'e.g. 16+, PG-13'],
            'phisk_watch_url' => ['Watch URL', 'url', 'https://...'],
            'phisk_watch_label' => ['Watch Button Label', 'text', 'e.g. Watch on YouTube'],
        ];
        $cast = get_post_meta($post->ID, 'phisk_cast', true);
        $crew = get_post_meta($post->ID, 'phisk_crew', true);
        $cast = is_array($cast) ? array_values($cast) : [];
        $crew = is_array($crew) ? array_values($crew) : [];
        echo '<div class="phisk-admin-fields">';
        foreach ($fields as $key => $spec) {
            printf('<p><label for="%1$s"><strong>%2$s</strong></label><br><input class="widefat" type="%3$s" id="%1$s" name="%1$s" value="%4$s" placeholder="%5$s"></p>',
                esc_attr($key), esc_html($spec[0]), esc_attr($spec[1]), esc_attr(get_post_meta($post->ID, $key, true)), esc_attr($spec[2]));
        }

        echo '<hr><h3>Cast</h3><p class="description">Add the actors and their characters. Photos are optional and can be selected from the WordPress Media Library.</p>';
        echo '<div class="phisk-people-list" data-people-type="cast">';
        foreach ($cast as $index => $person) $this->person_admin_row('cast', $index, $person);
        echo '</div><button type="button" class="button phisk-add-person" data-people-type="cast">+ Add Cast Member</button>';

        echo '<hr><h3>Crew</h3><p class="description">Add directors, producers, writers, cinematographers, editors, and other crew members.</p>';
        echo '<div class="phisk-people-list" data-people-type="crew">';
        foreach ($crew as $index => $person) $this->person_admin_row('crew', $index, $person);
        echo '</div><button type="button" class="button phisk-add-person" data-people-type="crew">+ Add Crew Member</button>';

        echo '<p class="description">Use the main WordPress content editor for the plot/synopsis. Set the Featured Image to the movie/show poster. Select one or more Genres and Countries in their taxonomy panels.</p>';
        echo '</div>';
    }

    public function video_meta_box($post) {
        wp_nonce_field(self::NONCE, self::NONCE);
        $provider = get_post_meta($post->ID, '_phisk_video_provider', true) ?: 'wordpress';
        $source_url = get_post_meta($post->ID, '_phisk_video_source_url', true);
        $attachment_id = absint(get_post_meta($post->ID, '_phisk_video_attachment_id', true));
        echo '<p><strong>Video Provider</strong><br><select class="widefat" name="_phisk_video_provider"><option value="wordpress" '.selected($provider,'wordpress',false).'>WordPress / Media Library</option><option value="publitio" '.selected($provider,'publitio',false).'>Publit.io</option><option value="cloudflare_stream" '.selected($provider,'cloudflare_stream',false).'>Cloudflare Stream</option><option value="digitalocean" '.selected($provider,'digitalocean',false).'>DigitalOcean</option><option value="youtube_embed" '.selected($provider,'youtube_embed',false).'>YouTube Embed (imported)</option></select></p>';
        echo '<p><strong>Video Source URL</strong><br><input class="widefat" type="url" name="_phisk_video_source_url" value="'.esc_attr($source_url).'" placeholder="Provider playback URL"></p>';
        $download_url = (string)get_post_meta($post->ID, '_phisk_video_download_url', true);
        echo '<p><strong>Downloadable original file URL (external providers)</strong><br><input class="widefat" type="url" name="_phisk_video_download_url" value="'.esc_attr($download_url).'" placeholder="https://.../original-video.mp4"></p><p class="description">For Publit.io, Cloudflare Stream and DigitalOcean, enter the authorised direct downloadable video file URL when available. Do not enter an HLS .m3u8 playback URL. Leave blank to disable downloads.</p>';
        if ($provider === 'youtube_embed') {
            echo '<p><strong>YouTube video ID:</strong> '.esc_html(get_post_meta($post->ID, '_phisk_youtube_video_id', true)).'</p>';
            echo '<p><strong>Channel metadata:</strong> '.esc_html(get_post_meta($post->ID, '_phisk_youtube_channel_name', true)).'</p>';
            echo '<p><strong>Partnership earnings:</strong> Reduced rate marker enabled.</p>';
            echo '<p class="description">This is an externally hosted YouTube embed. The original video is not stored on Phisk.</p>';
        } else {
            echo '<p class="description">Publit.io is supported for new uploads when enabled under Settings → Phisk Videos. Cloudflare Stream is not yet integrated.</p>';
        }
        if ($attachment_id && wp_get_attachment_url($attachment_id)) echo '<p><strong>Current video:</strong> <a href="'.esc_url(wp_get_attachment_url($attachment_id)).'" target="_blank" rel="noopener">Open video file</a></p>';
        echo '<p>Use the Featured Image for the landscape 16:9 video thumbnail. The main editor is the video description.</p>';
    }

    private function person_admin_row($type, $index, $person) {
        $person_id = isset($person['person_id']) ? absint($person['person_id']) : 0;
        $name = isset($person['name']) ? $person['name'] : '';
        $role = isset($person['role']) ? $person['role'] : '';
        $photo = isset($person['photo']) ? $person['photo'] : '';
        if ($person_id) {
            $p = get_post($person_id);
            if ($p && $p->post_type === 'phisk_person') {
                $name = $p->post_title;
                $thumb = get_the_post_thumbnail_url($person_id, 'thumbnail');
                if ($thumb) $photo = $thumb;
            }
        }
        $role_label = $type === 'cast' ? 'Character' : 'Role';
        $name_value = $name ?: '';
        echo '<div class="phisk-person-row" data-index="' . esc_attr($index) . '">';
        echo '<div class="phisk-person-fields">';
        echo '<div class="phisk-person-picker">';
        echo '<input class="widefat phisk-person-search" type="text" autocomplete="off" value="' . esc_attr($name_value) . '" placeholder="Search existing person by name...">';
        echo '<input type="hidden" class="phisk-person-id" name="phisk_' . esc_attr($type) . '[' . esc_attr($index) . '][person_id]" value="' . esc_attr($person_id) . '">';
        echo '<input type="hidden" class="phisk-person-photo" name="phisk_' . esc_attr($type) . '[' . esc_attr($index) . '][photo]" value="' . esc_attr($photo) . '">';
        echo '<div class="phisk-person-results"></div>';
        echo '<div class="phisk-selected-person">' . ($person_id ? 'Saved person: <strong>' . esc_html($name_value) . '</strong>' : 'Type at least 2 letters to search, or create a new person.') . '</div>';
        echo '<button type="button" class="button phisk-create-person">+ Create New Person</button>';
        echo '</div>';
        printf('<input class="widefat" type="text" name="phisk_%1$s[%2$s][role]" value="%3$s" placeholder="%4$s">', esc_attr($type), esc_attr($index), esc_attr($role), esc_attr($role_label));
        echo '<div class="phisk-photo-field">';
        echo '<button type="button" class="button phisk-person-photo-button">' . ($photo ? 'Change Photo' : 'Select Photo') . '</button>';
        echo '<button type="button" class="button-link-delete phisk-remove-person">Remove</button>';
        echo '<div class="phisk-photo-preview">';
        if ($photo) echo '<img src="' . esc_url($photo) . '" alt="" style="max-width:60px;height:60px;object-fit:cover;border-radius:50%;display:block;margin-top:6px;">';
        echo '</div></div></div></div>';
    }

    public function admin_assets($hook) {
        if (!in_array($hook, ['post.php', 'post-new.php'], true)) return;
        $screen = get_current_screen();
        if (!$screen || !in_array($screen->post_type, ['phisk_movie', 'phisk_tvshow'], true)) return;
        wp_enqueue_media();
        wp_add_inline_style('dashicons', '.phisk-person-row{border:1px solid #dcdcde;padding:12px;margin:10px 0;background:#fff}.phisk-person-fields{display:grid;grid-template-columns:1fr 1fr;gap:8px}.phisk-photo-field,.phisk-person-picker{grid-column:1/-1}.phisk-photo-field .button-link-delete{margin-left:10px}.phisk-people-list{margin-bottom:10px}.phisk-person-picker{position:relative}.phisk-person-results{position:absolute;z-index:9999;left:0;right:0;background:#fff;border:1px solid #8c8f94;display:none;max-height:220px;overflow:auto}.phisk-person-result{padding:8px 10px;cursor:pointer;border-bottom:1px solid #eee}.phisk-person-result:hover{background:#f0f0f1}.phisk-selected-person{font-size:12px;color:#646970;margin:5px 0}.phisk-create-person{margin-top:3px}@media(max-width:700px){.phisk-person-fields{grid-template-columns:1fr}}');
        wp_enqueue_script('jquery');
        wp_enqueue_script('phisk-admin-people', plugins_url('assets/admin-people.js', __FILE__), ['jquery'], self::VERSION, true);
        wp_localize_script('phisk-admin-people', 'PhiskPeople', [
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('phisk_people_nonce'),
        ]);
    }

    public function ajax_search_people() {
        check_ajax_referer('phisk_people_nonce', 'nonce');
        if (!current_user_can('edit_posts')) wp_send_json_error('Permission denied.', 403);
        $q = isset($_POST['q']) ? sanitize_text_field(wp_unslash($_POST['q'])) : '';
        if (mb_strlen($q) < 2) wp_send_json_success([]);
        $posts = get_posts(['post_type'=>'phisk_person','post_status'=>'publish','posts_per_page'=>12,'s'=>$q,'orderby'=>'title','order'=>'ASC']);
        $out=[];
        foreach($posts as $person){$out[]=['id'=>$person->ID,'name'=>$person->post_title,'photo'=>get_the_post_thumbnail_url($person->ID,'thumbnail') ?: get_post_meta($person->ID,'phisk_person_photo',true)];}
        wp_send_json_success($out);
    }

    public function ajax_create_person() {
        check_ajax_referer('phisk_people_nonce', 'nonce');
        if (!current_user_can('edit_posts')) wp_send_json_error('Permission denied.', 403);
        $name=isset($_POST['name'])?sanitize_text_field(wp_unslash($_POST['name'])):'';
        if($name==='') wp_send_json_error('A name is required.');
        $existing=get_page_by_title($name,OBJECT,'phisk_person');
        $id=$existing?$existing->ID:wp_insert_post(['post_type'=>'phisk_person','post_status'=>'publish','post_title'=>$name],true);
        if(is_wp_error($id)) wp_send_json_error($id->get_error_message());
        $photo=isset($_POST['photo'])?esc_url_raw(wp_unslash($_POST['photo'])):'';$photo_id=isset($_POST['photo_id'])?absint($_POST['photo_id']):0;
        if($photo_id) set_post_thumbnail($id,$photo_id); elseif($photo) update_post_meta($id,'phisk_person_photo',$photo);
        wp_send_json_success(['id'=>$id,'name'=>get_the_title($id),'photo'=>get_the_post_thumbnail_url($id,'thumbnail') ?: get_post_meta($id,'phisk_person_photo',true)]);
    }

    public function maybe_migrate_people() {
        if (get_option('phisk_people_migrated_109')) return;
        if (!current_user_can('manage_options')) return;
        $ids=get_posts(['post_type'=>['phisk_movie','phisk_tvshow'],'post_status'=>'any','posts_per_page'=>-1,'fields'=>'ids']);
        foreach ($ids as $post_id) {
            foreach (['phisk_cast', 'phisk_crew'] as $key) {
                $people = get_post_meta($post_id, $key, true);
                if (!is_array($people)) continue;
                if (isset($people['name'])) $people = [$people];
                $changed = false;
                $clean = [];
                foreach ($people as $person) {
                    if (!is_array($person)) continue;
                    $name = isset($person['name']) ? sanitize_text_field($person['name']) : '';
                    $role = isset($person['role']) ? sanitize_text_field($person['role']) : '';
                    $photo = isset($person['photo']) ? esc_url_raw($person['photo']) : '';
                    $pid = isset($person['person_id']) ? absint($person['person_id']) : 0;
                    if (!$pid && $name) {
                        $existing = get_page_by_title($name, OBJECT, 'phisk_person');
                        $pid = $existing ? $existing->ID : wp_insert_post(['post_type' => 'phisk_person', 'post_status' => 'publish', 'post_title' => $name], true);
                        if (!is_wp_error($pid)) {
                            if ($photo && !has_post_thumbnail($pid)) update_post_meta($pid, 'phisk_person_photo', $photo);
                            $changed = true;
                        }
                    }
                    if (!$name && $pid) $name = get_the_title($pid);
                    $clean[] = ['person_id' => (int) $pid, 'name' => $name, 'role' => $role, 'photo' => $photo];
                }
                if ($changed) update_post_meta($post_id, $key, $clean);
            }
        }
        update_option('phisk_people_migrated_109',1,false);
    }

    public function save_meta($post_id, $post) {
        if (!isset($_POST[self::NONCE]) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST[self::NONCE])), self::NONCE)) return;
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (wp_is_post_revision($post_id) || !current_user_can('edit_post', $post_id)) return;
        if (in_array($post->post_type, ['phisk_movie', 'phisk_tvshow'], true)) {
            $keys = ['phisk_year', 'phisk_country', 'phisk_runtime', 'phisk_age_rating', 'phisk_watch_url', 'phisk_watch_label'];
            foreach ($keys as $key) {
                if (!isset($_POST[$key])) continue;
                $value = wp_unslash($_POST[$key]);
                $value = $key === 'phisk_watch_url' ? esc_url_raw($value) : sanitize_text_field($value);
                update_post_meta($post_id, $key, $value);
            }
            foreach (['phisk_cast', 'phisk_crew'] as $people_key) {
                $people = isset($_POST[$people_key]) && is_array($_POST[$people_key]) ? wp_unslash($_POST[$people_key]) : [];
                $clean = [];
                foreach ($people as $person) {
                    if (!is_array($person)) continue;
                    $person_id = isset($person['person_id']) ? absint($person['person_id']) : 0;
                    $name = isset($person['name']) ? sanitize_text_field($person['name']) : '';
                    $role = isset($person['role']) ? sanitize_text_field($person['role']) : '';
                    $photo = isset($person['photo']) ? esc_url_raw($person['photo']) : '';
                    if ($person_id) {
                        $person_post = get_post($person_id);
                        if ($person_post && $person_post->post_type === 'phisk_person') {
                            $name = $person_post->post_title;
                            $thumb = get_the_post_thumbnail_url($person_id, 'thumbnail');
                            if ($thumb) $photo = $thumb;
                            elseif (!$photo) $photo = get_post_meta($person_id, 'phisk_person_photo', true);
                        } else { $person_id = 0; }
                    }
                    if ($name === '' && $role === '' && $photo === '') continue;
                    $clean[] = ['person_id' => $person_id, 'name' => $name, 'role' => $role, 'photo' => $photo];
                }
                if ($clean) update_post_meta($post_id, $people_key, $clean);
                else delete_post_meta($post_id, $people_key);
            }
        } elseif ($post->post_type === 'phisk_video') {
            foreach (['phisk_year','phisk_runtime','phisk_age_rating'] as $key) {
                if (isset($_POST[$key])) update_post_meta($post_id, $key, sanitize_text_field(wp_unslash($_POST[$key])));
            }
            if (isset($_POST['_phisk_video_provider'])) update_post_meta($post_id, '_phisk_video_provider', sanitize_key(wp_unslash($_POST['_phisk_video_provider'])));
            if (isset($_POST['_phisk_video_source_url'])) update_post_meta($post_id, '_phisk_video_source_url', esc_url_raw(wp_unslash($_POST['_phisk_video_source_url'])));
            if (isset($_POST['_phisk_video_download_url'])) update_post_meta($post_id, '_phisk_video_download_url', esc_url_raw(wp_unslash($_POST['_phisk_video_download_url'])));
        }
    }

    public function register_assets() {
        wp_register_style('phiskvideos-front', plugin_dir_url(__FILE__) . 'assets/front.css', [], self::VERSION);
        wp_register_script('phiskvideos-front', plugin_dir_url(__FILE__) . 'assets/front.js', ['jquery'], self::VERSION, true);
        wp_localize_script('phiskvideos-front', 'PhiskVideosFront', [
            'ajaxurl' => admin_url('admin-ajax.php'),
            'subscriptionAction' => 'phisk_toggle_subscription',
            'subscriptionNonceAction' => 'phisk_subscription_nonce',
            'likeAction' => 'phisk_toggle_video_like',
            'likeNonceAction' => 'phisk_video_like_nonce',
            'commentAction' => 'phisk_add_video_comment',
            'reportAction' => 'phisk_submit_video_report',
            'reportNonce' => wp_create_nonce('phisk_video_report_nonce'),
            'videoUploadNonce' => wp_create_nonce('phisk_video_upload_nonce'),
            'videoSubmitNonce' => wp_create_nonce('phisk_video_submit_nonce'),
            'commentNonceAction' => 'phisk_video_comment_nonce',
            'articleVoteNonce' => wp_create_nonce('phisk_article_vote_nonce'),
            'usernameCheckNonce' => wp_create_nonce('phisk_public_username_check'),
            'storyImageNonce' => wp_create_nonce('phisk_story_image_upload'),
            'channelImageNonce' => wp_create_nonce('phisk_profile_image_upload'),
            'pluginUrl' => plugin_dir_url(__FILE__),
        ]);
        wp_enqueue_script('phiskvideos-front');
        if (is_singular('post') && get_option('thread_comments')) wp_enqueue_script('comment-reply');
    }
    private function enqueue_style() {
        wp_enqueue_style('phiskvideos-front');
        wp_enqueue_script('phiskvideos-front');
    }

    private function phisk_following_ids($user_id) {
        $following = get_user_meta($user_id, 'phisk_following', true);
        if (!is_array($following)) $following = [];
        $following = array_values(array_unique(array_filter(array_map('absint', $following))));
        return $following;
    }

    private function phisk_subscriber_count($author_id) {
        $author_id = absint($author_id);
        if (!$author_id) return 0;
        return max(0, (int) get_user_meta($author_id, 'phisk_subscriber_count', true));
    }

    public function phisk_subscribe_button($author_id) {
        $author_id = absint($author_id);
        if (!$author_id || !get_userdata($author_id) || !is_user_logged_in() || get_current_user_id() === $author_id) return '';
        $following = $this->phisk_following_ids(get_current_user_id());
        $subscribed = in_array($author_id, $following, true);
        return '<button type="button" class="phisk-subscribe-button'.($subscribed ? ' is-subscribed' : '').'" data-author-id="'.esc_attr($author_id).'" data-nonce="'.esc_attr(wp_create_nonce('phisk_subscription_nonce')).'" aria-pressed="'.($subscribed ? 'true' : 'false').'">'.($subscribed ? 'Subscribed' : 'Subscribe').'</button>';
    }

    public function ajax_toggle_subscription() {
        if (!is_user_logged_in()) wp_send_json_error(['message' => 'Login required.'], 401);
        check_ajax_referer('phisk_subscription_nonce', 'nonce');
        $user_id = get_current_user_id();
        $author_id = isset($_POST['author_id']) ? absint($_POST['author_id']) : 0;
        if (!$author_id || !get_userdata($author_id) || $author_id === $user_id) wp_send_json_error(['message' => 'Invalid account.'], 400);
        $following = $this->phisk_following_ids($user_id);
        if (in_array($author_id, $following, true)) {
            $following = array_values(array_diff($following, [$author_id]));
            $subscribed = false;
        } else {
            $following[] = $author_id;
            $following = array_values(array_unique(array_map('absint', $following)));
            $subscribed = true;
        }
        update_user_meta($user_id, 'phisk_following', $following);
        $subscriber_count = $this->phisk_subscriber_count($author_id);
        $subscriber_count = $subscribed ? $subscriber_count + 1 : max(0, $subscriber_count - 1);
        update_user_meta($author_id, 'phisk_subscriber_count', $subscriber_count);
        $demo_subscriber_count = (bool) get_user_meta($author_id, '_phisk_demo_stats_enabled', true);
        wp_send_json_success(['subscribed' => $subscribed, 'subscriber_count' => $subscriber_count, 'display_subscriber_count' => $this->phisk_display_subscriber_count($author_id), 'demo_display' => $demo_subscriber_count]);
    }

    private function phisk_video_like_count($video_id) {
        $video_id = absint($video_id);
        if (!$video_id) return 0;
        $count = get_post_meta($video_id, '_phisk_video_like_count', true);
        return max(0, (int) $count);
    }

    private function phisk_user_liked_video($user_id, $video_id) {
        if (!$user_id || !$video_id) return false;
        $liked = get_user_meta($user_id, 'phisk_liked_videos', true);
        if (!is_array($liked)) $liked = [];
        return in_array(absint($video_id), array_map('absint', $liked), true);
    }

    public function video_engagement_markup($video_id, $context = 'feed') {
        $video_id = absint($video_id);
        if (!$video_id) return '';
        $count = $this->phisk_video_like_count($video_id);
        $liked = is_user_logged_in() ? $this->phisk_user_liked_video(get_current_user_id(), $video_id) : false;
        $nonce = wp_create_nonce('phisk_video_like_nonce');
        $comments = (int) get_comments([
            'post_id' => $video_id,
            'status' => 'approve',
            'count' => true,
            'type' => 'comment',
        ]);
        $class = $context === 'single' ? ' phisk-engagement-single' : ' phisk-engagement-feed';
        $login_note = !is_user_logged_in() ? ' title="Log in to like this video"' : '';
        $report_button = $context === 'single'
            ? '<button type="button" class="phisk-video-report-button" data-video-id="' . esc_attr($video_id) . '" aria-label="Report this video"><span class="phisk-report-label">Report</span></button>'
            : '';
        $share_button = $context === 'single'
            ? '<button type="button" class="phisk-video-share" data-share-url="' . esc_url(get_permalink($video_id)) . '" data-share-title="' . esc_attr(get_the_title($video_id)) . '" aria-label="Share this video"><span class="phisk-share-label">Share</span></button>'
            : '';
        $embed_url = home_url('/phisk-embed/' . $video_id . '/');
        $embed_button = $context === 'single'
            ? '<button type="button" class="phisk-video-embed-button" data-embed-url="' . esc_url($embed_url) . '" data-embed-title="' . esc_attr(get_the_title($video_id)) . '">Embed</button>'
            : '';
        $download_button = '';
        if ($context === 'single' && is_user_logged_in() && $this->phisk_video_download_url($video_id)) {
            $creator = get_userdata((int)get_post_field('post_author', $video_id));
            $channel_name = $creator ? $this->phisk_creator_display_name((int)$creator->ID) : get_bloginfo('name');
            $thumbnail = get_the_post_thumbnail_url($video_id, 'large');
            $download_button = '<button type="button" class="phisk-video-download-button" data-video-id="' . esc_attr($video_id) . '" data-nonce="' . esc_attr(wp_create_nonce('phisk_video_download_' . $video_id)) . '" data-filename="' . esc_attr(sanitize_file_name(get_the_title($video_id)) . '.mp4') . '" data-title="' . esc_attr(get_the_title($video_id)) . '" data-thumbnail="' . esc_url($thumbnail ?: '') . '" data-channel="' . esc_attr($channel_name) . '" hidden aria-label="Download video"><span class="phisk-download-label">Download</span></button>';
        }
        $display_views = $this->phisk_display_video_views($video_id);
        $demo_views = $this->phisk_video_demo_label($video_id);
        $view_markup = '<div class="phisk-video-view-count' . ($demo_views ? ' is-demo-stats' : '') . '"><span>' . esc_html(number_format_i18n($display_views)) . ' views</span>' . ($demo_views ? '<span class="phisk-demo-stats-label">Promotional Stats</span>' : '') . '</div>';
        return $view_markup . '<div class="phisk-video-engagement' . esc_attr($class) . '" data-video-id="' . esc_attr($video_id) . '">'
            . $download_button
            . $embed_button
            . $share_button
            . '<button type="button" class="phisk-video-like-button' . ($liked ? ' is-liked' : '') . '" data-video-id="' . esc_attr($video_id) . '" data-nonce="' . esc_attr($nonce) . '" aria-label="' . esc_attr($liked ? 'Unlike this video' : 'Like this video') . '" aria-pressed="' . ($liked ? 'true' : 'false') . '"' . $login_note . '><span class="phisk-like-label">Like</span><span class="phisk-like-count">' . esc_html(number_format_i18n($count)) . '</span></button>'
            . '<a class="phisk-video-comment-link" aria-label="View comments" href="' . esc_url(add_query_arg('phisk_comments','1',get_permalink($video_id))) . '"><span class="phisk-comment-label">Comment</span><span class="phisk-comment-count">' . esc_html(number_format_i18n($comments)) . '</span></a>'
            . $report_button
            . '</div>';
    }

    public function register_downloads_route() {
        add_rewrite_rule('^downloads/?$', 'index.php?phisk_app_downloads=1', 'top');
    }

    public function register_downloads_query_var($vars) {
        $vars[] = 'phisk_app_downloads';
        return $vars;
    }

    /** Browser fallback for the Downloads menu item; the Android WebView intercepts it. */
    public function render_downloads_fallback() {
        if (!get_query_var('phisk_app_downloads')) return;
        status_header(200);
        get_header();
        echo '<main style="max-width:720px;margin:48px auto;padding:24px;text-align:center">';
        echo '<h1>PhiskVideos Downloads</h1><p>Get the PhiskVideos app to download videos and watch them offline.</p>';
        echo '<a href="' . esc_url(home_url('/')) . '" style="display:inline-block;background:#7C3AED;color:#fff;padding:12px 22px;text-decoration:none;border-radius:6px">Explore PhiskVideos</a>';
        echo '</main>';
        get_footer();
        exit;
    }

    /** Register a shared, nonce-protected logout URL for browsers and the Android app. */
    public function register_logout_route() {
        add_rewrite_rule('^logout/?$', 'index.php?phisk_universal_logout=1', 'top');
    }

    public function register_logout_query_var($vars) {
        $vars[] = 'phisk_universal_logout';
        return $vars;
    }

    /**
     * GET displays a confirmation form; only a nonce-protected POST performs logout.
     * This prevents crawlers, link previews, and cross-site image requests from logging users out.
     * On Android, the success page calls the native bridge after WordPress has invalidated its cookie.
     */
    public function handle_universal_logout() {
        // Also recognise the path directly. This keeps /logout/ working on hosts whose
        // rewrite layer does not refresh custom rules immediately after plugin updates.
        $request_path = trim((string)wp_parse_url(wp_unslash($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH), '/');
        $home_path = trim((string)wp_parse_url(home_url('/'), PHP_URL_PATH), '/');
        $expected_path = trim(($home_path !== '' ? $home_path . '/' : '') . 'logout', '/');
        $is_logout_path = ($request_path === $expected_path);
        if (!get_query_var('phisk_universal_logout') && !$is_logout_path) return;

        nocache_headers();
        if (!is_user_logged_in()) {
            wp_safe_redirect(home_url('/'));
            exit;
        }

        $error = '';
        if (strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
            $nonce = isset($_POST['phisk_universal_logout_nonce'])
                ? sanitize_text_field(wp_unslash($_POST['phisk_universal_logout_nonce'])) : '';
            if (!$nonce || !wp_verify_nonce($nonce, 'phisk_universal_logout')) {
                $error = 'Your security check expired. Please try again.';
            } else {
                wp_logout();
                status_header(200);
                header('Content-Type: text/html; charset=' . get_option('blog_charset'));
                $home = esc_url(home_url('/'));
                echo '<!doctype html><html lang="en"><head><meta charset="' . esc_attr(get_option('blog_charset')) . '"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Logged out - PhiskVideos</title></head><body style="margin:0;background:#fff;color:#171717;font-family:Arial,sans-serif"><main style="max-width:480px;margin:12vh auto;padding:28px;text-align:center"><h1 style="font-size:25px">You are logged out</h1><p>Your PhiskVideos account session has ended.</p><a href="' . $home . '" style="display:inline-block;margin-top:12px;padding:12px 22px;background:#7C3AED;color:#fff;text-decoration:none;border-radius:5px">Continue to PhiskVideos</a></main><script>(function(){try{if(window.PhiskApp&&typeof window.PhiskApp.completeLogout==="function"){window.PhiskApp.completeLogout();return;}}catch(e){}window.setTimeout(function(){window.location.replace(' . wp_json_encode(home_url('/')) . ');},1800);})();</script></body></html>';
                exit;
            }
        }

        status_header(200);
        header('Content-Type: text/html; charset=' . get_option('blog_charset'));
        $nonce_field = wp_nonce_field('phisk_universal_logout', 'phisk_universal_logout_nonce', true, false);
        echo '<!doctype html><html lang="en"><head><meta charset="' . esc_attr(get_option('blog_charset')) . '"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Log out - PhiskVideos</title></head><body style="margin:0;background:#fff;color:#171717;font-family:Arial,sans-serif"><main style="max-width:480px;margin:12vh auto;padding:28px;text-align:center"><h1 style="font-size:25px">Log out of PhiskVideos?</h1><p>Are you sure you want to end your account session?</p>';
        if ($error) echo '<p role="alert" style="color:#b42318">' . esc_html($error) . '</p>';
        echo '<form method="post" action="' . esc_url(home_url('/logout/')) . '">' . $nonce_field . '<button type="submit" style="border:0;cursor:pointer;margin:8px;padding:12px 24px;background:#7C3AED;color:#fff;border-radius:5px;font-size:15px">Yes, log me out</button></form><a href="' . esc_url(home_url('/')) . '" style="display:inline-block;margin-top:12px;color:#6D28D9">Cancel</a></main></body></html>';
        exit;
    }

    /** Return an explicitly authorised downloadable file for a platform-owned video. */
    private function phisk_video_download_url($video_id) {
        $provider = sanitize_key((string)get_post_meta($video_id, '_phisk_video_provider', true));
        if ($provider === 'youtube_embed' || !$provider) return '';
        if ($provider === 'wordpress') {
            $attachment_id = absint(get_post_meta($video_id, '_phisk_video_attachment_id', true));
            $url = $attachment_id ? wp_get_attachment_url($attachment_id) : (string)get_post_meta($video_id, '_phisk_video_source_url', true);
            if (!$url || !wp_http_validate_url($url)) return '';
            $path = (string)parse_url($url, PHP_URL_PATH);
            $mime = $attachment_id ? get_post_mime_type($attachment_id) : '';
            if (($mime && strpos($mime, 'video/') !== 0) || (!$mime && !preg_match('/\.(mp4|m4v|mov|webm|ogv)(?:$|\?)/i', $url))) return '';
            return esc_url_raw($url);
        }
        // External providers must have an explicit downloadable original URL saved by an admin.
        // Playback/HLS manifests are deliberately never treated as downloadable files.
        if (in_array($provider, ['publitio', 'cloudflare_stream', 'digitalocean'], true)) {
            $url = (string)get_post_meta($video_id, '_phisk_video_download_url', true);
            if (!$url || !wp_http_validate_url($url) || !preg_match('/\.(mp4|m4v|mov|webm|ogv)(?:$|\?)/i', $url)) return '';
            return esc_url_raw($url);
        }
        return '';
    }

    public function ajax_get_video_download() {
        if (!is_user_logged_in()) wp_send_json_error(['message' => 'Please log in to download this video.'], 401);
        $video_id = isset($_POST['video_id']) ? absint($_POST['video_id']) : 0;
        if (!$video_id || get_post_type($video_id) !== 'phisk_video' || get_post_status($video_id) !== 'publish') {
            wp_send_json_error(['message' => 'This video is unavailable.'], 404);
        }
        check_ajax_referer('phisk_video_download_' . $video_id, 'nonce');
        $url = $this->phisk_video_download_url($video_id);
        if (!$url) wp_send_json_error(['message' => 'A downloadable video file is not available for this video.'], 409);
        $creator = get_userdata((int)get_post_field('post_author', $video_id));
        wp_send_json_success([
            'url' => $url,
            'filename' => sanitize_file_name(get_the_title($video_id)) . '.mp4',
            'title' => get_the_title($video_id),
            'thumbnail' => get_the_post_thumbnail_url($video_id, 'large') ?: '',
            'channel' => $creator ? $this->phisk_creator_display_name((int)$creator->ID) : get_bloginfo('name'),
        ]);
    }

    public function ajax_toggle_video_like() {
        $video_id = isset($_POST['video_id']) ? absint($_POST['video_id']) : 0;
        if (!$video_id || get_post_type($video_id) !== 'phisk_video' || get_post_status($video_id) !== 'publish') {
            wp_send_json_error(['message' => 'Invalid video.'], 400);
        }
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => 'Please log in to like videos.'], 401);
        }
        check_ajax_referer('phisk_video_like_nonce', 'nonce');
        $user_id = get_current_user_id();
        $liked = get_user_meta($user_id, 'phisk_liked_videos', true);
        if (!is_array($liked)) $liked = [];
        $liked = array_values(array_unique(array_filter(array_map('absint', $liked))));
        $index = array_search($video_id, $liked, true);
        if ($index !== false) {
            unset($liked[$index]);
            $liked = array_values($liked);
            $is_liked = false;
            $count = max(0, $this->phisk_video_like_count($video_id) - 1);
        } else {
            $liked[] = $video_id;
            $is_liked = true;
            $count = $this->phisk_video_like_count($video_id) + 1;
        }
        update_user_meta($user_id, 'phisk_liked_videos', $liked);
        update_post_meta($video_id, '_phisk_video_like_count', $count);
        wp_send_json_success(['liked' => $is_liked, 'like_count' => $count]);
    }

    public function ajax_submit_video_report() {
        if (!is_user_logged_in()) wp_send_json_error(['message' => 'Please log in to report a video.'], 401);
        check_ajax_referer('phisk_video_report_nonce', 'nonce');
        $video_id = isset($_POST['video_id']) ? absint($_POST['video_id']) : 0;
        if (!$video_id || get_post_type($video_id) !== 'phisk_video' || get_post_status($video_id) !== 'publish') wp_send_json_error(['message' => 'Invalid video.'], 400);
        $reason = isset($_POST['reason']) ? sanitize_text_field(wp_unslash($_POST['reason'])) : '';
        $details = isset($_POST['details']) ? sanitize_textarea_field(wp_unslash($_POST['details'])) : '';
        $allowed = ['Spam or misleading','Hateful or abusive content','Harassment or bullying','Violence or dangerous content','Sexual or inappropriate content','Copyright infringement','Scam or fraud','Privacy violation','Something else'];
        if (!in_array($reason, $allowed, true)) wp_send_json_error(['message' => 'Please select a valid reason.'], 400);
        $report_id = wp_insert_post([
            'post_type' => 'phisk_report', 'post_status' => 'publish',
            'post_title' => 'Report: ' . (get_the_title($video_id) ?: ('Video #' . $video_id)),
            'post_author' => get_current_user_id(),
        ], true);
        if (is_wp_error($report_id) || !$report_id) wp_send_json_error(['message' => 'Unable to submit the report. Please try again.'], 500);
        update_post_meta($report_id, '_phisk_report_video_id', $video_id);
        update_post_meta($report_id, '_phisk_reporter_id', get_current_user_id());
        update_post_meta($report_id, '_phisk_report_reason', $reason);
        update_post_meta($report_id, '_phisk_report_details', $details);
        update_post_meta($report_id, '_phisk_report_status', 'pending');
        update_post_meta($report_id, '_phisk_report_submitted_at', current_time('mysql'));
        wp_send_json_success(['message' => 'Report submitted. Thank you for helping keep Phisk safe.']);
    }

    public function add_report_meta_box() {
        remove_meta_box('submitdiv', 'phisk_report', 'side');
        add_meta_box('submitdiv', 'Report Status', [$this, 'report_status_meta_box'], 'phisk_report', 'side', 'high');
    }

    public function report_status_meta_box($post) {
        wp_nonce_field('phisk_report_status_save', 'phisk_report_status_nonce');
        $status = get_post_meta($post->ID, '_phisk_report_status', true) ?: 'pending';
        $statuses = ['pending'=>'Pending','reviewing'=>'Reviewing','resolved'=>'Resolved','dismissed'=>'Dismissed'];
        echo '<p><label for="phisk_report_status"><strong>Status</strong></label></p><select class="widefat" id="phisk_report_status" name="phisk_report_status">';
        foreach ($statuses as $key=>$label) echo '<option value="'.esc_attr($key).'" '.selected($status,$key,false).'>'.esc_html($label).'</option>';
        echo '</select><p class="description">Choose the new status and save the report.</p>';
        submit_button('Update', 'primary', 'save', false, ['style'=>'margin-top:10px;width:100%;']);
    }

    public function report_meta_box($post) {
        $video_id=absint(get_post_meta($post->ID,'_phisk_report_video_id',true));
        $reporter_id=absint(get_post_meta($post->ID,'_phisk_reporter_id',true));
        $reason=get_post_meta($post->ID,'_phisk_report_reason',true);
        $details=get_post_meta($post->ID,'_phisk_report_details',true);
        $submitted=get_post_meta($post->ID,'_phisk_report_submitted_at',true);
        $u=$reporter_id?get_userdata($reporter_id):false;
        echo '<table class="widefat striped" style="border:0">';
        echo '<tr><td style="width:180px"><strong>Video</strong></td><td>';
        if($video_id && get_post($video_id)) echo '<a href="'.esc_url(get_edit_post_link($video_id)).'">'.esc_html(get_the_title($video_id)).'</a> &nbsp; <a href="'.esc_url(get_permalink($video_id)).'" target="_blank" rel="noopener">View video</a>'; else echo 'Video no longer exists.';
        echo '</td></tr>';
        echo '<tr><td><strong>Reported by</strong></td><td>'.esc_html($u?$u->display_name:'Unknown user').'</td></tr>';
        echo '<tr><td><strong>Reason</strong></td><td>'.esc_html($reason).'</td></tr>';
        echo '<tr><td><strong>Submitted</strong></td><td>'.esc_html($submitted?:get_the_date('', $post)).'</td></tr>';
        echo '<tr><td><strong>Additional details</strong></td><td>'.($details!==''?nl2br(esc_html($details)):'<em>No additional details.</em>').'</td></tr>';
        echo '</table>';
        echo '<p class="description" style="margin-top:12px">Use the Status box to mark this report Pending, Reviewing, Resolved, or Dismissed.</p>';
    }

    public function report_columns($columns) {
        return ['cb'=>$columns['cb'],'title'=>'Report','phisk_report_video'=>'Video','phisk_report_reason'=>'Reason','phisk_reporter'=>'Reporter','phisk_report_status'=>'Status','date'=>'Date'];
    }

    public function report_column_content($column,$post_id) {
        if($column==='phisk_report_video'){ $id=absint(get_post_meta($post_id,'_phisk_report_video_id',true)); echo ($id&&get_post($id))?'<a href="'.esc_url(get_edit_post_link($id)).'">'.esc_html(get_the_title($id)).'</a>':'—'; }
        elseif($column==='phisk_report_reason') echo esc_html(get_post_meta($post_id,'_phisk_report_reason',true)?:'—');
        elseif($column==='phisk_reporter'){ $id=absint(get_post_meta($post_id,'_phisk_reporter_id',true)); $u=$id?get_userdata($id):false; echo esc_html($u?$u->display_name:'Unknown'); }
        elseif($column==='phisk_report_status') echo esc_html(ucfirst(get_post_meta($post_id,'_phisk_report_status',true)?:'pending'));
    }

    public function report_sortable_columns($columns) { $columns['phisk_report_status']='phisk_report_status'; return $columns; }

    public function save_report_status($post_id,$post) {
        if($post->post_type!=='phisk_report') return;
        if(!isset($_POST['phisk_report_status_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['phisk_report_status_nonce'])),'phisk_report_status_save')) return;
        if(defined('DOING_AUTOSAVE')&&DOING_AUTOSAVE) return;
        if(!current_user_can('edit_post',$post_id)) return;
        $status=isset($_POST['phisk_report_status'])?sanitize_key(wp_unslash($_POST['phisk_report_status'])):'pending';
        if(!in_array($status,['pending','reviewing','resolved','dismissed'],true)) $status='pending';
        update_post_meta($post_id,'_phisk_report_status',$status);
    }

    /** Render a comment and its nested replies for the dedicated comments page. */
    private function render_video_comment_node($comment, $children_map, $video_id, $nonce, $depth = 0, $children_counts = []) {
        $comment_id = absint($comment->comment_ID);
        $avatar_id = $comment->user_id ? absint(get_user_meta($comment->user_id, 'phisk_profile_image_id', true)) : 0;
        $avatar = $avatar_id ? wp_get_attachment_image_url($avatar_id, 'thumbnail') : get_avatar_url($comment->user_id ?: $comment->comment_author_email, ['size'=>72]);
        $author = $comment->user_id ? $this->phisk_creator_display_name((int)$comment->user_id) : $comment->comment_author;
        $author_url = $comment->user_id ? $this->phisk_user_dashboard_url((int)$comment->user_id) : '';
        $children = isset($children_map[$comment_id]) ? $children_map[$comment_id] : [];
        $children_count = isset($children_counts[$comment_id]) ? (int)$children_counts[$comment_id] : count($children);
        $class = $depth > 0 ? ' phisk-comment-reply' : '';
        $html = '<article id="phisk-comment-' . $comment_id . '" class="phisk-video-comment' . esc_attr($class) . '" data-comment-id="' . $comment_id . '">';
        $html .= '<img class="phisk-comment-avatar" src="' . esc_url($avatar) . '" alt=""><div class="phisk-comment-body">';
        if ((int)$comment->comment_parent) {
            $parent_comment = get_comment((int)$comment->comment_parent);
            if ($parent_comment) {
                $parent_author = $parent_comment->user_id ? $this->phisk_creator_display_name((int)$parent_comment->user_id) : $parent_comment->comment_author;
                $html .= '<div class="phisk-comment-reply-context">Replying to <strong>' . esc_html($parent_author) . '</strong></div>';
            }
        }
        $html .= '<div class="phisk-comment-author-row"><strong>' . ($author_url ? '<a href="' . esc_url($author_url) . '">' . esc_html($author) . '</a>' : esc_html($author)) . '</strong><time>' . esc_html(get_comment_date('', $comment)) . '</time></div>';
        $html .= '<div class="phisk-comment-text">' . nl2br(esc_html($comment->comment_content)) . '</div>';
        if (is_user_logged_in()) {
            $html .= '<button type="button" class="phisk-comment-reply-button" data-parent-id="' . $comment_id . '">Reply</button>';
            $html .= '<form class="phisk-comment-reply-form" data-video-id="' . absint($video_id) . '" data-parent-id="' . $comment_id . '" data-nonce="' . esc_attr($nonce) . '" hidden><textarea name="comment" maxlength="2000" required placeholder="Write a reply..."></textarea><button type="submit">Send reply</button><span class="phisk-comment-form-message" aria-live="polite"></span></form>';
        }
        if ($children_count > 0) {
            $html .= '<button type="button" class="phisk-comment-toggle-replies" data-loaded="' . ($children ? '1' : '0') . '" aria-expanded="false">View ' . number_format_i18n($children_count) . ($children_count === 1 ? ' reply' : ' replies') . '</button>';
        }
        $html .= '<div class="phisk-comment-children" data-parent-id="' . $comment_id . '"' . ($children ? ' hidden' : '') . '>';
        foreach ($children as $child) $html .= $this->render_video_comment_node($child, $children_map, $video_id, $nonce, $depth + 1, $children_counts);
        $html .= '</div></div></article>';
        return $html;
    }

    public function video_comments_markup($video_id) {
        $video_id = absint($video_id);
        // The video page itself never queries or renders comments.
        if (empty($_GET['phisk_comments'])) return '';
        $nonce = wp_create_nonce('phisk_video_comment_nonce');
        ob_start();
        echo '<main class="phisk-comments-page" data-video-id="' . esc_attr($video_id) . '" data-comment-nonce="' . esc_attr($nonce) . '">';
        echo '<a class="phisk-comments-back" href="' . esc_url(get_permalink($video_id)) . '">← Back to video</a>';
        echo '<header class="phisk-comments-page-heading"><h1>Comments</h1><span class="phisk-comments-total">—</span></header>';
        if (is_user_logged_in()) {
            echo '<form class="phisk-video-comment-form" data-video-id="' . esc_attr($video_id) . '" data-nonce="' . esc_attr($nonce) . '"><textarea name="comment" rows="3" maxlength="2000" required placeholder="Add a comment..."></textarea><div class="phisk-comment-form-actions"><span>Commenting as ' . esc_html($this->phisk_creator_display_name(get_current_user_id())) . '</span><button type="submit">Comment</button></div><div class="phisk-comment-form-message" aria-live="polite"></div></form>';
        }
        echo '<div class="phisk-comments-loading" role="status"><span class="phisk-comments-spinner" aria-hidden="true"></span><span>Loading comments…</span></div>';
        echo '<div class="phisk-video-comment-list" aria-live="polite"></div><button type="button" class="phisk-comments-load-more" hidden>Load more comments</button>';
        echo '</main>';
        return ob_get_clean();
    }

    /** Retrieve only 20 root comments after the visitor opens the dedicated comments page. */
    public function ajax_load_video_comments() {
        check_ajax_referer('phisk_video_comment_nonce', 'nonce');
        $video_id = absint($_POST['video_id'] ?? 0);
        $page = max(1, absint($_POST['page'] ?? 1));
        $target_id = absint($_POST['target_comment_id'] ?? 0);
        $target_path = [];
        if (!$video_id || get_post_type($video_id) !== 'phisk_video' || get_post_status($video_id) !== 'publish') wp_send_json_error(['message'=>'Invalid video.'], 400);
        $per_page = 20;
        if ($target_id) {
            $target = get_comment($target_id);
            if ($target && (int)$target->comment_post_ID === $video_id) {
                $cursor = $target;
                while ($cursor && (int)$cursor->comment_parent > 0) {
                    $target_path[] = (int)$cursor->comment_parent;
                    $cursor = get_comment((int)$cursor->comment_parent);
                }
                $target_path = array_reverse($target_path);
                if ($cursor) {
                    global $wpdb;
                    $before = (int)$wpdb->get_var($wpdb->prepare(
                        "SELECT COUNT(*) FROM {$wpdb->comments} WHERE comment_post_ID = %d AND comment_approved = '1' AND comment_type = 'comment' AND comment_parent = 0 AND (comment_date_gmt < %s OR (comment_date_gmt = %s AND comment_ID <= %d))",
                        $video_id, $cursor->comment_date_gmt, $cursor->comment_date_gmt, (int)$cursor->comment_ID
                    ));
                    $page = max(1, (int)ceil(max(1, $before) / $per_page));
                }
            }
        }
        $total = (int)get_comments(['post_id'=>$video_id,'status'=>'approve','type'=>'comment','parent'=>0,'count'=>true]);
        $roots = get_comments(['post_id'=>$video_id,'status'=>'approve','type'=>'comment','parent'=>0,'orderby'=>'comment_date_gmt','order'=>'ASC','number'=>$per_page,'offset'=>($page-1)*$per_page]);
        $children_counts = [];
        if ($roots) {
            global $wpdb;
            $ids = implode(',', array_map('absint', wp_list_pluck($roots, 'comment_ID')));
            $rows = $wpdb->get_results("SELECT comment_parent, COUNT(*) AS total FROM {$wpdb->comments} WHERE comment_post_ID = " . (int)$video_id . " AND comment_approved = '1' AND comment_type = 'comment' AND comment_parent IN ($ids) GROUP BY comment_parent");
            foreach ((array)$rows as $row) $children_counts[(int)$row->comment_parent] = (int)$row->total;
        }
        $nonce = wp_create_nonce('phisk_video_comment_nonce'); $html = '';
        foreach ($roots as $root) $html .= $this->render_video_comment_node($root, [], $video_id, $nonce, 0, $children_counts);
        wp_send_json_success(['html'=>$html,'total'=>$total,'page'=>$page,'has_more'=>($page*$per_page)<$total,'target_path'=>$target_path]);
    }

    /** Fetch replies only when a visitor expands a discussion thread. */
    public function ajax_load_video_comment_replies() {
        check_ajax_referer('phisk_video_comment_nonce', 'nonce');
        $parent_id = absint($_POST['parent_id'] ?? 0); $parent = get_comment($parent_id);
        if (!$parent || $parent->comment_approved !== '1' || get_post_type($parent->comment_post_ID) !== 'phisk_video') wp_send_json_error(['message'=>'Comment not found.'], 404);
        $replies = get_comments(['parent'=>$parent_id,'status'=>'approve','type'=>'comment','orderby'=>'comment_date_gmt','order'=>'ASC','number'=>50]);
        $children_counts = [];
        if ($replies) {
            global $wpdb;
            $ids = implode(',', array_map('absint', wp_list_pluck($replies, 'comment_ID')));
            $rows = $wpdb->get_results("SELECT comment_parent, COUNT(*) AS total FROM {$wpdb->comments} WHERE comment_post_ID = " . (int)$parent->comment_post_ID . " AND comment_approved = '1' AND comment_type = 'comment' AND comment_parent IN ($ids) GROUP BY comment_parent");
            foreach ((array)$rows as $row) $children_counts[(int)$row->comment_parent] = (int)$row->total;
        }
        $nonce = wp_create_nonce('phisk_video_comment_nonce'); $html = '';
        foreach ($replies as $reply) $html .= $this->render_video_comment_node($reply, [], (int)$parent->comment_post_ID, $nonce, 1, $children_counts);
        wp_send_json_success(['html'=>$html,'count'=>count($replies)]);
    }

    public function ajax_reply_video_comment() {
        if (!is_user_logged_in()) wp_send_json_error(['message'=>'Please log in to reply.'], 401);
        check_ajax_referer('phisk_video_comment_nonce', 'nonce');
        $parent_id = absint($_POST['parent_id'] ?? 0);
        $parent = get_comment($parent_id);
        $content = trim(wp_unslash($_POST['comment'] ?? ''));
        if (!$parent || $parent->comment_approved !== '1' || get_post_type($parent->comment_post_ID) !== 'phisk_video' || $content === '') wp_send_json_error(['message'=>'Invalid comment or empty reply.'], 400);
        $content = function_exists('mb_substr') ? mb_substr($content, 0, 2000) : substr($content, 0, 2000);
        $user = wp_get_current_user();
        $reply_id = wp_insert_comment(wp_slash(['comment_post_ID'=>(int)$parent->comment_post_ID,'comment_parent'=>$parent_id,'comment_author'=>$this->phisk_creator_display_name($user->ID),'comment_author_email'=>$user->user_email,'comment_content'=>$content,'user_id'=>$user->ID,'comment_type'=>'comment','comment_approved'=>1]));
        if (!$reply_id) wp_send_json_error(['message'=>'Unable to post your reply.'], 500);
        if ((int)$parent->user_id && (int)$parent->user_id !== (int)$user->ID) {
            $video_url = add_query_arg('phisk_comments', '1', get_permalink($parent->comment_post_ID));
            $target = $video_url . '#phisk-comment-' . (int)$reply_id;
            $this->create_notification((int)$parent->user_id, 'video-comment-reply:' . (int)$reply_id, 'video_comment_reply', 'New reply to your comment', $this->phisk_creator_display_name($user->ID) . ' replied to your comment.', $target, true, false);
        }
        $reply = get_comment($reply_id);
        $html = $this->render_video_comment_node($reply, [], (int)$parent->comment_post_ID, wp_create_nonce('phisk_video_comment_nonce'), 1);
        $count = (int) get_comments(['post_id'=>(int)$parent->comment_post_ID, 'status'=>'approve', 'type'=>'comment', 'count'=>true]);
        wp_send_json_success(['id'=>(int)$reply_id,'html'=>$html,'parent_id'=>$parent_id,'reply_count'=>count(get_comments(['parent'=>$parent_id,'status'=>'approve','type'=>'comment'])),'comment_count'=>$count]);
    }

    public function ajax_add_video_comment() {
        if (!is_user_logged_in()) wp_send_json_error(['message' => 'Please log in to comment.'], 401);
        check_ajax_referer('phisk_video_comment_nonce', 'nonce');
        $video_id = isset($_POST['video_id']) ? absint($_POST['video_id']) : 0;
        $content = isset($_POST['comment']) ? trim(wp_unslash($_POST['comment'])) : '';
        if (!$video_id || get_post_type($video_id) !== 'phisk_video' || get_post_status($video_id) !== 'publish') {
            wp_send_json_error(['message' => 'Invalid video.'], 400);
        }
        if ($content === '') wp_send_json_error(['message' => 'Please write a comment.'], 400);
        if (function_exists('mb_substr')) $content = mb_substr($content, 0, 2000);
        else $content = substr($content, 0, 2000);
        $user = wp_get_current_user();
        $comment_id = wp_insert_comment(wp_slash([
            'comment_post_ID' => $video_id,
            'comment_author' => $this->phisk_creator_display_name($user->ID),
            'comment_author_email' => $user->user_email,
            'comment_author_url' => '',
            'comment_content' => $content,
            'user_id' => $user->ID,
            'comment_type' => 'comment',
            'comment_parent' => 0,
            'comment_approved' => 1,
        ]));
        if (!$comment_id) wp_send_json_error(['message' => 'Unable to post your comment.'], 500);
        $count = (int) get_comments(['post_id' => $video_id, 'status' => 'approve', 'count' => true, 'type' => 'comment']);
        $avatar_id = absint(get_user_meta($user->ID, 'phisk_profile_image_id', true));
        $avatar = $avatar_id ? wp_get_attachment_image_url($avatar_id, 'thumbnail') : '';
        if (!$avatar) $avatar = get_avatar_url($user->ID, ['size' => 72]);
        wp_send_json_success([
            'comment_count' => $count,
            'comment' => [
                'id' => $comment_id,
                'author' => $this->phisk_creator_display_name($user->ID),
                'author_url' => $this->phisk_user_dashboard_url($user->ID),
                'avatar' => $avatar,
                'date' => get_comment_date('', $comment_id),
                'content' => nl2br(esc_html($content)),
            ],
        ]);
    }

    private function video_runtime_label($post_id) {
        $runtime = trim((string)get_post_meta($post_id, 'phisk_runtime', true));
        if ($runtime !== '') return $runtime;
        $seconds = (int)get_post_meta($post_id, '_phisk_video_duration_seconds', true);
        if ($seconds <= 0) return '';
        $h = floor($seconds / 3600); $m = floor(($seconds % 3600) / 60); $s = $seconds % 60;
        return $h > 0 ? sprintf('%d:%02d:%02d', $h, $m, $s) : sprintf('%d:%02d', $m, $s);
    }

    private function feed($type, $atts) {
        $atts = shortcode_atts(['genre' => '', 'layout' => 'carousel', 'limit' => 10, 'title' => '', 'show_year' => 'yes'], $atts, 'phiskvideos');
        $layout = in_array($atts['layout'], ['carousel', 'grid'], true) ? $atts['layout'] : 'carousel';
        $args = [
            'post_type' => $type, 'post_status' => 'publish', 'posts_per_page' => max(1, min(50, absint($atts['limit']))),
            'orderby' => 'date', 'order' => 'DESC',
        ];
        $genre_taxonomy = $type === 'phisk_video' ? 'phisk_video_genre' : 'phisk_genre';
        if ($atts['genre'] !== '') {
            $args['tax_query'] = [[
                'taxonomy' => $genre_taxonomy, 'field' => 'slug',
                'terms' => sanitize_title($atts['genre']),
            ]];
        }
        $query = new WP_Query($args);
        if (!$query->have_posts()) {
            wp_reset_postdata();
            return '';
        }
        $this->enqueue_style();
        ob_start();
        echo '<section class="phisk-feed-wrap">';
        if ($atts['title'] !== '') echo '<h2 class="phisk-feed-heading">' . esc_html($atts['title']) . '</h2>';
        if ($query->have_posts()) {
            echo '<div class="phisk-feed phisk-' . esc_attr($layout) . ' phisk-feed-' . esc_attr($type) . '">';
            while ($query->have_posts()) {
                $query->the_post();
                $id = get_the_ID();
                $poster = get_the_post_thumbnail_url($id, 'large');
                $year = get_post_meta($id, 'phisk_year', true);
                $genres = get_the_terms($id, $genre_taxonomy);
                echo '<a class="phisk-card" href="' . esc_url(get_permalink()) . '">';
                echo '<div class="phisk-card-image">';
                if ($poster) echo '<img loading="lazy" src="' . esc_url($poster) . '" alt="' . esc_attr(get_the_title()) . '" style="display:block!important;width:100%!important;height:100%!important;max-width:none!important;max-height:none!important;object-fit:cover!important;object-position:center!important;">';
                else echo '<span class="phisk-poster-placeholder">PHISKVIDEOS</span>';
                echo '<span class="phisk-card-shade"></span>';
                if ($type === 'phisk_video') { $video_runtime = $this->video_runtime_label($id); if ($video_runtime !== '') echo '<span class="phisk-video-runtime-badge">' . esc_html($video_runtime) . '</span>'; }
                echo '</div><div class="phisk-card-info"><h3>' . esc_html(get_the_title()) . '</h3><div class="phisk-card-meta">';
                if ($atts['show_year'] !== 'no' && $year) echo '<span>' . esc_html($year) . '</span>';
                if ($genres && !is_wp_error($genres)) echo '<span>' . esc_html($genres[0]->name) . '</span>';
                echo '</div></div></a>';
            }
            echo '</div>';
        } else echo '<p class="phisk-empty">No titles found yet.</p>';
        echo '</section>';
        wp_reset_postdata();
        return ob_get_clean();
    }

    public function movies_shortcode($atts) { return $this->feed('phisk_movie', $atts ?: []); }
    public function tvshows_shortcode($atts) { return $this->feed('phisk_tvshow', $atts ?: []); }
    public function videos_shortcode($atts) { return $this->feed('phisk_video', $atts ?: []); }

    /**
     * Record a genuine single-content page view.
     * A short browser cookie prevents accidental rapid refreshes from inflating
     * the counter while still allowing normal repeat visits to count later.
     */
    private function record_content_view($post_id) {
        $post_id = absint($post_id);
        $post = $post_id ? get_post($post_id) : null;
        if (!$post || $post->post_status !== 'publish' || !in_array($post->post_type, ['phisk_video','phisk_movie','phisk_tvshow','post'], true)) return;
        if (is_admin() || wp_doing_ajax() || (defined('REST_REQUEST') && REST_REQUEST)) return;

        $cookie_name = 'phisk_viewed_' . $post_id;
        if (!empty($_COOKIE[$cookie_name])) return;

        $total = (int) get_post_meta($post_id, '_phisk_views', true);
        update_post_meta($post_id, '_phisk_views', $total + 1);

        // 30-minute per-browser cooldown for this specific item.
        setcookie($cookie_name, '1', time() + (30 * MINUTE_IN_SECONDS), COOKIEPATH ?: '/', COOKIE_DOMAIN, is_ssl(), true);
        $_COOKIE[$cookie_name] = '1';
    }

    private function render_video_feed($query, $atts, $class = '') {
        $layout = in_array($atts['layout'] ?? 'grid', ['carousel', 'grid'], true) ? $atts['layout'] : 'grid';
        $this->enqueue_style();
        ob_start();
        echo '<section class="phisk-feed-wrap phisk-video-discovery-feed ' . esc_attr($class) . '">';
        if (!empty($atts['title'])) echo '<h2 class="phisk-feed-heading">' . esc_html($atts['title']) . '</h2>';
        echo '<div class="phisk-video-feed phisk-video-feed-' . esc_attr($layout) . '">';
        while ($query->have_posts()) {
            $query->the_post();
            $id = get_the_ID();
            $author_id = (int) get_post_field('post_author', $id);
            $author_name = $this->phisk_creator_display_name(get_post_field('post_author', get_the_ID()));
            $poster = get_the_post_thumbnail_url($id, 'large');
            $avatar = get_avatar_url($author_id, ['size' => 96]);
            $permalink = get_permalink($id);
            $share_title = get_the_title($id);

            echo '<article class="phisk-video-feed-item">';
            echo '<div class="phisk-video-feed-card">';
            echo '<a class="phisk-video-feed-thumb" href="' . esc_url($permalink) . '">';
            if ($poster) echo '<img loading="lazy" src="' . esc_url($poster) . '" alt="' . esc_attr($share_title) . '">';
            else echo '<span class="phisk-poster-placeholder">PHISKVIDEOS</span>';
            $video_runtime = $this->video_runtime_label($id);
            if ($video_runtime !== '') echo '<span class="phisk-video-runtime-badge">' . esc_html($video_runtime) . '</span>';
            echo '</a>';
            echo '<div class="phisk-video-feed-details">';
            echo '<div class="phisk-video-feed-title-row">';
            echo '<h3><a href="' . esc_url($permalink) . '">' . esc_html($share_title) . '</a></h3>';
            echo '<button type="button" class="phisk-video-menu-button" aria-label="More options" aria-expanded="false"><span>⋮</span></button>';
            echo '<div class="phisk-video-menu" hidden><button type="button" class="phisk-video-share" data-share-url="' . esc_url($permalink) . '" data-share-title="' . esc_attr($share_title) . '">Share</button></div>';
            echo '</div>';
            echo '<div class="phisk-video-feed-author">';
            echo '<a class="phisk-video-feed-avatar" href="' . esc_url($this->phisk_user_dashboard_url($author_id)) . '"><img loading="lazy" src="' . esc_url($avatar) . '" alt="' . esc_attr($author_name) . '"></a>';
            echo '<div class="phisk-video-feed-author-info"><a class="phisk-video-feed-author-name" href="' . esc_url($this->phisk_user_dashboard_url($author_id)) . '">' . esc_html($author_name) . '</a>';
            echo '<div class="phisk-video-feed-actions">' . $this->phisk_subscribe_button($author_id) . '</div>';
            echo '</div></div>';
            echo '</div></div></article>';
        }
        echo '</div></section>';
        wp_reset_postdata();
        return ob_get_clean();
    }

    /** Latest video discovery feed: newest published videos first, capped at 12. */
    public function latest_video_feed_shortcode($atts) {
        $atts = shortcode_atts(['layout' => 'grid', 'title' => '', 'limit' => 10], $atts, 'phiskvideos_video_feed');
        $limit = max(1, min(10, absint($atts['limit'])));
        $query = new WP_Query([
            'post_type' => 'phisk_video',
            'post_status' => 'publish',
            'posts_per_page' => $limit,
            'orderby' => 'date',
            'order' => 'DESC',
            'no_found_rows' => true,
        ]);
        if (!$query->have_posts()) { wp_reset_postdata(); return ''; }
        return $this->render_video_feed($query, $atts, 'phisk-latest-video-feed');
    }

    /** Personalized feed: only videos from accounts the current user subscribes to. */
    public function following_video_feed_shortcode($atts) {
        if (!is_user_logged_in()) return '';
        $following = $this->phisk_following_ids(get_current_user_id());
        if (empty($following)) return '';

        $atts = shortcode_atts(['layout' => 'grid', 'title' => '', 'limit' => 10], $atts, 'phiskvideos_following_feed');
        $limit = max(1, min(10, absint($atts['limit'])));
        $query = new WP_Query([
            'post_type' => 'phisk_video',
            'post_status' => 'publish',
            'posts_per_page' => $limit,
            'orderby' => 'date',
            'order' => 'DESC',
            'author__in' => $following,
            'no_found_rows' => true,
        ]);
        if (!$query->have_posts()) { wp_reset_postdata(); return ''; }
        return $this->render_video_feed($query, $atts, 'phisk-following-video-feed');
    }

    /** Get a validated article image gallery, falling back to the featured image for older articles. */
    private function article_gallery_ids($post_id) {
        $ids = get_post_meta($post_id, '_phisk_article_gallery_ids', true);
        if (!is_array($ids)) $ids = [];
        $ids = array_values(array_unique(array_filter(array_map('absint', $ids), function($id) { return $id && wp_attachment_is_image($id); })));
        if (!$ids && has_post_thumbnail($post_id)) $ids[] = (int)get_post_thumbnail_id($post_id);
        return $ids;
    }

    /** Render an accessible image slider for article gallery images. */
    private function render_article_image_slider($post_id, $context = 'feed') {
        $ids = $this->article_gallery_ids($post_id);
        if (!$ids) return '';
        $title = get_the_title($post_id);
        $class = 'phisk-article-gallery phisk-article-gallery-' . sanitize_html_class($context);
        $html = '<div class="' . esc_attr($class) . '" data-phisk-article-gallery="1" aria-label="Story images">';
        foreach ($ids as $index => $id) {
            $src = wp_get_attachment_image_url($id, 'large');
            if (!$src) continue;
            $alt = get_post_meta($id, '_wp_attachment_image_alt', true);
            if ($alt === '') $alt = $title;
            $full = wp_get_attachment_image_url($id, 'full');
            $html .= '<div class="phisk-article-gallery-slide' . ($index === 0 ? ' is-active' : '') . '" data-slide-index="' . esc_attr($index) . '"' . ($index === 0 ? '' : ' hidden') . '><button type="button" class="phisk-article-gallery-open" data-full-src="' . esc_url($full ?: $src) . '" aria-label="View full-screen image"><img src="' . esc_url($src) . '" alt="' . esc_attr($alt) . '" loading="lazy"></button></div>'; 
        }
        if (count($ids) > 1) {
            $html .= '<div class="phisk-article-gallery-controls"><button type="button" class="phisk-article-gallery-prev" aria-label="Previous image">‹</button><span class="phisk-article-gallery-count"><span class="phisk-article-gallery-current">1</span> / ' . count($ids) . '</span><button type="button" class="phisk-article-gallery-next" aria-label="Next image">›</button></div>';
            $html .= '<div class="phisk-article-gallery-dots" aria-label="Choose image">';
            foreach ($ids as $index => $id) $html .= '<button type="button" class="phisk-article-gallery-dot' . ($index === 0 ? ' is-active' : '') . '" data-go-to="' . esc_attr($index) . '" aria-label="Show image ' . esc_attr($index + 1) . '" aria-pressed="' . ($index === 0 ? 'true' : 'false') . '"></button>';
            $html .= '</div>';
        }
        $html .= '</div>';
        return $html;
    }

    /** Replace the single featured image with the article gallery on full article pages. */
    public function filter_article_featured_image_gallery($html, $post_id, $post_thumbnail_id, $size, $attr) {
        if (is_admin() || !is_singular('post') || (int)$post_id !== (int)get_queried_object_id()) return $html;
        $ids = get_post_meta($post_id, '_phisk_article_gallery_ids', true);
        if (!is_array($ids) || count($ids) < 2) return $html;
        $this->enqueue_style();
        return $this->render_article_image_slider($post_id, 'single');
    }

    /** Render a Reddit-inspired long-form article card. */
    private function render_article_card($post_id, $channel_owner_view = false) {
        $post = get_post($post_id);
        if (!$post || $post->post_type !== 'post') return '';
        $title = get_the_title($post_id);
        $url = get_permalink($post_id);
        $content = trim(wp_strip_all_tags(strip_shortcodes($post->post_content)));
        $excerpt = get_post_meta($post_id, '_phisk_article_short_intro', true);
        if (!$excerpt) $excerpt = get_the_excerpt($post_id);
        if (!$excerpt) $excerpt = $content;
        $excerpt = wp_trim_words($excerpt, 70, '…');
        $image = get_the_post_thumbnail_url($post_id, 'large');
        $author_id = (int)$post->post_author;
        $author = get_userdata($author_id);
        $display = $author ? $this->phisk_creator_display_name($author_id) : 'Phisk member';
        $avatar_id = absint(get_user_meta($author_id, 'phisk_profile_image_id', true));
        $avatar = $avatar_id ? wp_get_attachment_image_url($avatar_id, 'thumbnail') : '';
        if (!$avatar) $avatar = plugin_dir_url(__FILE__) . 'assets/story-avatar-placeholder.svg';
        $terms = get_the_terms($post_id, 'phisk_interest');
        $interest = ($terms && !is_wp_error($terms) && isset($terms[0]) && $terms[0] instanceof WP_Term) ? $terms[0] : null;
        $interest_url = $interest ? get_term_link($interest, 'phisk_interest') : '';
        if (is_wp_error($interest_url)) $interest_url = '';
        $count = max(0, (int)get_post_meta($post_id, '_phisk_article_upvotes', true));
        $voted = false;
        if (is_user_logged_in()) {
            $votes = get_user_meta(get_current_user_id(), 'phisk_upvoted_articles', true);
            $voted = is_array($votes) && in_array((int)$post_id, array_map('absint', $votes), true);
        }
        $comments = (int)get_comments_number($post_id);
        $nonce = wp_create_nonce('phisk_article_vote_nonce');
        $is_story_owner = is_user_logged_in() && (int) get_current_user_id() === $author_id;
        $edit_story_url = $is_story_owner ? add_query_arg('edit_story', $post_id, $this->creator_page_url('phiskvideos_article_submit_page_id', 'write-article')) : '';
        $delete_story_nonce = $is_story_owner ? wp_create_nonce('phisk_dashboard_content_action') : '';
        ob_start(); ?>
        <article class="phisk-article-card" data-article-id="<?php echo esc_attr($post_id); ?>" data-channel-owner-view="<?php echo $is_story_owner ? '1' : '0'; ?>" data-edit-story-url="<?php echo esc_url($edit_story_url); ?>" data-delete-story-nonce="<?php echo esc_attr($delete_story_nonce); ?>">
          <div class="phisk-article-card-head">
            <a class="phisk-article-author-avatar-link" href="<?php echo esc_url($this->phisk_channel_url($author_id)); ?>" aria-label="Visit <?php echo esc_attr($display); ?>'s channel"><img class="phisk-article-author-avatar" src="<?php echo esc_url($avatar); ?>" alt="" loading="lazy"></a>
            <div class="phisk-article-author-meta"><a href="<?php echo esc_url($this->phisk_channel_url($author_id)); ?>" class="phisk-article-author-name"><?php echo esc_html($display); ?></a><span><?php echo esc_html(human_time_diff(get_post_time('U', true, $post_id), current_time('timestamp', true)) . ' ago'); ?><?php if ($interest && $interest_url !== '') : ?> · <a href="<?php echo esc_url($interest_url); ?>" class="phisk-article-interest-label"><?php echo esc_html($interest->name); ?></a><?php endif; ?></span></div>
            <button type="button" class="phisk-article-more" aria-label="Story options" title="Story options">⋯</button>
          </div>
          <a class="phisk-article-title-link" href="<?php echo esc_url($url); ?>"><h2 class="phisk-article-title"><?php echo esc_html($title); ?></h2></a>
          <div class="phisk-article-preview"><?php echo esc_html($excerpt); ?></div>
          <?php if ($image) : ?><?php echo $this->render_article_image_slider($post_id, 'feed'); ?><?php endif; ?>
          <div class="phisk-article-engagement">
            <button type="button" class="phisk-article-upvote<?php echo $voted ? ' is-upvoted' : ''; ?>" data-article-id="<?php echo esc_attr($post_id); ?>" data-nonce="<?php echo esc_attr($nonce); ?>" aria-pressed="<?php echo $voted ? 'true' : 'false'; ?>"><span class="phisk-article-upvote-icon">▲</span><span class="phisk-article-upvote-label">Upvote</span><span class="phisk-article-upvote-count"><?php echo esc_html(number_format_i18n($count)); ?></span></button>
            <a class="phisk-article-comment-link" href="<?php echo esc_url($url . '#comments'); ?>"><span aria-hidden="true">▢</span> <span><?php echo esc_html(number_format_i18n($comments)); ?> comments</span></a>
            <button type="button" class="phisk-article-share" data-share-url="<?php echo esc_url($url); ?>" data-share-title="<?php echo esc_attr($title); ?>"><span aria-hidden="true">↗</span> Share</button>
          </div>
        </article>
        <?php return ob_get_clean();
    }

    public function posts_shortcode($atts) {
        $atts = shortcode_atts(['category' => '', 'interest' => '', 'layout' => 'grid', 'limit' => 10, 'title' => ''], $atts, 'phiskvideos_posts');
        $args = ['post_type'=>'post','post_status'=>'publish','posts_per_page'=>max(1,min(50,absint($atts['limit']))),'orderby'=>'date','order'=>'DESC','no_found_rows'=>true];
        if ($atts['category'] !== '') $args['category_name'] = sanitize_title($atts['category']);
        $interest = sanitize_title($atts['interest'] ?: (isset($_GET['interest']) ? wp_unslash($_GET['interest']) : ''));
        if ($interest !== '') $args['tax_query'] = [['taxonomy'=>'phisk_interest','field'=>'slug','terms'=>$interest]];
        $query = new WP_Query($args);
        if (!$query->have_posts()) { wp_reset_postdata(); return ''; }
        $this->enqueue_style();
        ob_start();
        echo '<section class="phisk-article-feed-wrap">';
        if ($atts['title'] !== '') echo '<h2 class="phisk-feed-heading">' . esc_html($atts['title']) . '</h2>';
        echo '<div class="phisk-article-feed">';
        while ($query->have_posts()) { $query->the_post(); echo $this->render_article_card(get_the_ID()); }
        echo '</div></section>';
        wp_reset_postdata();
        return ob_get_clean();
    }

    /** A single 24-hour upvote wall with an All/Interest filter. */
    public function article_wall_shortcode($atts) {
        $atts = shortcode_atts(['mode'=>'both','interest'=>'','limit'=>10,'title'=>'Top Stories'], $atts, 'phisk_article_wall');
        $mode = in_array($atts['mode'], ['global','interest','both'], true) ? $atts['mode'] : 'both';
        $limit = max(1, min(30, absint($atts['limit'])));
        $now = current_time('timestamp', true);
        $cutoff = gmdate('Y-m-d H:i:s', $now - DAY_IN_SECONDS);

        // A shortcode's explicit interest is the default only for interest mode;
        // the visitor can still choose another interest using the filter.
        $requested = isset($_GET['phisk_wall_interest']) ? sanitize_title(wp_unslash($_GET['phisk_wall_interest'])) : '';
        if ($requested === '' && $mode === 'interest') $requested = sanitize_title($atts['interest']);
        $selected_term = $requested !== '' ? get_term_by('slug', $requested, 'phisk_interest') : null;
        if (!$selected_term) $requested = '';

        $tax_query = [];
        if ($requested !== '') $tax_query = [['taxonomy'=>'phisk_interest','field'=>'slug','terms'=>$requested]];

        // The Top Stories wall scans a bounded 24-hour candidate set and ranks it
        // by upvotes. Cache the ranked IDs briefly so repeated visits don't repeat
        // two wide queries and per-story metadata lookups on every request.
        $wall_cache_key = 'phisk_story_wall_' . md5($requested . '|' . $limit . '|' . gmdate('YmdHi'));
        $cached_wall_ids = get_transient($wall_cache_key);
        if (is_array($cached_wall_ids)) {
            $ids = $cached_wall_ids;
        } else {
        // Include Stories published in the last 24 hours. A Story remains eligible
        // until its own publication timestamp is at least 24 hours old.
        $published_query = new WP_Query([
            'post_type'=>'post','post_status'=>'publish','posts_per_page'=>500,'fields'=>'ids',
            'meta_query'=>[['key'=>'_phisk_article_published_at_gmt','value'=>$cutoff,'compare'=>'>=','type'=>'CHAR']],
            'tax_query'=>$tax_query,'orderby'=>'date','order'=>'DESC','no_found_rows'=>true
        ]);
        $ids = array_map('absint', $published_query->posts);
        wp_reset_postdata();

        $legacy_args = [
            'post_type'=>'post','post_status'=>'publish','posts_per_page'=>500,'fields'=>'ids',
            'date_query'=>[['after'=>$cutoff,'inclusive'=>true,'column'=>'post_date_gmt']],
            'orderby'=>'date','order'=>'DESC','no_found_rows'=>true
        ];
        if ($tax_query) $legacy_args['tax_query'] = $tax_query;
        $legacy_query = new WP_Query($legacy_args);
        $ids = array_values(array_unique(array_merge($ids, array_map('absint', $legacy_query->posts))));
        wp_reset_postdata();

        $cutoff_ts = strtotime($cutoff . ' UTC');
        $ids = array_values(array_filter($ids, function($id) use ($cutoff_ts) {
            $published_at = get_post_meta($id, '_phisk_article_published_at_gmt', true);
            $timestamp = $published_at ? strtotime($published_at . ' UTC') : get_post_time('U', true, $id);
            return $timestamp && $timestamp >= $cutoff_ts;
        }));

        usort($ids, function($a, $b) {
            $votes_a = max(0, (int)get_post_meta($a, '_phisk_article_upvotes', true));
            $votes_b = max(0, (int)get_post_meta($b, '_phisk_article_upvotes', true));
            if ($votes_a === $votes_b) return get_post_time('U', true, $b) <=> get_post_time('U', true, $a);
            return $votes_b <=> $votes_a;
        });
        $ids = array_slice($ids, 0, $limit);

            set_transient($wall_cache_key, $ids, 60);
        }

        $this->enqueue_style();
        $terms = get_terms(['taxonomy'=>'phisk_interest','hide_empty'=>false,'orderby'=>'name','order'=>'ASC']);
        $action = remove_query_arg('phisk_wall_interest');
        $html = '<div class="phisk-article-wall">';
        $html .= '<form class="phisk-article-wall-filter" method="get" action="' . esc_url($action) . '">';
        // Preserve other query parameters while replacing this filter.
        foreach ($_GET as $key => $value) {
            if ($key === 'phisk_wall_interest' || is_array($value)) continue;
            $html .= '<input type="hidden" name="' . esc_attr(sanitize_key($key)) . '" value="' . esc_attr(sanitize_text_field(wp_unslash($value))) . '">';
        }
        $html .= '<nav class="phisk-wall-interest-carousel" aria-label="Filter Stories by Interest">';
        $html .= '<button type="submit" class="phisk-wall-interest-button' . ($requested === '' ? ' is-active' : '') . '" name="phisk_wall_interest" value="" aria-pressed="' . ($requested === '' ? 'true' : 'false') . '">All</button>';
        if (!is_wp_error($terms)) foreach ($terms as $term) {
            $active = $requested === $term->slug;
            $html .= '<button type="submit" class="phisk-wall-interest-button' . ($active ? ' is-active' : '') . '" name="phisk_wall_interest" value="' . esc_attr($term->slug) . '" aria-pressed="' . ($active ? 'true' : 'false') . '">' . esc_html($term->name) . '</button>';
        }
        $html .= '</nav></form>';
        $heading = $selected_term ? $selected_term->name . ' · Top Stories' : ($atts['title'] ?: 'Top Stories · Last 24 Hours');
        $html .= '<section class="phisk-article-wall-section">';
        if ($heading !== '') $html .= '<h2 class="phisk-article-wall-heading">' . esc_html($heading) . '</h2>';
        if ($ids) {
            $html .= '<div class="phisk-article-feed">';
            foreach ($ids as $id) $html .= $this->render_article_card($id);
            $html .= '</div>';
        } else {
            $html .= $this->render_creator_empty_state('story', 'No Stories yet', 'Stories for this Interest will appear here when creators publish them.');
        }
        $html .= '</section></div>';
        return $html;
    }

    /**
     * Lightweight homepage Top Stories list. Ranks published Stories from the
     * last 24 hours by existing upvote count, caches IDs briefly, and uses a
     * compact layout independent of the full article-wall cards.
     */
    public function top_stories_wall_shortcode($atts = []) {
        $atts = shortcode_atts(['limit' => 20, 'title' => 'Top Stories'], $atts, 'phisk_top_stories_wall');
        $limit = max(1, min(20, absint($atts['limit'])));
        $now = current_time('timestamp', true);
        $cutoff = gmdate('Y-m-d H:i:s', $now - DAY_IN_SECONDS);
        $cutoff_ts = $now - DAY_IN_SECONDS;

        // Query Stories stamped when they actually became public (including approval time).
        $stamped_query = new WP_Query([
            'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 500,
            'fields' => 'ids', 'no_found_rows' => true, 'ignore_sticky_posts' => true,
            'meta_query' => [[
                'key' => '_phisk_article_published_at_gmt', 'value' => $cutoff,
                'compare' => '>=', 'type' => 'CHAR',
            ]],
            'orderby' => 'date', 'order' => 'DESC',
        ]);
        $ids = array_map('absint', $stamped_query->posts);
        wp_reset_postdata();

        // Backward compatibility for older Stories that predate the publication stamp.
        $legacy_query = new WP_Query([
            'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 500,
            'fields' => 'ids', 'no_found_rows' => true, 'ignore_sticky_posts' => true,
            'date_query' => [[ 'after' => $cutoff, 'inclusive' => true, 'column' => 'post_date_gmt' ]],
            'meta_query' => [[ 'key' => '_phisk_article_published_at_gmt', 'compare' => 'NOT EXISTS' ]],
            'orderby' => 'date', 'order' => 'DESC',
        ]);
        $ids = array_values(array_unique(array_merge($ids, array_map('absint', $legacy_query->posts))));
        wp_reset_postdata();

        // Recheck each Story's exact publication timestamp on every render. This prevents
        // a cached ID from remaining visible after its own 24-hour window has expired.
        $ids = array_values(array_filter($ids, function($id) use ($cutoff_ts) {
            $published_at = get_post_meta($id, '_phisk_article_published_at_gmt', true);
            $timestamp = $published_at ? strtotime($published_at . ' UTC') : get_post_time('U', true, $id);
            return $timestamp && $timestamp >= $cutoff_ts && get_post_status($id) === 'publish';
        }));

        usort($ids, function($a, $b) {
            $votes_a = max(0, (int)get_post_meta($a, '_phisk_article_upvotes', true));
            $votes_b = max(0, (int)get_post_meta($b, '_phisk_article_upvotes', true));
            if ($votes_a === $votes_b) {
                $time_a = get_post_meta($a, '_phisk_article_published_at_gmt', true);
                $time_b = get_post_meta($b, '_phisk_article_published_at_gmt', true);
                $time_a = $time_a ? strtotime($time_a . ' UTC') : get_post_time('U', true, $a);
                $time_b = $time_b ? strtotime($time_b . ' UTC') : get_post_time('U', true, $b);
                return $time_b <=> $time_a;
            }
            return $votes_b <=> $votes_a;
        });
        $ids = array_slice($ids, 0, $limit);

        $this->enqueue_style();
        $title = trim((string)$atts['title']);
        $html = '<section class="phisk-top-stories-wall phisk-article-feed-wrap">';
        if ($title !== '') $html .= '<h2 class="phisk-feed-heading phisk-top-stories-heading">' . esc_html($title) . '</h2>';
        if (!$ids) {
            $html .= '<p class="phisk-top-stories-empty">No top Stories published in the last 24 hours yet.</p></section>';
            return $html;
        }
        $html .= '<div class="phisk-article-feed phisk-top-stories-feed">';
        $rank = 0;
        foreach ($ids as $id) {
            $post = get_post($id);
            if (!$post || $post->post_type !== 'post' || $post->post_status !== 'publish') continue;
            $rank++;
            $html .= '<div class="phisk-top-ranked-story">';
            $html .= '<div class="phisk-top-story-rank-label" aria-label="Rank ' . esc_attr($rank) . '">#' . esc_html($rank) . '</div>';
            $html .= $this->render_article_card($id);
            $html .= '</div>';
        }
        $html .= '</div></section>';
        return $html;
    }

    public function ajax_toggle_article_upvote() {
        if (!is_user_logged_in()) wp_send_json_error(['message'=>'Please log in to upvote Stories.'], 401);
        check_ajax_referer('phisk_article_vote_nonce', 'nonce');
        $article_id = isset($_POST['article_id']) ? absint($_POST['article_id']) : 0;
        if (!$article_id || get_post_type($article_id) !== 'post' || get_post_status($article_id) !== 'publish') wp_send_json_error(['message'=>'This Story is not available for voting.'], 400);
        $user_id = get_current_user_id();
        $votes = get_user_meta($user_id, 'phisk_upvoted_articles', true);
        if (!is_array($votes)) $votes = [];
        $votes = array_values(array_unique(array_filter(array_map('absint', $votes))));
        $count = max(0, (int)get_post_meta($article_id, '_phisk_article_upvotes', true));
        if (in_array($article_id, $votes, true)) {
            $votes = array_values(array_diff($votes, [$article_id]));
            $count = max(0, $count - 1);
            $upvoted = false;
        } else {
            $votes[] = $article_id;
            $count++;
            $upvoted = true;
        }
        update_user_meta($user_id, 'phisk_upvoted_articles', $votes);
        update_post_meta($article_id, '_phisk_article_upvotes', $count);
        delete_transient('phisk_top_stories_ids_24h');
        wp_send_json_success(['upvoted'=>$upvoted,'count'=>$count]);
    }

    /**
     * Build the "Watch Also" list for a movie using its assigned shared genres.
     * Movies are excluded from the current post and limited to six results.
     */
    public function watch_also_movies($post_id) {
        $genres = get_the_terms($post_id, 'phisk_genre');
        if (!$genres || is_wp_error($genres)) return [];

        $term_ids = wp_list_pluck($genres, 'term_id');
        if (!$term_ids) return [];

        $query = new WP_Query([
            'post_type' => 'phisk_movie',
            'post_status' => 'publish',
            'posts_per_page' => 6,
            'post__not_in' => [$post_id],
            'orderby' => 'date',
            'order' => 'DESC',
            'tax_query' => [[
                'taxonomy' => 'phisk_genre',
                'field' => 'term_id',
                'terms' => array_map('absint', $term_ids),
                'operator' => 'IN',
            ]],
            'no_found_rows' => true,
        ]);

        $movies = [];
        while ($query->have_posts()) {
            $query->the_post();
            $movies[] = [
                'id' => get_the_ID(),
                'title' => get_the_title(),
                'permalink' => get_permalink(),
                'poster' => get_the_post_thumbnail_url(get_the_ID(), 'large'),
                'year' => get_post_meta(get_the_ID(), 'phisk_year', true),
                'genres' => get_the_terms(get_the_ID(), 'phisk_genre'),
            ];
        }
        wp_reset_postdata();

        return $movies;
    }

    public function watch_also_videos($post_id) {
        $genres = get_the_terms($post_id, 'phisk_video_genre');
        $term_ids = (!$genres || is_wp_error($genres)) ? [] : wp_list_pluck($genres, 'term_id');

        $args = [
            'post_type' => 'phisk_video',
            'post_status' => 'publish',
            'posts_per_page' => 6,
            'post__not_in' => [$post_id],
            'orderby' => 'date',
            'order' => 'DESC',
            'no_found_rows' => true,
        ];
        if ($term_ids) {
            $args['tax_query'] = [[
                'taxonomy' => 'phisk_video_genre',
                'field' => 'term_id',
                'terms' => array_map('absint', $term_ids),
                'operator' => 'IN',
            ]];
        }

        $query = new WP_Query($args);
        $videos=[];
        while ($query->have_posts()) {
            $query->the_post();
            $id=get_the_ID();
            $videos[]=[
                'id'=>$id,
                'title'=>get_the_title(),
                'permalink'=>get_permalink(),
                'poster'=>get_the_post_thumbnail_url($id,'large'),
                'year'=>get_post_meta($id,'phisk_year',true),
                'genres'=>get_the_terms($id,'phisk_video_genre')
            ];
        }
        wp_reset_postdata();
        return $videos;
    }

    public function video_player_markup($post_id) {
        $data = $this->video_provider_data($post_id);
        if (!$data['source_url']) return '';
        if ($data['provider'] === 'youtube_embed') {
            $youtube_id = (string)get_post_meta($post_id, '_phisk_youtube_video_id', true);
            if (!preg_match('/^[A-Za-z0-9_-]{11}$/', $youtube_id)) return '<div class="phisk-youtube-unavailable">This embedded YouTube video is unavailable.</div>';
            return '<div class="phisk-video-player phisk-youtube-embed-player" data-provider="youtube_embed"><iframe src="https://www.youtube-nocookie.com/embed/' . esc_attr($youtube_id) . '?rel=0" title="' . esc_attr(get_the_title($post_id)) . '" loading="lazy" referrerpolicy="strict-origin-when-cross-origin" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div>';
        }
        $poster = get_the_post_thumbnail_url($post_id, 'large');
        $url = esc_url($data['source_url']);
        $poster_attr = $poster ? ' poster="' . esc_url($poster) . '"' : '';
        $provider = sanitize_html_class($data['provider'] ?: 'wordpress');
        $next_query = new WP_Query(['post_type' => 'phisk_video', 'post_status' => 'publish', 'posts_per_page' => 1, 'post__not_in' => [absint($post_id)], 'orderby' => 'date', 'order' => 'DESC', 'no_found_rows' => true]);
        $next_video = null;
        if ($next_query->have_posts()) {
            $next_query->the_post(); $next_id = get_the_ID();
            $next_video = ['url' => get_permalink($next_id), 'title' => get_the_title($next_id), 'poster' => get_the_post_thumbnail_url($next_id, 'medium')];
        }
        wp_reset_postdata();
        $next_overlay = '<div class="phisk-player-end-screen" data-player-end-screen hidden><button type="button" class="phisk-player-replay" data-player-action="replay" aria-label="Replay current video">↻<span>Replay</span></button>';
        if ($next_video) $next_overlay .= '<a class="phisk-player-next" href="' . esc_url($next_video['url']) . '"><span class="phisk-player-next-label">NEXT VIDEO</span>' . ($next_video['poster'] ? '<img src="' . esc_url($next_video['poster']) . '" alt="" loading="lazy">' : '') . '<span class="phisk-player-next-title">' . esc_html($next_video['title']) . '</span></a>';
        $next_overlay .= '</div>';
        return '<div class="phisk-video-player phisk-modern-player phisk-original-player" data-phisk-player data-player-brand="phisk-original" data-provider="' . esc_attr($provider) . '">
            <video class="phisk-player-video" playsinline preload="metadata"'.$poster_attr.'>
                <source src="' . $url . '">
            </video>
            <div class="phisk-player-loading" data-player-loading role="status" aria-label="Loading video" hidden><span class="phisk-player-loading-spinner" aria-hidden="true"></span><span class="phisk-player-loading-text">Loading video…</span></div>' . ($provider === 'cloudflare_stream' ? '<script src="https://cdn.jsdelivr.net/npm/hls.js@1.5.18/dist/hls.min.js"></script><script>(function(){var p=document.currentScript&&document.currentScript.previousElementSibling;var v=p&&p.matches("video")?p:null;if(!v){var box=document.currentScript&&document.currentScript.closest("[data-phisk-player]");v=box&&box.querySelector("video");}if(!v)return;var src=' . wp_json_encode($data['source_url']) . ';if(v.canPlayType("application/vnd.apple.mpegurl")){v.src=src;}else if(window.Hls&&window.Hls.isSupported()){var h=new Hls({enableWorker:true});h.loadSource(src);h.attachMedia(v);v._phiskHls=h;}})();</script>' : '') . $next_overlay . '
            <button type="button" class="phisk-player-big-play" data-player-action="play" aria-label="Play video">
                <span class="phisk-player-play-icon" aria-hidden="true"></span>
            </button>
            <div class="phisk-player-gradient" aria-hidden="true"></div>
            <div class="phisk-player-controls" data-player-controls>
                <div class="phisk-player-seek-row">
                    <input class="phisk-player-seek" type="range" min="0" max="1000" value="0" step="1" aria-label="Seek video">
                </div>
                <div class="phisk-player-control-row">
                    <button type="button" class="phisk-player-control" data-player-action="play" aria-label="Play video"><span class="phisk-player-control-icon phisk-icon-play" aria-hidden="true"></span></button>
                    <button type="button" class="phisk-player-control" data-player-action="mute" aria-label="Mute video"><span class="phisk-player-control-icon phisk-icon-volume" aria-hidden="true"></span></button>
                    <input class="phisk-player-volume" type="range" min="0" max="1" value="1" step="0.05" aria-label="Volume">
                    <span class="phisk-player-time"><span data-player-current>0:00</span><span class="phisk-player-time-divider"> / </span><span data-player-duration>0:00</span></span>
                    <span class="phisk-player-spacer-control"></span>
                    <button type="button" class="phisk-player-control phisk-player-speed" data-player-action="speed" aria-label="Playback speed">1×</button>
                    <button type="button" class="phisk-player-control" data-player-action="pip" aria-label="Picture in picture"><span class="phisk-player-control-icon phisk-icon-pip" aria-hidden="true"></span></button>
                    <button type="button" class="phisk-player-control" data-player-action="fullscreen" aria-label="Fullscreen"><span class="phisk-player-control-icon phisk-icon-fullscreen" aria-hidden="true"></span></button>
                </div>
            </div>
            <div class="phisk-player-speed-menu" data-player-speed-menu hidden>
                <button type="button" data-speed="0.5">0.5×</button>
                <button type="button" data-speed="0.75">0.75×</button>
                <button type="button" data-speed="1">Normal</button>
                <button type="button" data-speed="1.25">1.25×</button>
                <button type="button" data-speed="1.5">1.5×</button>
                <button type="button" data-speed="2">2×</button>
            </div>
        </div>';
    }

    /**
     * Keep the mobile video player directly below the site's sticky header.
     * The height is calculated from the actual visible fixed/sticky header so
     * BuddyBoss and other responsive themes can use their own header height.
     */
    public function video_sticky_header_script() {
        if (!is_singular('phisk_video')) return;
        ?>
        <script>
        (function(){
            var root = document.documentElement;
            var selectors = [
                '.bb-mobile-header',
                '.bb-mobile-header-wrapper',
                '.bb-header',
                '#masthead',
                '.site-header',
                'header.site-header',
                'header#masthead'
            ];
            function visible(el) {
                if (!el) return false;
                var r = el.getBoundingClientRect();
                var s = window.getComputedStyle(el);
                return s.display !== 'none' && s.visibility !== 'hidden' && r.height > 0 && r.bottom > 0 && r.top < window.innerHeight;
            }
            function setHeaderOffset(){
                var bestBottom = 0;
                selectors.forEach(function(sel){
                    document.querySelectorAll(sel).forEach(function(el){
                        if (!visible(el)) return;
                        var s = window.getComputedStyle(el);
                        var r = el.getBoundingClientRect();
                        if ((s.position === 'fixed' || s.position === 'sticky') && r.top <= 8 && r.bottom > bestBottom && r.bottom < window.innerHeight * .7) {
                            bestBottom = r.bottom;
                        }
                    });
                });
                root.style.setProperty('--phisk-sticky-header-height', Math.max(0, Math.round(bestBottom)) + 'px');
            }
            function setPlayerHeight(){
                var dock = document.querySelector('.phisk-video-player-dock');
                var spacer = document.querySelector('.phisk-video-player-spacer');
                if (!dock || !spacer) return;
                var player = dock.querySelector('.phisk-video-player');
                var h = player ? player.getBoundingClientRect().height : dock.getBoundingClientRect().height;
                if (h > 0) {
                    root.style.setProperty('--phisk-video-player-height', Math.round(h) + 'px');
                }
            }
            function run(){
                setHeaderOffset();
                setPlayerHeight();
                window.setTimeout(setHeaderOffset, 100);
                window.setTimeout(setPlayerHeight, 100);
                window.setTimeout(setHeaderOffset, 500);
                window.setTimeout(setPlayerHeight, 500);
            }
            function boot(){
                run();
                var dock = document.querySelector('.phisk-video-player-dock');
                var video = dock && dock.querySelector('video');
                if (video) {
                    video.addEventListener('loadedmetadata', run, {passive:true});
                    video.addEventListener('loadeddata', run, {passive:true});
                }
                if (window.ResizeObserver) {
                    var observer = new ResizeObserver(run);
                    if (dock) observer.observe(dock);
                    selectors.forEach(function(sel){ document.querySelectorAll(sel).forEach(function(el){ observer.observe(el); }); });
                }
            }
            if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
            window.addEventListener('load', run, {passive:true});
            window.addEventListener('resize', run, {passive:true});
            window.addEventListener('orientationchange', run, {passive:true});
            window.addEventListener('scroll', setHeaderOffset, {passive:true});
        })();
        </script>
        <?php
    }
    public function single_template($template) {
        if (is_singular(['phisk_movie', 'phisk_tvshow', 'phisk_video'])) {
            if (is_singular('phisk_video') && !empty($_GET['phisk_comments'])) {
                $this->enqueue_style();
                $comments_template = plugin_dir_path(__FILE__) . 'templates/video-comments-page.php';
                if (file_exists($comments_template)) return $comments_template;
            }
            $this->record_content_view(get_queried_object_id());
            $this->enqueue_style();
            $plugin_template = plugin_dir_path(__FILE__) . 'templates/single-phiskvideo.php';
            if (file_exists($plugin_template)) return $plugin_template;
        }
        return $template;
    }

    /** Keep Story discussions open even when older WordPress posts had comments disabled. */
    public function open_story_comments($open, $post_id) {
        return get_post_type($post_id) === 'post' ? true : $open;
    }

    /** Enable nested replies for Story discussions without changing the site's global Discussion settings. */
    public function enable_story_threaded_comments($pre) {
        return is_singular('post') ? 1 : $pre;
    }

    public function set_story_thread_depth($pre) {
        return is_singular('post') ? 5 : $pre;
    }

    /** Prefer the real Phisk profile image for registered users throughout WordPress comment/avatar output. */
    public function use_phisk_profile_avatar($avatar, $id_or_email, $size, $default, $alt, $args = []) {
        $user = false;
        if (is_numeric($id_or_email)) $user = get_user_by('id', absint($id_or_email));
        elseif (is_object($id_or_email) && !empty($id_or_email->user_id)) $user = get_user_by('id', absint($id_or_email->user_id));
        elseif (is_object($id_or_email) && !empty($id_or_email->comment_author_email)) $user = get_user_by('email', $id_or_email->comment_author_email);
        elseif (is_string($id_or_email) && is_email($id_or_email)) $user = get_user_by('email', $id_or_email);
        if (!$user) return $avatar;
        $image_id = absint(get_user_meta($user->ID, 'phisk_profile_image_id', true));
        $image = $image_id ? wp_get_attachment_image_url($image_id, 'thumbnail') : '';
        if (!$image) return $avatar;
        return '<img alt="' . esc_attr($alt ?: $user->display_name) . '" src="' . esc_url($image) . '" class="avatar avatar-' . absint($size) . ' photo phisk-real-avatar" height="' . absint($size) . '" width="' . absint($size) . '" loading="lazy" />';
    }

    /** Hide legacy review ratings and append Stories from the same Interest to the full Story page. */
    public function story_publish_success_markup($post_id) {
        if (is_admin() || empty($_GET['phisk_story_published']) || sanitize_text_field(wp_unslash($_GET['phisk_story_published'])) !== '1') return '';
        $post = get_post(absint($post_id));
        if (!$post || $post->post_type !== 'post' || $post->post_status !== 'publish' || !is_user_logged_in() || (int)$post->post_author !== get_current_user_id()) return '';
        $url = get_permalink($post_id); $title = get_the_title($post_id);
        $html = '<section class="phisk-video-publish-success phisk-story-publish-success" data-phisk-publish-share data-share-url="'.esc_url($url).'" data-share-title="'.esc_attr(wp_strip_all_tags($title)).'" role="status" aria-live="polite">';
        $html .= '<h2>🎉 Congratulations! Your Story is live!</h2><p>Your Story has been successfully published on PhiskVideos.</p><p class="phisk-video-publish-encouragement">🌍 Let the world discover your creativity! Share your Story with your community and invite others to read it.</p><p class="phisk-video-publish-tagline">❤️ Your next reader could come from your next share!</p><div class="phisk-video-publish-actions"><button type="button" class="phisk-video-publish-share">↗ Share Story</button><button type="button" class="phisk-video-publish-copy">Copy Story link</button><span class="phisk-video-publish-feedback" aria-live="polite"></span></div></section>';
        return $html;
    }

    /** Show a one-time creator-facing sharing prompt after a new video is published. */
    public function video_publish_success_markup($post_id) {
        if (is_admin() || empty($_GET['phisk_video_published']) || sanitize_text_field(wp_unslash($_GET['phisk_video_published'])) !== '1') return '';
        $post = get_post(absint($post_id));
        if (!$post || $post->post_type !== 'phisk_video' || $post->post_status !== 'publish' || !is_user_logged_in() || (int) $post->post_author !== get_current_user_id()) return '';
        $url = get_permalink($post_id);
        $title = get_the_title($post_id);
        $message = '<section class="phisk-video-publish-success" data-phisk-publish-share data-share-url="' . esc_url($url) . '" data-share-title="' . esc_attr(wp_strip_all_tags($title)) . '" role="status" aria-live="polite">';
        $message .= '<h2>🎉 Congratulations! Your video is live!</h2>';
        $message .= '<p>Your video has been successfully published on PhiskVideos.</p>';
        $message .= '<p class="phisk-video-publish-encouragement">🌍 Let the world discover your creativity! Share your video on WhatsApp, Facebook, Instagram, TikTok, X, and other social platforms to reach more viewers.</p>';
        $message .= '<p class="phisk-video-publish-tagline">❤️ Your next viewer could come from your next share!</p>';
        $message .= '<div class="phisk-video-publish-actions"><button type="button" class="phisk-video-publish-share">↗ Share video</button><button type="button" class="phisk-video-publish-copy">Copy video link</button><span class="phisk-video-publish-feedback" aria-live="polite"></span></div>';
        $message .= '</section>';
        return $message;
    }

    public function append_post_rating($content) {
        // Prevent recursive rendering of the related-story cards.
        if ($this->rendering_related_stories) return $content;
        if (!is_singular('post') || !in_the_loop() || !is_main_query()) return $content;

        $post_id = get_the_ID();
        $this->record_content_view($post_id);
        $content = $this->story_publish_success_markup($post_id) . $content;

        $settings = get_option('phiskvideos_related_stories_settings', []);
        if (!is_array($settings)) $settings = [];
        if (isset($settings['enabled']) && !$settings['enabled']) return $content;

        $count = max(1, min(5, absint($settings['count'] ?? 3)));
        $heading = sanitize_text_field($settings['heading'] ?? 'More Stories');
        if ($heading === '') $heading = 'More Stories';

        // Deliberately use the latest published posts only: no Interest/taxonomy,
        // voting, or view-count ranking. Exclude the current Story.
        $related = null;
        try {
            $related = new WP_Query([
                'post_type' => 'post',
                'post_status' => 'publish',
                'posts_per_page' => $count,
                'post__not_in' => [$post_id],
                'orderby' => 'date',
                'order' => 'DESC',
                'ignore_sticky_posts' => true,
                'no_found_rows' => true,
                'update_post_meta_cache' => true,
                'update_post_term_cache' => false,
            ]);
            if (!$related->have_posts()) {
                wp_reset_postdata();
                return $content;
            }

            $this->enqueue_style();
            $html = '<section class="phisk-related-stories"><h2 class="phisk-related-stories-heading">' . esc_html($heading) . '</h2><div class="phisk-article-feed">';
            $this->rendering_related_stories = true;
            try {
                while ($related->have_posts()) {
                    $related->the_post();
                    try {
                        $card = $this->render_article_card(get_the_ID());
                        if (is_string($card)) $html .= $card;
                    } catch (Throwable $render_error) {
                        // Skip a failed card without breaking the main Story.
                        continue;
                    }
                }
            } finally {
                $this->rendering_related_stories = false;
                wp_reset_postdata();
            }
            $html .= '</div></section>';
            return $content . $html;
        } catch (Throwable $related_error) {
            $this->rendering_related_stories = false;
            wp_reset_postdata();
            return $content;
        }
    }

    /** Admin controls for the lightweight latest-Stories section. */
    public function related_stories_admin_page() {
        if (!current_user_can('manage_options')) return;
        $settings = get_option('phiskvideos_related_stories_settings', []);
        if (!is_array($settings)) $settings = [];
        if (isset($_POST['phisk_related_stories_save'])) {
            check_admin_referer('phisk_related_stories_save_action', 'phisk_related_stories_nonce');
            $settings = [
                'enabled' => !empty($_POST['related_enabled']) ? 1 : 0,
                'count' => max(1, min(5, absint($_POST['related_count'] ?? 3))),
                'heading' => sanitize_text_field(wp_unslash($_POST['related_heading'] ?? 'More Stories')),
            ];
            if ($settings['heading'] === '') $settings['heading'] = 'More Stories';
            update_option('phiskvideos_related_stories_settings', $settings, false);
            echo '<div class="notice notice-success is-dismissible"><p>Related Stories settings saved.</p></div>';
        }
        $enabled = !isset($settings['enabled']) || !empty($settings['enabled']);
        $count = max(1, min(5, absint($settings['count'] ?? 3)));
        $heading = sanitize_text_field($settings['heading'] ?? 'More Stories');
        if ($heading === '') $heading = 'More Stories';
        ?>
        <div class="wrap">
          <h1>PhiskVideos — Related Stories</h1>
          <p>Show the latest published Stories beneath each Story. Recommendations do not use Interest taxonomy, votes, or view counts.</p>
          <form method="post">
            <?php wp_nonce_field('phisk_related_stories_save_action', 'phisk_related_stories_nonce'); ?>
            <table class="form-table" role="presentation">
              <tr><th scope="row">Enable Related Stories</th><td><label><input type="checkbox" name="related_enabled" value="1" <?php checked($enabled); ?>> Display below individual Stories</label></td></tr>
              <tr><th scope="row"><label for="related_count">Number of Stories</label></th><td><select id="related_count" name="related_count"><?php for ($n=1; $n<=5; $n++): ?><option value="<?php echo esc_attr($n); ?>" <?php selected($count, $n); ?>><?php echo esc_html($n); ?></option><?php endfor; ?></select><p class="description">Default: 3. The current Story is excluded.</p></td></tr>
              <tr><th scope="row"><label for="related_heading">Section heading</label></th><td><input id="related_heading" class="regular-text" type="text" name="related_heading" value="<?php echo esc_attr($heading); ?>"></td></tr>
            </table>
            <p><button type="submit" class="button button-primary" name="phisk_related_stories_save" value="1">Save Related Stories Settings</button></p>
          </form>
        </div>
        <?php
    }

    public function rewrite_notice() {
        if (get_option('phiskvideos_rewrite_notice') && current_user_can('manage_options')) {
            echo '<div class="notice notice-info is-dismissible"><p><strong>PhiskVideos:</strong> Please visit Settings → Permalinks and click Save Changes if Movie, TV Show, or Video pages return a 404. Rewrite rules are refreshed automatically when the plugin version changes; you can also save Permalinks manually if your server has cached old rules.</p></div>';
        }
    }
}
new PhiskVideos_Movie_TV();

// Ensure the shared /logout/ route is registered immediately when this plugin is activated.
register_activation_hook(__FILE__, function () {
    add_rewrite_rule('^logout/?$', 'index.php?phisk_universal_logout=1', 'top');
    flush_rewrite_rules();
});
register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('phisk_user_strike_daily_maintenance');
    flush_rewrite_rules();
});
