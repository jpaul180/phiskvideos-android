# PhiskVideos Android v1.14.1 — Homepage Polish Update 1

Based on v1.13.0. This update changes only the native homepage presentation and card interactions.

## Changes
- Moves Subscribe/Subscribed onto the same metadata row as creator/views, right-aligned at the far edge of the video-card details area.
- Uses the supplied SVG artwork for Activities, Settings, Create, and Studio navigation icons; the existing temporary Home outline remains.
- Keeps the current bundled default avatar because the previously selected happy-face image is not included in this source archive.
- Replaces the hamburger shortcut with the signed-in user's channel avatar.
- Loads the current creator's avatar from the existing Creator Studio and Creator Detail REST APIs; bundled Phisk violet avatar is the fallback.
- Avatar opens the user's native Channel page. If no channel is available, it directs the user to Creator Studio.
- Uses image-based navigation icons sourced from the supplied SVG collection for Activities, Settings, Create, and Studio; retains the temporary Home outline.
- Adds Subscribe/Subscribed controls to creator video cards using the existing creator subscribe API.
- Removes the monetized-channel label and the standalone Following label.
- Adds Share to the video thumbnail overflow menu using Android's native share chooser.
- Decodes HTML entities in video titles and creator names.

## Backend
Phisk Video Manager v1.20.0 adds `has_custom_avatar` to the existing creator detail response so the app can distinguish a real uploaded channel image from WordPress's generated fallback avatar. The existing API also provides:
- `GET /wp-json/phisk/v1/creator-studio`
- `GET /wp-json/phisk/v1/creators/{id}`
- `POST /wp-json/phisk/v1/creators/{id}/subscribe`

## Build
Upload this archive to the repository root and replace `.github/workflows/android.yml` with the included workflow, then run GitHub Actions.
