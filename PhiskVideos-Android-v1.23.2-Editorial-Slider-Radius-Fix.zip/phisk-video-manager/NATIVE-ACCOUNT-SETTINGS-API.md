# Native Account Settings API

Companion API updated in Phisk Video Manager 1.20.5 for the PhiskVideos Android v1.17.1 native Edit Profile screen.

## Authentication
All requests require HTTPS and the existing native app bearer session:

`Authorization: Bearer <native-app-access-token>`

The route uses the existing `app_api_permission_callback`; users can only read or update their own currently authenticated WordPress account.

## GET `/wp-json/phisk/v1/account-settings`
Returns the website Account Settings → Personal Information fields:

- `account.username`
- `account.first_name`
- `account.last_name`
- `account.phone_number`
- `account.username_can_change`
- `account.username_change_available_at` (Unix timestamp; zero if no cooldown is active)
- `account.email`
- `account.profile_image_url` (empty when no custom profile image is set)

## POST `/wp-json/phisk/v1/account-settings`
JSON body:

```json
{
  "username": "example_user",
  "first_name": "Example",
  "last_name": "User",
  "phone_number": "+234..."
}
```

The endpoint preserves the website's username rules: 3–24 lowercase letters, numbers or underscores; uniqueness checks; 30-day change cooldown; username history and previous-slug redirects. First and last names are saved to WordPress user fields. Phone number is saved to `phisk_phone_number`, matching the website Account Settings form.

A successful response contains `success`, `message`, and the refreshed `account` object. Validation, conflict, and cooldown errors are returned as WordPress REST errors with appropriate HTTP status codes.

This endpoint does not modify creator-channel names, biographies, profile/cover images, or social links.


## GET `/wp-json/phisk/v1/account-settings/username-availability?username=example_user`

Authenticated live check for the editable public `phisk_username`. Returns `available`, `valid`, optional `cooldown` and `username_change_available_at`, plus a user-facing `message`. The current username is treated as available/unchanged. This check is advisory; `POST /account-settings` always repeats the uniqueness and cooldown validation before saving.

## POST `/wp-json/phisk/v1/account-settings/profile-image`

Authenticated multipart/form-data upload with file field `image`. Accepts JPG, PNG or WebP up to 8 MB. Stores the attachment in the WordPress media library, assigns its owner to the authenticated user, and updates only `phisk_profile_image_id`. It does not read or modify `phisk_cover_image_id` or creator-channel fields. Returns `profile_image_url` and the attachment ID.
