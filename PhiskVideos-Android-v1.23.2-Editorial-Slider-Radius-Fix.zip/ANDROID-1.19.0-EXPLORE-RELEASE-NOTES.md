# PhiskVideos Android v1.19.0 — Native Explore

## Included
- Added Explore as the first native homepage tab, ahead of For You.
- Loads Explore section configuration from `wp-json/phisk-algorithm/v1/explore/config`.
- Loads each carousel from `wp-json/phisk-algorithm/v1/explore/sections/{section_id}`.
- Native horizontal carousels use the remotely configured section order, titles, categories, sorting and limits.
- Carousel cards use thumbnail overlays for creator avatars and video duration, followed by `By: Creator Name | Views` and a fixed two-line title area with ellipsis truncation.
- View More opens a native category archive backed by `wp-json/phisk-algorithm/v1/categories/{slug}/videos`.
- Category archive shows category name and description, supports Latest / Popular / Trending sorting, and loads additional videos as the user scrolls.
- Existing For You and other homepage feed endpoints remain in place; Explore is a separate tab.

## Compatibility
- Requires Phisk Algorithm v1.3.0 or later with the Explore and category REST routes enabled.
- No WordPress theme or plugin files are modified in this Android package.


## Native Explore carousel visual refinement

- Reduced Explore carousel card corner radius for a less rounded appearance.
- Reduced the fixed card height and removed excess space beneath video titles.
- Kept a consistent card height and two-line title ellipsis.
- Rebuilt creator avatar presentation with a circular crop and visible white border, including for square source images.
- Added the supplied white share SVG icon to the top-right of each Explore thumbnail and connected it to the existing native share action.
- No website theme, WordPress plugin, or other app screens were changed.
