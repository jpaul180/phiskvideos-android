# PhiskVideos Android v1.21.0 — Native Phisk Collections

## Added
- Native Phisk Collections carousel at the top of the Explore tab, before the Explore heading and subtitle.
- Collections loaded from Mr Atlas & Admin: `GET /wp-json/phisk-editorial/v1/collections?per_page=20`.
- Five-layer maximum card stack (cover thumbnail plus up to four backing thumbnails), preserving editorial stack order.
- Wide native carousel cards with side preview, subtle borders, matching rounded clipping, and a neutral gray draggable position indicator.
- Collection-specific skeleton loading that mirrors the stacked card layout.
- Native collection detail screen using `GET /wp-json/phisk-editorial/v1/collections/{id}` and displaying videos in the exact editorial order.
- Native video opening from collection detail using the existing player activity.
- Light/dark-aware collection surfaces, borders, text and indicator.

## Preserved
- Existing Phisk Algorithm Explore configuration and recommendation sections.
- Existing homepage tabs, native player, authentication, Creator Studio, upload, downloads, notifications, settings and app-wide dark mode.
- Editorial management remains in Mr Atlas & Admin; the app only consumes its read-only API.

## Version
- versionName: 1.21.0
- versionCode: 51

## Validation note
The source package was updated and Android manifest XML was validated. A local Gradle build could not be run in this environment because Gradle/Android build tooling is not installed. Run the repository's existing GitHub Actions workflow to perform the authoritative Android build before installing the APK.
