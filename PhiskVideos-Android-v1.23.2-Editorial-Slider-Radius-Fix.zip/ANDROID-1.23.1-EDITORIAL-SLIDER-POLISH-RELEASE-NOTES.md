# PhiskVideos Android v1.23.1 — Editorial Slider Polish

- Added subtle 8dp rounded corners to the collection hero, clipping the cover image, gradient and overlays together.
- Removed the redundant in-feed “Explore” heading and “Discover videos across PhiskVideos.” subtitle.
- Editorial category sections now follow the collection carousel directly, reducing unnecessary vertical space.
- Preserved collection carousel dimensions, margins, gradient, title, description, video count, pagination, swipe navigation and auto-advance.
- Fixed a literal escaped newline between `NativeHomeActivity` lifecycle methods that caused Java compilation to fail.
- Version: 1.23.1 (versionCode 54).
