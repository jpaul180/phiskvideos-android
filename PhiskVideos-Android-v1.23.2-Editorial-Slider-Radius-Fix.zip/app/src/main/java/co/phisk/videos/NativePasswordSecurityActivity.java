package co.phisk.videos;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Native implementation of the website's Privacy & Security settings. */
public class NativePasswordSecurityActivity extends Activity {
    private static final String HOME="https://videos.phisk.co/";
    private static final int VIOLET=Color.rgb(124,58,237), DEEP=Color.rgb(109,40,217);
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private boolean dark, googleNeedsPassword, loading;
    private int bg,card,ink,muted,border,divider;
    private LinearLayout content, deviceList;
    private ProgressBar progress;
    private EditText currentPassword,newPassword,confirmPassword;
    private LinearLayout passwordForm;
    private TextView passwordTitle,passwordDescription;
    private Button passwordSave;
    private JSONArray devices=new JSONArray();

    @Override public void onCreate(Bundle state){
        PhiskTheme.configureActivityTheme(this); super.onCreate(state);
        dark=PhiskTheme.isDark(this); palette(); build(); load();
    }
    private void palette(){
        bg=dark?Color.rgb(20,20,24):Color.rgb(247,248,250);
        card=dark?Color.rgb(31,32,38):Color.WHITE;
        ink=dark?Color.rgb(245,245,248):Color.rgb(25,29,38);
        muted=dark?Color.rgb(170,172,183):Color.rgb(112,117,128);
        border=dark?Color.rgb(58,59,68):Color.rgb(231,233,238);
        divider=dark?Color.rgb(54,55,63):Color.rgb(239,240,243);
    }
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable shape(int color,int stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
    private TextView label(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private String token(){return getSharedPreferences("phisk_native_auth",MODE_PRIVATE).getString("access_token","");}
    private JSONObject request(String path,String method,JSONObject body)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(HOME+"wp-json/phisk/v1/"+path).openConnection();
        try{
            c.setRequestMethod(method);c.setConnectTimeout(15000);c.setReadTimeout(22000);
            c.setRequestProperty("Accept","application/json");c.setRequestProperty("Authorization","Bearer "+token());
            if(body!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=UTF-8");try(OutputStream o=c.getOutputStream()){o.write(body.toString().getBytes(StandardCharsets.UTF_8));}}
            int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();
            ByteArrayOutputStream out=new ByteArrayOutputStream();if(in!=null){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);in.close();}
            String raw=out.toString("UTF-8");if(code<200||code>=300){String message="Request failed ("+code+")";try{message=new JSONObject(raw).optString("message",message);}catch(Exception ignored){}throw new Exception(message);}
            return raw.isEmpty()?new JSONObject():new JSONObject(raw);
        }finally{c.disconnect();}
    }
    private void build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(dp(14),0,dp(16),0);top.setBackgroundColor(card);
        TextView back=label("‹",34,ink,false);back.setGravity(Gravity.CENTER);top.addView(back,new LinearLayout.LayoutParams(dp(42),dp(56)));back.setOnClickListener(v->finish());
        LinearLayout titleBox=new LinearLayout(this);titleBox.setOrientation(LinearLayout.VERTICAL);TextView title=label("Password & Security",17,ink,true);titleBox.addView(title);TextView sub=label("Protect your account and connected devices",11,muted,false);titleBox.addView(sub);top.addView(titleBox);
        root.addView(top);View line=new View(this);line.setBackgroundColor(border);root.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
        FrameLayout frame=new FrameLayout(this);ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(18),dp(18),dp(18),dp(34));scroll.addView(content);
        frame.addView(scroll,new FrameLayout.LayoutParams(-1,-1));progress=new ProgressBar(this);FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(dp(34),dp(34),Gravity.TOP|Gravity.CENTER_HORIZONTAL);pp.topMargin=dp(14);frame.addView(progress,pp);root.addView(frame,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
        // Restrained violet security masthead.
        LinearLayout hero=new LinearLayout(this);hero.setOrientation(LinearLayout.VERTICAL);hero.setPadding(dp(18),dp(18),dp(18),dp(18));hero.setBackground(shape(dark?Color.rgb(43,32,63):Color.rgb(246,241,255),0,12));
        LinearLayout heroTop=new LinearLayout(this);heroTop.setGravity(Gravity.CENTER_VERTICAL);TextView shield=label("◆",20,VIOLET,true);shield.setGravity(Gravity.CENTER);heroTop.addView(shield,new LinearLayout.LayoutParams(dp(34),dp(34)));TextView status=label("ACCOUNT PROTECTION",10,VIOLET,true);status.setLetterSpacing(.12f);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-2,-2);sp.leftMargin=dp(10);heroTop.addView(status,sp);hero.addView(heroTop);
        TextView heroTitle=label("Your account, kept secure.",18,ink,true);heroTitle.setPadding(0,dp(12),0,dp(4));hero.addView(heroTitle);TextView heroCopy=label("Manage your sign-in password and review the devices connected to your PhiskVideos account.",12,muted,false);heroCopy.setLineSpacing(dp(3),1f);hero.addView(heroCopy);content.addView(hero);
        section("PASSWORD");LinearLayout pw=card();passwordForm=pw;
        LinearLayout pwHead=new LinearLayout(this);pwHead.setOrientation(LinearLayout.VERTICAL);pwHead.setPadding(dp(16),dp(15),dp(16),dp(8));passwordTitle=label("Change Password",15,ink,true);pwHead.addView(passwordTitle);passwordDescription=label("Use at least 8 characters for your new password.",11,muted,false);passwordDescription.setPadding(0,dp(4),0,0);pwHead.addView(passwordDescription);pw.addView(pwHead);
        currentPassword=field("Current password",true);pw.addView(fieldWrap(currentPassword));
        newPassword=field("New password",true);pw.addView(fieldWrap(newPassword));
        confirmPassword=field("Confirm new password",true);pw.addView(fieldWrap(confirmPassword));
        LinearLayout pwFoot=new LinearLayout(this);pwFoot.setPadding(dp(16),dp(8),dp(16),dp(16));pwFoot.setGravity(Gravity.CENTER_VERTICAL);pwFoot.setOrientation(LinearLayout.VERTICAL);
        TextView rule=label("Password must contain at least 8 characters.",10,muted,false);pwFoot.addView(rule);
        passwordSave=new Button(this);passwordSave.setText("Update password");passwordSave.setAllCaps(false);passwordSave.setTextColor(Color.WHITE);passwordSave.setBackground(shape(VIOLET,0,7));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(46));bp.topMargin=dp(13);pwFoot.addView(passwordSave,bp);passwordSave.setOnClickListener(v->submitPassword());pw.addView(pwFoot);
        section("CONNECTED DEVICES");LinearLayout dev=card();TextView deviceIntro=label("These are the app installations registered to your account. Removing a device disconnects its registration from PhiskVideos. Your FCM token is never displayed.",11,muted,false);deviceIntro.setLineSpacing(dp(3),1f);deviceIntro.setPadding(dp(16),dp(14),dp(16),dp(12));dev.addView(deviceIntro);deviceList=new LinearLayout(this);deviceList.setOrientation(LinearLayout.VERTICAL);dev.addView(deviceList);
        TextView privacyNote=label("Only devices registered to your account are shown here.",10,muted,false);privacyNote.setPadding(dp(4),dp(10),dp(4),0);content.addView(privacyNote);
        progress.setVisibility(View.VISIBLE);
    }
    private void section(String s){TextView t=label(s,10,muted,true);t.setLetterSpacing(.12f);t.setPadding(dp(3),dp(22),dp(3),dp(9));content.addView(t);}
    private LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setBackground(shape(card,border,11));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(2);content.addView(c,p);return c;}
    private EditText field(String hint,boolean secret){EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(14);e.setTextColor(ink);e.setHintTextColor(muted);e.setHint(hint);e.setPadding(dp(13),0,dp(12),0);e.setBackground(shape(dark?Color.rgb(38,39,46):Color.rgb(250,250,252),border,7));e.setInputType(InputType.TYPE_CLASS_TEXT|(secret?InputType.TYPE_TEXT_VARIATION_PASSWORD:0));return e;}
    private View fieldWrap(EditText e){LinearLayout wrap=new LinearLayout(this);wrap.setPadding(dp(16),dp(5),dp(16),dp(5));wrap.addView(e,new LinearLayout.LayoutParams(-1,dp(48)));return wrap;}
    private void load(){if(token().isEmpty()){progress.setVisibility(View.GONE);new AlertDialog.Builder(this).setMessage("Please sign in to manage your account security.").setPositiveButton("OK",(d,w)->finish()).show();return;}
        io.execute(()->{try{JSONObject result=request("security-settings","GET",null);JSONObject account=result.optJSONObject("account");JSONArray list=result.optJSONArray("devices");runOnUiThread(()->{googleNeedsPassword=account!=null&&account.optBoolean("needs_password",false);devices=list==null?new JSONArray():list;passwordTitle.setText(googleNeedsPassword?"Set Password":"Change Password");passwordDescription.setText(googleNeedsPassword?"Set a password to also sign in with your email.":"Enter your current password and choose a new password of at least 8 characters.");currentPassword.setVisibility(googleNeedsPassword?View.GONE:View.VISIBLE);passwordSave.setText(googleNeedsPassword?"Set password":"Update password");renderDevices();progress.setVisibility(View.GONE);});}catch(Exception e){runOnUiThread(()->{progress.setVisibility(View.GONE);Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();});}});
    }
    private void renderDevices(){deviceList.removeAllViews();if(devices.length()==0){TextView empty=label("No app devices are registered to your account yet. Your signed-in app will appear here when device registration is active.",12,muted,false);empty.setPadding(dp(16),dp(4),dp(16),dp(16));deviceList.addView(empty);return;}
        for(int i=0;i<devices.length();i++){JSONObject d=devices.optJSONObject(i);if(d==null)continue;final int id=d.optInt("id");LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(16),dp(12),dp(14),dp(12));
            LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);String platform=d.optString("platform","android").toUpperCase(Locale.ROOT);copy.addView(label(platform+" device",13,ink,true));
            String version=d.optString("app_version","");String date=d.optString("last_active","");String meta=(version.isEmpty()?"App version unknown":"App version "+version)+(date.isEmpty()?"":"  ·  Last active "+date);TextView detail=label(meta,10,muted,false);detail.setPadding(0,dp(4),0,0);copy.addView(detail);row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
            TextView remove=label("Remove",11,VIOLET,true);remove.setGravity(Gravity.CENTER);remove.setPadding(dp(10),dp(8),dp(10),dp(8));remove.setBackground(shape(dark?Color.rgb(53,39,75):Color.rgb(246,241,255),0,6));row.addView(remove);remove.setOnClickListener(v->confirmRemove(id,platform));deviceList.addView(row);if(i<devices.length()-1){View div=new View(this);div.setBackgroundColor(divider);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(1));p.leftMargin=dp(16);p.rightMargin=dp(16);deviceList.addView(div,p);}}
    }
    private void confirmRemove(int id,String platform){new AlertDialog.Builder(this).setTitle("Remove this device?").setMessage("This will remove this "+platform.toLowerCase(Locale.ROOT)+" device registration from your account.").setNegativeButton("Cancel",null).setPositiveButton("Remove",(d,w)->removeDevice(id)).show();}
    private void removeDevice(int id){setBusy(true);io.execute(()->{try{JSONObject body=new JSONObject();body.put("device_id",id);request("security-settings/devices","POST",body);JSONObject result=request("security-settings","GET",null);JSONArray list=result.optJSONArray("devices");runOnUiThread(()->{devices=list==null?new JSONArray():list;renderDevices();setBusy(false);Toast.makeText(this,"Device removed.",Toast.LENGTH_SHORT).show();});}catch(Exception e){runOnUiThread(()->{setBusy(false);Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();});}});}
    private void submitPassword(){String current=currentPassword.getText().toString(),next=newPassword.getText().toString(),confirm=confirmPassword.getText().toString();if(!googleNeedsPassword&&current.isEmpty()){currentPassword.setError("Enter your current password");return;}if(next.length()<8){newPassword.setError("Use at least 8 characters");return;}if(!next.equals(confirm)){confirmPassword.setError("Passwords do not match");return;}
        passwordSave.setEnabled(false);passwordSave.setText("Updating…");io.execute(()->{try{JSONObject body=new JSONObject();body.put("current_password",current);body.put("new_password",next);body.put("confirm_password",confirm);JSONObject result=request("security-settings/password","POST",body);runOnUiThread(()->{currentPassword.setText("");newPassword.setText("");confirmPassword.setText("");passwordSave.setEnabled(true);passwordSave.setText(googleNeedsPassword?"Set password":"Update password");Toast.makeText(this,result.optString("message","Password updated successfully."),Toast.LENGTH_LONG).show();googleNeedsPassword=false;currentPassword.setVisibility(View.VISIBLE);passwordTitle.setText("Change Password");passwordDescription.setText("Enter your current password and choose a new password of at least 8 characters.");});}catch(Exception e){runOnUiThread(()->{passwordSave.setEnabled(true);passwordSave.setText(googleNeedsPassword?"Set password":"Update password");Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();});}});
    }
    private void setBusy(boolean busy){loading=busy;progress.setVisibility(busy?View.VISIBLE:View.GONE);}
    @Override protected void onDestroy(){super.onDestroy();io.shutdown();}
}
