package co.phisk.videos;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Three-slide native onboarding for app welcome, channel creation and Creator Studio. */
public class NativeOnboardingActivity extends Activity {
    public static final String EXTRA_FLOW = "onboarding_flow";
    public static final String FLOW_APP = "app";
    public static final String FLOW_CHANNEL = "channel";
    public static final String FLOW_STUDIO = "studio";
    private static final int VIOLET = Color.rgb(124,58,237);
    private static final int INK = Color.rgb(25,29,38);
    private static final int MUTED = Color.rgb(112,117,128);
    private static final String PREFS = "phisk_native_onboarding";
    private String flow = FLOW_APP;
    private int page = 0;
    private LinearLayout root, dots;
    private FrameLayout illustration;
    private TextView heading, description, action, skip;
    private float downX, downY;

    private static final String[][] APP = {
        {"Welcome to PhiskVideos!", "Discover exciting videos, amazing stories and endless entertainment. There's always something new to enjoy!"},
        {"Discover. Connect. Engage.", "Find your favourite creators, explore fresh content and become part of our growing community."},
        {"There's Something for Everyone!", "Watch, share, interact and discover content worth coming back for."}
    };
    private static final String[][] CHANNEL = {
        {"Your Voice Deserves to Be Heard!", "Create your own channel and share your creativity with the world."},
        {"Create. Share. Grow.", "Publish videos and stories, build your audience and connect with your viewers."},
        {"Create Content. Earn Rewards!", "Grow your channel and unlock opportunities to earn through our creator monetization programme."}
    };
    private static final String[][] STUDIO = {
        {"Welcome to Creator Studio!", "Your creative journey starts here. Manage your channel and take charge of your growth."},
        {"Know Your Performance!", "Track your views, engagement and earnings. Turn insights into better content."},
        {"Keep Creating. Keep Growing!", "Reach new audiences, achieve your goals and unlock your creator potential."}
    };

    @Override public void onCreate(Bundle state) {
        PhiskTheme.configureActivityTheme(this);
        super.onCreate(state);
        flow = getIntent().getStringExtra(EXTRA_FLOW);
        if (flow == null) flow = FLOW_APP;
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        build();
        showPage(0);
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
    private String[][] slides() { return FLOW_CHANNEL.equals(flow) ? CHANNEL : FLOW_STUDIO.equals(flow) ? STUDIO : APP; }
    private String finalLabel() { return FLOW_CHANNEL.equals(flow) ? "Create Your Channel" : FLOW_STUDIO.equals(flow) ? "Explore Creator Studio" : "Get Started"; }

    private void build() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(20), dp(8), dp(20), dp(8));
        TextView brand = label("PhiskVideos", 17, VIOLET, true);
        top.addView(brand, new LinearLayout.LayoutParams(0, dp(44), 1));
        skip = label("Skip", 14, MUTED, true);
        top.addView(skip);
        skip.setOnClickListener(v -> finishFlow());
        root.addView(top);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout content = new LinearLayout(this);
        content.setGravity(Gravity.CENTER_HORIZONTAL);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(26), dp(12), dp(26), dp(12));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        illustration = new FrameLayout(this);
        illustration.setBackground(background(Color.rgb(248,246,252), 22, Color.rgb(242,239,248)));
        TextView placeholder = label("Illustration placeholder", 14, MUTED, false);
        placeholder.setGravity(Gravity.CENTER);
        illustration.addView(placeholder, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout.LayoutParams imageParams = new LinearLayout.LayoutParams(-1, dp(300));
        imageParams.bottomMargin = dp(28);
        content.addView(illustration, imageParams);

        heading = label("", 25, INK, true);
        heading.setGravity(Gravity.CENTER);
        heading.setLineSpacing(dp(1), 1f);
        content.addView(heading, new LinearLayout.LayoutParams(-1, -2));

        description = label("", 15, MUTED, false);
        description.setGravity(Gravity.CENTER);
        description.setLineSpacing(dp(4), 1f);
        LinearLayout.LayoutParams descParams = new LinearLayout.LayoutParams(-1, -2);
        descParams.topMargin = dp(12);
        content.addView(description, descParams);

        dots = new LinearLayout(this);
        dots.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams dotsParams = new LinearLayout.LayoutParams(-1, dp(44));
        dotsParams.topMargin = dp(12);
        content.addView(dots, dotsParams);

        action = label("", 15, VIOLET, true);
        action.setGravity(Gravity.CENTER);
        action.setPadding(dp(18), dp(15), dp(18), dp(15));
        action.setBackground(background(Color.WHITE, 9, Color.WHITE));
        LinearLayout.LayoutParams actionParams = new LinearLayout.LayoutParams(-1, dp(54));
        actionParams.topMargin = dp(8);
        actionParams.bottomMargin = dp(18);
        content.addView(action, actionParams);
        action.setOnClickListener(v -> { if (page < 2) showPage(page + 1); else finishFlow(); });

        View.OnTouchListener swipe = (v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) { downX = event.getX(); downY = event.getY(); return true; }
            if (event.getAction() == MotionEvent.ACTION_UP) {
                float dx = event.getX() - downX, dy = event.getY() - downY;
                if (Math.abs(dx) > dp(55) && Math.abs(dx) > Math.abs(dy)) {
                    if (dx < 0 && page < 2) showPage(page + 1);
                    else if (dx > 0 && page > 0) showPage(page - 1);
                    return true;
                }
            }
            return true;
        };
        illustration.setOnTouchListener(swipe);
        heading.setOnTouchListener(swipe);
        description.setOnTouchListener(swipe);
        setContentView(root);
    }

    private void showPage(int index) {
        page = Math.max(0, Math.min(2, index));
        String[][] data = slides();
        heading.setText(data[page][0]);
        description.setText(data[page][1]);
        action.setText(page == 2 ? finalLabel() : "Next");
        skip.setVisibility(page == 2 ? View.INVISIBLE : View.VISIBLE);
        dots.removeAllViews();
        for (int i = 0; i < 3; i++) {
            View dot = new View(this);
            GradientDrawable d = new GradientDrawable();
            d.setShape(GradientDrawable.OVAL);
            d.setColor(i == page ? VIOLET : Color.rgb(215,215,220));
            dot.setBackground(d);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(i == page ? 9 : 7), dp(i == page ? 9 : 7));
            p.leftMargin = dp(4); p.rightMargin = dp(4);
            dots.addView(dot, p);
        }
        illustration.setContentDescription("Illustration placeholder for slide " + (page + 1));
    }

    private void finishFlow() {
        if (FLOW_APP.equals(flow)) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("app_intro_complete", true).apply();
            Intent next = new Intent(this, MainActivity.class);
            if (getIntent() != null) {
                if (getIntent().getExtras() != null) next.putExtras(getIntent().getExtras());
                if (getIntent().getAction() != null) next.setAction(getIntent().getAction());
                if (getIntent().getData() != null) next.setData(getIntent().getData());
            }
            next.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(next);
            finish();
        } else if (FLOW_CHANNEL.equals(flow)) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(userKey("channel_intro_complete_"), true).apply();
            Intent create = new Intent(this, NativeCreatorChannelEditorActivity.class);
            create.putExtra("create_channel_from_studio", true);
            startActivityForResult(create, 901);
        } else {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(userKey("studio_intro_complete_"), true).apply();
            setResult(RESULT_OK);
            finish();
        }
    }

    private String userKey(String prefix) {
        String token = getSharedPreferences("phisk_native_auth", MODE_PRIVATE).getString("access_token", "");
        try {
            byte[] digest = java.security.MessageDigest.getInstance("SHA-256").digest(token.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder();
            for (int i = 0; i < 12; i++) out.append(String.format(java.util.Locale.US, "%02x", digest[i]));
            return prefix + out;
        } catch (Exception ignored) { return prefix + "local_user"; }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 901) { setResult(resultCode, data); finish(); }
    }

    @Override public void onBackPressed() {
        if (page > 0) showPage(page - 1); else finishFlow();
    }

    private TextView label(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private GradientDrawable background(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        if (stroke != Color.WHITE) d.setStroke(dp(1), stroke);
        return d;
    }
}
