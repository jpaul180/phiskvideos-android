package co.phisk.videos;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Switch;
import android.widget.TextView;

/** Central persisted Light/Dark appearance for all PhiskVideos Android screens. */
public final class PhiskTheme {
    private static final String PREFS = "phisk_native_settings";
    private static final String KEY = "dark_mode";
    public static final int VIOLET = Color.rgb(124, 58, 237);
    private static final int DARK_BG = Color.rgb(20, 20, 24);
    private static final int DARK_CARD = Color.rgb(31, 32, 38);
    private static final int DARK_SURFACE = Color.rgb(38, 39, 46);
    private static final int DARK_BORDER = Color.rgb(58, 59, 68);
    private static final int LIGHT_TEXT = Color.rgb(245, 245, 248);
    private static final int MUTED_TEXT = Color.rgb(170, 172, 183);

    private PhiskTheme() {}

    public static boolean isDark(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY, false);
    }

    public static void setDark(Context context, boolean dark) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY, dark).apply();
    }

    public static void configureActivityTheme(Activity activity) {
        activity.setTheme(isDark(activity) ? R.style.AppTheme_Dark : R.style.AppTheme);
    }

    public static void apply(Activity activity) {
        boolean dark = isDark(activity);
        activity.getWindow().setStatusBarColor(dark ? DARK_BG : Color.WHITE);
        activity.getWindow().setNavigationBarColor(dark ? DARK_BG : Color.WHITE);
        if (Build.VERSION.SDK_INT >= 26) {
            activity.getWindow().getDecorView().setSystemUiVisibility(dark ? 0 :
                    View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        } else {
            activity.getWindow().getDecorView().setSystemUiVisibility(dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        View root = activity.getWindow().getDecorView().findViewById(android.R.id.content);
        if (root != null) applyView(root, dark, true);
    }

    private static void rememberOriginals(View view) {
        if (view.getTag(R.id.phisk_theme_original_background) == null) {
            Drawable bg = view.getBackground();
            Drawable copy = bg == null ? null : (bg.getConstantState() != null
                    ? bg.getConstantState().newDrawable(view.getResources()).mutate() : bg.mutate());
            view.setTag(R.id.phisk_theme_original_background, copy == null ? Boolean.FALSE : copy);
        }
        if (view instanceof TextView && view.getTag(R.id.phisk_theme_original_text) == null) {
            TextView t = (TextView) view;
            view.setTag(R.id.phisk_theme_original_text, t.getTextColors());
            if (t instanceof EditText) view.setTag(R.id.phisk_theme_original_hint, ((EditText)t).getHintTextColors());
        }
        if (view instanceof Switch) {
            Switch sw = (Switch)view;
            if (view.getTag(R.id.phisk_theme_original_switch_thumb) == null) view.setTag(R.id.phisk_theme_original_switch_thumb, sw.getThumbTintList());
            if (view.getTag(R.id.phisk_theme_original_switch_track) == null) view.setTag(R.id.phisk_theme_original_switch_track, sw.getTrackTintList());
        }
    }

    private static void applyView(View view, boolean dark, boolean root) {
        rememberOriginals(view);
        if (dark) {
            if (root) view.setBackgroundColor(DARK_BG); else transformBackground(view);
            if (view instanceof TextView) {
                TextView text = (TextView) view;
                int color = text.getCurrentTextColor();
                if (isNearWhite(color)) { if (!hasVioletAncestor(view)) text.setTextColor(LIGHT_TEXT); }
                else if (isDarkInk(color)) text.setTextColor(LIGHT_TEXT);
                else if (isMuted(color)) text.setTextColor(MUTED_TEXT);
                if (view instanceof EditText) ((EditText) view).setHintTextColor(MUTED_TEXT);
            }
            if (view instanceof Switch) {
                Switch sw = (Switch) view;
                sw.setThumbTintList(new ColorStateList(new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}}, new int[]{VIOLET, Color.rgb(190, 191, 199)}));
                sw.setTrackTintList(new ColorStateList(new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}}, new int[]{Color.rgb(177, 145, 245), DARK_BORDER}));
            }
            if (view instanceof ProgressBar) ((ProgressBar) view).setIndeterminateTintList(ColorStateList.valueOf(VIOLET));
            if (view instanceof WebView) { WebView web = (WebView) view; web.setBackgroundColor(DARK_BG); web.evaluateJavascript(darkCss(), null); }
        } else {
            Object originalBg = view.getTag(R.id.phisk_theme_original_background);
            if (originalBg instanceof Drawable) view.setBackground(((Drawable)originalBg).getConstantState() != null ? ((Drawable)originalBg).getConstantState().newDrawable(view.getResources()).mutate() : ((Drawable)originalBg).mutate());
            else if (originalBg == Boolean.FALSE) view.setBackground(null);
            if (view instanceof TextView) {
                Object colors = view.getTag(R.id.phisk_theme_original_text); if (colors instanceof ColorStateList) ((TextView)view).setTextColor((ColorStateList)colors);
                Object hints = view.getTag(R.id.phisk_theme_original_hint); if (view instanceof EditText && hints instanceof ColorStateList) ((EditText)view).setHintTextColor((ColorStateList)hints);
            }
            if (view instanceof Switch) {
                Object thumb=view.getTag(R.id.phisk_theme_original_switch_thumb), track=view.getTag(R.id.phisk_theme_original_switch_track);
                if (thumb instanceof ColorStateList) ((Switch)view).setThumbTintList((ColorStateList)thumb);
                if (track instanceof ColorStateList) ((Switch)view).setTrackTintList((ColorStateList)track);
            }
            if (view instanceof WebView) { WebView web=(WebView)view; web.setBackgroundColor(Color.WHITE); web.evaluateJavascript("(function(){var s=document.getElementById('phisk-app-dark-mode');if(s)s.remove();document.documentElement.style.colorScheme='light';})();", null); }
        }
        if (view instanceof ViewGroup) { ViewGroup group=(ViewGroup)view; for(int i=0;i<group.getChildCount();i++) applyView(group.getChildAt(i),dark,false); }
    }

    private static void transformBackground(View view) {
        Drawable background = view.getBackground();
        if (background instanceof ColorDrawable) {
            int c = ((ColorDrawable) background).getColor();
            int mapped = mapBackground(c);
            if (mapped != c) view.setBackgroundColor(mapped);
        } else if (background instanceof GradientDrawable) {
            GradientDrawable gd = (GradientDrawable) background.mutate();
            try {
                ColorStateList colors = gd.getColor();
                if (colors != null) {
                    int c = colors.getDefaultColor();
                    int mapped = mapBackground(c);
                    if (mapped != c) gd.setColor(mapped);
                }
                gd.setStroke(1, DARK_BORDER);
            } catch (Exception ignored) { }
            view.setBackground(gd);
        }
    }

    private static int mapBackground(int color) {
        if (isNearWhite(color)) return DARK_CARD;
        if (isLightSurface(color)) return DARK_SURFACE;
        if (isDarkInk(color)) return DARK_BG;
        return color;
    }

    private static boolean isNearWhite(int c) { return Color.red(c) > 242 && Color.green(c) > 242 && Color.blue(c) > 242; }
    private static boolean isLightSurface(int c) { return Color.red(c) > 215 && Color.green(c) > 215 && Color.blue(c) > 215 && !isNearWhite(c); }
    private static boolean isDarkInk(int c) { return Color.red(c) < 65 && Color.green(c) < 70 && Color.blue(c) < 85; }
    private static boolean isMuted(int c) { return Color.red(c) >= 85 && Color.red(c) < 175 && Math.abs(Color.red(c)-Color.green(c)) < 25 && Math.abs(Color.green(c)-Color.blue(c)) < 25; }

    private static boolean hasVioletAncestor(View view) {
        android.view.ViewParent p = view.getParent();
        while (p instanceof View) {
            Drawable d = ((View) p).getBackground();
            if (d instanceof ColorDrawable && isViolet(((ColorDrawable) d).getColor())) return true;
            if (d instanceof GradientDrawable) {
                try { ColorStateList c = ((GradientDrawable) d).getColor(); if (c != null && isViolet(c.getDefaultColor())) return true; }
                catch (Exception ignored) { }
            }
            p = p.getParent();
        }
        return false;
    }

    private static boolean isViolet(int c) { return Color.red(c) > 90 && Color.blue(c) > 170 && Color.green(c) < 110; }

    public static String darkCss() {
        return "(function(){var id='phisk-app-dark-mode';var old=document.getElementById(id);if(old)old.remove();var s=document.createElement('style');s.id=id;s.textContent=`html,body{background:#141418!important;color:#f5f5f8!important;color-scheme:dark!important}body,main,header,footer,nav,section,article,aside,div,form,fieldset,dialog,[class*='card'],[class*='panel'],[class*='modal'],[class*='menu']{border-color:#3a3b44!important}input,textarea,select,[contenteditable='true']{background:#26272e!important;color:#f5f5f8!important;border-color:#3a3b44!important}input::placeholder,textarea::placeholder{color:#aaacb7!important}a{color:#b99af8!important}button,[role='button']{border-color:#3a3b44!important}img,video,iframe{color-scheme:normal!important} .phisk-app-light,.phisk-light-mode{filter:none!important}`;document.head.appendChild(s);})();";
    }
}
