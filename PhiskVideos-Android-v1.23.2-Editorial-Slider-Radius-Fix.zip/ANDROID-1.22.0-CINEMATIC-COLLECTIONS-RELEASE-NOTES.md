# PhiskVideos Android v1.22.0 — Cinematic Collections

## Design update
- Retired the overlapping five-layer thumbnail stack.
- Replaced it with a single cinematic 16:9 collection cover.
- Added a restrained bottom scrim with collection title and curated-collection descriptor.
- Added a Phisk Violet video-count badge.
- Added a compact horizontal filmstrip of collection preview thumbnails with a `+N` overflow tile.
- Preserved the existing horizontal carousel width, side peek, gray draggable indicator and collection navigation.
- Preserved collection API source and administrator-defined ordering; no automatic ranking or editorial logic added.
- Uses existing light/dark theme surfaces and subtle borders.

## Preserved
- Explore ordering: Phisk Collections appears before Explore heading and subtitle.
- Mr Atlas & Admin REST API integration.
- Native collection detail screen and native player handoff.
- Existing Explore recommendations, algorithm integration, navigation, authentication, downloads, notifications, Creator Studio and app-wide Dark Mode.

## Version
- versionName: 1.22.0
- versionCode: 52
