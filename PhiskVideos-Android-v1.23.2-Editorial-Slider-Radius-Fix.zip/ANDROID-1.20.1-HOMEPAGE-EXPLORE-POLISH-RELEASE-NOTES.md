# PhiskVideos Android 1.20.1 — Homepage / Explore Polish

- Added a native swipe-down-to-refresh gesture on Homepage / Explore and feed tabs.
- Added a restrained Phisk Violet refresh indicator and refresh-state protection.
- Added reusable animated loading skeleton placeholders for Explore sections and feed cards.
- Refined Homepage / Explore surfaces with subtle borders and modest corner radii.
- Preserved existing feed endpoints, navigation, pagination, player launch and account actions.
- App version: 1.20.1 (versionCode 45).
