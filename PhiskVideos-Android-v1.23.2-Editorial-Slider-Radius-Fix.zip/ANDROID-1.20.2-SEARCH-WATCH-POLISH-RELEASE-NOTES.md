# PhiskVideos Android 1.20.2 — Search & Watch Page Polish

- App version: 1.20.2 (versionCode 48).
- Search now uses homepage-matched subtle borders (`#E8E9EE`) and skeleton surfaces (`#EEEFF3`).
- Search loading skeletons adapt to Videos, Stories, and Channels result layouts.
- Skeleton pulse timing matches Homepage/Explore at 850ms with a restrained alpha pulse.
- Search cards and header separators use consistent subtle borders.
- Native Watch Page now shows an elegant metadata, creator, description, and related-video skeleton while data loads.
- Watch Page description, comment cards, and bottom-navigation separator use subtle borders/dividers.
- Existing search endpoints, pagination, playback, creator actions, downloads, likes, sharing, reporting, and comments are retained.

This release is a source update; build and device testing are still required before release.
