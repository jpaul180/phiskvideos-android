# PhiskVideos Android 1.20.0 — Native Password & Security

- Replaced the Password & Security WebView destination with a native Android screen.
- Native screen mirrors the website's Privacy & Security section: Set/Change Password and My Devices.
- Uses the Phisk brand violet (#7C3AED), deep violet (#6D28D9), restrained surfaces, subtle borders and modest corner radii.
- Supports the app's existing light/dark appearance.
- Password updates validate current password, minimum length and confirmation on the server.
- Device list and removal are scoped to the authenticated account; FCM tokens are never exposed.
- Added authenticated REST endpoints in Phisk Video Manager 1.20.7.
