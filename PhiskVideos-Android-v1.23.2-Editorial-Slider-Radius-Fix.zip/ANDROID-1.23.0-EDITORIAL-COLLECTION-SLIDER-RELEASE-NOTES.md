# PhiskVideos Android v1.23.0 — Full-width Editorial Collection Slider

- Replaced the previous card/filmstrip carousel with a full-width, single-slide editorial hero directly beneath the Explore tabs.
- Removed the Phisk Collections heading, View All action, side peeking, filmstrip, and decorative card framing.
- Added a 16:9 collection artwork banner with title and description overlaid in white.
- Added a subtle video-count badge and compact pagination dots using Phisk Violet for the active slide.
- Added a full-height black gradient that remains transparent at the top and deepens smoothly toward the bottom.
- Added 6.5-second automatic slide advancement, manual horizontal swiping, dot navigation, and pause-while-touching behavior.
- Added subtle crossfade transitions between collection artwork.
- Preserved the editorial API, administrator-defined collection order, collection detail navigation, and existing Explore recommendations.
- Preserved the existing app features and app-wide light/dark theme support.
