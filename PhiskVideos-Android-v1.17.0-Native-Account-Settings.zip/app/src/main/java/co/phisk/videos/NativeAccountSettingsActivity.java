package co.phisk.videos;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Native equivalent of the website's Account Settings > Personal Information form. */
public class NativeAccountSettingsActivity extends Activity {
    private static final String HOME="https://videos.phisk.co/";
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private LinearLayout content; private EditText username,firstName,lastName,phone; private TextView usernameHint; private ProgressBar progress; private Button save; private boolean loading=false;
    private int bg,card,ink,muted,border;
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private boolean dark(){return PhiskTheme.isDark(this);}
    private void palette(){bg=dark()?Color.rgb(20,20,24):Color.rgb(247,248,250);card=dark()?Color.rgb(31,32,38):Color.WHITE;ink=dark()?Color.rgb(245,245,248):Color.rgb(25,29,38);muted=dark()?Color.rgb(170,172,183):Color.rgb(112,117,128);border=dark()?Color.rgb(58,59,68):Color.rgb(231,233,238);}
    private GradientDrawable shape(int color,int stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
    private TextView label(String value,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private String token(){return getSharedPreferences("phisk_native_auth",MODE_PRIVATE).getString("access_token","");}
    @Override public void onCreate(Bundle b){PhiskTheme.configureActivityTheme(this);super.onCreate(b);PhiskTheme.apply(this);build();load();}
    private void build(){palette();LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(14),0,dp(14),0);bar.setBackgroundColor(card);TextView back=label("‹",34,ink,false);back.setGravity(Gravity.CENTER);bar.addView(back,new LinearLayout.LayoutParams(dp(42),dp(54)));back.setOnClickListener(v->finish());bar.addView(label("Edit Profile",18,ink,true));root.addView(bar);View line=new View(this);line.setBackgroundColor(border);root.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
        ScrollView scroll=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(18),dp(20),dp(18),dp(30));scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        content.addView(label("Account Settings",21,ink,true));TextView intro=label("Manage your personal account information.",13,muted,false);intro.setPadding(0,dp(5),0,dp(18));content.addView(intro);
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(16),dp(17),dp(16),dp(17));form.setBackground(shape(card,border,10));content.addView(form);
        username=field(form,"Username","Enter a username","text");username.setSingleLine(true);username.setInputType( android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);username.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(24)});
        usernameHint=label("Use 3–24 letters, numbers or underscores.",11,muted,false);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=dp(-3);hp.bottomMargin=dp(13);form.addView(usernameHint,hp);
        firstName=field(form,"First Name","Enter your first name","text");lastName=field(form,"Last Name","Enter your last name","text");phone=field(form,"Phone Number (optional)","Add your phone number","phone");
        TextView note=label("Your username may only be changed once every 30 days.",11,muted,false);note.setPadding(0,dp(14),0,dp(2));form.addView(note);
        save=new Button(this);save.setText("Save Account Settings");save.setAllCaps(false);save.setTextColor(Color.WHITE);save.setTextSize(14);save.setBackground(shape(PhiskTheme.VIOLET,0,7));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(48));sp.topMargin=dp(16);content.addView(save,sp);save.setOnClickListener(v->save());
        progress=new ProgressBar(this);LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(dp(32),dp(32));pp.gravity=Gravity.CENTER_HORIZONTAL;pp.topMargin=dp(14);content.addView(progress,pp);setContentView(root);
    }
    private EditText field(LinearLayout parent,String title,String hint,String type){TextView t=label(title,13,ink,true);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.topMargin=dp(10);tp.bottomMargin=dp(7);parent.addView(t,tp);EditText e=new EditText(this);e.setTextSize(14);e.setSingleLine(true);e.setTextColor(ink);e.setHintTextColor(muted);e.setHint(hint);e.setPadding(dp(12),0,dp(12),0);e.setBackground(shape(dark()?Color.rgb(38,39,46):Color.WHITE,border,7));e.setSelectAllOnFocus(false);if("phone".equals(type))e.setInputType(android.text.InputType.TYPE_CLASS_PHONE);else e.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,dp(48));ep.bottomMargin=dp(3);parent.addView(e,ep);return e;}
    private void setBusy(boolean busy){loading=busy;save.setEnabled(!busy);save.setAlpha(busy?.6f:1f);progress.setVisibility(busy?View.VISIBLE:View.GONE);}
    private JSONObject request(String method,JSONObject body)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(HOME+"wp-json/phisk/v1/account-settings").openConnection();try{c.setRequestMethod(method);c.setConnectTimeout(15000);c.setReadTimeout(25000);c.setRequestProperty("Accept","application/json");c.setRequestProperty("Authorization","Bearer "+token());if(body!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=UTF-8");try(OutputStream o=c.getOutputStream()){o.write(body.toString().getBytes(StandardCharsets.UTF_8));}}int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();ByteArrayOutputStream out=new ByteArrayOutputStream();if(in!=null){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);in.close();}String raw=out.toString("UTF-8");if(code<200||code>=300){String msg=raw;try{msg=new JSONObject(raw).optString("message",raw);}catch(Exception ignored){}throw new Exception(msg);}return new JSONObject(raw);}finally{c.disconnect();}}
    private void load(){if(token().isEmpty()){progress.setVisibility(View.GONE);Toast.makeText(this,"Please sign in to manage your account.",Toast.LENGTH_LONG).show();finish();return;}setBusy(true);io.execute(()->{try{JSONObject result=request("GET",null);JSONObject a=result.optJSONObject("account");runOnUiThread(()->{if(a!=null){username.setText(a.optString("username",""));firstName.setText(a.optString("first_name",""));lastName.setText(a.optString("last_name",""));phone.setText(a.optString("phone_number",""));boolean can=a.optBoolean("username_can_change",true);username.setEnabled(can);if(!can){long at=a.optLong("username_change_available_at",0)*1000L;String date=new SimpleDateFormat("d MMM yyyy",Locale.getDefault()).format(new Date(at));usernameHint.setText("You can next change your username on "+date+".");}}setBusy(false);});}catch(Exception e){runOnUiThread(()->{setBusy(false);new android.app.AlertDialog.Builder(this).setTitle("Couldn't load account settings").setMessage(e.getMessage()).setPositiveButton("Retry",(d,w)->load()).setNegativeButton("Close",(d,w)->finish()).show();});}});}
    private void save(){String u=username.getText().toString().trim().toLowerCase(Locale.ROOT);if(!u.matches("[a-z0-9_]{3,24}")){username.setError("Use 3–24 letters, numbers or underscores.");return;}JSONObject body=new JSONObject();try{body.put("username",u);body.put("first_name",firstName.getText().toString().trim());body.put("last_name",lastName.getText().toString().trim());body.put("phone_number",phone.getText().toString().trim());}catch(Exception ignored){}setBusy(true);io.execute(()->{try{JSONObject result=request("POST",body);runOnUiThread(()->{setBusy(false);JSONObject a=result.optJSONObject("account");if(a!=null){username.setText(a.optString("username",u));firstName.setText(a.optString("first_name",""));lastName.setText(a.optString("last_name",""));phone.setText(a.optString("phone_number",""));}Toast.makeText(this,result.optString("message","Account settings saved successfully."),Toast.LENGTH_LONG).show();});}catch(Exception e){runOnUiThread(()->{setBusy(false);new android.app.AlertDialog.Builder(this).setTitle("Couldn't save changes").setMessage(e.getMessage()).setPositiveButton("OK",null).show();});}});}
    @Override protected void onDestroy(){io.shutdownNow();super.onDestroy();}
    @Override protected void onResume(){super.onResume();PhiskTheme.apply(this);}
}
