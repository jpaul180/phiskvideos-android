# PhiskVideos Android v1.17.0 — Native Account Settings

This release adds a native Android version of the website's **Account Settings → Personal Information** form. It is deliberately separate from Creator Channel Management.

## Native Edit Profile
- Username (3–24 lowercase letters, numbers or underscores; website's 30-day username-change cooldown and availability rules are enforced by the server).
- First Name.
- Last Name.
- Phone Number (optional).
- Loads and saves the signed-in user's own WordPress account through the authenticated Phisk Video Manager REST API.
- Uses existing Phisk bearer-session authentication; no credentials or tokens are embedded in the app.
- Supports the existing Phisk Light/Dark theme and Phisk Violet primary action.

This screen does **not** edit profile photos, cover images, channel names, channel descriptions, or creator-channel settings. Those remain in Creator Channel Management.

## Backend dependency
Install the companion **Phisk Video Manager v1.20.4** plugin package. It adds `GET` and `POST /wp-json/phisk/v1/account-settings`, protected by the existing native app bearer-session permission callback. The endpoint follows the website's existing account-settings field names, username rules, username history/redirect handling, and 30-day cooldown.

## Build
- Android version: `1.17.0`
- Android version code: `39`
- Minimum SDK: 24
- Target/compile SDK: 35
- Java: 17
- GitHub Actions workflow builds signed APK and AAB outputs using the existing repository signing secrets.
