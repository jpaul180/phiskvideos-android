package co.phisk.videos;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Native channel profile with owner-aware controls and paginated Videos/Stories tabs. */
public class NativeCreatorChannelActivity extends Activity {
    private static final String HOME = "https://videos.phisk.co/";
    private static final int VIOLET = Color.rgb(124, 58, 237);
    private static final int INK = Color.rgb(25, 29, 38);
    private static final int MUTED = Color.rgb(112, 117, 128);
    private static final int BG = Color.rgb(247, 248, 250);
    private static final int DIVIDER = Color.rgb(235, 236, 240);

    private final ExecutorService io = Executors.newFixedThreadPool(2);
    private int creatorId, tab = 0, videoPage = 1, storyPage = 1;
    private boolean loading = false, videoMore = true, storyMore = true;
    private JSONObject creator;
    private boolean isSubscribed = false;
    private LinearLayout root, body, list, tabs;
    private ScrollView scroll;
    private TextView subscribe;

    @Override
    public void onCreate(Bundle state) {
        PhiskTheme.configureActivityTheme(this);
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        creatorId = getIntent().getIntExtra("creator_id", 0);
        if (creatorId <= 0) {
            try { creatorId = Integer.parseInt(getIntent().getStringExtra("creator_id")); }
            catch (Exception ignored) {}
        }
        build();
        loadProfile();
    }

    private int dp(float n) {
        return (int) (n * getResources().getDisplayMetrics().density + .5f);
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private GradientDrawable borderedShape(int color, int radius, int strokeColor) {
        GradientDrawable d = shape(color, radius);
        d.setStroke(dp(1), strokeColor);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private String token() {
        return getSharedPreferences("phisk_native_auth", MODE_PRIVATE).getString("access_token", "");
    }

    private JSONObject request(String path, String method, JSONObject body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(HOME + "wp-json/phisk/v1/" + path).openConnection();
        try {
            c.setRequestMethod(method);
            c.setConnectTimeout(15000);
            c.setReadTimeout(20000);
            c.setRequestProperty("Accept", "application/json");
            c.setRequestProperty("Authorization", "Bearer " + token());
            if (body != null) {
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                try (OutputStream out = c.getOutputStream()) {
                    out.write(body.toString().getBytes(StandardCharsets.UTF_8));
                }
            }
            int code = c.getResponseCode();
            InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            if (in != null) {
                byte[] b = new byte[4096];
                int n;
                while ((n = in.read(b)) != -1) out.write(b, 0, n);
                in.close();
            }
            String raw = out.toString("UTF-8");
            if (code < 200 || code >= 300) throw new Exception(raw);
            return new JSONObject(raw);
        } finally {
            c.disconnect();
        }
    }

    private void build() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(14), 0, dp(14), 0);
        bar.setBackgroundColor(Color.WHITE);
        TextView back = text("‹", 34, INK, false);
        back.setGravity(Gravity.CENTER);
        bar.addView(back, new LinearLayout.LayoutParams(dp(42), dp(50)));
        back.setOnClickListener(v -> finish());
        TextView title = text("Creator Channel", 17, INK, true);
        bar.addView(title);
        root.addView(bar);

        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(16), dp(16), dp(16), dp(26));
        scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private void loadProfile() {
        if (creatorId <= 0) {
            error("This channel link is invalid.");
            return;
        }
        io.execute(() -> {
            try {
                JSONObject result = request("creators/" + creatorId, "GET", null);
                runOnUiThread(() -> renderProfile(result));
            } catch (Exception e) {
                runOnUiThread(() -> error("Couldn't load this channel. Please check your connection and try again."));
            }
        });
    }

    private void renderProfile(JSONObject p) {
        creator = p;
        isSubscribed = p.optBoolean("subscribed", false);
        body.removeAllViews();

        FrameLayout cover = new FrameLayout(this);
        cover.setBackground(shape(Color.rgb(230, 222, 247), 12));
        cover.setClipToOutline(true);
        body.addView(cover, new LinearLayout.LayoutParams(-1, dp(154)));
        ImageView coverImage = new ImageView(this);
        coverImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        cover.addView(coverImage, new FrameLayout.LayoutParams(-1, -1));
        loadImage(coverImage, p.optString("cover_url", ""));

        LinearLayout identity = new LinearLayout(this);
        identity.setGravity(Gravity.CENTER_VERTICAL);
        identity.setPadding(dp(2), dp(16), dp(2), dp(2));
        ImageView avatar = new ImageView(this);
        avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        avatar.setImageResource(R.drawable.ic_phisk_default_avatar);
        avatar.setBackground(borderedShape(Color.WHITE, 50, Color.WHITE));
        avatar.setClipToOutline(true);
        identity.addView(avatar, new LinearLayout.LayoutParams(dp(78), dp(78)));
        if (p.optBoolean("has_custom_avatar", false)) loadImage(avatar, p.optString("avatar_url", ""));

        LinearLayout names = new LinearLayout(this);
        names.setOrientation(LinearLayout.VERTICAL);
        names.setPadding(dp(14), 0, 0, 0);
        TextView channelName = text(p.optString("name", "Creator"), 20, INK, true);
        names.addView(channelName);
        TextView username = text("@" + p.optString("username", "creator"), 14, MUTED, false);
        LinearLayout.LayoutParams userLp = new LinearLayout.LayoutParams(-2, -2);
        userLp.topMargin = dp(3);
        names.addView(username, userLp);
        TextView subscribers = text(formatCount(p.optInt("subscriber_count")) + " subscribers", 13, MUTED, false);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-2, -2);
        subLp.topMargin = dp(7);
        names.addView(subscribers, subLp);
        identity.addView(names, new LinearLayout.LayoutParams(0, -2, 1));
        body.addView(identity);

        String description = p.optString("description", "").trim();
        if (!description.isEmpty()) {
            TextView bio = text(description, 14, INK, false);
            bio.setLineSpacing(dp(2), 1.0f);
            bio.setPadding(dp(2), dp(14), dp(2), dp(10));
            body.addView(bio);
        }

        addSocialSection(p.optJSONObject("social_links"));

        LinearLayout moreRow = new LinearLayout(this);
        moreRow.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        TextView more = text("Show more", 13, VIOLET, true);
        moreRow.addView(more);
        LinearLayout extra = new LinearLayout(this);
        extra.setOrientation(LinearLayout.VERTICAL);
        extra.setPadding(dp(2), dp(8), dp(2), dp(2));
        JSONArray history = p.optJSONArray("name_history");
        if (history != null) {
            for (int hi = 0; hi < history.length(); hi++) {
                JSONObject h = history.optJSONObject(hi);
                if (h != null) {
                    TextView historyRow = text(h.optString("old_name") + " → " + h.optString("new_name"), 12, MUTED, false);
                    historyRow.setPadding(0, dp(4), 0, dp(4));
                    extra.addView(historyRow);
                }
            }
        }
        int year = p.optInt("created_year", 0);
        if (year > 0) {
            TextView established = text("Channel established in " + year, 12, MUTED, false);
            established.setPadding(0, dp(4), 0, dp(4));
            extra.addView(established);
        }
        extra.setVisibility(View.GONE);
        if (extra.getChildCount() > 0) {
            body.addView(moreRow);
            body.addView(extra);
            more.setOnClickListener(v -> {
                boolean show = extra.getVisibility() != View.VISIBLE;
                extra.setVisibility(show ? View.VISIBLE : View.GONE);
                more.setText(show ? "Show less" : "Show more");
            });
        }

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        actions.setPadding(0, dp(14), 0, dp(16));
        if (p.optBoolean("is_owner")) {
            addAction(actions, "Edit Channel", () -> {
                Intent edit = new Intent(this, NativeCreatorChannelEditorActivity.class);
                startActivityForResult(edit, 70);
            });
            addAction(actions, "Creator Studio", () -> {
                Intent studio = new Intent(this, NativeCreatorStudioActivity.class);
                startActivity(studio);
            });
        } else {
            subscribe = text(p.optBoolean("subscribed") ? "Subscribed" : "Subscribe", 14, Color.WHITE, true);
            subscribe.setGravity(Gravity.CENTER);
            subscribe.setPadding(dp(22), dp(12), dp(22), dp(12));
            subscribe.setBackground(shape(VIOLET, 8));
            actions.addView(subscribe);
            subscribe.setOnClickListener(v -> toggleSubscribe());
        }
        body.addView(actions);

        tabs = new LinearLayout(this);
        tabs.setPadding(dp(3), dp(3), dp(3), dp(3));
        tabs.setBackground(borderedShape(Color.WHITE, 10, DIVIDER));
        body.addView(tabs);
        addTab("Videos", 0);
        addTab("Stories", 1);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(0, dp(14), 0, 0);
        body.addView(list);
        selectTab(0);
    }

    private void addSocialSection(JSONObject social) {
        if (social == null) return;
        String[] keys = {"linkedin", "x", "youtube", "facebook"};
        String[] labels = {"LinkedIn", "X", "YouTube", "Facebook"};
        int[] icons = {R.drawable.brand_linkedin, R.drawable.brand_x, R.drawable.brand_youtube, R.drawable.brand_facebook};

        LinearLayout section = new LinearLayout(this);
        section.setOrientation(LinearLayout.VERTICAL);
        boolean hasLinks = false;
        for (int i = 0; i < keys.length; i++) {
            String link = social.optString(keys[i], "").trim();
            if (link.isEmpty() || "null".equalsIgnoreCase(link)) continue;
            hasLinks = true;
            if (section.getChildCount() > 0) {
                View divider = new View(this);
                divider.setBackgroundColor(DIVIDER);
                LinearLayout.LayoutParams dividerLp = new LinearLayout.LayoutParams(-1, dp(1));
                dividerLp.topMargin = dp(10);
                dividerLp.bottomMargin = dp(10);
                section.addView(divider, dividerLp);
            }

            LinearLayout platformRow = new LinearLayout(this);
            platformRow.setGravity(Gravity.CENTER_VERTICAL);
            ImageView icon = new ImageView(this);
            icon.setImageResource(icons[i]);
            icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            platformRow.addView(icon, new LinearLayout.LayoutParams(dp(20), dp(20)));
            View iconDivider = new View(this);
            iconDivider.setBackgroundColor(DIVIDER);
            LinearLayout.LayoutParams iconDividerLp = new LinearLayout.LayoutParams(dp(1), dp(16));
            iconDividerLp.leftMargin = dp(9);
            iconDividerLp.rightMargin = dp(9);
            platformRow.addView(iconDivider, iconDividerLp);
            TextView platform = text(labels[i], 13, INK, true);
            platformRow.addView(platform);
            section.addView(platformRow);

            TextView url = text(displaySocialUrl(link), 12, VIOLET, false);
            url.setPadding(dp(30), dp(4), 0, 0);
            url.setClickable(true);
            url.setOnClickListener(v -> openSocialLink(link));
            section.addView(url);
        }
        if (!hasLinks) return;

        TextView heading = text("We are on", 14, INK, true);
        heading.setPadding(dp(2), dp(8), 0, dp(10));
        body.addView(heading);
        section.setPadding(dp(2), 0, dp(2), dp(4));
        body.addView(section);
    }

    private String displaySocialUrl(String value) {
        String url = value.trim();
        return url.replaceFirst("(?i)^https?://", "").replaceFirst("/$", "");
    }

    private void openSocialLink(String value) {
        try {
            String url = value.trim();
            if (!url.matches("(?i)^https?://.*")) url = "https://" + url;
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Couldn't open this social link.", Toast.LENGTH_SHORT).show();
        }
    }

    private void addAction(LinearLayout row, String label, Runnable action) {
        TextView b = text(label, 13, Color.WHITE, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(16), dp(11), dp(16), dp(11));
        b.setBackground(shape(VIOLET, 8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = dp(9);
        row.addView(b, lp);
        b.setOnClickListener(v -> action.run());
    }

    private void addTab(String label, int index) {
        TextView t = text(label, 14, MUTED, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(18), dp(12), dp(18), dp(12));
        tabs.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
        t.setOnClickListener(v -> selectTab(index));
    }

    private void selectTab(int index) {
        tab = index;
        for (int i = 0; i < tabs.getChildCount(); i++) {
            TextView t = (TextView) tabs.getChildAt(i);
            boolean active = i == index;
            t.setTextColor(active ? VIOLET : MUTED);
            t.setBackground(active ? shape(Color.rgb(245, 240, 255), 8) : shape(Color.WHITE, 8));
        }
        list.removeAllViews();
        loadItems(index == 0 ? videoPage : storyPage);
    }

    private void loadItems(int page) {
        if (loading) return;
        loading = true;
        int currentTab = tab;
        TextView loadingText = text("Loading…", 13, MUTED, false);
        loadingText.setGravity(Gravity.CENTER);
        loadingText.setPadding(0, dp(24), 0, dp(24));
        list.addView(loadingText);
        io.execute(() -> {
            try {
                JSONObject result = request("creators/" + creatorId + (currentTab == 0 ? "/videos" : "/stories")
                        + "?page=" + page + "&per_page=10", "GET", null);
                JSONArray items = result.optJSONArray("items");
                runOnUiThread(() -> {
                    loading = false;
                    list.removeAllViews();
                    if (items == null || items.length() == 0) {
                        TextView empty = text(currentTab == 0 ? "No published videos yet." : "No published Stories yet.", 14, MUTED, false);
                        empty.setGravity(Gravity.CENTER);
                        empty.setPadding(0, dp(30), 0, dp(30));
                        list.addView(empty);
                    } else {
                        for (int i = 0; i < items.length(); i++) {
                            JSONObject item = items.optJSONObject(i);
                            if (item != null) addContentCard(item, currentTab == 0);
                        }
                    }
                    boolean more = result.optBoolean("has_more", false);
                    if (more) {
                        TextView next = text("Load more", 14, VIOLET, true);
                        next.setGravity(Gravity.CENTER);
                        next.setPadding(0, dp(18), 0, dp(18));
                        list.addView(next);
                        next.setOnClickListener(v -> {
                            if (currentTab == 0) videoPage++; else storyPage++;
                            loadItems(currentTab == 0 ? videoPage : storyPage);
                        });
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    loading = false;
                    list.removeAllViews();
                    errorInline("Couldn't load content. Tap to retry.", () -> loadItems(page));
                });
            }
        });
    }

    private void addContentCard(JSONObject item, boolean video) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(11), dp(11), dp(11), dp(12));
        card.setBackground(shape(Color.WHITE, 13));
        card.setElevation(dp(2));
        card.setClipToOutline(true);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.bottomMargin = dp(14);
        list.addView(card, cp);

        FrameLayout thumbnailFrame = new FrameLayout(this);
        thumbnailFrame.setBackground(shape(Color.rgb(235, 235, 239), 9));
        thumbnailFrame.setClipToOutline(true);
        card.addView(thumbnailFrame, new LinearLayout.LayoutParams(-1, dp(190)));
        ImageView thumb = new ImageView(this);
        thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
        thumbnailFrame.addView(thumb, new FrameLayout.LayoutParams(-1, -1));
        loadImage(thumb, item.optString("thumbnail_url", ""));

        TextView title = text(item.optString("title", "Untitled"), 16, INK, true);
        title.setMaxLines(2);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        title.setPadding(dp(1), dp(11), dp(1), dp(4));
        card.addView(title);
        String excerpt = item.optString("excerpt", "");
        if (!excerpt.isEmpty()) {
            TextView description = text(excerpt, 13, MUTED, false);
            description.setMaxLines(3);
            description.setEllipsize(android.text.TextUtils.TruncateAt.END);
            description.setPadding(dp(1), 0, dp(1), 0);
            card.addView(description);
        }

        View.OnClickListener open = v -> {
            if (video) {
                Intent i = new Intent(this, NativePlayerActivity.class);
                i.putExtra("video_id", item.optInt("id"));
                startActivity(i);
            } else {
                openWeb(item.optString("permalink", HOME));
            }
        };
        card.setOnClickListener(open);
        thumbnailFrame.setOnClickListener(open);
    }

    private void toggleSubscribe() {
        if (creator == null) return;
        subscribe.setEnabled(false);
        io.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("action", isSubscribed ? "unsubscribe" : "subscribe");
                JSONObject result = request("creators/" + creatorId + "/subscribe", "POST", body);
                runOnUiThread(() -> {
                    isSubscribed = result.optBoolean("subscribed");
                    subscribe.setText(isSubscribed ? "Subscribed" : "Subscribe");
                    subscribe.setEnabled(true);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    subscribe.setEnabled(true);
                    Toast.makeText(this, "Couldn't update subscription. Please try again.", Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    private void loadImage(ImageView target, String url) {
        if (url == null || !url.startsWith("https://")) return;
        io.execute(() -> {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(url).openConnection();
                c.setConnectTimeout(8000);
                c.setReadTimeout(10000);
                Bitmap b = PhiskImageCache.getBitmap(this, url);
                if (b != null) runOnUiThread(() -> {
                    if (!isFinishing()) target.setImageBitmap(b);
                });
            } catch (Exception ignored) {
            } finally {
                if (c != null) c.disconnect();
            }
        });
    }

    private String formatCount(int n) {
        if (n >= 1000000) return String.format(java.util.Locale.US, "%.1fM", n / 1000000f);
        if (n >= 1000) return String.format(java.util.Locale.US, "%.1fK", n / 1000f);
        return String.valueOf(n);
    }

    private void error(String message) {
        body.removeAllViews();
        TextView t = text(message, 14, MUTED, false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(22), dp(60), dp(22), dp(20));
        body.addView(t);
    }

    private void errorInline(String message, Runnable retry) {
        TextView t = text(message, 14, VIOLET, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(25), 0, dp(25));
        list.addView(t);
        t.setOnClickListener(v -> retry.run());
    }

    private void openWeb(String url) {
        Intent i = new Intent(this, MainActivity.class);
        i.putExtra(MainActivity.EXTRA_NOTIFICATION_URL, url);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(i);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 70 && resultCode == RESULT_OK) loadProfile();
    }

    @Override
    protected void onDestroy() {
        io.shutdownNow();
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        PhiskTheme.apply(this);
    }
}
