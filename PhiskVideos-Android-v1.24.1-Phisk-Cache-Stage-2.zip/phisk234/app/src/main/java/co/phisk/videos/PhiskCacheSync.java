package co.phisk.videos;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Fetches and remembers the public Phisk Cache manifest without blocking app startup. */
public final class PhiskCacheSync {
    private static final String MANIFEST_URL = "https://videos.phisk.co/wp-json/phisk-cache/v1/manifest";
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
    private static final String PREFS = "phisk_cache_state";

    private PhiskCacheSync() {}

    public static void sync(Context context) {
        Context app = context.getApplicationContext();
        EXECUTOR.execute(() -> {
            HttpURLConnection connection = null;
            try {
                SharedPreferences prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
                connection = (HttpURLConnection) new URL(MANIFEST_URL).openConnection();
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(7000);
                connection.setRequestProperty("Accept", "application/json");
                String etag = prefs.getString("manifest_etag", "");
                if (!etag.isEmpty()) connection.setRequestProperty("If-None-Match", etag);
                int code = connection.getResponseCode();
                if (code == HttpURLConnection.HTTP_NOT_MODIFIED) return;
                if (code < 200 || code >= 300) return;
                byte[] bytes;
                try (InputStream input = connection.getInputStream();
                     ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                    byte[] buffer = new byte[4096];
                    int count;
                    while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
                    bytes = output.toByteArray();
                }
                JSONObject manifest = new JSONObject(new String(bytes, "UTF-8"));
                int version = manifest.optInt("manifest_version", 0);
                String previous = prefs.getString("manifest_json", "");
                int previousVersion = prefs.getInt("manifest_version", -1);
                SharedPreferences.Editor editor = prefs.edit()
                        .putInt("manifest_version", version)
                        .putString("manifest_json", manifest.toString());
                String responseEtag = connection.getHeaderField("ETag");
                if (responseEtag != null) editor.putString("manifest_etag", responseEtag);
                editor.apply();

                // Version changes are recorded for diagnostics and future targeted invalidation.
                // Individual image files are URL-keyed and are not indiscriminately purged.
                if (version != previousVersion) {
                    app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                            .edit().putLong("manifest_last_changed_at", System.currentTimeMillis()).apply();
                }
            } catch (Exception ignored) {
                // Offline/older plugin versions must not prevent the app from starting.
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }
}
