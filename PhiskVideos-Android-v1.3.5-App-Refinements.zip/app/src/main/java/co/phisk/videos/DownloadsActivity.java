package co.phisk.videos;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.VideoView;

import org.json.JSONObject;

import java.io.File;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DownloadsActivity extends Activity {
    private static final String PREFS = "phisk_download_metadata";
    private static final int VIOLET = Color.rgb(124, 58, 237);
    private LinearLayout list;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable refresher = new Runnable() {
        @Override public void run() {
            if (!playerVisible) refreshList();
            handler.postDelayed(this, 1200);
        }
    };
    private final Map<String, RowHolder> rows = new LinkedHashMap<>();
    private final Map<String, Bitmap> thumbnailCache = new HashMap<>();
    private final List<String> displayedOrder = new ArrayList<>();
    private boolean listBuilt = false;
    private final Set<String> loadingThumbnails = new HashSet<>();
    private final ExecutorService imageExecutor = Executors.newFixedThreadPool(2);
    private boolean playerVisible = false;
    private File activeFile;
    private int savedPosition = 0;
    private boolean resumeAfterRebuild = true;
    private VideoView activeVideo;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.WHITE);
        showDownloads();
    }

    @Override protected void onResume() {
        super.onResume();
        handler.removeCallbacks(refresher);
        handler.post(refresher);
    }

    @Override protected void onPause() {
        handler.removeCallbacks(refresher);
        super.onPause();
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (playerVisible && activeFile != null) {
            if (activeVideo != null) {
                try { savedPosition = activeVideo.getCurrentPosition(); resumeAfterRebuild = activeVideo.isPlaying(); }
                catch (Exception ignored) { }
            }
            buildPlayer();
        } else {
            showSystemBars();
            refreshList();
        }
    }

    private void showDownloads() {
        playerVisible = false;
        activeVideo = null;
        showSystemBars();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(12), dp(18), dp(12));
        root.setBackgroundColor(Color.WHITE);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Downloads");
        title.setTextColor(Color.BLACK);
        title.setTextSize(23);
        title.setTypeface(null, 1);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        TextView close = textAction("Close", VIOLET);
        close.setOnClickListener(v -> finish());
        header.addView(close);
        root.addView(header);

        TextView subtitle = new TextView(this);
        subtitle.setText("Videos saved on this device");
        subtitle.setTextColor(Color.DKGRAY);
        subtitle.setTextSize(13);
        subtitle.setPadding(0, dp(4), 0, dp(16));
        root.addView(subtitle);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        displayedOrder.clear();
        listBuilt = false;
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        refreshList();
    }

    private void refreshList() {
        if (list == null || playerVisible) return;
        File dir = new File(getFilesDir(), "downloads");
        File[] files = dir.listFiles();
        if (files == null) files = new File[0];
        Arrays.sort(files, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));

        List<String> visibleKeys = new ArrayList<>();
        List<RowHolder> orderedRows = new ArrayList<>();
        for (File file : files) {
            if (!file.isFile()) continue;
            boolean downloading = file.getName().endsWith(".part");
            String rowKey = downloading ? file.getName().substring(0, file.getName().length() - 5) : file.getName();
            JSONObject meta = readMeta(rowKey);
            RowHolder holder = rows.get(rowKey);
            if (holder == null) {
                holder = createRow(rowKey);
                rows.put(rowKey, holder);
            }
            holder.file = file;
            holder.meta = meta;
            updateRow(holder, downloading);
            visibleKeys.add(rowKey);
            orderedRows.add(holder);
        }

        Set<String> visible = new HashSet<>(visibleKeys);
        rows.keySet().removeIf(key -> !visible.contains(key));
        boolean orderChanged = !listBuilt || !visibleKeys.equals(displayedOrder);
        if (orderChanged) {
            list.removeAllViews();
            displayedOrder.clear();
            displayedOrder.addAll(visibleKeys);
            listBuilt = true;
            if (orderedRows.isEmpty()) {
                TextView empty = new TextView(this);
                empty.setText("No downloaded videos yet.");
                empty.setTextColor(Color.GRAY);
                empty.setGravity(Gravity.CENTER);
                list.addView(empty, new LinearLayout.LayoutParams(-1, dp(180)));
                return;
            }
            for (RowHolder holder : orderedRows) {
                list.addView(holder.row);
                View divider = new View(this);
                divider.setBackgroundColor(0xFFEAEAEA);
                list.addView(divider, new LinearLayout.LayoutParams(-1, dp(1)));
            }
        }
    }

    private RowHolder createRow(String key) {
        RowHolder holder = new RowHolder();
        holder.key = key;
        holder.row = new LinearLayout(this);
        holder.row.setOrientation(LinearLayout.HORIZONTAL);
        holder.row.setGravity(Gravity.CENTER_VERTICAL);
        holder.row.setPadding(0, dp(10), 0, dp(10));

        holder.thumb = new ImageView(this);
        holder.thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
        holder.thumb.setBackgroundColor(0xFFEDE9FE);
        holder.row.addView(holder.thumb, new LinearLayout.LayoutParams(dp(104), dp(66)));

        LinearLayout details = new LinearLayout(this);
        details.setOrientation(LinearLayout.VERTICAL);
        details.setPadding(dp(11), 0, dp(4), 0);
        holder.row.addView(details, new LinearLayout.LayoutParams(0, -2, 1));

        holder.name = new TextView(this);
        holder.name.setTextColor(Color.BLACK);
        holder.name.setTextSize(14);
        holder.name.setTypeface(null, 1);
        holder.name.setMaxLines(2);
        details.addView(holder.name);

        holder.by = new TextView(this);
        holder.by.setTextColor(Color.GRAY);
        holder.by.setTextSize(12);
        holder.by.setPadding(0, dp(3), 0, dp(4));
        details.addView(holder.by);

        holder.meter = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        holder.meter.setMax(100);
        holder.meter.setProgressTintList(android.content.res.ColorStateList.valueOf(VIOLET));
        details.addView(holder.meter, new LinearLayout.LayoutParams(-1, dp(4)));

        holder.progressLabel = new TextView(this);
        holder.progressLabel.setTextColor(Color.GRAY);
        holder.progressLabel.setTextSize(11);
        holder.progressLabel.setPadding(0, dp(3), 0, 0);
        details.addView(holder.progressLabel);

        holder.more = new TextView(this);
        holder.more.setText("⋮");
        holder.more.setTextSize(25);
        holder.more.setTextColor(Color.DKGRAY);
        holder.more.setGravity(Gravity.CENTER);
        holder.more.setPadding(dp(10), dp(8), 0, dp(8));
        holder.row.addView(holder.more);
        holder.more.setOnClickListener(v -> showActions(holder.more, holder.file));
        holder.row.setOnClickListener(v -> {
            if (holder.file != null && !holder.file.getName().endsWith(".part")) play(holder.file);
        });
        holder.thumb.setOnClickListener(v -> {
            if (holder.file != null && !holder.file.getName().endsWith(".part")) play(holder.file);
        });
        holder.name.setOnClickListener(v -> {
            if (holder.file != null && !holder.file.getName().endsWith(".part")) play(holder.file);
        });
        return holder;
    }

    private void updateRow(RowHolder holder, boolean downloading) {
        JSONObject meta = holder.meta;
        String title = meta.optString("title", holder.file.getName()
                .replaceFirst("^[0-9]+_", "")
                .replaceFirst("(?i)\\.(mp4|m4v|mov|webm|ogv)(\\.part)?$", ""));
        String channel = meta.optString("channel", "");
        int pct = meta.optInt("progress", downloading ? 0 : 100);
        holder.name.setText(title);
        holder.by.setText(channel.isEmpty() ? (downloading ? "Downloading…" : formatSize(holder.file.length())) : "By " + channel);
        holder.meter.setProgress(pct);
        holder.meter.setVisibility(downloading ? View.VISIBLE : View.GONE);
        holder.progressLabel.setText(downloading ? (pct > 0 ? pct + "% downloaded" : "Downloading…") : "Saved offline • " + formatSize(holder.file.length()));
        holder.progressLabel.setTextColor(Color.GRAY);
        holder.more.setVisibility(downloading ? View.INVISIBLE : View.VISIBLE);

        String thumbnailUrl = meta.optString("thumbnail", "");
        if (thumbnailUrl.equals(holder.thumbnailUrl)) return;
        holder.thumbnailUrl = thumbnailUrl;
        holder.thumb.setImageDrawable(null);
        loadThumbnail(holder.thumb, thumbnailUrl);
    }

    private JSONObject readMeta(String key) {
        try { return new JSONObject(getSharedPreferences(PREFS, MODE_PRIVATE).getString(key, "{}")); }
        catch (Exception e) { return new JSONObject(); }
    }

    private void loadThumbnail(ImageView view, String imageUrl) {
        if (imageUrl == null || !imageUrl.startsWith("https://")) return;
        view.setTag(imageUrl);
        Bitmap cached = thumbnailCache.get(imageUrl);
        if (cached != null) { view.setImageBitmap(cached); return; }
        if (!loadingThumbnails.add(imageUrl)) return;
        imageExecutor.execute(() -> {
            Bitmap bitmap = null;
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(imageUrl).openConnection();
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(15000);
                connection.setInstanceFollowRedirects(true);
                connection.setRequestProperty("User-Agent", "PhiskVideosApp/1.3.5");
                bitmap = BitmapFactory.decodeStream(connection.getInputStream());
            } catch (Exception ignored) {
            } finally {
                if (connection != null) connection.disconnect();
            }
            final Bitmap result = bitmap;
            runOnUiThread(() -> {
                loadingThumbnails.remove(imageUrl);
                if (result != null) {
                    thumbnailCache.put(imageUrl, result);
                    if (imageUrl.equals(view.getTag())) view.setImageBitmap(result);
                }
            });
        });
    }

    private void showActions(View anchor, File file) {
        if (file == null) return;
        PopupMenu menu = new PopupMenu(this, anchor);
        menu.getMenu().add("Play");
        menu.getMenu().add("Delete");
        menu.setOnMenuItemClickListener(item -> {
            if ("Play".contentEquals(item.getTitle())) play(file);
            else if ("Delete".contentEquals(item.getTitle())) {
                file.delete();
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(file.getName()).apply();
                refreshList();
            }
            return true;
        });
        menu.show();
    }

    private void play(File file) {
        if (file == null || !file.exists()) return;
        activeFile = file;
        savedPosition = 0;
        resumeAfterRebuild = true;
        playerVisible = true;
        buildPlayer();
    }

    private void buildPlayer() {
        if (activeFile == null) return;
        boolean landscape = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        if (landscape) enterImmersiveMode(); else showSystemBars();

        JSONObject meta = readMeta(activeFile.getName());
        String titleText = meta.optString("title", activeFile.getName().replaceFirst("^[0-9]+_", "")
                .replaceFirst("(?i)\\.(mp4|m4v|mov|webm|ogv)$", ""));
        String channel = meta.optString("channel", "");

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        if (!landscape) {
            LinearLayout top = new LinearLayout(this);
            top.setOrientation(LinearLayout.HORIZONTAL);
            top.setGravity(Gravity.CENTER_VERTICAL);
            top.setPadding(dp(16), dp(8), dp(16), dp(8));
            TextView close = textAction("‹  Close", VIOLET);
            close.setOnClickListener(v -> returnToDownloads());
            top.addView(close, new LinearLayout.LayoutParams(0, dp(44), 1));
            TextView fullscreen = textAction("⛶", VIOLET);
            fullscreen.setTextSize(24);
            fullscreen.setContentDescription("Open fullscreen player");
            fullscreen.setOnClickListener(v -> setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE));
            top.addView(fullscreen);
            root.addView(top);
        }

        FrameLayout playerFrame = new FrameLayout(this);
        playerFrame.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams frameParams = landscape
                ? new LinearLayout.LayoutParams(-1, 0, 1f)
                : new LinearLayout.LayoutParams(-1, dp(230));
        root.addView(playerFrame, frameParams);

        VideoView video = new VideoView(this);
        video.setBackgroundColor(Color.WHITE);
        playerFrame.addView(video, new FrameLayout.LayoutParams(-1, -1));
        activeVideo = video;

        if (landscape) {
            TextView exitFullscreen = textAction("⛶", Color.WHITE);
            exitFullscreen.setTextSize(22);
            exitFullscreen.setGravity(Gravity.CENTER);
            exitFullscreen.setBackground(roundBackground(0x88000000, dp(8)));
            FrameLayout.LayoutParams exitParams = new FrameLayout.LayoutParams(dp(48), dp(48), Gravity.TOP | Gravity.END);
            exitParams.setMargins(0, dp(12), dp(12), 0);
            playerFrame.addView(exitFullscreen, exitParams);
            exitFullscreen.setOnClickListener(v -> setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT));
        }

        MediaController controls = new MediaController(this);
        controls.setAnchorView(video);
        final int seekTo = savedPosition;
        final boolean shouldResume = resumeAfterRebuild;
        video.setOnPreparedListener(mp -> {
            if (seekTo > 0) video.seekTo(seekTo);
            if (shouldResume) video.start();
        });
        video.setMediaController(controls);
        video.setVideoURI(Uri.fromFile(activeFile));

        if (!landscape) {
            LinearLayout details = new LinearLayout(this);
            details.setOrientation(LinearLayout.VERTICAL);
            details.setPadding(dp(18), dp(14), dp(18), dp(18));
            root.addView(details, new LinearLayout.LayoutParams(-1, -2));

            TextView title = new TextView(this);
            title.setText(titleText);
            title.setTextColor(Color.BLACK);
            title.setTextSize(18);
            title.setTypeface(null, 1);
            details.addView(title);

            TextView creator = new TextView(this);
            creator.setText(channel.isEmpty() ? "Creator information unavailable" : "By " + channel);
            creator.setTextColor(VIOLET);
            creator.setTextSize(13);
            creator.setPadding(0, dp(7), 0, dp(9));
            details.addView(creator);

            TextView info = new TextView(this);
            info.setText("Saved for offline viewing • " + formatSize(activeFile.length()) + "\nThis video is stored on this device and can be watched without an internet connection.");
            info.setTextColor(0xFF667085);
            info.setTextSize(13);
            info.setLineSpacing(dp(3), 1f);
            details.addView(info);
        }

        setContentView(root);
    }

    private void returnToDownloads() {
        savedPosition = 0;
        activeFile = null;
        activeVideo = null;
        playerVisible = false;
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        showDownloads();
    }

    private void enterImmersiveMode() {
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    private void showSystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.WHITE);
    }

    private TextView textAction(String text, int color) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(color);
        view.setTextSize(16);
        view.setGravity(Gravity.CENTER_VERTICAL);
        view.setPadding(dp(4), 0, dp(4), 0);
        return view;
    }

    private android.graphics.drawable.GradientDrawable roundBackground(int color, int radius) {
        android.graphics.drawable.GradientDrawable drawable = new android.graphics.drawable.GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        return drawable;
    }

    private String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format(java.util.Locale.US, "%.1f KB", bytes / 1024.0);
        return String.format(java.util.Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0));
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override public void onBackPressed() {
        if (playerVisible) returnToDownloads();
        else finish();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(refresher);
        imageExecutor.shutdownNow();
        super.onDestroy();
    }

    private static class RowHolder {
        String key;
        String thumbnailUrl = "";
        File file;
        JSONObject meta;
        LinearLayout row;
        ImageView thumb;
        TextView name;
        TextView by;
        ProgressBar meter;
        TextView progressLabel;
        TextView more;
    }
}
