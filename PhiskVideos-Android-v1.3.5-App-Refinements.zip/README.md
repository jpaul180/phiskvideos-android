# PhiskVideos Android starter (v1.0.0)

This is an **Android Studio source project**, not a compiled APK. It loads `https://videos.phisk.co/` inside an Android WebView. The address is an assumption; edit `HOME` in `MainActivity.java` if the actual site differs.

## Build an APK without a laptop
1. Upload this project to a private GitHub repository (or open in Android Studio on a computer).
2. Set up a trusted Android build environment with JDK 17, Android SDK 35, and Gradle 8.9 (or use Android Studio's compatible Gradle tooling).
3. Run `gradle assembleDebug` from the project root (a Gradle wrapper is not included).
4. The resulting file is `app/build/outputs/apk/debug/app-debug.apk`. Install only on your own device for testing.

## Included
- Secure HTTPS-only WebView for PhiskVideos and other phisk.co subdomains
- Violet loading indicator, Android back navigation, file chooser for uploads
- External links open in browser; JavaScript and local storage enabled

## Before public distribution
- Confirm the website address and test login, video playback, uploads, and navigation on real devices.
- Add branded launcher icons, splash screen, full-screen playback, offline/error UI, and app link verification.
- Implement Android notification permissions and a proper push messaging backend if push notifications are required. **Push notifications are not implemented in this starter.**
- Test external sign-in and payments; WebView can be unsuitable for some third-party auth/payment flows.
- Use a release signing key and generate an AAB for Google Play; meet current Play target API, policy, privacy and testing requirements.
- Do not publish a thin WebView wrapper without ensuring meaningful mobile functionality and compliance with Play policies.


## Branding update (v1.0.0)
- Launcher icon uses the supplied transparent Phisk logo on a solid white background.
- Android adaptive and round launcher icons are included, with a white background layer.
- Launch splash uses a white background and a small centered Phisk logo (padded asset to keep it visually modest on Android 12+).
- Original WebView behaviour and package ID (`co.phisk.videos`) are unchanged.

## PhiskVideos offline downloads (integration build)

This build adds a native JavaScript bridge for downloads requested by the signed-in website session. The website asks the Phisk Video Manager AJAX endpoint for an eligible file URL; the native app downloads that HTTPS file into `files/downloads` under app-private internal storage. The native Downloads screen lists, plays, and deletes these files. Files are not written to the public media gallery.

External-provider downloads require an administrator to save an authorised direct video-file URL in the video's **Downloadable original file URL** field. HLS `.m3u8` playback manifests are not accepted. YouTube imports are never eligible.

Before release, configure direct downloadable URLs for each external provider and test on a real device. The native bridge and button visibility are app integration controls, not DRM or tamper-proof app attestation; Play Integrity and short-lived signed provider URLs should be added before treating downloads as a high-security entitlement.


## Downloads enhancement integration (working draft)
- The floating in-app Downloads overlay is removed. The website `/downloads/` navigation destination is intercepted by the Android WebView and opens the native Downloads screen.
- Native downloads now show Android notification progress and a completion notification. Android 13+ notification permission is requested at launch.
- The app stores the creator-saved title, thumbnail URL, and channel name with download metadata; the native Downloads list displays these fields, a progress meter, and a three-dot Play/Delete menu.
- The plugin adds a Downloads menu destination and browser fallback page, and passes title/thumbnail/channel metadata from the video page to the native bridge.
- Note: current implementation continues using the app's existing private-storage download thread; it is not yet a durable WorkManager/foreground-service implementation. Android may stop it if the OS kills the app process. Test long downloads and notification permission on real devices before production release.


## Native authentication navigation fix (v1.3.1)
- WebView authentication interception now handles anchors, buttons, role=button elements, data-url/data-href controls, and form submissions using capture-phase event delegation.
- Login, sign-in, registration, sign-up, create-account, and password-reset/forgot-password actions open the corresponding native screen.
- URL-based interception also recognises common WordPress login/register/lost-password routes.
- Existing downloads bridge, native download screen, WebView browsing, and disabled Google sign-in placeholder are preserved.


## Universal logout integration (v1.3.3)
- The shared website logout URL is `https://videos.phisk.co/logout/`. The WordPress plugin presents a nonce-protected confirmation form and invalidates the server-side WordPress login session on confirmation.
- After successful logout, the Android WebView calls the native bridge, clears app sign-in state, cookies, WebView cache/history and web storage, then returns to the native welcome screen.
- Normal website logout works in external browsers and redirects to the site homepage.
- The old click-text logout hook was removed because it cleared local app state before the server logout had completed.


### v1.3.3 logout interception fix
- Prevents legacy WordPress `wp-login.php?action=logout` links from being mistaken for native login links.
- Routes website logout controls inside the Android WebView to the shared `https://videos.phisk.co/logout/` confirmation endpoint.
- Allows the confirmation page to complete before the native `PhiskApp.completeLogout()` bridge clears the WebView session.


## Corrective navigation release (v1.3.4)
- Replaces broad parent-container text matching for logout with detection limited to the actual clicked control.
- Leaves the dedicated `/logout/` confirmation page untouched so the Yes form can POST normally and Cancel can navigate normally.
- Gives the exact `/downloads/` destination priority in the WebView click handler and opens the native Downloads screen through `PhiskApp.openDownloads()`.
- Keeps the existing WordPress plugin logout and Downloads routes unchanged.
- Build and test on a real Android device: open Downloads from the app menu; open Logout, test Cancel, then confirm logout and verify the native welcome/login screen appears.


## App refinements release (v1.3.5)

- Native authentication now opens on the Sign In form first. Sign Up remains available from the form switcher.
- Updated the launcher icon and native login logo with the white Phisk mascot artwork.
- Updated the splash screen to use the black mascot artwork on Phisk Violet (#7C3AED).
- Renamed the guest navigation action to “Explore PhiskVideos”.
- Added show/hide password controls to the native password fields.
- Completed download notifications explicitly clear the progress indicator; completed video rows hide their download meter.
- Reworked the Downloads list to retain row and thumbnail views while refreshing progress, reducing thumbnail flicker.
- Added tap-to-play on downloaded thumbnails and titles.
- Added a Close action to the Downloads screen, a white player layout with title, creator and offline information, and orientation-aware fullscreen playback.
- Version code 8 / version name 1.3.5. Google sign-in remains disabled until Firebase credentials are configured.

Build the debug APK using the repository GitHub Actions workflow. The workflow expects the source archive `PhiskVideos-Android-v1.3.5-App-Refinements.zip` at the repository root.
