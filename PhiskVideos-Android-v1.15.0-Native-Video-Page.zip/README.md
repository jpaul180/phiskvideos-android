# PhiskVideos Android v1.15.0 — Native Video Page Update

This source archive is based on the supplied PhiskVideos Android v1.14.1 source and adds the first complete native video-page integration with Phisk Video Manager v1.20.2.

## Native video page changes
- Long video titles collapse to two lines and expand/collapse with a Show more / Show less control beside the title.
- Creator avatar uses the actual uploaded profile image when present and the approved bundled PhiskVideos default avatar otherwise.
- Related video cards load the real thumbnail URL returned by the Video Manager API.
- Native page opens call the Video Manager view endpoint. Genuine page views use a 30-minute per-installation/per-video cooldown.
- Regular monetization mode credits eligible page views; Verified mode credits only after the configured watch percentage is reached during native ExoPlayer playback. The server applies creator/self-view, monetization-enabled, strike-pause, rate-limit and daily verified cooldown rules.
- Action row order is Download icon, Like icon, Share icon, Report icon | Report text. The first three actions have no visible labels.
- Like toggles the same `phisk_liked_videos` user-meta and `_phisk_video_like_count` counter used by the website.
- Share uses Android's native share chooser and the canonical video permalink.
- Download requests the authorised original URL from the Video Manager and stores the file in the app-private downloads directory, with progress metadata and Android download notifications.
- Report opens a dedicated native page and submits to the existing `phisk_report` moderation queue using the website's report reasons and metadata.

## Backend requirement
Install the included Phisk Video Manager v1.20.2 plugin archive alongside this Android update. The native page uses these endpoints:
- `GET /wp-json/phisk/v1/videos/{id}`
- `GET /wp-json/phisk/v1/videos/{id}/related`
- `POST /wp-json/phisk/v1/videos/{id}/view`
- `POST /wp-json/phisk/v1/videos/{id}/like` (authenticated)
- `POST /wp-json/phisk/v1/videos/{id}/download` (authenticated)
- `POST /wp-json/phisk/v1/videos/{id}/report` (authenticated)
- Existing native comments endpoints remain unchanged.

## Build
The included GitHub Actions workflow expects this source archive at the repository root as `PhiskVideos-Android-v1.15.0-Native-Video-Page.zip`. It extracts the archive while preserving the workflow file, then builds a signed APK and AAB using the repository's configured signing secrets.
