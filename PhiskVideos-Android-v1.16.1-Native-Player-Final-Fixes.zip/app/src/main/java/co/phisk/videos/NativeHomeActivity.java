package co.phisk.videos;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Drawable;
import android.text.Html;
import android.widget.PopupMenu;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Native tabbed homepage. Feed ranking remains owned by the WordPress Algorithm plugin. */
public class NativeHomeActivity extends Activity {
    private static final String HOME="https://videos.phisk.co/";
    private static final String API=HOME+"wp-json/phisk-algorithm/v1/feeds/";
    private static final int VIOLET=Color.rgb(124,58,237), DEEP=Color.rgb(109,40,217), INK=Color.rgb(25,29,38), MUTED=Color.rgb(112,117,128), BG=Color.rgb(247,248,250);
    private static final String[] FEEDS={"for-you","top-stories","trending","discover","recommended"};
    private static final String[] LABELS={"For You","Top Stories","Trending","Discover","Recommended"};
    private final ExecutorService io=Executors.newFixedThreadPool(3);
    private final ExecutorService images=Executors.newFixedThreadPool(4);
    private final JSONArray[] data={new JSONArray(),new JSONArray(),new JSONArray(),new JSONArray(),new JSONArray()};
    private final int[] pages={1,1,1,1,1};
    private final boolean[] loaded={false,false,false,false,false};
    private final boolean[] more={true,true,true,true,true};
    private int active=0; private boolean loading=false;
    private LinearLayout root, tabStrip, feedList; private ScrollView feedScroll; private ProgressBar spinner; private TextView status;
    private ImageView accountAvatar; private volatile int myCreatorId = 0; private volatile boolean myChannelKnown = false;
    private static final String AUTH_PREFS = "phisk_native_auth";

    @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(Color.WHITE);getWindow().setNavigationBarColor(Color.WHITE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);build();selectTab(0);loadMyChannel();}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable shape(int color,int stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
    private TextView label(String value,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private void build(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(14),dp(10),dp(14),dp(10));header.setBackgroundColor(Color.WHITE);
        accountAvatar=new ImageView(this);accountAvatar.setScaleType(ImageView.ScaleType.CENTER_CROP);accountAvatar.setImageResource(R.drawable.ic_phisk_default_avatar);accountAvatar.setBackground(shape(Color.rgb(239,235,247),0,50));accountAvatar.setClipToOutline(true);
        LinearLayout.LayoutParams avatarParams=new LinearLayout.LayoutParams(dp(42),dp(42));avatarParams.rightMargin=dp(8);header.addView(accountAvatar,avatarParams);
        accountAvatar.setContentDescription("Your channel");accountAvatar.setOnClickListener(v->openMyChannel());
        TextView logo=label("▷",34,VIOLET,true);logo.setGravity(Gravity.CENTER);header.addView(logo,new LinearLayout.LayoutParams(dp(42),dp(48)));
        EditText search=new EditText(this);search.setSingleLine(true);search.setTextSize(15);search.setHint("Search videos, stories and channels...");search.setPadding(dp(14),0,dp(12),0);search.setBackground(shape(Color.WHITE,Color.rgb(225,226,231),24));search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(44),1);sp.leftMargin=dp(8);header.addView(search,sp);search.setOnEditorActionListener((v,action,event)->{if(action==EditorInfo.IME_ACTION_SEARCH){String q=search.getText().toString().trim();if(!q.isEmpty()){Intent searchIntent=new Intent(this,NativeSearchActivity.class);searchIntent.putExtra("search_query",q);startActivity(searchIntent);}return true;}return false;});
        root.addView(header);
        HorizontalScrollView tabs=new HorizontalScrollView(this);tabs.setHorizontalScrollBarEnabled(false);tabs.setBackgroundColor(Color.WHITE);tabStrip=new LinearLayout(this);tabStrip.setGravity(Gravity.CENTER_VERTICAL);tabStrip.setPadding(dp(12),dp(10),dp(12),dp(10));tabs.addView(tabStrip);for(int i=0;i<LABELS.length;i++)addTab(i);root.addView(tabs);
        View divider=new View(this);divider.setBackgroundColor(Color.rgb(235,236,240));root.addView(divider,new LinearLayout.LayoutParams(-1,dp(1)));
        FrameLayout body=new FrameLayout(this);feedScroll=new ScrollView(this);feedScroll.setFillViewport(true);feedList=new LinearLayout(this);feedList.setOrientation(LinearLayout.VERTICAL);feedList.setPadding(dp(14),dp(18),dp(14),dp(18));feedScroll.addView(feedList);body.addView(feedScroll,new FrameLayout.LayoutParams(-1,-1));spinner=new ProgressBar(this);FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(dp(38),dp(38),Gravity.TOP|Gravity.CENTER_HORIZONTAL);pp.topMargin=dp(24);body.addView(spinner,pp);spinner.setVisibility(View.GONE);root.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        root.addView(bottomBar());setContentView(root);
        feedScroll.setOnScrollChangeListener((View v,int sx,int sy,int oldx,int oldy)->{if(active!=1 && more[active] && !loading && sy+feedScroll.getHeight()>=feedList.getHeight()-dp(500))loadPage(active);});
    }
    private void addTab(int index){TextView t=label(LABELS[index],14,INK,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(17),dp(11),dp(17),dp(11));t.setBackground(shape(Color.WHITE,0,10));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,dp(42));p.rightMargin=dp(7);tabStrip.addView(t,p);t.setOnClickListener(v->selectTab(index));t.setTag("tab_"+index);}
    private void updateTabs(){for(int i=0;i<tabStrip.getChildCount();i++){TextView t=(TextView)tabStrip.getChildAt(i);boolean selected=i==active;t.setTextColor(selected?Color.WHITE:INK);t.setBackground(shape(selected?VIOLET:Color.WHITE,0,10));}}
    private LinearLayout bottomBar(){
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER);bar.setBackgroundColor(Color.WHITE);
        bar.setPadding(dp(5),dp(6),dp(5),dp(6));
        String[] names={"Home","Studio","Create","Activities","Settings"};
        int[] icons={R.drawable.ic_nav_home,R.drawable.ic_nav_studio,R.drawable.ic_nav_create,R.drawable.ic_nav_activities,R.drawable.ic_nav_settings};
        for(int i=0;i<names.length;i++){
            final int n=i; boolean selected=i==0;
            LinearLayout item=new LinearLayout(this);item.setOrientation(LinearLayout.VERTICAL);item.setGravity(Gravity.CENTER);
            ImageView icon=new ImageView(this);icon.setImageResource(icons[i]);icon.setColorFilter(selected?VIOLET:MUTED);
            item.addView(icon,new LinearLayout.LayoutParams(dp(23),dp(23)));
            TextView caption=label(names[i],11,selected?VIOLET:MUTED,true);caption.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=dp(3);item.addView(caption,cp);
            bar.addView(item,new LinearLayout.LayoutParams(0,dp(54),1));
            if(i!=0)item.setOnClickListener(v->{if(n==1)startActivity(new Intent(this,NativeCreatorStudioActivity.class));else if(n==2)startActivity(new Intent(this,NativeVideoUploadActivity.class));else if(n==3)startActivity(new Intent(this,NotificationCentreActivity.class));else startActivity(new Intent(this,NativeSettingsActivity.class));});
        }
        return bar;
    }
    private String authToken(){return getSharedPreferences(AUTH_PREFS,MODE_PRIVATE).getString("access_token","");}
    private JSONObject apiRequest(String path,String method,JSONObject payload)throws Exception{
        HttpURLConnection c=null;
        try{
            c=(HttpURLConnection)new URL(HOME+"wp-json/phisk/v1/"+path).openConnection();c.setRequestMethod(method);
            c.setConnectTimeout(12000);c.setReadTimeout(15000);c.setRequestProperty("Accept","application/json");
            String token=authToken();if(!token.isEmpty())c.setRequestProperty("Authorization","Bearer "+token);
            if(payload!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=UTF-8");try(java.io.OutputStream out=c.getOutputStream()){out.write(payload.toString().getBytes("UTF-8"));}}
            int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();
            ByteArrayOutputStream out=new ByteArrayOutputStream();if(in!=null){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);in.close();}
            String raw=out.toString("UTF-8");if(code<200||code>=300)throw new Exception(raw);return new JSONObject(raw);
        }finally{if(c!=null)c.disconnect();}
    }
    private void loadMyChannel(){
        if(authToken().isEmpty())return;
        io.execute(()->{
            try{
                JSONObject studio=apiRequest("creator-studio","GET",null);
                JSONObject creator=studio.optJSONObject("creator");if(creator==null)return;
                int id=creator.optInt("id",0);if(id<=0)return;
                JSONObject profile=apiRequest("creators/"+id,"GET",null);
                String avatar=profile.optString("avatar_url","");
                myCreatorId=id;myChannelKnown=true;
                if(profile.optBoolean("has_custom_avatar",false) && validImage(avatar))loadImage(accountAvatar,avatar);
                runOnUiThread(()->{if(loaded[active] && data[active].length()>0)renderItems(active);});
            }catch(Exception ignored){/* Keep the bundled default avatar when no channel/profile is available. */}
        });
    }
    private void openMyChannel(){
        if(myCreatorId>0){Intent i=new Intent(this,NativeCreatorChannelActivity.class);i.putExtra("creator_id",myCreatorId);startActivity(i);}
        else if(myChannelKnown){Toast.makeText(this,"Create a channel to access your channel page.",Toast.LENGTH_SHORT).show();startActivity(new Intent(this,NativeCreatorStudioActivity.class));}
        else{
            Toast.makeText(this,"Loading your channel…",Toast.LENGTH_SHORT).show();
            io.execute(()->{try{JSONObject studio=apiRequest("creator-studio","GET",null);JSONObject creator=studio.optJSONObject("creator");int id=creator==null?0:creator.optInt("id",0);if(id>0){myCreatorId=id;runOnUiThread(()->openMyChannel());}else runOnUiThread(()->startActivity(new Intent(this,NativeCreatorStudioActivity.class)));}catch(Exception e){runOnUiThread(()->startActivity(new Intent(this,NativeCreatorStudioActivity.class)));}});
        }
    }
    private void subscribeToCreator(JSONObject creator, TextView button){
        int creatorId=creator.optInt("id",0);if(creatorId<=0){Toast.makeText(this,"Creator channel unavailable.",Toast.LENGTH_SHORT).show();return;}
        boolean wasFollowed=creator.optBoolean("is_followed",false);button.setEnabled(false);
        io.execute(()->{try{JSONObject body=new JSONObject();body.put("action",wasFollowed?"unsubscribe":"subscribe");JSONObject response=apiRequest("creators/"+creatorId+"/subscribe","POST",body);boolean subscribed=response.optBoolean("subscribed",!wasFollowed);
            creator.put("is_followed",subscribed);
            runOnUiThread(()->{button.setText(subscribed?"Subscribed":"Subscribe");button.setBackground(shape(subscribed?Color.rgb(244,240,251):VIOLET,subscribed?Color.rgb(225,216,242):0,6));button.setTextColor(subscribed?VIOLET:Color.WHITE);button.setEnabled(true);});
        }catch(Exception e){runOnUiThread(()->{button.setEnabled(true);Toast.makeText(this,"Couldn't update subscription. Please try again.",Toast.LENGTH_SHORT).show();});}});
    }
    private void selectTab(int index){active=index;updateTabs();feedList.removeAllViews();if(loaded[index])renderItems(index);else if(index==1){loaded[index]=true;showTopStoriesPending();}else loadPage(index);feedScroll.scrollTo(0,0);}
    private String token(){return getSharedPreferences("phisk_native_auth",MODE_PRIVATE).getString("access_token","");}
    private void loadPage(int index){if(index==1||loading||!more[index])return;loading=true;spinner.setVisibility(View.VISIBLE);final int page=pages[index];io.execute(()->{HttpURLConnection c=null;try{String url=API+FEEDS[index]+"?page="+page+"&per_page=10";c=(HttpURLConnection)new URL(url).openConnection();c.setRequestMethod("GET");c.setConnectTimeout(15000);c.setReadTimeout(20000);c.setRequestProperty("Accept","application/json");String access=token();if(!access.isEmpty())c.setRequestProperty("Authorization","Bearer "+access);int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();ByteArrayOutputStream out=new ByteArrayOutputStream();if(in!=null){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);in.close();}if(code<200||code>=300)throw new Exception("Server returned "+code);JSONObject response=new JSONObject(out.toString("UTF-8"));if(!response.optBoolean("success"))throw new Exception("Feed request was not successful");JSONArray items=response.optJSONArray("items");if(items==null)items=new JSONArray();final JSONArray result=items;final boolean hasMore=response.optBoolean("has_more",false);runOnUiThread(()->{loading=false;spinner.setVisibility(View.GONE);loaded[index]=true;pages[index]=page+1;more[index]=hasMore;for(int i=0;i<result.length();i++)data[index].put(result.opt(i));if(active==index)renderItems(index);});}catch(Exception e){runOnUiThread(()->{loading=false;spinner.setVisibility(View.GONE);if(active==index)showError(index,"Couldn't load this feed. Check your connection and try again.");});}finally{if(c!=null)c.disconnect();}});}
    private void renderItems(int index){feedList.removeAllViews();if(data[index].length()==0){showEmpty("No videos to show yet.");return;}for(int i=0;i<data[index].length();i++){JSONObject item=data[index].optJSONObject(i);if(item!=null)addVideoCard(item);}if(more[index]){TextView moreLabel=label("Loading more videos…",12,MUTED,false);moreLabel.setGravity(Gravity.CENTER);moreLabel.setPadding(0,dp(16),0,dp(18));feedList.addView(moreLabel);}}
    private void addVideoCard(JSONObject item){
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(10),dp(10),dp(10),dp(12));card.setBackground(shape(Color.WHITE,Color.rgb(229,230,234),15));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=dp(14);feedList.addView(card,cp);
        FrameLayout media=new FrameLayout(this);media.setBackground(shape(Color.rgb(24,24,27),0,12));media.setClipToOutline(true);ImageView thumb=new ImageView(this);thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);media.addView(thumb,new FrameLayout.LayoutParams(-1,dp(205)));String thumbUrl=item.optString("thumbnail_url","");if(validImage(thumbUrl))loadImage(thumb,thumbUrl);
        TextView duration=label(item.optString("runtime",""),12,Color.WHITE,true);duration.setPadding(dp(7),dp(4),dp(7),dp(4));duration.setBackground(shape(Color.rgb(20,20,20),0,5));FrameLayout.LayoutParams dur=new FrameLayout.LayoutParams(-2,-2,Gravity.RIGHT|Gravity.BOTTOM);dur.setMargins(0,0,dp(8),dp(8));media.addView(duration,dur);
        TextView age=label(item.optString("published_ago",""),11,Color.WHITE,true);age.setPadding(dp(7),dp(4),dp(7),dp(4));age.setBackground(shape(Color.rgb(20,20,20),0,5));FrameLayout.LayoutParams ag=new FrameLayout.LayoutParams(-2,-2,Gravity.LEFT|Gravity.BOTTOM);ag.setMargins(dp(8),0,0,dp(8));media.addView(age,ag);
        TextView dots=label("⋮",24,Color.WHITE,true);dots.setGravity(Gravity.CENTER);dots.setBackground(shape(Color.argb(75,0,0,0),0,18));FrameLayout.LayoutParams dotp=new FrameLayout.LayoutParams(dp(36),dp(38),Gravity.RIGHT|Gravity.TOP);dotp.setMargins(0,dp(4),dp(4),0);media.addView(dots,dotp);
        dots.setOnClickListener(v->{PopupMenu menu=new PopupMenu(this,dots);menu.getMenu().add("Share").setOnMenuItemClickListener(mi->{shareVideo(item);return true;});menu.show();});
        card.addView(media);
        LinearLayout details=new LinearLayout(this);details.setOrientation(LinearLayout.HORIZONTAL);details.setGravity(Gravity.TOP);details.setPadding(0,dp(12),0,0);
        ImageView avatar=new ImageView(this);avatar.setImageResource(R.drawable.ic_phisk_default_avatar);avatar.setBackground(shape(Color.rgb(239,235,247),0,40));avatar.setClipToOutline(true);LinearLayout.LayoutParams avp=new LinearLayout.LayoutParams(dp(48),dp(48));avp.rightMargin=dp(11);details.addView(avatar,avp);
        JSONObject creator=item.optJSONObject("creator");String creatorName=creator==null?"Creator":decodeText(creator.optString("name","Creator"));String avatarUrl=creator==null?"":creator.optString("avatar_url","");if(creator!=null&&validImage(avatarUrl))loadImage(avatar,avatarUrl);
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);details.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
        TextView title=label(truncateHomepageTitle(decodeText(item.optString("title","Untitled video"))),17,INK,true);title.setMaxLines(3);copy.addView(title);
        LinearLayout metaRow=new LinearLayout(this);metaRow.setOrientation(LinearLayout.HORIZONTAL);metaRow.setGravity(Gravity.CENTER_VERTICAL);LinearLayout.LayoutParams metaRowParams=new LinearLayout.LayoutParams(-1,-2);metaRowParams.topMargin=dp(7);copy.addView(metaRow,metaRowParams);
        TextView meta=label(creatorName+"  ·  "+item.optInt("views",0)+" views",13,MUTED,false);meta.setSingleLine(true);meta.setEllipsize(android.text.TextUtils.TruncateAt.END);metaRow.addView(meta,new LinearLayout.LayoutParams(0,-2,1));
        boolean followed=creator!=null&&creator.optBoolean("is_followed");
        TextView subscribe=label(followed?"Subscribed":"Subscribe",12,followed?VIOLET:Color.WHITE,true);
        subscribe.setGravity(Gravity.CENTER);subscribe.setSingleLine(true);subscribe.setPadding(dp(11),dp(5),dp(11),dp(5));subscribe.setBackground(shape(followed?Color.rgb(244,240,251):VIOLET,followed?Color.rgb(225,216,242):0,6));
        LinearLayout.LayoutParams subp=new LinearLayout.LayoutParams(-2,dp(30));subp.leftMargin=dp(8);metaRow.addView(subscribe,subp);
        if(creator==null||creator.optInt("id",0)<=0||(myCreatorId>0&&creator.optInt("id",0)==myCreatorId)){subscribe.setEnabled(false);subscribe.setVisibility(View.GONE);}
        else subscribe.setOnClickListener(v->subscribeToCreator(creator,subscribe));
        card.addView(details);
        View.OnClickListener open=v->openNativePlayer(item);media.setOnClickListener(open);title.setOnClickListener(open);
        View.OnClickListener openCreator=v->{if(creator!=null){int creatorId=creator.optInt("id",0);if(creatorId>0){Intent channel=new Intent(this,NativeCreatorChannelActivity.class);channel.putExtra("creator_id",creatorId);startActivity(channel);}else openWeb(creator.optString("profile_url",HOME));}};
        avatar.setOnClickListener(openCreator);meta.setOnClickListener(openCreator);
    }
    // Homepage titles are limited to 60 displayed characters, including the ellipsis.
    private String truncateHomepageTitle(String value){
        if(value==null)return "";
        int count=value.codePointCount(0,value.length());
        if(count<=60)return value;
        int end=value.offsetByCodePoints(0,59);
        return value.substring(0,end).trim()+"…";
    }
    private String decodeText(String value){
        if(value==null)return "";String decoded=value;
        for(int i=0;i<2;i++){if(decoded.contains("&")&&decoded.contains(";"))decoded=Html.fromHtml(decoded,Html.FROM_HTML_MODE_LEGACY).toString();else break;}
        return decoded;
    }
    private void shareVideo(JSONObject item){
        String url=item.optString("permalink","");if(url==null||!url.startsWith("https://videos.phisk.co/"))url=HOME;
        String title=decodeText(item.optString("title","Watch on PhiskVideos"));
        Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(Intent.EXTRA_SUBJECT,title);send.putExtra(Intent.EXTRA_TEXT,title+"\n"+url);
        startActivity(Intent.createChooser(send,"Share video"));
    }
    private void openNativePlayer(JSONObject item){
        int id=item.optInt("id",0);
        if(id<=0){new AlertDialog.Builder(this).setTitle("Video unavailable").setMessage("This feed item is missing its video ID. Please refresh the feed.").setPositiveButton("OK",null).show();return;}
        Intent intent=new Intent(this,NativePlayerActivity.class);
        intent.putExtra("video_id",id);
        startActivity(intent);
    }
    private boolean validImage(String value){try{Uri u=Uri.parse(value);return "https".equalsIgnoreCase(u.getScheme())&&u.getHost()!=null;}catch(Exception e){return false;}}
    private void loadImage(ImageView target,String value){images.execute(()->{HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(value).openConnection();c.setConnectTimeout(8000);c.setReadTimeout(10000);c.setRequestProperty("User-Agent","PhiskVideosAndroid/1.6.0");Bitmap bitmap=BitmapFactory.decodeStream(c.getInputStream());if(bitmap!=null)runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())target.setImageBitmap(bitmap);});}catch(Exception ignored){}finally{if(c!=null)c.disconnect();}});}
    private void showTopStoriesPending(){feedList.removeAllViews();TextView h=label("Top Stories",22,INK,true);feedList.addView(h);TextView m=label("Top Stories will appear here once its dedicated Video Manager feed endpoint is connected.",14,MUTED,false);m.setPadding(0,dp(9),0,0);feedList.addView(m);}
    private void showEmpty(String message){TextView t=label(message,14,MUTED,false);t.setGravity(Gravity.CENTER);t.setPadding(dp(20),dp(55),dp(20),dp(55));feedList.addView(t);}
    private void showError(int index,String message){feedList.removeAllViews();TextView t=label(message,14,MUTED,false);t.setGravity(Gravity.CENTER);t.setPadding(dp(18),dp(40),dp(18),dp(18));feedList.addView(t);TextView retry=label("Try again",14,VIOLET,true);retry.setGravity(Gravity.CENTER);feedList.addView(retry);retry.setOnClickListener(v->{loaded[index]=false;loadPage(index);});}
    private void openWeb(String url){Intent i=new Intent(this,MainActivity.class);i.putExtra(MainActivity.EXTRA_NOTIFICATION_URL,url);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(i);finish();}
    @Override public void onBackPressed(){super.onBackPressed();}
    @Override protected void onDestroy(){io.shutdownNow();images.shutdownNow();super.onDestroy();}
}
