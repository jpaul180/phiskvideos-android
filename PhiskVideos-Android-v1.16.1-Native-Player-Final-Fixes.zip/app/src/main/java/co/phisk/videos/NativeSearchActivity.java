package co.phisk.videos;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Native search results for Videos, Stories and Channels only. */
public class NativeSearchActivity extends Activity {
    private static final String HOME = "https://videos.phisk.co/";
    private static final String API = HOME + "wp-json/phisk/v1/search";
    private static final int VIOLET = Color.rgb(124,58,237), INK = Color.rgb(25,29,38), MUTED = Color.rgb(112,117,128), BG = Color.rgb(247,248,250);
    private static final String[] TYPES = {"videos", "stories", "channels"};
    private static final String[] LABELS = {"Videos", "Stories", "Channels"};
    private final ExecutorService io = Executors.newFixedThreadPool(3);
    private final ExecutorService images = Executors.newFixedThreadPool(4);
    private final JSONArray[] results = {new JSONArray(), new JSONArray(), new JSONArray()};
    private final int[] pages = {1,1,1};
    private final boolean[] more = {false,false,false};
    private String query = "";
    private int activeTab = 0;
    private boolean loading = false;
    private LinearLayout root, tabs, resultList;
    private EditText searchInput;
    private ScrollView resultScroll;
    private ProgressBar progress;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        query = getIntent().getStringExtra("search_query");
        if (query == null) query = "";
        String requestedType = getIntent().getStringExtra("search_type");
        if (requestedType != null) { for (int i=0;i<TYPES.length;i++) if (TYPES[i].equals(requestedType)) activeTab=i; }
        build();
        if (!query.trim().isEmpty()) { searchInput.setText(query); searchInput.setSelection(searchInput.getText().length()); runSearch(activeTab, true); }
        else searchInput.requestFocus();
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable shape(int color, int stroke, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); if (stroke != 0) d.setStroke(dp(1), stroke); return d; }
    private TextView text(String value, int size, int color, boolean bold) { TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t; }

    private void build() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setPadding(dp(12),dp(8),dp(12),dp(8)); header.setBackgroundColor(Color.WHITE);
        TextView back = text("‹",34,INK,false); back.setGravity(Gravity.CENTER); header.addView(back,new LinearLayout.LayoutParams(dp(38),dp(46))); back.setOnClickListener(v -> finish());
        searchInput = new EditText(this); searchInput.setSingleLine(true); searchInput.setTextSize(15); searchInput.setHint("Search videos, stories and channels..."); searchInput.setPadding(dp(13),0,dp(12),0); searchInput.setBackground(shape(Color.rgb(248,248,250),Color.rgb(228,229,234),8)); searchInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        header.addView(searchInput,new LinearLayout.LayoutParams(0,dp(44),1));
        TextView go = text("Search",14,Color.WHITE,true); go.setGravity(Gravity.CENTER); go.setPadding(dp(13),0,dp(13),0); go.setBackground(shape(VIOLET,0,7)); LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-2,dp(42)); gp.leftMargin=dp(8); header.addView(go,gp); go.setOnClickListener(v -> runSearch(activeTab,true));
        searchInput.setOnEditorActionListener((v, action, event) -> { if (action == EditorInfo.IME_ACTION_SEARCH) { runSearch(activeTab,true); return true; } return false; });
        root.addView(header);

        HorizontalScrollView tabScroll = new HorizontalScrollView(this); tabScroll.setHorizontalScrollBarEnabled(false); tabScroll.setBackgroundColor(Color.WHITE); tabs = new LinearLayout(this); tabs.setPadding(dp(12),dp(9),dp(12),dp(9)); tabScroll.addView(tabs); for(int i=0;i<LABELS.length;i++) addTab(i); root.addView(tabScroll);
        View divider = new View(this); divider.setBackgroundColor(Color.rgb(235,236,240)); root.addView(divider,new LinearLayout.LayoutParams(-1,dp(1)));

        FrameLayout body = new FrameLayout(this); resultScroll = new ScrollView(this); resultScroll.setFillViewport(true); resultList = new LinearLayout(this); resultList.setOrientation(LinearLayout.VERTICAL); resultList.setPadding(dp(14),dp(14),dp(14),dp(28)); resultScroll.addView(resultList); body.addView(resultScroll,new FrameLayout.LayoutParams(-1,-1));
        progress = new ProgressBar(this); FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(dp(34),dp(34),Gravity.TOP|Gravity.CENTER_HORIZONTAL); pp.topMargin=dp(12); body.addView(progress,pp); progress.setVisibility(View.GONE); root.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        resultScroll.setOnScrollChangeListener((View v,int sx,int sy,int oldx,int oldy) -> { if(more[activeTab] && !loading && sy + resultScroll.getHeight() >= resultList.getHeight()-dp(420)) loadPage(false); });
        updateTabs();
    }

    private void addTab(int index) {
        TextView tab = text(LABELS[index],14,INK,true); tab.setGravity(Gravity.CENTER); tab.setPadding(dp(19),dp(10),dp(19),dp(10)); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2,dp(40)); p.rightMargin=dp(7); tabs.addView(tab,p); tab.setOnClickListener(v -> { if(activeTab==index)return; activeTab=index; updateTabs(); resultList.removeAllViews(); if(results[index].length()>0) renderResults(); else if(!query.trim().isEmpty()) runSearch(index,true); });
    }
    private void updateTabs() { for(int i=0;i<tabs.getChildCount();i++){TextView t=(TextView)tabs.getChildAt(i);boolean selected=i==activeTab;t.setTextColor(selected?Color.WHITE:INK);t.setBackground(shape(selected?VIOLET:Color.WHITE,selected?0:Color.rgb(235,235,239),7));} }

    private void runSearch(int tab, boolean reset) {
        String value = searchInput.getText().toString().trim();
        if(value.length()<2){Toast.makeText(this,"Enter at least two characters to search.",Toast.LENGTH_SHORT).show();return;}
        boolean changed = !value.equals(query);
        query=value; activeTab=tab; updateTabs();
        if(changed){for(int i=0;i<TYPES.length;i++){results[i]=new JSONArray();pages[i]=1;more[i]=false;}}
        if(reset){results[tab]=new JSONArray();pages[tab]=1;more[tab]=false;resultList.removeAllViews();}
        loadPage(true);
    }
    private void loadPage(boolean firstPage) {
        if(loading)return; if(!firstPage && !more[activeTab])return;
        loading=true; progress.setVisibility(View.VISIBLE); final int tab=activeTab, page=pages[activeTab]; final String term=query;
        io.execute(() -> {
            HttpURLConnection connection=null;
            try {
                String url=API+"?q="+URLEncoder.encode(term,"UTF-8")+"&type="+TYPES[tab]+"&page="+page+"&per_page=10";
                connection=(HttpURLConnection)new URL(url).openConnection(); connection.setRequestMethod("GET"); connection.setConnectTimeout(15000); connection.setReadTimeout(20000); connection.setRequestProperty("Accept","application/json");
                int code=connection.getResponseCode(); InputStream in=code>=200&&code<300?connection.getInputStream():connection.getErrorStream(); ByteArrayOutputStream out=new ByteArrayOutputStream(); if(in!=null){byte[] buffer=new byte[4096];int n;while((n=in.read(buffer))!=-1)out.write(buffer,0,n);in.close();}
                String raw=out.toString("UTF-8"); if(code<200||code>=300)throw new Exception(extractError(raw)); JSONObject response=new JSONObject(raw); JSONArray items=response.optJSONArray("items"); if(items==null)items=new JSONArray(); final JSONArray found=items; final boolean hasMore=response.optBoolean("has_more",false);
                runOnUiThread(() -> { loading=false;progress.setVisibility(View.GONE); if(tab!=activeTab||!term.equals(query))return; for(int i=0;i<found.length();i++)results[tab].put(found.opt(i));pages[tab]=page+1;more[tab]=hasMore;renderResults(); });
            } catch(Exception e) { runOnUiThread(() -> { loading=false;progress.setVisibility(View.GONE);if(tab==activeTab){if(results[tab].length()==0)showMessage("Couldn't load search results. Check your connection and try again.",true);else Toast.makeText(this,"Couldn't load more results.",Toast.LENGTH_SHORT).show();} }); }
            finally { if(connection!=null)connection.disconnect(); }
        });
    }
    private String extractError(String raw){try{return new JSONObject(raw).optString("message","Search request failed.");}catch(Exception e){return "Search request failed.";}}

    private void renderResults() {
        resultList.removeAllViews(); JSONArray items=results[activeTab];
        if(items.length()==0){showMessage("No "+LABELS[activeTab].toLowerCase()+" found. Try another search term.",false);return;}
        for(int i=0;i<items.length();i++){JSONObject item=items.optJSONObject(i);if(item==null)continue;if(activeTab==0)addVideo(item);else if(activeTab==1)addStory(item);else addChannel(item);}
        if(more[activeTab]){TextView moreButton=text("Load more",14,VIOLET,true);moreButton.setGravity(Gravity.CENTER);moreButton.setPadding(0,dp(19),0,dp(19));resultList.addView(moreButton);moreButton.setOnClickListener(v->loadPage(false));}
    }

    private void addVideo(JSONObject item) {
        LinearLayout card=card(); ImageView thumb=new ImageView(this);thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);thumb.setBackground(shape(Color.rgb(231,232,236),0,7));card.addView(thumb,new LinearLayout.LayoutParams(-1,dp(190)));loadImage(thumb,item.optString("thumbnail_url",""));
        TextView title=text(item.optString("title","Untitled video"),16,INK,true);title.setMaxLines(2);title.setPadding(0,dp(10),0,dp(5));card.addView(title);
        JSONObject creator=item.optJSONObject("creator");String creatorName=creator==null?"Creator":creator.optString("name","Creator");TextView meta=text(creatorName+"  ·  "+formatCount(item.optInt("views"))+" views  ·  "+date(item.optString("published_at","")),12,MUTED,false);card.addView(meta);
        View.OnClickListener open=v->{int id=item.optInt("id",0);if(id>0){Intent i=new Intent(this,NativePlayerActivity.class);i.putExtra("video_id",id);startActivity(i);}};card.setOnClickListener(open);title.setOnClickListener(open);
        if(creator!=null){meta.setOnClickListener(v->openChannel(creator.optInt("id",0)));}
    }
    private void addStory(JSONObject item) {
        LinearLayout card=card(); LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.TOP);ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.CENTER_CROP);image.setBackground(shape(Color.rgb(231,232,236),0,6));row.addView(image,new LinearLayout.LayoutParams(dp(112),dp(112)));loadImage(image,item.optString("thumbnail_url",""));
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(11),0,0,0);row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));TextView title=text(item.optString("title","Story"),15,INK,true);title.setMaxLines(3);copy.addView(title);TextView excerpt=text(item.optString("excerpt",""),12,MUTED,false);excerpt.setMaxLines(3);excerpt.setPadding(0,dp(5),0,dp(6));copy.addView(excerpt);JSONObject creator=item.optJSONObject("creator");if(creator!=null)copy.addView(text(creator.optString("name","Creator")+"  ·  "+date(item.optString("published_at","")),11,MUTED,false));card.addView(row);
        card.setOnClickListener(v->openWeb(item.optString("permalink",HOME)));title.setOnClickListener(v->openWeb(item.optString("permalink",HOME)));
    }
    private void addChannel(JSONObject item) {
        LinearLayout card=card();card.setOrientation(LinearLayout.HORIZONTAL);card.setGravity(Gravity.CENTER_VERTICAL);ImageView avatar=new ImageView(this);avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);avatar.setImageResource(R.drawable.ic_phisk_default_avatar);avatar.setBackground(shape(Color.rgb(235,229,248),0,40));avatar.setClipToOutline(true);card.addView(avatar,new LinearLayout.LayoutParams(dp(68),dp(68)));if(item.optBoolean("has_custom_avatar",false))loadImage(avatar,item.optString("avatar_url",""));
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(12),0,0,0);card.addView(copy,new LinearLayout.LayoutParams(0,-2,1));TextView name=text(item.optString("name","Creator"),15,INK,true);copy.addView(name);copy.addView(text("@"+item.optString("username","creator")+"  ·  "+formatCount(item.optInt("subscriber_count"))+" subscribers",11,MUTED,false));String bio=item.optString("description","").trim();if(!bio.isEmpty()){TextView desc=text(bio,12,MUTED,false);desc.setMaxLines(2);desc.setPadding(0,dp(4),0,0);copy.addView(desc);}if(item.optBoolean("verified")){TextView verified=text("Verified creator",11,VIOLET,true);verified.setPadding(0,dp(4),0,0);copy.addView(verified);}card.setOnClickListener(v->openChannel(item.optInt("id",0)));name.setOnClickListener(v->openChannel(item.optInt("id",0)));
    }
    private LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(10),dp(10),dp(10),dp(10));c.setBackground(shape(Color.WHITE,Color.rgb(231,233,238),8));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(10);resultList.addView(c,p);return c;}
    private void openChannel(int id){if(id<=0)return;Intent i=new Intent(this,NativeCreatorChannelActivity.class);i.putExtra("creator_id",id);startActivity(i);}
    private void openWeb(String url){if(url==null||!url.startsWith("https://videos.phisk.co"))url=HOME;Intent i=new Intent(this,MainActivity.class);i.putExtra(MainActivity.EXTRA_NOTIFICATION_URL,url);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(i);}
    private void showMessage(String message,boolean retry){resultList.removeAllViews();TextView t=text(message,14,MUTED,false);t.setGravity(Gravity.CENTER);t.setPadding(dp(20),dp(44),dp(20),dp(14));resultList.addView(t);if(retry){TextView again=text("Try again",14,VIOLET,true);again.setGravity(Gravity.CENTER);resultList.addView(again);again.setOnClickListener(v->runSearch(activeTab,true));}}
    private void loadImage(ImageView target,String value){if(value==null||!value.startsWith("https://"))return;images.execute(()->{HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(value).openConnection();c.setConnectTimeout(8000);c.setReadTimeout(10000);Bitmap bitmap=BitmapFactory.decodeStream(c.getInputStream());if(bitmap!=null)runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())target.setImageBitmap(bitmap);});}catch(Exception ignored){}finally{if(c!=null)c.disconnect();}});}
    private String formatCount(int n){if(n>=1000000)return String.format(java.util.Locale.US,"%.1fM",n/1000000f);if(n>=1000)return String.format(java.util.Locale.US,"%.1fK",n/1000f);return String.valueOf(n);}
    private String date(String value){if(value==null||value.isEmpty())return "";try{return value.substring(0,10);}catch(Exception e){return "";}}
    @Override protected void onDestroy(){io.shutdownNow();images.shutdownNow();super.onDestroy();}
}
