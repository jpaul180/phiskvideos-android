# PhiskVideos Android v1.16.0 — Offline Video Experience

This release builds on the successfully tested v1.15.0 native video page and includes the supplied Phisk Video Manager v1.20.2 source/API reference.

## Native video page fixes
- Fixed the Report screen: the native report form is now attached to the Activity view hierarchy, so it opens instead of leaving the splash screen visible.
- Decode HTML entities consistently in video titles, descriptions, creator names, related-video titles, comments and report titles. Text such as `&amp;` is displayed as `&`.
- Related-video thumbnails now clip to their lightly rounded thumbnail background.

## Offline video page
- A completed download saves a local snapshot of the native video payload, including title, description, publication date, creator details, views, likes, thumbnail and related-video cards.
- The thumbnail, creator avatar and related-video thumbnails are cached in app-private storage when available.
- Opening a completed download displays a native offline watch page using the locally saved video and metadata. The Download, Like, Share, Report and Comments controls are not shown on this offline page.
- Related videos that are already downloaded open their offline page. Other related videos open their native online video page when a network connection is available; otherwise the app explains that the video must be downloaded first.
- Download files use a stable video-ID-based name. The app checks for an existing or in-progress download before starting another one. A video can be downloaded again only after its existing file is deleted.
- Downloaded video files and cached page images remain in the app-private storage area and do not appear in the device gallery.

## Backend/API
The included Video Manager source is v1.20.2. Its existing native video detail, related, download and report endpoints provide the required data and authorised original download URL. No new server endpoint is required for this offline-page implementation.

## Build
- Android version: `1.16.0`
- Android version code: `29`
- Minimum SDK: 24
- Target/compile SDK: 35
- Java: 17
- The included GitHub Actions workflow expects `PhiskVideos-Android-v1.16.0-Offline-Video-Experience.zip` at the repository root and builds signed APK and AAB outputs using the configured signing secrets.
