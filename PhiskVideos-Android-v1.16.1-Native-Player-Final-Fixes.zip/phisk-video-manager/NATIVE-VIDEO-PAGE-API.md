# Native Video Page API (v1.20.2)

All routes use the `phisk/v1` namespace.

- `GET /videos/{id}` returns the native watch payload, including creator avatar URL/custom-avatar state, thumbnail, playback data, download availability and monetization mode/watch threshold.
- `GET /videos/{id}/related` returns native related-video cards with real thumbnail URLs.
- `POST /videos/{id}/view` accepts `install_id` (32 lowercase hex chars), `event_type` (`page` or `watch`), `view_event_id` (32 lowercase hex chars), and for watch events `watched_seconds` and `duration`.
  - Genuine `_phisk_views` increments at most once per app installation/video per 30 minutes.
  - Regular monetization mode credits the page-view event.
  - Verified monetization mode requires the configured watch percentage and a valid duration before crediting.
  - Existing monetization enablement, creator self-view exclusion, strike pause, rate limits and verified daily cooldown are enforced server-side.
- `POST /videos/{id}/like` requires a native bearer session and toggles the same user-meta and post-meta counters as the website.
- `POST /videos/{id}/download` requires a native bearer session and returns only the authorised original file URL configured in Video Manager. HLS playback manifests are not offered as downloads.
- `POST /videos/{id}/report` requires a native bearer session and accepts `reason` and optional `details`. It creates the same `phisk_report` moderation record as the website.

Report reasons: Spam or misleading; Hateful or abusive content; Harassment or bullying; Violence or dangerous content; Sexual or inappropriate content; Copyright infringement; Scam or fraud; Privacy violation; Something else.
