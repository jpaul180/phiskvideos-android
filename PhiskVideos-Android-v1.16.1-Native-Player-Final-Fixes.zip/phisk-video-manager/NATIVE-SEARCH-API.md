# Native Search API

Phisk Video Manager 1.19.0 exposes a public, read-only search endpoint for the PhiskVideos Android app.

`GET /wp-json/phisk/v1/search?q=<term>&type=<videos|stories|channels>&page=1&per_page=10`

- `videos`: published `phisk_video` content. Uses the same native video card payload as the watch API.
- `stories`: published WordPress Story posts, including the featured gallery image and creator profile data.
- `channels`: creator channels only; email addresses are never returned or searched.

The endpoint requires HTTPS, accepts search terms of at least two characters, and returns `items`, `total`, `total_pages`, and `has_more`. It is read-only and does not require an authenticated app session.
