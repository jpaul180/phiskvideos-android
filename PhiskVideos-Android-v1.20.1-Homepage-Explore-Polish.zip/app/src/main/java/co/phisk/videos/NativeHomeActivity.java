package co.phisk.videos;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Drawable;
import android.text.Html;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Native tabbed homepage. Feed ranking remains owned by the WordPress Algorithm plugin. */
public class NativeHomeActivity extends Activity {
    private static final String HOME="https://videos.phisk.co/";
    private static final String API=HOME+"wp-json/phisk-algorithm/v1/feeds/";
    private static final String ALGORITHM_API=HOME+"wp-json/phisk-algorithm/v1/";
    private static final int VIOLET=Color.rgb(124,58,237), DEEP=Color.rgb(109,40,217), INK=Color.rgb(25,29,38), MUTED=Color.rgb(112,117,128), BG=Color.rgb(247,248,250);
    private static final String[] FEEDS={"","for-you","top-stories","trending","discover","recommended"};
    private static final String[] LABELS={"Explore","For You","Top Stories","Trending","Discover","Recommended"};
    private final ExecutorService io=Executors.newFixedThreadPool(3);
    private final ExecutorService images=Executors.newFixedThreadPool(4);
    private final JSONArray[] data={new JSONArray(),new JSONArray(),new JSONArray(),new JSONArray(),new JSONArray(),new JSONArray()};
    private final int[] pages={1,1,1,1,1,1};
    private final boolean[] loaded={false,false,false,false,false,false};
    private final boolean[] more={false,true,true,true,true,true};
    private int active=0; private boolean loading=false;
    private boolean exploreConfigLoaded=false, exploreLoading=false;
    private JSONArray exploreSections=new JSONArray();
    private final java.util.HashSet<String> exploreSectionLoading=new java.util.HashSet<>();
    private LinearLayout root, tabStrip, feedList; private ScrollView feedScroll; private ProgressBar spinner, refreshIndicator; private TextView status;
    private float refreshTouchStartY=0f; private boolean refreshTriggered=false; private boolean refreshing=false; private static final int BORDER=Color.rgb(232,233,238); private static final int SKELETON=Color.rgb(238,239,243);
    private ImageView accountAvatar; private volatile int myCreatorId = 0; private volatile boolean myChannelKnown = false;
    private static final String AUTH_PREFS = "phisk_native_auth";

    @Override public void onCreate(Bundle state){PhiskTheme.configureActivityTheme(this);super.onCreate(state);getWindow().setStatusBarColor(Color.WHITE);getWindow().setNavigationBarColor(Color.WHITE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);build();selectTab(0);loadMyChannel();}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable shape(int color,int stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
    private TextView label(String value,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private void build(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(14),dp(10),dp(14),dp(10));header.setBackgroundColor(Color.WHITE);
        accountAvatar=new ImageView(this);accountAvatar.setScaleType(ImageView.ScaleType.CENTER_CROP);accountAvatar.setImageResource(R.drawable.ic_phisk_default_avatar);accountAvatar.setBackground(shape(Color.rgb(239,235,247),0,50));accountAvatar.setClipToOutline(true);
        LinearLayout.LayoutParams avatarParams=new LinearLayout.LayoutParams(dp(42),dp(42));avatarParams.rightMargin=dp(8);header.addView(accountAvatar,avatarParams);
        accountAvatar.setContentDescription("Your channel");accountAvatar.setOnClickListener(v->openMyChannel());
        TextView logo=label("▷",34,VIOLET,true);logo.setGravity(Gravity.CENTER);header.addView(logo,new LinearLayout.LayoutParams(dp(42),dp(48)));
        EditText search=new EditText(this);search.setSingleLine(true);search.setTextSize(15);search.setHint("Search videos, stories and channels...");search.setPadding(dp(14),0,dp(12),0);search.setBackground(shape(Color.WHITE,BORDER,10));search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(44),1);sp.leftMargin=dp(8);header.addView(search,sp);search.setOnEditorActionListener((v,action,event)->{if(action==EditorInfo.IME_ACTION_SEARCH){String q=search.getText().toString().trim();if(!q.isEmpty()){Intent searchIntent=new Intent(this,NativeSearchActivity.class);searchIntent.putExtra("search_query",q);startActivity(searchIntent);}return true;}return false;});
        root.addView(header);
        HorizontalScrollView tabs=new HorizontalScrollView(this);tabs.setHorizontalScrollBarEnabled(false);tabs.setBackgroundColor(Color.WHITE);tabStrip=new LinearLayout(this);tabStrip.setGravity(Gravity.CENTER_VERTICAL);tabStrip.setPadding(dp(12),dp(10),dp(12),dp(10));tabs.addView(tabStrip);for(int i=0;i<LABELS.length;i++)addTab(i);root.addView(tabs);
        View divider=new View(this);divider.setBackgroundColor(BORDER);root.addView(divider,new LinearLayout.LayoutParams(-1,dp(1)));
        FrameLayout body=new FrameLayout(this);feedScroll=new ScrollView(this);feedScroll.setFillViewport(true);feedList=new LinearLayout(this);feedList.setOrientation(LinearLayout.VERTICAL);feedList.setPadding(dp(14),dp(18),dp(14),dp(18));feedScroll.addView(feedList);body.addView(feedScroll,new FrameLayout.LayoutParams(-1,-1));spinner=new ProgressBar(this);FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(dp(34),dp(34),Gravity.TOP|Gravity.CENTER_HORIZONTAL);pp.topMargin=dp(18);body.addView(spinner,pp);spinner.setVisibility(View.GONE);refreshIndicator=new ProgressBar(this);refreshIndicator.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(VIOLET));FrameLayout.LayoutParams rp=new FrameLayout.LayoutParams(dp(28),dp(28),Gravity.TOP|Gravity.CENTER_HORIZONTAL);rp.topMargin=dp(8);body.addView(refreshIndicator,rp);refreshIndicator.setVisibility(View.GONE);root.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        feedScroll.setOnTouchListener((view,event)->{switch(event.getActionMasked()){case android.view.MotionEvent.ACTION_DOWN:refreshTouchStartY=event.getY();refreshTriggered=false;break;case android.view.MotionEvent.ACTION_MOVE:if(feedScroll.getScrollY()==0&&!refreshing&&event.getY()-refreshTouchStartY>dp(72)){refreshTriggered=true;}break;case android.view.MotionEvent.ACTION_UP:case android.view.MotionEvent.ACTION_CANCEL:if(refreshTriggered&&feedScroll.getScrollY()==0&&!refreshing){beginPullRefresh();}refreshTriggered=false;break;}return false;});
        View bottomDivider=new View(this);bottomDivider.setBackgroundColor(BORDER);root.addView(bottomDivider,new LinearLayout.LayoutParams(-1,dp(1)));root.addView(bottomBar());setContentView(root);
        feedScroll.setOnScrollChangeListener((View v,int sx,int sy,int oldx,int oldy)->{if(active!=0 && active!=2 && more[active] && !loading && sy+feedScroll.getHeight()>=feedList.getHeight()-dp(500))loadPage(active);});
    }
    private void addTab(int index){TextView t=label(LABELS[index],14,INK,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(17),dp(11),dp(17),dp(11));t.setBackground(shape(Color.WHITE,0,10));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,dp(42));p.rightMargin=dp(7);tabStrip.addView(t,p);t.setOnClickListener(v->selectTab(index));t.setTag("tab_"+index);}
    private void updateTabs(){for(int i=0;i<tabStrip.getChildCount();i++){TextView t=(TextView)tabStrip.getChildAt(i);boolean selected=i==active;t.setTextColor(selected?Color.WHITE:INK);t.setBackground(shape(selected?VIOLET:Color.WHITE,0,10));}}
    private LinearLayout bottomBar(){
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER);bar.setBackgroundColor(Color.WHITE);
        bar.setPadding(dp(5),dp(6),dp(5),dp(6));
        String[] names={"Home","Studio","Create","Activities","Settings"};
        int[] icons={R.drawable.phisk_home,R.drawable.phisk_studio,R.drawable.phisk_create,R.drawable.phisk_activities,R.drawable.phisk_settings};
        for(int i=0;i<names.length;i++){
            final int n=i; boolean selected=i==0;
            LinearLayout item=new LinearLayout(this);item.setOrientation(LinearLayout.VERTICAL);item.setGravity(Gravity.CENTER);
            ImageView icon=new ImageView(this);icon.setImageResource(icons[i]);icon.setColorFilter(selected?VIOLET:MUTED);
            item.addView(icon,new LinearLayout.LayoutParams(dp(23),dp(23)));
            TextView caption=label(names[i],11,selected?VIOLET:MUTED,true);caption.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=dp(3);item.addView(caption,cp);
            bar.addView(item,new LinearLayout.LayoutParams(0,dp(54),1));
            if(i!=0)item.setOnClickListener(v->{if(n==1)startActivity(new Intent(this,NativeCreatorStudioActivity.class));else if(n==2)startActivity(new Intent(this,NativeVideoUploadActivity.class));else if(n==3)startActivity(new Intent(this,NotificationCentreActivity.class));else startActivity(new Intent(this,NativeSettingsActivity.class));});
        }
        return bar;
    }
    private String authToken(){return getSharedPreferences(AUTH_PREFS,MODE_PRIVATE).getString("access_token","");}
    private JSONObject apiRequest(String path,String method,JSONObject payload)throws Exception{
        HttpURLConnection c=null;
        try{
            c=(HttpURLConnection)new URL(HOME+"wp-json/phisk/v1/"+path).openConnection();c.setRequestMethod(method);
            c.setConnectTimeout(12000);c.setReadTimeout(15000);c.setRequestProperty("Accept","application/json");
            String token=authToken();if(!token.isEmpty())c.setRequestProperty("Authorization","Bearer "+token);
            if(payload!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=UTF-8");try(java.io.OutputStream out=c.getOutputStream()){out.write(payload.toString().getBytes("UTF-8"));}}
            int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();
            ByteArrayOutputStream out=new ByteArrayOutputStream();if(in!=null){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);in.close();}
            String raw=out.toString("UTF-8");if(code<200||code>=300)throw new Exception(raw);return new JSONObject(raw);
        }finally{if(c!=null)c.disconnect();}
    }
    private void loadMyChannel(){
        if(authToken().isEmpty())return;
        io.execute(()->{
            try{
                JSONObject studio=apiRequest("creator-studio","GET",null);
                JSONObject creator=studio.optJSONObject("creator");if(creator==null)return;
                int id=creator.optInt("id",0);if(id<=0)return;
                JSONObject profile=apiRequest("creators/"+id,"GET",null);
                String avatar=profile.optString("avatar_url","");
                myCreatorId=id;myChannelKnown=true;
                if(profile.optBoolean("has_custom_avatar",false) && validImage(avatar))loadImage(accountAvatar,avatar);
                runOnUiThread(()->{if(loaded[active] && data[active].length()>0)renderItems(active);});
            }catch(Exception ignored){/* Keep the bundled default avatar when no channel/profile is available. */}
        });
    }
    private void openMyChannel(){
        if(myCreatorId>0){Intent i=new Intent(this,NativeCreatorChannelActivity.class);i.putExtra("creator_id",myCreatorId);startActivity(i);}
        else if(myChannelKnown){startActivity(new Intent(this,NativeCreatorChannelEditorActivity.class));}
        else{
            Toast.makeText(this,"Loading your channel…",Toast.LENGTH_SHORT).show();
            io.execute(()->{try{JSONObject studio=apiRequest("creator-studio","GET",null);JSONObject creator=studio.optJSONObject("creator");int id=creator==null?0:creator.optInt("id",0);if(id>0){myCreatorId=id;runOnUiThread(()->openMyChannel());}else runOnUiThread(()->startActivity(new Intent(this,NativeCreatorChannelEditorActivity.class)));}catch(Exception e){runOnUiThread(()->startActivity(new Intent(this,NativeCreatorChannelEditorActivity.class)));}});
        }
    }
    private void subscribeToCreator(JSONObject creator, TextView button){
        int creatorId=creator.optInt("id",0);if(creatorId<=0){Toast.makeText(this,"Creator channel unavailable.",Toast.LENGTH_SHORT).show();return;}
        boolean wasFollowed=creator.optBoolean("is_followed",false);button.setEnabled(false);
        io.execute(()->{try{JSONObject body=new JSONObject();body.put("action",wasFollowed?"unsubscribe":"subscribe");JSONObject response=apiRequest("creators/"+creatorId+"/subscribe","POST",body);boolean subscribed=response.optBoolean("subscribed",!wasFollowed);
            creator.put("is_followed",subscribed);
            runOnUiThread(()->{button.setText(subscribed?"Subscribed":"Subscribe");button.setBackground(shape(subscribed?Color.rgb(244,240,251):VIOLET,subscribed?Color.rgb(225,216,242):0,6));button.setTextColor(subscribed?VIOLET:Color.WHITE);button.setEnabled(true);});
        }catch(Exception e){runOnUiThread(()->{button.setEnabled(true);Toast.makeText(this,"Couldn't update subscription. Please try again.",Toast.LENGTH_SHORT).show();});}});
    }
    private void selectTab(int index){active=index;updateTabs();feedList.removeAllViews();feedScroll.scrollTo(0,0);if(index==0){if(exploreConfigLoaded)renderExplore();else loadExplore();}else if(index==2){loaded[index]=true;showTopStoriesPending();}else if(loaded[index])renderItems(index);else loadPage(index);}

    private JSONObject algorithmGet(String path)throws Exception{
        HttpURLConnection c=null;
        try{
            c=(HttpURLConnection)new URL(ALGORITHM_API+path).openConnection();c.setRequestMethod("GET");
            c.setConnectTimeout(15000);c.setReadTimeout(20000);c.setRequestProperty("Accept","application/json");
            String access=token();if(!access.isEmpty())c.setRequestProperty("Authorization","Bearer "+access);
            int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();
            ByteArrayOutputStream out=new ByteArrayOutputStream();if(in!=null){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);in.close();}
            if(code<200||code>=300)throw new Exception("Server returned "+code+": "+out.toString("UTF-8"));
            return new JSONObject(out.toString("UTF-8"));
        }finally{if(c!=null)c.disconnect();}
    }
    private void beginPullRefresh(){
        if(refreshing||loading||exploreLoading)return;refreshing=true;refreshIndicator.setVisibility(View.VISIBLE);
        refreshIndicator.animate().alpha(1f).setDuration(120).start();
        feedScroll.postDelayed(()->{
            if(active==0){exploreConfigLoaded=false;exploreSections=new JSONArray();exploreSectionLoading.clear();loadExplore();}
            else if(active==2){showTopStoriesPending();finishPullRefresh();}
            else{data[active]=new JSONArray();pages[active]=1;loaded[active]=false;more[active]=true;loading=false;loadPage(active);}
        },120);
    }
    private void finishPullRefresh(){refreshing=false;refreshIndicator.animate().alpha(0f).setDuration(180).withEndAction(()->refreshIndicator.setVisibility(View.GONE)).start();}
    private View skeletonBlock(int width,int height,int radius){View v=new View(this);v.setBackground(shape(SKELETON,0,radius));v.setLayoutParams(new LinearLayout.LayoutParams(width<0?width:dp(width),height<0?height:dp(height)));android.view.animation.AlphaAnimation pulse=new android.view.animation.AlphaAnimation(.58f,1f);pulse.setDuration(850);pulse.setRepeatMode(android.view.animation.Animation.REVERSE);pulse.setRepeatCount(android.view.animation.Animation.INFINITE);v.startAnimation(pulse);return v;}
    private void showExploreSkeleton(){
        feedList.removeAllViews();feedList.addView(skeletonBlock(138,27,6));View subtitle=skeletonBlock(-1,13,5);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(13));sp.topMargin=dp(10);sp.bottomMargin=dp(26);feedList.addView(subtitle,sp);
        for(int section=0;section<3;section++){LinearLayout group=new LinearLayout(this);group.setOrientation(LinearLayout.VERTICAL);LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,-2);gp.bottomMargin=dp(24);feedList.addView(group,gp);group.addView(skeletonBlock(150,18,5));LinearLayout row=new LinearLayout(this);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.topMargin=dp(12);group.addView(row,rp);for(int i=0;i<2;i++){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setBackground(shape(Color.WHITE,BORDER,8));card.setPadding(dp(5),dp(5),dp(5),dp(8));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(258),dp(220));cp.rightMargin=dp(12);row.addView(card,cp);card.addView(skeletonBlock(-1,135,6));View line=skeletonBlock(145,10,4);LinearLayout.LayoutParams lp=(LinearLayout.LayoutParams)line.getLayoutParams();lp.topMargin=dp(12);card.addView(line,lp);View line2=skeletonBlock(205,12,4);LinearLayout.LayoutParams l2=(LinearLayout.LayoutParams)line2.getLayoutParams();l2.topMargin=dp(8);card.addView(line2,l2);}}}
    private void showFeedSkeleton(){feedList.removeAllViews();for(int i=0;i<3;i++){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(8),dp(8),dp(8),dp(12));card.setBackground(shape(Color.WHITE,BORDER,10));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=dp(14);feedList.addView(card,cp);card.addView(skeletonBlock(-1,195,8));LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.topMargin=dp(12);card.addView(row,rp);View avatar=skeletonBlock(44,44,30);row.addView(avatar);LinearLayout lines=new LinearLayout(this);lines.setOrientation(LinearLayout.VERTICAL);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.leftMargin=dp(12);row.addView(lines,lp);lines.addView(skeletonBlock(190,14,5));View second=skeletonBlock(120,11,5);LinearLayout.LayoutParams s2=new LinearLayout.LayoutParams(-2,dp(11));s2.topMargin=dp(8);lines.addView(second,s2);}}
    private void loadExplore(){
        if(exploreLoading)return;exploreLoading=true;spinner.setVisibility(View.GONE);showExploreSkeleton();
        io.execute(()->{try{
            JSONObject response=algorithmGet("explore/config");JSONArray sections=response.optJSONArray("sections");if(sections==null)sections=new JSONArray();
            final JSONArray result=sections;
            runOnUiThread(()->{exploreLoading=false;finishPullRefresh();exploreConfigLoaded=true;exploreSections=result;renderExplore();});
        }catch(Exception e){runOnUiThread(()->{exploreLoading=false;finishPullRefresh();showExploreError();});}});
    }
    private void renderExplore(){
        if(active!=0)return;feedList.removeAllViews();
        TextView heading=label("Explore",26,INK,true);feedList.addView(heading);
        TextView subtitle=label("Discover videos across PhiskVideos.",15,MUTED,false);LinearLayout.LayoutParams subp=new LinearLayout.LayoutParams(-1,-2);subp.topMargin=dp(7);subp.bottomMargin=dp(28);feedList.addView(subtitle,subp);
        if(exploreSections.length()==0){showEmpty("No Explore sections are available yet.");return;}
        for(int i=0;i<exploreSections.length();i++){
            JSONObject section=exploreSections.optJSONObject(i);if(section!=null)addExploreSection(section);
        }
    }
    private void addExploreSection(JSONObject section){
        String id=section.optString("id",""),titleText=section.optString("title","Videos");
        String slug=section.optString("category_slug","");String categoryName=section.optString("category_name",titleText);
        String categoryDescription=section.optString("category_description","");
        String sort=section.optString("sort","latest");
        LinearLayout block=new LinearLayout(this);block.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.bottomMargin=dp(28);feedList.addView(block,bp);
        LinearLayout headingRow=new LinearLayout(this);headingRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=label(titleText,19,INK,true);headingRow.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        TextView viewMore=label("View More   →",14,INK,true);viewMore.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);viewMore.setPadding(dp(8),dp(8),0,dp(8));headingRow.addView(viewMore);
        viewMore.setOnClickListener(v->{Intent intent=new Intent(this,NativeCategoryActivity.class);intent.putExtra("category_slug",slug);intent.putExtra("category_name",categoryName);intent.putExtra("category_description",categoryDescription);intent.putExtra("category_sort",sort);startActivity(intent);});
        block.addView(headingRow);
        HorizontalScrollView horizontal=new HorizontalScrollView(this);horizontal.setHorizontalScrollBarEnabled(false);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=dp(12);block.addView(horizontal,hp);
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);horizontal.addView(row);
        String key=id;
        if(!exploreSectionLoading.contains(key)){
            exploreSectionLoading.add(key);
            io.execute(()->{try{
                JSONObject response=algorithmGet("explore/sections/"+Uri.encode(id)+"?page=1&per_page="+Math.max(1,Math.min(20,section.optInt("limit",10))));
                JSONArray items=response.optJSONArray("items");if(items==null)items=new JSONArray();final JSONArray result=items;
                runOnUiThread(()->{exploreSectionLoading.remove(key);if(active==0){int pos=findExploreSection(id);if(pos>=0)replaceExploreSectionCards(pos,result);}});
            }catch(Exception e){runOnUiThread(()->{exploreSectionLoading.remove(key);});}});
        }
        for(int sk=0;sk<2;sk++){LinearLayout skeleton=new LinearLayout(this);skeleton.setOrientation(LinearLayout.VERTICAL);skeleton.setPadding(dp(5),dp(5),dp(5),dp(8));skeleton.setBackground(shape(Color.WHITE,BORDER,8));LinearLayout.LayoutParams skp=new LinearLayout.LayoutParams(dp(258),dp(220));skp.rightMargin=dp(12);row.addView(skeleton,skp);skeleton.addView(skeletonBlock(-1,135,6));View a=skeletonBlock(150,10,4);LinearLayout.LayoutParams ap=(LinearLayout.LayoutParams)a.getLayoutParams();ap.topMargin=dp(12);skeleton.addView(a,ap);View b=skeletonBlock(205,12,4);LinearLayout.LayoutParams bp2=(LinearLayout.LayoutParams)b.getLayoutParams();bp2.topMargin=dp(8);skeleton.addView(b,bp2);}
        block.setTag("explore_"+id);
    }
    private int findExploreSection(String id){for(int i=0;i<feedList.getChildCount();i++){View v=feedList.getChildAt(i);if(v.getTag()!=null&&("explore_"+id).equals(v.getTag()))return i;}return -1;}
    private void replaceExploreSectionCards(int blockIndex,JSONArray items){
        LinearLayout block=(LinearLayout)feedList.getChildAt(blockIndex);
        if(block.getChildCount()<2)return;
        HorizontalScrollView horizontal=(HorizontalScrollView)block.getChildAt(1);
        LinearLayout row=(LinearLayout)horizontal.getChildAt(0);row.removeAllViews();
        if(items.length()==0){TextView empty=label("No videos available yet.",13,MUTED,false);empty.setPadding(dp(4),dp(20),dp(4),dp(20));row.addView(empty);return;}
        for(int i=0;i<items.length();i++){JSONObject item=items.optJSONObject(i);if(item!=null)addExploreVideoCard(row,item);}
    }
    private void addExploreVideoCard(LinearLayout row,JSONObject item){
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(shape(Color.WHITE,BORDER,8));card.setClipToOutline(true);
        // Fixed height keeps every carousel card aligned; the title is limited to two lines.
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(258),dp(232));cp.rightMargin=dp(12);row.addView(card,cp);

        FrameLayout media=new FrameLayout(this);media.setBackgroundColor(Color.rgb(24,24,27));media.setClipToOutline(true);
        card.addView(media,new LinearLayout.LayoutParams(-1,dp(145)));
        ImageView thumb=new ImageView(this);thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);media.addView(thumb,new FrameLayout.LayoutParams(-1,-1));
        String thumbUrl=item.optString("thumbnail_url","");if(validImage(thumbUrl))loadImage(thumb,thumbUrl);

        TextView duration=label(item.optString("runtime",""),11,Color.WHITE,true);
        duration.setPadding(dp(6),dp(4),dp(6),dp(4));duration.setBackground(shape(Color.rgb(20,20,20),0,5));
        FrameLayout.LayoutParams dur=new FrameLayout.LayoutParams(-2,-2,Gravity.RIGHT|Gravity.BOTTOM);
        dur.setMargins(0,0,dp(7),dp(7));media.addView(duration,dur);
        if(duration.getText().length()==0)duration.setVisibility(View.GONE);

        // Circular avatar sits in a white padded frame so square source images are clipped cleanly.
        FrameLayout avatarFrame=new FrameLayout(this);
        avatarFrame.setBackground(shape(Color.WHITE,Color.WHITE,30));avatarFrame.setClipToOutline(true);avatarFrame.setPadding(dp(2),dp(2),dp(2),dp(2));
        FrameLayout.LayoutParams av=new FrameLayout.LayoutParams(dp(44),dp(44),Gravity.LEFT|Gravity.BOTTOM);
        av.setMargins(dp(10),0,0,dp(6));media.addView(avatarFrame,av);
        ImageView avatar=new ImageView(this);avatar.setImageResource(R.drawable.ic_phisk_default_avatar);
        avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);avatar.setBackground(shape(Color.WHITE,0,30));avatar.setClipToOutline(true);
        avatarFrame.addView(avatar,new FrameLayout.LayoutParams(-1,-1));

        JSONObject creator=item.optJSONObject("creator");
        String creatorName=creator==null?"Creator":decodeText(creator.optString("name","Creator"));
        String avatarUrl=creator==null?"":creator.optString("avatar_url","");
        if(validImage(avatarUrl))loadImage(avatar,avatarUrl);

        ImageView share=new ImageView(this);share.setImageResource(R.drawable.phisk_share_white);
        share.setScaleType(ImageView.ScaleType.CENTER_INSIDE);share.setPadding(dp(8),dp(8),dp(8),dp(8));
        share.setBackground(shape(Color.argb(85,0,0,0),0,18));share.setContentDescription("Share video");
        FrameLayout.LayoutParams shareParams=new FrameLayout.LayoutParams(dp(38),dp(38),Gravity.RIGHT|Gravity.TOP);
        shareParams.setMargins(0,dp(7),dp(7),0);media.addView(share,shareParams);
        share.setOnClickListener(v->shareVideo(item));

        LinearLayout meta=new LinearLayout(this);meta.setGravity(Gravity.CENTER_VERTICAL);
        meta.setPadding(dp(10),0,dp(10),0);card.addView(meta,new LinearLayout.LayoutParams(-1,dp(32)));
        TextView by=label("By: "+creatorName+"  |  "+item.optInt("views",0)+" Views",11,MUTED,false);
        by.setSingleLine(true);by.setEllipsize(android.text.TextUtils.TruncateAt.END);
        meta.addView(by,new LinearLayout.LayoutParams(-1,-2));

        TextView title=label(decodeText(item.optString("title","Untitled video")),14,INK,true);
        title.setMaxLines(2);title.setEllipsize(android.text.TextUtils.TruncateAt.END);title.setGravity(Gravity.TOP);
        title.setPadding(dp(10),dp(3),dp(10),0);
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,dp(48));
        card.addView(title,tp);

        View.OnClickListener open=v->openNativePlayer(item);media.setOnClickListener(open);title.setOnClickListener(open);
        if(creator!=null){
            View.OnClickListener openCreator=v->{int creatorId=creator.optInt("id",0);if(creatorId>0){Intent ch=new Intent(this,NativeCreatorChannelActivity.class);ch.putExtra("creator_id",creatorId);startActivity(ch);}};
            avatarFrame.setOnClickListener(openCreator);avatar.setOnClickListener(openCreator);
        }
    }
    private void showExploreError(){
        feedList.removeAllViews();TextView h=label("Explore",26,INK,true);feedList.addView(h);
        TextView msg=label("Couldn't load Explore. Check your connection and try again.",14,MUTED,false);msg.setPadding(0,dp(12),0,dp(12));feedList.addView(msg);
        TextView retry=label("Try again",14,VIOLET,true);feedList.addView(retry);retry.setOnClickListener(v->loadExplore());
    }
    private String token(){return getSharedPreferences("phisk_native_auth",MODE_PRIVATE).getString("access_token","");}
    private void loadPage(int index){if(index==0||index==2||loading||!more[index])return;loading=true;spinner.setVisibility(View.GONE);if(data[index].length()==0)showFeedSkeleton();final int page=pages[index];io.execute(()->{HttpURLConnection c=null;try{String url=API+FEEDS[index]+"?page="+page+"&per_page=10";c=(HttpURLConnection)new URL(url).openConnection();c.setRequestMethod("GET");c.setConnectTimeout(15000);c.setReadTimeout(20000);c.setRequestProperty("Accept","application/json");String access=token();if(!access.isEmpty())c.setRequestProperty("Authorization","Bearer "+access);int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();ByteArrayOutputStream out=new ByteArrayOutputStream();if(in!=null){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);in.close();}if(code<200||code>=300)throw new Exception("Server returned "+code);JSONObject response=new JSONObject(out.toString("UTF-8"));if(!response.optBoolean("success"))throw new Exception("Feed request was not successful");JSONArray items=response.optJSONArray("items");if(items==null)items=new JSONArray();final JSONArray result=items;final boolean hasMore=response.optBoolean("has_more",false);runOnUiThread(()->{loading=false;spinner.setVisibility(View.GONE);finishPullRefresh();loaded[index]=true;pages[index]=page+1;more[index]=hasMore;for(int i=0;i<result.length();i++)data[index].put(result.opt(i));if(active==index)renderItems(index);});}catch(Exception e){runOnUiThread(()->{loading=false;spinner.setVisibility(View.GONE);finishPullRefresh();if(active==index)showError(index,"Couldn't load this feed. Check your connection and try again.");});}finally{if(c!=null)c.disconnect();}});}
    private void renderItems(int index){feedList.removeAllViews();if(data[index].length()==0){showEmpty("No videos to show yet.");return;}for(int i=0;i<data[index].length();i++){JSONObject item=data[index].optJSONObject(i);if(item!=null)addVideoCard(item);}if(more[index]){TextView moreLabel=label("Loading more videos…",12,MUTED,false);moreLabel.setGravity(Gravity.CENTER);moreLabel.setPadding(0,dp(16),0,dp(18));feedList.addView(moreLabel);}}
    private void addVideoCard(JSONObject item){
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(10),dp(10),dp(10),dp(12));card.setBackground(shape(Color.WHITE,BORDER,10));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=dp(14);feedList.addView(card,cp);
        FrameLayout media=new FrameLayout(this);media.setBackground(shape(Color.rgb(24,24,27),0,12));media.setClipToOutline(true);ImageView thumb=new ImageView(this);thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);media.addView(thumb,new FrameLayout.LayoutParams(-1,dp(205)));String thumbUrl=item.optString("thumbnail_url","");if(validImage(thumbUrl))loadImage(thumb,thumbUrl);
        TextView duration=label(item.optString("runtime",""),12,Color.WHITE,true);duration.setPadding(dp(7),dp(4),dp(7),dp(4));duration.setBackground(shape(Color.rgb(20,20,20),0,5));FrameLayout.LayoutParams dur=new FrameLayout.LayoutParams(-2,-2,Gravity.RIGHT|Gravity.BOTTOM);dur.setMargins(0,0,dp(8),dp(8));media.addView(duration,dur);
        TextView age=label(item.optString("published_ago",""),11,Color.WHITE,true);age.setPadding(dp(7),dp(4),dp(7),dp(4));age.setBackground(shape(Color.rgb(20,20,20),0,5));FrameLayout.LayoutParams ag=new FrameLayout.LayoutParams(-2,-2,Gravity.LEFT|Gravity.BOTTOM);ag.setMargins(dp(8),0,0,dp(8));media.addView(age,ag);
        ImageView share=new ImageView(this);share.setImageResource(R.drawable.phisk_share_white);share.setScaleType(ImageView.ScaleType.CENTER_INSIDE);share.setPadding(dp(8),dp(8),dp(8),dp(8));share.setBackground(shape(Color.argb(75,0,0,0),0,18));share.setContentDescription("Share video");FrameLayout.LayoutParams shareParams=new FrameLayout.LayoutParams(dp(36),dp(38),Gravity.RIGHT|Gravity.TOP);shareParams.setMargins(0,dp(4),dp(4),0);media.addView(share,shareParams);
        share.setOnClickListener(v->shareVideo(item));
        card.addView(media);
        LinearLayout details=new LinearLayout(this);details.setOrientation(LinearLayout.HORIZONTAL);details.setGravity(Gravity.TOP);details.setPadding(0,dp(12),0,0);
        ImageView avatar=new ImageView(this);avatar.setImageResource(R.drawable.ic_phisk_default_avatar);avatar.setBackground(shape(Color.rgb(239,235,247),0,40));avatar.setClipToOutline(true);LinearLayout.LayoutParams avp=new LinearLayout.LayoutParams(dp(48),dp(48));avp.rightMargin=dp(11);details.addView(avatar,avp);
        JSONObject creator=item.optJSONObject("creator");String creatorName=creator==null?"Creator":decodeText(creator.optString("name","Creator"));String avatarUrl=creator==null?"":creator.optString("avatar_url","");if(creator!=null&&validImage(avatarUrl))loadImage(avatar,avatarUrl);
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);details.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
        TextView title=label(truncateHomepageTitle(decodeText(item.optString("title","Untitled video"))),17,INK,true);title.setMaxLines(3);copy.addView(title);
        LinearLayout metaRow=new LinearLayout(this);metaRow.setOrientation(LinearLayout.HORIZONTAL);metaRow.setGravity(Gravity.CENTER_VERTICAL);LinearLayout.LayoutParams metaRowParams=new LinearLayout.LayoutParams(-1,-2);metaRowParams.topMargin=dp(7);copy.addView(metaRow,metaRowParams);
        TextView meta=label(creatorName+"  ·  "+item.optInt("views",0)+" views",13,MUTED,false);meta.setSingleLine(true);meta.setEllipsize(android.text.TextUtils.TruncateAt.END);metaRow.addView(meta,new LinearLayout.LayoutParams(0,-2,1));
        boolean followed=creator!=null&&creator.optBoolean("is_followed");
        TextView subscribe=label(followed?"Subscribed":"Subscribe",12,followed?VIOLET:Color.WHITE,true);
        subscribe.setGravity(Gravity.CENTER);subscribe.setSingleLine(true);subscribe.setPadding(dp(11),dp(5),dp(11),dp(5));subscribe.setBackground(shape(followed?Color.rgb(244,240,251):VIOLET,followed?Color.rgb(225,216,242):0,6));
        LinearLayout.LayoutParams subp=new LinearLayout.LayoutParams(-2,dp(30));subp.leftMargin=dp(8);metaRow.addView(subscribe,subp);
        if(creator==null||creator.optInt("id",0)<=0||(myCreatorId>0&&creator.optInt("id",0)==myCreatorId)){subscribe.setEnabled(false);subscribe.setVisibility(View.GONE);}
        else subscribe.setOnClickListener(v->subscribeToCreator(creator,subscribe));
        card.addView(details);
        View.OnClickListener open=v->openNativePlayer(item);media.setOnClickListener(open);title.setOnClickListener(open);
        View.OnClickListener openCreator=v->{if(creator!=null){int creatorId=creator.optInt("id",0);if(creatorId>0){Intent channel=new Intent(this,NativeCreatorChannelActivity.class);channel.putExtra("creator_id",creatorId);startActivity(channel);}else openWeb(creator.optString("profile_url",HOME));}};
        avatar.setOnClickListener(openCreator);meta.setOnClickListener(openCreator);
    }
    // Homepage titles are limited to 60 displayed characters, including the ellipsis.
    private String truncateHomepageTitle(String value){
        if(value==null)return "";
        int count=value.codePointCount(0,value.length());
        if(count<=60)return value;
        int end=value.offsetByCodePoints(0,59);
        return value.substring(0,end).trim()+"…";
    }
    private String decodeText(String value){
        if(value==null)return "";String decoded=value;
        for(int i=0;i<2;i++){if(decoded.contains("&")&&decoded.contains(";"))decoded=Html.fromHtml(decoded,Html.FROM_HTML_MODE_LEGACY).toString();else break;}
        return decoded;
    }
    private void shareVideo(JSONObject item){
        String url=item.optString("permalink","");if(url==null||!url.startsWith("https://videos.phisk.co/"))url=HOME;
        String title=decodeText(item.optString("title","Watch on PhiskVideos"));
        Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(Intent.EXTRA_SUBJECT,title);send.putExtra(Intent.EXTRA_TEXT,title+"\n"+url);
        startActivity(Intent.createChooser(send,"Share video"));
    }
    private void openNativePlayer(JSONObject item){
        int id=item.optInt("id",0);
        if(id<=0){new AlertDialog.Builder(this).setTitle("Video unavailable").setMessage("This feed item is missing its video ID. Please refresh the feed.").setPositiveButton("OK",null).show();return;}
        Intent intent=new Intent(this,NativePlayerActivity.class);
        intent.putExtra("video_id",id);
        startActivity(intent);
    }
    private boolean validImage(String value){try{Uri u=Uri.parse(value);return "https".equalsIgnoreCase(u.getScheme())&&u.getHost()!=null;}catch(Exception e){return false;}}
    private void loadImage(ImageView target,String value){images.execute(()->{HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(value).openConnection();c.setConnectTimeout(8000);c.setReadTimeout(10000);c.setRequestProperty("User-Agent","PhiskVideosAndroid/1.6.0");Bitmap bitmap=BitmapFactory.decodeStream(c.getInputStream());if(bitmap!=null)runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())target.setImageBitmap(bitmap);});}catch(Exception ignored){}finally{if(c!=null)c.disconnect();}});}
    private void showTopStoriesPending(){feedList.removeAllViews();TextView h=label("Top Stories",22,INK,true);feedList.addView(h);TextView m=label("Top Stories will appear here once its dedicated Video Manager feed endpoint is connected.",14,MUTED,false);m.setPadding(0,dp(9),0,0);feedList.addView(m);}
    private void showEmpty(String message){TextView t=label(message,14,MUTED,false);t.setGravity(Gravity.CENTER);t.setPadding(dp(20),dp(55),dp(20),dp(55));feedList.addView(t);}
    private void showError(int index,String message){feedList.removeAllViews();TextView t=label(message,14,MUTED,false);t.setGravity(Gravity.CENTER);t.setPadding(dp(18),dp(40),dp(18),dp(18));feedList.addView(t);TextView retry=label("Try again",14,VIOLET,true);retry.setGravity(Gravity.CENTER);feedList.addView(retry);retry.setOnClickListener(v->{loaded[index]=false;loadPage(index);});}
    private void openWeb(String url){Intent i=new Intent(this,MainActivity.class);i.putExtra(MainActivity.EXTRA_NOTIFICATION_URL,url);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(i);finish();}
    @Override public void onBackPressed(){super.onBackPressed();}
    @Override protected void onDestroy(){io.shutdownNow();images.shutdownNow();super.onDestroy();}
    @Override protected void onResume(){super.onResume();PhiskTheme.apply(this);}
}
