# PhiskVideos Android v1.24.2 — Phisk Cache Stage 3

- Advances Android version to 1.24.2 (versionCode 60).
- Manifest synchronization now records last successful sync time, HTTP status, manifest version and bounded prefetch count.
- On a changed/updated manifest response, the app queues up to 30 public category images and up to 30 public featured-image assets for background cache warming.
- Adds public image prefetch and disk-cache byte diagnostics to the shared image cache.
- Continues to use ETag / If-None-Match and preserves the last usable manifest when offline.
- Does not cache personalized recommendations, account data, notifications or private user content.
- Image cache remains separate from downloaded offline videos; the existing 80 MB image-cache cap and 24-hour freshness policy remain in place.

Build validation is performed by the repository's GitHub Actions workflow.
