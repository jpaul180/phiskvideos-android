package co.phisk.videos;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Native category archive backed by the shared Phisk Algorithm category feed API. */
public class NativeCategoryActivity extends Activity {
    private static final String API="https://videos.phisk.co/wp-json/phisk-algorithm/v1/";
    private static final int VIOLET=Color.rgb(124,58,237), INK=Color.rgb(25,29,38), MUTED=Color.rgb(112,117,128), BG=Color.rgb(247,248,250);
    private final ExecutorService io=Executors.newFixedThreadPool(3), images=Executors.newFixedThreadPool(4);
    private LinearLayout list,sortRow; private ScrollView scroll; private ProgressBar progress;
    private String slug="",sort="latest",name="",description=""; private int page=1; private boolean hasMore=true,loading=false;
    @Override public void onCreate(Bundle state){PhiskTheme.configureActivityTheme(this);super.onCreate(state);slug=getIntent().getStringExtra("category_slug");name=getIntent().getStringExtra("category_name");description=getIntent().getStringExtra("category_description");sort=getIntent().getStringExtra("category_sort");if(sort==null||sort.isEmpty())sort="latest";if(slug==null||slug.isEmpty()){finish();return;}build();load();}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable shape(int color,int stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
    private TextView text(String value,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private void build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
        LinearLayout toolbar=new LinearLayout(this);toolbar.setGravity(Gravity.CENTER_VERTICAL);toolbar.setPadding(dp(14),dp(10),dp(14),dp(10));toolbar.setBackgroundColor(Color.WHITE);
        TextView back=text("‹",34,INK,false);back.setGravity(Gravity.CENTER);toolbar.addView(back,new LinearLayout.LayoutParams(dp(42),dp(42)));back.setOnClickListener(v->finish());
        TextView heading=text(name==null?"Category":name,19,INK,true);heading.setMaxLines(1);heading.setEllipsize(android.text.TextUtils.TruncateAt.END);LinearLayout.LayoutParams h=new LinearLayout.LayoutParams(0,-2,1);h.leftMargin=dp(8);toolbar.addView(heading,h);root.addView(toolbar);
        LinearLayout intro=new LinearLayout(this);intro.setOrientation(LinearLayout.VERTICAL);intro.setPadding(dp(18),dp(20),dp(18),dp(12));TextView title=text(name==null?"Category":name,25,INK,true);intro.addView(title);TextView desc=text(description==null?"":description,14,MUTED,false);LinearLayout.LayoutParams d=new LinearLayout.LayoutParams(-1,-2);d.topMargin=dp(7);intro.addView(desc,d);root.addView(intro);
        sortRow=new LinearLayout(this);sortRow.setPadding(dp(14),dp(6),dp(14),dp(10));sortRow.setGravity(Gravity.CENTER_VERTICAL);root.addView(sortRow);addSort("Latest","latest");addSort("Popular","popular");addSort("Trending","trending");
        FrameLayout body=new FrameLayout(this);scroll=new ScrollView(this);scroll.setFillViewport(true);list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setPadding(dp(14),dp(8),dp(14),dp(20));scroll.addView(list);body.addView(scroll,new FrameLayout.LayoutParams(-1,-1));progress=new ProgressBar(this);FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(dp(36),dp(36),Gravity.TOP|Gravity.CENTER_HORIZONTAL);pp.topMargin=dp(14);body.addView(progress,pp);root.addView(body,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
        scroll.setOnScrollChangeListener((View v,int x,int y,int ox,int oy)->{if(hasMore&&!loading&&y+scroll.getHeight()>=list.getHeight()-dp(400))load();});
        updateSort();
    }
    private void addSort(String label,String value){TextView b=text(label,13,INK,true);b.setGravity(Gravity.CENTER);b.setPadding(dp(15),dp(8),dp(15),dp(8));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,-2);p.rightMargin=dp(8);sortRow.addView(b,p);b.setTag(value);b.setOnClickListener(v->{String next=(String)v.getTag();if(!sort.equals(next)){sort=next;page=1;hasMore=true;list.removeAllViews();updateSort();load();}});}
    private void updateSort(){for(int i=0;i<sortRow.getChildCount();i++){TextView b=(TextView)sortRow.getChildAt(i);boolean selected=sort.equals(b.getTag());b.setTextColor(selected?Color.WHITE:INK);b.setBackground(shape(selected?VIOLET:Color.WHITE,selected?0:Color.rgb(225,226,231),18));}}
    private void load(){if(loading||!hasMore)return;loading=true;progress.setVisibility(View.VISIBLE);final int requested=page;io.execute(()->{HttpURLConnection c=null;try{
        String url=API+"categories/"+URLEncoder.encode(slug,"UTF-8")+"/videos?sort="+URLEncoder.encode(sort,"UTF-8")+"&page="+requested+"&per_page=10";c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(15000);c.setReadTimeout(20000);c.setRequestProperty("Accept","application/json");int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();ByteArrayOutputStream out=new ByteArrayOutputStream();if(in!=null){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);in.close();}if(code<200||code>=300)throw new Exception("Server returned "+code);JSONObject response=new JSONObject(out.toString("UTF-8"));JSONArray items=response.optJSONArray("items");if(items==null)items=new JSONArray();JSONObject category=response.optJSONObject("category");final JSONArray result=items;final boolean next=response.optBoolean("has_more",false);final String actualName=category==null?name:category.optString("name",name);final String actualDescription=category==null?description:category.optString("description",description);
        runOnUiThread(()->{loading=false;progress.setVisibility(View.GONE);name=actualName;description=actualDescription;hasMore=next;page=requested+1;if(requested==1&&result.length()==0)empty();else for(int i=0;i<result.length();i++){JSONObject item=result.optJSONObject(i);if(item!=null)addCard(item);}});
    }catch(Exception e){runOnUiThread(()->{loading=false;progress.setVisibility(View.GONE);if(list.getChildCount()==0){TextView error=text("Couldn't load videos. Check your connection and try again.",14,MUTED,false);error.setPadding(dp(16),dp(30),dp(16),dp(20));list.addView(error);TextView retry=text("Try again",14,VIOLET,true);list.addView(retry);retry.setOnClickListener(v->{list.removeAllViews();load();});}});}finally{if(c!=null)c.disconnect();}});}
    private void empty(){TextView e=text("No videos in this category yet.",14,MUTED,false);e.setGravity(Gravity.CENTER);e.setPadding(dp(15),dp(55),dp(15),dp(55));list.addView(e);}
    private void addCard(JSONObject item){
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(8),dp(8),dp(8),dp(10));card.setBackground(shape(Color.WHITE,Color.rgb(229,230,234),13));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=dp(13);list.addView(card,cp);
        FrameLayout media=new FrameLayout(this);media.setClipToOutline(true);media.setBackground(shape(Color.rgb(24,24,27),0,10));card.addView(media,new LinearLayout.LayoutParams(-1,dp(190)));
        ImageView thumb=new ImageView(this);thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);media.addView(thumb,new FrameLayout.LayoutParams(-1,-1));String image=item.optString("thumbnail_url","");if(validImage(image))loadImage(thumb,image);
        JSONObject creator=item.optJSONObject("creator");String creatorName=creator==null?"Creator":creator.optString("name","Creator");String avatar=creator==null?"":creator.optString("avatar_url","");ImageView av=new ImageView(this);av.setImageResource(R.drawable.ic_phisk_default_avatar);av.setScaleType(ImageView.ScaleType.CENTER_CROP);av.setBackground(shape(Color.WHITE,Color.WHITE,30));av.setPadding(dp(2),dp(2),dp(2),dp(2));av.setClipToOutline(true);FrameLayout.LayoutParams ap=new FrameLayout.LayoutParams(dp(42),dp(42),Gravity.LEFT|Gravity.BOTTOM);ap.setMargins(dp(10),0,0,dp(8));media.addView(av,ap);if(validImage(avatar))loadImage(av,avatar);
        TextView duration=text(item.optString("runtime",""),11,Color.WHITE,true);duration.setPadding(dp(6),dp(4),dp(6),dp(4));duration.setBackground(shape(Color.rgb(20,20,20),0,5));FrameLayout.LayoutParams dpms=new FrameLayout.LayoutParams(-2,-2,Gravity.RIGHT|Gravity.BOTTOM);dpms.setMargins(0,0,dp(8),dp(8));media.addView(duration,dpms);if(duration.getText().length()==0)duration.setVisibility(View.GONE);
        LinearLayout meta=new LinearLayout(this);meta.setPadding(dp(8),dp(10),dp(8),dp(2));TextView m=text("By: "+creatorName+"  |  "+item.optInt("views",0)+" Views",12,MUTED,false);m.setSingleLine(true);m.setEllipsize(android.text.TextUtils.TruncateAt.END);meta.addView(m);card.addView(meta);
        TextView title=text(item.optString("title","Untitled video"),16,INK,true);title.setMaxLines(2);title.setEllipsize(android.text.TextUtils.TruncateAt.END);title.setPadding(dp(8),dp(5),dp(8),dp(4));card.addView(title);
        View.OnClickListener open=v->{int id=item.optInt("id",0);if(id>0)startActivity(new Intent(this,NativePlayerActivity.class).putExtra("video_id",id));};media.setOnClickListener(open);title.setOnClickListener(open);
    }
    private boolean validImage(String value){try{Uri u=Uri.parse(value);return "https".equalsIgnoreCase(u.getScheme())&&u.getHost()!=null;}catch(Exception e){return false;}}
    private void loadImage(ImageView target,String url){images.execute(()->{HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(8000);c.setReadTimeout(10000);Bitmap bitmap=PhiskImageCache.getBitmap(this, url);if(bitmap!=null)runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())target.setImageBitmap(bitmap);});}catch(Exception ignored){}finally{if(c!=null)c.disconnect();}});}
    @Override protected void onDestroy(){io.shutdownNow();images.shutdownNow();super.onDestroy();}
    @Override protected void onResume(){super.onResume();PhiskTheme.apply(this);}
}
