package co.phisk.videos;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.LruCache;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Shared disk-backed cache for public remote images.
 * Cache entries are keyed by the complete URL, so changed CDN/media URLs naturally
 * create new entries. Entries are refreshed after 24 hours; stale entries remain
 * available offline while a background refresh is attempted.
 */
public final class PhiskImageCache {
    private static final long FRESH_MS = 24L * 60L * 60L * 1000L;
    private static final long MAX_BYTES = 80L * 1024L * 1024L;
    private static final Object LOCK = new Object();
    private static final java.util.Set<String> REFRESHING = java.util.Collections.newSetFromMap(new java.util.concurrent.ConcurrentHashMap<String, Boolean>());
    private static final ExecutorService REFRESH = Executors.newFixedThreadPool(2);
    private static final LruCache<String, Bitmap> MEMORY =
            new LruCache<String, Bitmap>((int) (Runtime.getRuntime().maxMemory() / 8)) {
                @Override protected int sizeOf(String key, Bitmap value) {
                    return value.getByteCount();
                }
            };

    private PhiskImageCache() {}

    public static Bitmap getBitmap(Context context, String imageUrl) {
        if (context == null || imageUrl == null || !imageUrl.startsWith("https://")) return null;
        String key = sha256(imageUrl);
        Bitmap memory = MEMORY.get(key);
        if (memory != null) {
            File file = fileFor(context, key);
            if (file.exists() && System.currentTimeMillis() - file.lastModified() > FRESH_MS) {
                refreshInBackground(context, imageUrl, key);
            }
            return memory;
        }

        File file = fileFor(context, key);
        if (file.exists() && file.length() > 0) {
            Bitmap disk = BitmapFactory.decodeFile(file.getAbsolutePath());
            if (disk != null) {
                MEMORY.put(key, disk);
                if (System.currentTimeMillis() - file.lastModified() > FRESH_MS) {
                    refreshInBackground(context, imageUrl, key);
                }
                return disk;
            }
        }

        Bitmap downloaded = downloadAndStore(context, imageUrl, key);
        if (downloaded != null) MEMORY.put(key, downloaded);
        return downloaded;
    }

    /** Queue a public image for background caching without blocking the UI. */
    public static void prefetch(Context context, String imageUrl) {
        if (context == null || imageUrl == null || !imageUrl.startsWith("https://")) return;
        Context app = context.getApplicationContext();
        String key = sha256(imageUrl);
        File cached = fileFor(app, key);
        if (cached.exists() && cached.length() > 0 && System.currentTimeMillis() - cached.lastModified() <= FRESH_MS) return;
        refreshInBackground(app, imageUrl, key);
    }

    /** Basic disk-cache diagnostics for the cache status screen/API. */
    public static long getDiskCacheBytes(Context context) {
        File dir = new File(context.getApplicationContext().getFilesDir(), "phisk-images-v1");
        File[] files = dir.listFiles();
        long total = 0L;
        if (files != null) for (File file : files) if (file.isFile() && file.getName().endsWith(".img")) total += file.length();
        return total;
    }

    private static void refreshInBackground(Context context, String url, String key) {
        if (!REFRESHING.add(key)) return;
        REFRESH.execute(() -> {
            try {
                Bitmap updated = downloadAndStore(context.getApplicationContext(), url, key);
                if (updated != null) MEMORY.put(key, updated);
            } finally {
                REFRESHING.remove(key);
            }
        });
    }

    private static Bitmap downloadAndStore(Context context, String url, String key) {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(url).openConnection();
            connection.setConnectTimeout(8000);
            connection.setReadTimeout(12000);
            connection.setInstanceFollowRedirects(true);
            connection.setRequestProperty("User-Agent", "PhiskVideosAndroid/1.24.1");
            connection.setRequestProperty("Accept", "image/avif,image/webp,image/*,*/*;q=0.8");
            int status = connection.getResponseCode();
            if (status < 200 || status >= 300) return null;
            byte[] bytes;
            try (InputStream input = connection.getInputStream();
                 ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192];
                int count;
                while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
                bytes = output.toByteArray();
            }
            if (bytes.length == 0) return null;

            File target = fileFor(context, key);
            File temp = new File(target.getParentFile(), key + ".tmp");
            try (FileOutputStream output = new FileOutputStream(temp)) {
                output.write(bytes);
                output.flush();
            }
            if (target.exists()) target.delete();
            if (!temp.renameTo(target)) {
                try (FileOutputStream output = new FileOutputStream(target)) {
                    output.write(bytes);
                }
                temp.delete();
            }
            target.setLastModified(System.currentTimeMillis());
            trimCache(context);
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
        } catch (Exception ignored) {
            return null;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static File fileFor(Context context, String key) {
        File dir = new File(context.getApplicationContext().getFilesDir(), "phisk-images-v1");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, key + ".img");
    }

    private static void trimCache(Context context) {
        synchronized (LOCK) {
            File dir = new File(context.getApplicationContext().getFilesDir(), "phisk-images-v1");
            File[] files = dir.listFiles();
            if (files == null) return;
            long total = 0;
            for (File file : files) if (file.isFile() && file.getName().endsWith(".img")) total += file.length();
            if (total <= MAX_BYTES) return;
            java.util.Arrays.sort(files, (a, b) -> Long.compare(a.lastModified(), b.lastModified()));
            for (File file : files) {
                if (total <= MAX_BYTES) break;
                if (file.isFile() && file.getName().endsWith(".img")) {
                    long size = file.length();
                    if (file.delete()) total -= size;
                }
            }
        }
    }

    private static String sha256(String value) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(value.getBytes("UTF-8"));
            StringBuilder result = new StringBuilder();
            for (byte b : digest) result.append(String.format(java.util.Locale.US, "%02x", b));
            return result.toString();
        } catch (Exception e) {
            return Integer.toHexString(value.hashCode());
        }
    }
}
