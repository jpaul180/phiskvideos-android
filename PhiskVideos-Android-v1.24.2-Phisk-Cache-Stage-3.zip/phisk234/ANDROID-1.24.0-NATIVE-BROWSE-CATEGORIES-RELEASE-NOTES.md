# PhiskVideos Android v1.24.0 — Native Browse Categories

## Changes
- Reads the administrator-ordered Explore section configuration from `phisk-algorithm/v1/explore/config`.
- Renders the `browse_categories` section at its configured position among Algorithm Explore sections.
- Displays administrator-featured categories using their shared `image_url`, category name, portrait cover cards, and horizontal scrolling.
- Category cards open the existing native category video feed.
- View All opens a native category directory backed by `GET /wp-json/phisk-algorithm/v1/categories` and includes all categories, not only featured categories.
- Preserves Phisk Collections and existing Algorithm video sections.
- Supports existing app light/dark theme colors and image loading behavior.

## Version
- versionName: 1.24.0
- versionCode: 58

## Server compatibility
Requires Phisk Algorithm v1.3.1 (or later compatible release) and Phisk Video Manager v1.20.8 for featured category images and metadata.

## Validation
Source changes and manifest/version wiring were reviewed. A local Gradle build could not be run in this environment because the source archive does not include `gradlew` and Gradle is not installed. GitHub Actions should perform the authoritative Android build before installation testing.
