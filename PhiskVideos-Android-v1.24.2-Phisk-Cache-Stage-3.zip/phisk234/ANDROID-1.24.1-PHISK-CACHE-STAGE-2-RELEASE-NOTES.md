# PhiskVideos Android v1.24.1 — Phisk Cache Stage 2

## Included
- Added shared `PhiskImageCache` with memory and persistent disk caching for remote HTTPS images.
- Integrated cached image loading across Explore/home cards, category browsing, category video cards, collection details, creator channel surfaces, search, player surfaces, and downloaded-video thumbnails.
- Images are served from local disk immediately when available.
- Entries older than 24 hours are served stale-first and refreshed in the background, allowing offline display while refresh is attempted.
- Persistent image cache uses app-private files storage and is capped at approximately 80 MiB with least-recently-used file cleanup.
- Added asynchronous ETag-aware synchronization with the public `/wp-json/phisk-cache/v1/manifest` endpoint.
- Manifest sync is non-blocking and failure-safe; it never prevents app startup.
- Existing offline video downloads remain separate and are not deleted by image-cache cleanup.
- Bumped Android version to 1.24.1 (versionCode 59).

## Privacy and cache boundaries
- Only image URLs explicitly passed by existing UI image loaders are cached.
- Personalized feed JSON, notification payloads, account settings, and authenticated API responses are not placed in a shared response cache.
- Local image files are stored in app-private internal storage and are not shared with other apps.

## Notes
- Image freshness is currently 24 hours. A changed image URL is a new cache key; same-URL image replacements refresh after the freshness window.
- The server manifest is fetched conditionally using ETag. Targeted asset invalidation can be added when the server exposes stable per-asset revision identifiers.
