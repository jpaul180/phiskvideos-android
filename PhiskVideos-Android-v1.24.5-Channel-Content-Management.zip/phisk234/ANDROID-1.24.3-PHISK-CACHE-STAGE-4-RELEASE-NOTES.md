# PhiskVideos Android 1.24.3 — Phisk Cache Stage 4

- Adds an on-device Cache & performance diagnostics screen under Settings.
- Measures memory/disk cache hits, misses, image downloads, downloaded bytes, estimated bytes saved and failed image downloads.
- Records manifest HTTP 200/304 outcomes, synchronization duration and failed attempts locally.
- Statistics remain on the device; no analytics or telemetry is uploaded.
- No additional polling, scheduled background work, or new WordPress requests are introduced.
- Existing manifest sync trigger, ETag behavior, bounded prefetch, 80 MB image-cache limit and offline video storage separation are preserved.
- Diagnostics reset clears counters only; it does not delete cached images or offline videos.
