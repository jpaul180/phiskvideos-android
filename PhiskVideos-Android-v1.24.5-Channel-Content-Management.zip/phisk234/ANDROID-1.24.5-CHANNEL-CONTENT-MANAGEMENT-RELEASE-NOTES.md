# PhiskVideos Android v1.24.5 — Channel Content Management

- Added an owner-only three-dot menu to video and Story thumbnails on the native channel page.
- Added Edit, Stats and Delete actions.
- Added a confirmation dialog before permanent deletion.
- Added authenticated WordPress API calls for owner-only content statistics, editing and deletion.
- Content management API rechecks author ownership and published status on every request; Story operations additionally require the Story gallery metadata marker.
- Story channel feed now supplies the full plain-text body for editing.
- Existing cache sync, image cache and offline video download paths are unchanged.

Android version: 1.24.5 (versionCode 63).
