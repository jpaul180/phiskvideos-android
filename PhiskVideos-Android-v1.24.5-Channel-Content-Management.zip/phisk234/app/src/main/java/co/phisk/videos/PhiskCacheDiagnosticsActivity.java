package co.phisk.videos;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.DecimalFormat;
import java.text.DateFormat;
import java.util.Date;

/** On-device cache diagnostics. This screen performs no network requests. */
public class PhiskCacheDiagnosticsActivity extends Activity {
    private static final int VIOLET = Color.rgb(124,58,237);
    private LinearLayout content;
    private int ink, muted, card, border, bg;
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private TextView label(String value,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private GradientDrawable shape(int color,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(10));d.setStroke(dp(1),stroke);return d;}
    @Override public void onCreate(Bundle state){super.onCreate(state);PhiskTheme.configureActivityTheme(this);render();}
    private void render(){
        boolean dark=getSharedPreferences("phisk_native_settings",MODE_PRIVATE).getBoolean("dark_mode",false);
        bg=dark?Color.rgb(20,20,24):Color.rgb(247,248,250);card=dark?Color.rgb(31,32,38):Color.WHITE;ink=dark?Color.rgb(245,245,248):Color.rgb(25,29,38);muted=dark?Color.rgb(170,172,183):Color.rgb(112,117,128);border=dark?Color.rgb(58,59,68):Color.rgb(231,233,238);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(14),0,dp(14),0);bar.setBackgroundColor(card);
        TextView back=label("‹",34,ink,false);back.setGravity(Gravity.CENTER);bar.addView(back,new LinearLayout.LayoutParams(dp(42),dp(54)));back.setOnClickListener(v->finish());bar.addView(label("Cache & performance",18,ink,true));root.addView(bar);
        ScrollView scroll=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(16),dp(16),dp(16),dp(28));scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
        SharedPreferences stats=PhiskImageCache.getAnalytics(this);SharedPreferences sync=getSharedPreferences("phisk_cache_state",MODE_PRIVATE);
        addHeading("ON-DEVICE IMAGE CACHE");addCard("Storage used",bytes(PhiskImageCache.getDiskCacheBytes(this))+" of 80 MB");
        addCard("Memory cache hits",number(stats.getLong("memory_hits",0)));addCard("Disk cache hits",number(stats.getLong("disk_hits",0)));addCard("Cache misses",number(stats.getLong("cache_misses",0)));
        addCard("Network image downloads",number(stats.getLong("network_downloads",0)));addCard("Image data downloaded",bytes(stats.getLong("network_bytes",0)));addCard("Estimated data saved",bytes(stats.getLong("estimated_bytes_saved",0)));addCard("Failed image downloads",number(stats.getLong("failed_downloads",0)));
        addHeading("MANIFEST SYNCHRONIZATION");addCard("Last HTTP status",sync.getInt("manifest_last_http_status",0)==0?"Not recorded":String.valueOf(sync.getInt("manifest_last_http_status",0)));
        addCard("Last synchronization",time(sync.getLong("manifest_last_sync_at",0)));addCard("Last sync duration",sync.getLong("manifest_last_duration_ms",0)+" ms");addCard("HTTP 304 responses",number(sync.getLong("manifest_304_count",0)));addCard("Successful manifest responses",number(sync.getLong("manifest_200_count",0)));addCard("Failed sync attempts",number(sync.getLong("manifest_failed_syncs",0)));
        TextView note=label("Privacy & server protection: all statistics on this screen stay on this device. Phisk Cache does not upload analytics, run extra background polling, or send telemetry to WordPress.",12,muted,false);note.setPadding(dp(4),dp(12),dp(4),dp(16));content.addView(note);
        Button reset=new Button(this);reset.setText("Reset on-device statistics");reset.setTextColor(VIOLET);reset.setOnClickListener(v->new android.app.AlertDialog.Builder(this).setTitle("Reset cache statistics?").setMessage("This clears only local counters. It will not delete cached images or offline videos.").setNegativeButton("Cancel",null).setPositiveButton("Reset",(d,w)->{stats.edit().clear().apply();sync.edit().remove("manifest_304_count").remove("manifest_200_count").remove("manifest_failed_syncs").remove("manifest_response_bytes").apply();render();}).show());content.addView(reset);
    }
    private void addHeading(String value){TextView t=label(value,11,muted,true);t.setPadding(dp(3),dp(16),dp(3),dp(8));content.addView(t);}
    private void addCard(String title,String value){LinearLayout box=new LinearLayout(this);box.setGravity(Gravity.CENTER_VERTICAL);box.setPadding(dp(13),dp(12),dp(13),dp(12));box.setBackground(shape(card,border));LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.addView(label(title,12,muted,false));TextView val=label(value,16,ink,true);val.setPadding(0,dp(4),0,0);copy.addView(val);box.addView(copy,new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(7);content.addView(box,p);}
    private String number(long n){return new DecimalFormat("#,##0").format(n);}
    private String bytes(long n){if(n<1024)return n+" B";if(n<1024*1024)return new DecimalFormat("#,##0.0").format(n/1024.0)+" KB";return new DecimalFormat("#,##0.00").format(n/1048576.0)+" MB";}
    private String time(long t){return t<=0?"Not yet synchronized":DateFormat.getDateTimeInstance(DateFormat.MEDIUM,DateFormat.SHORT).format(new Date(t));}
}
