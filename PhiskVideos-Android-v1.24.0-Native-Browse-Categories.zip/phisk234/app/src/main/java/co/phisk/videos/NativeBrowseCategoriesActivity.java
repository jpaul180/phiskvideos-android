package co.phisk.videos;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Complete category directory backed by the shared Phisk Algorithm categories API. */
public class NativeBrowseCategoriesActivity extends Activity {
    private static final String API="https://videos.phisk.co/wp-json/phisk-algorithm/v1/";
    private final ExecutorService io=Executors.newSingleThreadExecutor(),images=Executors.newFixedThreadPool(4);
    private LinearLayout grid; private ProgressBar progress;
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private int ink(){return PhiskTheme.isDark(this)?Color.rgb(245,245,248):Color.rgb(25,29,38);}
    private int muted(){return PhiskTheme.isDark(this)?Color.rgb(174,176,186):Color.rgb(112,117,128);}
    private int surface(){return PhiskTheme.isDark(this)?Color.rgb(27,28,34):Color.WHITE;}
    private GradientDrawable shape(int color,int stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
    private TextView text(String value,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    @Override public void onCreate(Bundle state){PhiskTheme.configureActivityTheme(this);super.onCreate(state);build();load();}
    private void build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(PhiskTheme.isDark(this)?Color.rgb(17,18,23):Color.rgb(247,248,250));
        LinearLayout toolbar=new LinearLayout(this);toolbar.setGravity(Gravity.CENTER_VERTICAL);toolbar.setPadding(dp(14),dp(10),dp(16),dp(10));toolbar.setBackgroundColor(surface());
        TextView back=text("‹",34,ink(),false);back.setGravity(Gravity.CENTER);toolbar.addView(back,new LinearLayout.LayoutParams(dp(42),dp(42)));back.setOnClickListener(v->finish());
        TextView heading=text("Categories",20,ink(),true);LinearLayout.LayoutParams th=new LinearLayout.LayoutParams(-2,-2);th.leftMargin=dp(8);toolbar.addView(heading,th);root.addView(toolbar);
        ScrollView scroll=new ScrollView(this);grid=new LinearLayout(this);grid.setOrientation(LinearLayout.VERTICAL);grid.setPadding(dp(16),dp(18),dp(16),dp(24));scroll.addView(grid);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        progress=new ProgressBar(this);FrameLayout body=new FrameLayout(this);body.addView(progress,new FrameLayout.LayoutParams(dp(38),dp(38),Gravity.CENTER));root.addView(body,new LinearLayout.LayoutParams(-1,dp(60)));setContentView(root);
    }
    private void load(){io.execute(()->{HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(API+"categories").openConnection();c.setConnectTimeout(15000);c.setReadTimeout(20000);c.setRequestProperty("Accept","application/json");int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();ByteArrayOutputStream out=new ByteArrayOutputStream();if(in!=null){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);in.close();}if(code<200||code>=300)throw new Exception("HTTP "+code);JSONObject response=new JSONObject(out.toString("UTF-8"));JSONArray items=response.optJSONArray("items");if(items==null)items=new JSONArray();final JSONArray result=items;runOnUiThread(()->render(result));}catch(Exception e){runOnUiThread(()->{progress.setVisibility(View.GONE);TextView retry=text("Couldn't load categories. Tap to try again.",14,muted(),false);retry.setGravity(Gravity.CENTER);grid.addView(retry);retry.setOnClickListener(v->{grid.removeAllViews();progress.setVisibility(View.VISIBLE);load();});});}finally{if(c!=null)c.disconnect();}});}
    private void render(JSONArray items){progress.setVisibility(View.GONE);grid.removeAllViews();if(items.length()==0){TextView empty=text("No categories are available yet.",14,muted(),false);grid.addView(empty);return;}int columns=2;for(int start=0;start<items.length();start+=columns){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(18);grid.addView(row,rp);for(int col=0;col<columns&&start+col<items.length();col++){JSONObject item=items.optJSONObject(start+col);if(item==null)continue;addCard(row,item,col==0?dp(8):dp(8));}}}
    private void addCard(LinearLayout row,JSONObject item,int rightMargin){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,-2,1);cp.leftMargin=dp(4);cp.rightMargin=dp(4);row.addView(card,cp);FrameLayout media=new FrameLayout(this);media.setBackground(shape(PhiskTheme.isDark(this)?Color.rgb(44,43,53):Color.rgb(235,232,242),0,9));media.setClipToOutline(true);card.addView(media,new LinearLayout.LayoutParams(-1,dp(205)));ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.CENTER_CROP);media.addView(image,new FrameLayout.LayoutParams(-1,-1));String url=item.optString("image_url","");if(validImage(url))loadImage(image,url);TextView name=text(item.optString("name","Category"),15,ink(),true);name.setSingleLine(true);name.setEllipsize(android.text.TextUtils.TruncateAt.END);LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2);np.topMargin=dp(8);card.addView(name,np);TextView count=text(item.optInt("count",0)+" videos",12,muted(),false);card.addView(count);card.setOnClickListener(v->{Intent intent=new Intent(this,NativeCategoryActivity.class);intent.putExtra("category_slug",item.optString("slug",""));intent.putExtra("category_name",item.optString("name","Category"));intent.putExtra("category_description",item.optString("description",""));intent.putExtra("category_sort","latest");startActivity(intent);});}
    private boolean validImage(String value){try{Uri u=Uri.parse(value);return "https".equalsIgnoreCase(u.getScheme())&&u.getHost()!=null;}catch(Exception e){return false;}}
    private void loadImage(ImageView target,String url){images.execute(()->{HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(8000);c.setReadTimeout(10000);Bitmap bitmap=BitmapFactory.decodeStream(c.getInputStream());if(bitmap!=null)runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())target.setImageBitmap(bitmap);});}catch(Exception ignored){}finally{if(c!=null)c.disconnect();}});}
    @Override protected void onDestroy(){io.shutdownNow();images.shutdownNow();super.onDestroy();}
    @Override protected void onResume(){super.onResume();PhiskTheme.apply(this);}
}
