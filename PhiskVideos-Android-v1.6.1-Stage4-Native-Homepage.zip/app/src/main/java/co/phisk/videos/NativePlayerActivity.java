package co.phisk.videos;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class NativePlayerActivity extends Activity {
    private ExoPlayer player;
    private PlayerView playerView;
    private boolean playWhenReady=true;
    private long playbackPosition=0;

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.BLACK);
        String url=getIntent().getStringExtra("video_url");
        String title=getIntent().getStringExtra("video_title");
        String creator=getIntent().getStringExtra("creator_name");
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        TextView back=new TextView(this); back.setText("‹   Back"); back.setTextSize(17);
        back.setTextColor(Color.rgb(124,58,237)); back.setPadding(18,14,18,14);
        back.setOnClickListener(v->finish()); root.addView(back);
        playerView=new PlayerView(this); playerView.setUseController(true);
        playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);
        root.addView(playerView,new LinearLayout.LayoutParams(-1,0,1));
        TextView heading=new TextView(this); heading.setText(title==null?"Video":title);
        heading.setTextColor(Color.rgb(25,29,38)); heading.setTextSize(18); heading.setPadding(16,14,16,4);
        root.addView(heading);
        TextView byline=new TextView(this); byline.setText(creator==null?"":creator);
        byline.setTextColor(Color.rgb(112,117,128)); byline.setTextSize(14); byline.setPadding(16,0,16,18);
        root.addView(byline);
        setContentView(root);
        if(state!=null){playbackPosition=state.getLong("position",0);playWhenReady=state.getBoolean("play_when_ready",true);}
        if(url==null||!url.startsWith("https://")){Toast.makeText(this,"Invalid video source",Toast.LENGTH_LONG).show();finish();return;}
    }
    @Override protected void onStart(){super.onStart();initializePlayer();}
    private void initializePlayer(){
        if(player!=null)return;
        player=new ExoPlayer.Builder(this).build();playerView.setPlayer(player);
        player.addListener(new Player.Listener(){
            @Override public void onPlayerError(PlaybackException error){
                Toast.makeText(NativePlayerActivity.this,"Playback failed. The source may be unsupported or unavailable.",Toast.LENGTH_LONG).show();
            }
        });
        String url=getIntent().getStringExtra("video_url");
        player.setMediaItem(MediaItem.fromUri(url));player.prepare();
        player.seekTo(playbackPosition);player.setPlayWhenReady(playWhenReady);
    }
    private void releasePlayer(){
        if(player!=null){playbackPosition=player.getCurrentPosition();playWhenReady=player.getPlayWhenReady();player.release();player=null;}
        if(playerView!=null)playerView.setPlayer(null);
    }
    @Override protected void onStop(){super.onStop();releasePlayer();}
    @Override protected void onSaveInstanceState(Bundle out){if(player!=null){out.putLong("position",player.getCurrentPosition());out.putBoolean("play_when_ready",player.getPlayWhenReady());}super.onSaveInstanceState(out);}
}
