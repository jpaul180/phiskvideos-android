package co.phisk.videos;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Native tabbed homepage. Feed ranking remains owned by the WordPress Algorithm plugin. */
public class NativeHomeActivity extends Activity {
    private static final String HOME="https://videos.phisk.co/";
    private static final String API=HOME+"wp-json/phisk-algorithm/v1/feeds/";
    private static final int VIOLET=Color.rgb(124,58,237), DEEP=Color.rgb(109,40,217), INK=Color.rgb(25,29,38), MUTED=Color.rgb(112,117,128), BG=Color.rgb(247,248,250);
    private static final String[] FEEDS={"for-you","top-stories","trending","discover","recommended"};
    private static final String[] LABELS={"For You","Top Stories","Trending","Discover","Recommended"};
    private final ExecutorService io=Executors.newFixedThreadPool(3);
    private final ExecutorService images=Executors.newFixedThreadPool(4);
    private final JSONArray[] data={new JSONArray(),new JSONArray(),new JSONArray(),new JSONArray(),new JSONArray()};
    private final int[] pages={1,1,1,1,1};
    private final boolean[] loaded={false,false,false,false,false};
    private final boolean[] more={true,true,true,true,true};
    private int active=0; private boolean loading=false;
    private LinearLayout root, tabStrip, feedList; private ScrollView feedScroll; private ProgressBar spinner; private TextView status;

    @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(Color.WHITE);getWindow().setNavigationBarColor(Color.WHITE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);build();selectTab(0);}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable shape(int color,int stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
    private TextView label(String value,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private void build(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(14),dp(10),dp(14),dp(10));header.setBackgroundColor(Color.WHITE);
        TextView menu=label("☰",27,INK,false);menu.setGravity(Gravity.CENTER);header.addView(menu,new LinearLayout.LayoutParams(dp(42),dp(48)));menu.setOnClickListener(v->openWeb(HOME+"menu/"));
        TextView logo=label("▷",34,VIOLET,true);logo.setGravity(Gravity.CENTER);header.addView(logo,new LinearLayout.LayoutParams(dp(42),dp(48)));
        EditText search=new EditText(this);search.setSingleLine(true);search.setTextSize(15);search.setHint("Search videos, stories and channels...");search.setPadding(dp(14),0,dp(12),0);search.setBackground(shape(Color.WHITE,Color.rgb(225,226,231),24));search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(44),1);sp.leftMargin=dp(8);header.addView(search,sp);search.setOnEditorActionListener((v,action,event)->{if(action==EditorInfo.IME_ACTION_SEARCH){String q=search.getText().toString().trim();if(!q.isEmpty())openWeb(HOME+"?s="+Uri.encode(q));return true;}return false;});
        root.addView(header);
        HorizontalScrollView tabs=new HorizontalScrollView(this);tabs.setHorizontalScrollBarEnabled(false);tabs.setBackgroundColor(Color.WHITE);tabStrip=new LinearLayout(this);tabStrip.setGravity(Gravity.CENTER_VERTICAL);tabStrip.setPadding(dp(12),dp(10),dp(12),dp(10));tabs.addView(tabStrip);for(int i=0;i<LABELS.length;i++)addTab(i);root.addView(tabs);
        View divider=new View(this);divider.setBackgroundColor(Color.rgb(235,236,240));root.addView(divider,new LinearLayout.LayoutParams(-1,dp(1)));
        FrameLayout body=new FrameLayout(this);feedScroll=new ScrollView(this);feedScroll.setFillViewport(true);feedList=new LinearLayout(this);feedList.setOrientation(LinearLayout.VERTICAL);feedList.setPadding(dp(14),dp(18),dp(14),dp(18));feedScroll.addView(feedList);body.addView(feedScroll,new FrameLayout.LayoutParams(-1,-1));spinner=new ProgressBar(this);FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(dp(38),dp(38),Gravity.TOP|Gravity.CENTER_HORIZONTAL);pp.topMargin=dp(24);body.addView(spinner,pp);spinner.setVisibility(View.GONE);root.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        root.addView(bottomBar());setContentView(root);
        feedScroll.setOnScrollChangeListener((View v,int sx,int sy,int oldx,int oldy)->{if(active!=1 && more[active] && !loading && sy+feedScroll.getHeight()>=feedList.getHeight()-dp(500))loadPage(active);});
    }
    private void addTab(int index){TextView t=label(LABELS[index],14,INK,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(17),dp(11),dp(17),dp(11));t.setBackground(shape(Color.WHITE,0,10));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,dp(42));p.rightMargin=dp(7);tabStrip.addView(t,p);t.setOnClickListener(v->selectTab(index));t.setTag("tab_"+index);}
    private void updateTabs(){for(int i=0;i<tabStrip.getChildCount();i++){TextView t=(TextView)tabStrip.getChildAt(i);boolean selected=i==active;t.setTextColor(selected?Color.WHITE:INK);t.setBackground(shape(selected?VIOLET:Color.WHITE,0,10));}}
    private LinearLayout bottomBar(){LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER);bar.setBackgroundColor(Color.WHITE);bar.setPadding(dp(4),dp(7),dp(4),dp(7));String[] names={"⌂\nHome","▱\nStudio","＋\nCreate","♧\nActivities","●\nUser"};String[] urls={null,HOME+"creator-studio/",HOME+"upload/",HOME+"phisk-notifications/",HOME+"my-account/"};for(int i=0;i<names.length;i++){final int n=i;TextView item=label(names[i],12,i==0?VIOLET:MUTED,true);item.setGravity(Gravity.CENTER);bar.addView(item,new LinearLayout.LayoutParams(0,dp(54),1));if(i!=0)item.setOnClickListener(v->openWeb(urls[n]));}return bar;}
    private void selectTab(int index){active=index;updateTabs();feedList.removeAllViews();if(loaded[index])renderItems(index);else if(index==1){loaded[index]=true;showTopStoriesPending();}else loadPage(index);feedScroll.scrollTo(0,0);}
    private String token(){return getSharedPreferences("phisk_native_auth",MODE_PRIVATE).getString("access_token","");}
    private void loadPage(int index){if(index==1||loading||!more[index])return;loading=true;spinner.setVisibility(View.VISIBLE);final int page=pages[index];io.execute(()->{HttpURLConnection c=null;try{String url=API+FEEDS[index]+"?page="+page+"&per_page=10";c=(HttpURLConnection)new URL(url).openConnection();c.setRequestMethod("GET");c.setConnectTimeout(15000);c.setReadTimeout(20000);c.setRequestProperty("Accept","application/json");String access=token();if(!access.isEmpty())c.setRequestProperty("Authorization","Bearer "+access);int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();ByteArrayOutputStream out=new ByteArrayOutputStream();if(in!=null){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);in.close();}if(code<200||code>=300)throw new Exception("Server returned "+code);JSONObject response=new JSONObject(out.toString("UTF-8"));if(!response.optBoolean("success"))throw new Exception("Feed request was not successful");JSONArray items=response.optJSONArray("items");if(items==null)items=new JSONArray();final JSONArray result=items;final boolean hasMore=response.optBoolean("has_more",false);runOnUiThread(()->{loading=false;spinner.setVisibility(View.GONE);loaded[index]=true;pages[index]=page+1;more[index]=hasMore;for(int i=0;i<result.length();i++)data[index].put(result.opt(i));if(active==index)renderItems(index);});}catch(Exception e){runOnUiThread(()->{loading=false;spinner.setVisibility(View.GONE);if(active==index)showError(index,"Couldn't load this feed. Check your connection and try again.");});}finally{if(c!=null)c.disconnect();}});}
    private void renderItems(int index){feedList.removeAllViews();if(data[index].length()==0){showEmpty("No videos to show yet.");return;}for(int i=0;i<data[index].length();i++){JSONObject item=data[index].optJSONObject(i);if(item!=null)addVideoCard(item);}if(more[index]){TextView moreLabel=label("Loading more videos…",12,MUTED,false);moreLabel.setGravity(Gravity.CENTER);moreLabel.setPadding(0,dp(16),0,dp(18));feedList.addView(moreLabel);}}
    private void addVideoCard(JSONObject item){
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(10),dp(10),dp(10),dp(12));card.setBackground(shape(Color.WHITE,Color.rgb(229,230,234),15));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=dp(14);feedList.addView(card,cp);
        FrameLayout media=new FrameLayout(this);media.setBackground(shape(Color.rgb(24,24,27),VIOLET,12));media.setClipToOutline(true);ImageView thumb=new ImageView(this);thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);media.addView(thumb,new FrameLayout.LayoutParams(-1,dp(205)));String thumbUrl=item.optString("thumbnail_url","");if(validImage(thumbUrl))loadImage(thumb,thumbUrl);
        TextView duration=label(item.optString("runtime",""),12,Color.WHITE,true);duration.setPadding(dp(7),dp(4),dp(7),dp(4));duration.setBackground(shape(Color.rgb(20,20,20),0,5));FrameLayout.LayoutParams dur=new FrameLayout.LayoutParams(-2,-2,Gravity.RIGHT|Gravity.BOTTOM);dur.setMargins(0,0,dp(8),dp(8));media.addView(duration,dur);
        TextView age=label(item.optString("published_ago",""),11,Color.WHITE,true);age.setPadding(dp(7),dp(4),dp(7),dp(4));age.setBackground(shape(Color.rgb(20,20,20),0,5));FrameLayout.LayoutParams ag=new FrameLayout.LayoutParams(-2,-2,Gravity.LEFT|Gravity.BOTTOM);ag.setMargins(dp(8),0,0,dp(8));media.addView(age,ag);
        TextView dots=label("⋮",24,Color.WHITE,true);dots.setGravity(Gravity.CENTER);FrameLayout.LayoutParams dotp=new FrameLayout.LayoutParams(dp(34),dp(38),Gravity.RIGHT|Gravity.TOP);media.addView(dots,dotp);dots.setOnClickListener(v->openWeb(item.optString("permalink",HOME)));
        card.addView(media);
        LinearLayout details=new LinearLayout(this);details.setOrientation(LinearLayout.HORIZONTAL);details.setGravity(Gravity.TOP);details.setPadding(0,dp(12),0,0);ImageView avatar=new ImageView(this);avatar.setImageDrawable(null);avatar.setBackground(shape(Color.rgb(239,235,247),0,40));avatar.setClipToOutline(true);LinearLayout.LayoutParams avp=new LinearLayout.LayoutParams(dp(48),dp(48));avp.rightMargin=dp(11);details.addView(avatar,avp);JSONObject creator=item.optJSONObject("creator");String creatorName=creator==null?"Creator":creator.optString("name","Creator");String avatarUrl=creator==null?"":creator.optString("avatar_url","");if(validImage(avatarUrl))loadImage(avatar,avatarUrl);
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);details.addView(copy,new LinearLayout.LayoutParams(0,-2,1));TextView title=label(item.optString("title","Untitled video"),17,INK,true);title.setMaxLines(3);copy.addView(title);TextView meta=label(creatorName+"   "+item.optInt("views",0)+" views",13,MUTED,false);meta.setPadding(0,dp(7),0,0);copy.addView(meta);if(creator!=null&&creator.optBoolean("is_monetized")){TextView monetized=label("$ Monetized Channel",12,Color.rgb(35,132,83),true);monetized.setPadding(0,dp(7),0,0);copy.addView(monetized);}if(creator!=null&&creator.optBoolean("is_followed")){TextView followed=label("Following",12,VIOLET,true);followed.setPadding(0,dp(5),0,0);copy.addView(followed);}card.addView(details);
        View.OnClickListener open=v->openNativePlayer(item);media.setOnClickListener(open);title.setOnClickListener(open);avatar.setOnClickListener(v->{if(creator!=null)openWeb(creator.optString("profile_url",HOME));});
    }
    private void openNativePlayer(JSONObject item){
        String stream=item.optString("video_url","");
        if(stream.isEmpty())stream=item.optString("media_url","");
        if(stream.isEmpty())stream=item.optString("stream_url","");
        if(stream.isEmpty())stream=item.optString("playback_url","");
        if(stream.isEmpty()){
            JSONObject media=item.optJSONObject("media");
            if(media!=null)stream=media.optString("url",media.optString("src",""));
        }
        if(stream.isEmpty() || !stream.startsWith("https://")){
            new AlertDialog.Builder(this).setTitle("Video unavailable")
                .setMessage("A direct HTTPS playback URL was not included in this feed item. The native player needs the video source URL from the content API.")
                .setPositiveButton("OK",null).show();
            return;
        }
        Intent intent=new Intent(this,NativePlayerActivity.class);
        intent.putExtra("video_url",stream);
        intent.putExtra("video_title",item.optString("title","PhiskVideos"));
        JSONObject creator=item.optJSONObject("creator");
        intent.putExtra("creator_name",creator==null?"":creator.optString("name",""));
        intent.putExtra("video_id",item.optString("id",""));
        startActivity(intent);
    }
    private boolean validImage(String value){try{Uri u=Uri.parse(value);return "https".equalsIgnoreCase(u.getScheme())&&u.getHost()!=null;}catch(Exception e){return false;}}
    private void loadImage(ImageView target,String value){images.execute(()->{HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(value).openConnection();c.setConnectTimeout(8000);c.setReadTimeout(10000);c.setRequestProperty("User-Agent","PhiskVideosAndroid/1.6.0");Bitmap bitmap=BitmapFactory.decodeStream(c.getInputStream());if(bitmap!=null)runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())target.setImageBitmap(bitmap);});}catch(Exception ignored){}finally{if(c!=null)c.disconnect();}});}
    private void showTopStoriesPending(){feedList.removeAllViews();TextView h=label("Top Stories",22,INK,true);feedList.addView(h);TextView m=label("Top Stories will appear here once its dedicated Video Manager feed endpoint is connected.",14,MUTED,false);m.setPadding(0,dp(9),0,0);feedList.addView(m);}
    private void showEmpty(String message){TextView t=label(message,14,MUTED,false);t.setGravity(Gravity.CENTER);t.setPadding(dp(20),dp(55),dp(20),dp(55));feedList.addView(t);}
    private void showError(int index,String message){feedList.removeAllViews();TextView t=label(message,14,MUTED,false);t.setGravity(Gravity.CENTER);t.setPadding(dp(18),dp(40),dp(18),dp(18));feedList.addView(t);TextView retry=label("Try again",14,VIOLET,true);retry.setGravity(Gravity.CENTER);feedList.addView(retry);retry.setOnClickListener(v->{loaded[index]=false;loadPage(index);});}
    private void openWeb(String url){Intent i=new Intent(this,MainActivity.class);i.putExtra(MainActivity.EXTRA_NOTIFICATION_URL,url);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(i);finish();}
    @Override public void onBackPressed(){super.onBackPressed();}
    @Override protected void onDestroy(){io.shutdownNow();images.shutdownNow();super.onDestroy();}
}
