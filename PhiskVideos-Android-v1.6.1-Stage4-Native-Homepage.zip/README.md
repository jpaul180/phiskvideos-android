# PhiskVideos Android v1.6.1

This source package is based on the successfully tested v1.5.0 Stage 3 Notification Centre build.

## v1.5.1 changes
- Adds Android verified App Links for `https://videos.phisk.co/*`.
- Handles App Links and FCM notification destinations on cold start and when the app is already running.
- Preserves incoming destinations until the user signs in, then opens the requested destination.
- Supports destination keys used by notification intents and Firebase data payloads (`target_url`, `url`, and `link`).
- Displays notification image URLs returned by the WordPress notifications API (`thumbnail_url`, with avatar/image fallbacks) instead of always using the category icon.
- Retains category icons as fallbacks when an image is absent or cannot be loaded.
- Updates app version to 1.5.1 / versionCode 15 and the WebView user-agent marker.
- Keeps existing FCM, authentication, notification inbox, downloads, and app design.

## Android App Links domain verification
The app manifest is configured with `android:autoVerify="true"` for `videos.phisk.co`.
Publish the accompanying `assetlinks.json` at:

`https://videos.phisk.co/.well-known/assetlinks.json`

The included fingerprint is the current GitHub Actions release-signing certificate. When Google Play App Signing is enabled, add Google's **App signing key** SHA-256 fingerprint to the same `sha256_cert_fingerprints` array. Keep the upload-key fingerprint separate; it is not the certificate used to sign Play-delivered installs.

## Build outputs
The updated GitHub Actions workflow builds:
- Signed APK for direct installation/testing.
- Signed Android App Bundle (AAB) for future Google Play submission.

Do not upload the AAB to Play until the Play Console app-signing setup and store listing are ready.

## Stage 4.2 — Native Homepage (v1.6.0)

This build introduces `NativeHomeActivity` as the signed-in app landing screen. It provides native horizontal tabs for For You, Top Stories, Trending, Discover, and Recommended, native video cards, a search field, and the existing five-item app navigation concept.

The four algorithm feeds call the WordPress Algorithm API directly:

- `/wp-json/phisk-algorithm/v1/feeds/for-you`
- `/wp-json/phisk-algorithm/v1/feeds/trending`
- `/wp-json/phisk-algorithm/v1/feeds/discover`
- `/wp-json/phisk-algorithm/v1/feeds/recommended`

Requests include the existing `phisk_native_auth/access_token` bearer token when available. Each feed keeps its own loaded items and page counter. More items are requested as the active feed is scrolled.

**Top Stories is intentionally a non-network placeholder in this build.** Its source is the Video Manager plugin, and it must be connected only after the dedicated Top Stories JSON endpoint is available. No theme-rendered feed or substitute algorithm is used.

Video cards open their existing website permalink in the app's retained WebView route. Authentication, notification handling, FCM, downloads, and App Links remain in the existing app components. Movies and TV Shows are not included in the native feed tabs.

Version: `1.6.1` (versionCode `17`).\n\n## v1.6.1 — Stage 4.2 completion increment\n- Removes guest/website bypass from the welcome screen; authentication is mandatory.\n- Adds native Media3 ExoPlayer screen and native video-card playback routing.\n- Feed item playback expects a direct HTTPS `video_url`, `media_url`, `stream_url`, or `playback_url` field (or `media.url`/`media.src`). If the API does not provide one, the app displays a clear unavailable-source message rather than silently opening the website.\n- Preserves the native homepage, notifications, FCM, App Links, and downloads.
