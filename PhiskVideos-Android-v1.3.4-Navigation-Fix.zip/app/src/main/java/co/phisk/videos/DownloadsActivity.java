package co.phisk.videos;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.VideoView;
import android.widget.MediaController;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.PopupMenu;
import android.net.Uri;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import java.io.File;
import java.net.URL;
import java.util.Arrays;
import org.json.JSONObject;

public class DownloadsActivity extends Activity {
    private LinearLayout list;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable refresher = new Runnable() { @Override public void run() { refreshList(); handler.postDelayed(this, 1200); } };
    private static final String PREFS = "phisk_download_metadata";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(18),dp(18),dp(18)); root.setBackgroundColor(Color.WHITE);
        TextView title = new TextView(this); title.setText("Downloads"); title.setTextColor(Color.BLACK); title.setTextSize(23); title.setTypeface(null,1); root.addView(title);
        TextView subtitle = new TextView(this); subtitle.setText("Videos saved on this device"); subtitle.setTextColor(Color.DKGRAY); subtitle.setTextSize(13); subtitle.setPadding(0,dp(4),0,dp(16)); root.addView(subtitle);
        list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); root.addView(list,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root); refreshList();
    }
    @Override protected void onResume() { super.onResume(); handler.post(refresher); }
    @Override protected void onPause() { handler.removeCallbacks(refresher); super.onPause(); }

    private void refreshList() {
        list.removeAllViews(); File dir = new File(getFilesDir(),"downloads"); File[] files = dir.listFiles();
        if (files == null || files.length == 0) { TextView empty = new TextView(this); empty.setText("No downloaded videos yet."); empty.setTextColor(Color.GRAY); empty.setGravity(Gravity.CENTER); list.addView(empty,new LinearLayout.LayoutParams(-1,dp(180))); return; }
        Arrays.sort(files,(a,b)->Long.compare(b.lastModified(),a.lastModified()));
        for (File file : files) {
            if (!file.isFile()) continue;
            boolean downloading = file.getName().endsWith(".part");
            String metadataKey = downloading ? file.getName().substring(0, file.getName().length()-5) : file.getName();
            JSONObject meta = readMeta(metadataKey);
            String displayName = meta.optString("title", file.getName().replaceFirst("^[0-9]+_", "").replaceFirst("(?i)\\.(mp4|m4v|mov|webm|ogv)(\\.part)?$", ""));
            String channel = meta.optString("channel", "");
            int pct = meta.optInt("progress", downloading ? 0 : 100);
            LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0,dp(10),0,dp(10));
            ImageView thumb = new ImageView(this); thumb.setScaleType(ImageView.ScaleType.CENTER_CROP); thumb.setBackgroundColor(0xFFEDE9FE); row.addView(thumb,new LinearLayout.LayoutParams(dp(104),dp(66)));
            loadThumbnail(thumb, meta.optString("thumbnail", ""));
            LinearLayout details = new LinearLayout(this); details.setOrientation(LinearLayout.VERTICAL); details.setPadding(dp(11),0,dp(4),0); row.addView(details,new LinearLayout.LayoutParams(0,-2,1));
            TextView name = new TextView(this); name.setText(displayName); name.setTextColor(Color.BLACK); name.setTextSize(14); name.setTypeface(null,1); name.setMaxLines(2); details.addView(name);
            TextView by = new TextView(this); by.setText(channel.isEmpty() ? (downloading ? "Downloading…" : formatSize(file.length())) : "By " + channel); by.setTextColor(Color.GRAY); by.setTextSize(12); by.setPadding(0,dp(3),0,dp(4)); details.addView(by);
            ProgressBar meter = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal); meter.setMax(100); meter.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.rgb(124,58,237))); meter.setProgress(pct); details.addView(meter,new LinearLayout.LayoutParams(-1,dp(4)));
            TextView progressLabel = new TextView(this); progressLabel.setText(downloading ? (pct > 0 ? pct + "% downloaded" : "Downloading…") : formatSize(file.length())); progressLabel.setTextColor(Color.GRAY); progressLabel.setTextSize(11); progressLabel.setPadding(0,dp(3),0,0); details.addView(progressLabel);
            TextView more = new TextView(this); more.setText("⋮"); more.setTextSize(25); more.setTextColor(Color.DKGRAY); more.setGravity(Gravity.CENTER); more.setPadding(dp(10),dp(8),0,dp(8)); row.addView(more);
            if (!downloading) more.setOnClickListener(v -> showActions(more, file)); else { more.setVisibility(View.INVISIBLE); }
            list.addView(row); View divider = new View(this); divider.setBackgroundColor(0xFFEAEAEA); list.addView(divider,new LinearLayout.LayoutParams(-1,dp(1)));
        }
    }

    private JSONObject readMeta(String key) { try { String raw=getSharedPreferences(PREFS,MODE_PRIVATE).getString(key,"{}"); return new JSONObject(raw); } catch(Exception e) { return new JSONObject(); } }
    private void loadThumbnail(ImageView view, String imageUrl) {
        if (imageUrl == null || !imageUrl.startsWith("https://")) return;
        new Thread(() -> { try { Bitmap bitmap=BitmapFactory.decodeStream(new URL(imageUrl).openStream()); if(bitmap!=null) runOnUiThread(() -> view.setImageBitmap(bitmap)); } catch(Exception ignored) {} }).start();
    }
    private void showActions(View anchor, File file) {
        PopupMenu menu = new PopupMenu(this, anchor); menu.getMenu().add("Play"); menu.getMenu().add("Delete");
        menu.setOnMenuItemClickListener(item -> { if ("Play".contentEquals(item.getTitle())) play(file); else if ("Delete".contentEquals(item.getTitle())) { file.delete(); getSharedPreferences(PREFS,MODE_PRIVATE).edit().remove(file.getName()).apply(); refreshList(); } return true; }); menu.show();
    }
    private void play(File file) {
        LinearLayout player = new LinearLayout(this); player.setOrientation(LinearLayout.VERTICAL); player.setPadding(dp(12),dp(12),dp(12),dp(12)); player.setBackgroundColor(Color.BLACK);
        TextView back = new TextView(this); back.setText("‹  Downloads"); back.setTextColor(Color.WHITE); back.setTextSize(16); back.setPadding(0,0,0,dp(12)); back.setOnClickListener(v -> { setContentView(buildRoot()); refreshList(); }); player.addView(back);
        VideoView video = new VideoView(this); player.addView(video,new LinearLayout.LayoutParams(-1,0,1));
        MediaController controls = new MediaController(this); controls.setAnchorView(video); video.setMediaController(controls); video.setVideoURI(Uri.fromFile(file)); video.start(); setContentView(player);
    }
    private View buildRoot() { LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(18),dp(18),dp(18)); root.setBackgroundColor(Color.WHITE); TextView title=new TextView(this); title.setText("Downloads"); title.setTextColor(Color.BLACK); title.setTextSize(23); title.setTypeface(null,1); root.addView(title); TextView subtitle=new TextView(this); subtitle.setText("Videos saved on this device"); subtitle.setTextColor(Color.DKGRAY); subtitle.setTextSize(13); subtitle.setPadding(0,dp(4),0,dp(16)); root.addView(subtitle); list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); root.addView(list,new LinearLayout.LayoutParams(-1,0,1)); return root; }
    private String formatSize(long bytes) { if(bytes<1024) return bytes+" B"; if(bytes<1024*1024) return String.format(java.util.Locale.US,"%.1f KB",bytes/1024.0); return String.format(java.util.Locale.US,"%.1f MB",bytes/(1024.0*1024.0)); }
    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
}
