package co.phisk.videos;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Fully native, editorial-style reader for PhiskVideos Stories. */
public class NativeStoryDetailActivity extends Activity {
    private static final int VIOLET=Color.rgb(124,58,237), INK=Color.rgb(30,32,38), MUTED=Color.rgb(118,122,132);
    private static final String HOME="https://videos.phisk.co/";
    private final ExecutorService images=Executors.newFixedThreadPool(3);
    private LinearLayout root,body; private ScrollView scroll; private JSONObject story;
    private boolean dark; private int bg, surface, ink, muted, divider;

    @Override public void onCreate(Bundle state){PhiskTheme.configureActivityTheme(this);super.onCreate(state);dark=PhiskTheme.isDark(this);colors();try{story=new JSONObject(getIntent().getStringExtra("story_json"));}catch(Exception e){story=new JSONObject();}build();render();}
    private void colors(){bg=dark?Color.rgb(18,19,23):Color.WHITE;surface=dark?Color.rgb(28,29,35):Color.WHITE;ink=dark?Color.rgb(244,244,247):INK;muted=dark?Color.rgb(169,171,181):MUTED;divider=dark?Color.rgb(57,58,66):Color.rgb(235,236,240);}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String value,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,android.graphics.Typeface.BOLD);return t;}
    private void build(){getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);getWindow().getDecorView().setSystemUiVisibility(dark?0:View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(12),0,dp(16),0);bar.setBackgroundColor(surface);TextView back=text("‹",36,ink,false);back.setGravity(Gravity.CENTER);bar.addView(back,new LinearLayout.LayoutParams(dp(42),dp(52)));back.setOnClickListener(v->finish());TextView label=text("Story",16,ink,true);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.leftMargin=dp(8);bar.addView(label,lp);TextView share=text("↗",23,ink,false);share.setGravity(Gravity.CENTER);bar.addView(share,new LinearLayout.LayoutParams(dp(42),dp(48)));share.setOnClickListener(v->share());root.addView(bar);View line=new View(this);line.setBackgroundColor(divider);root.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
        scroll=new ScrollView(this);scroll.setFillViewport(true);body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(20),dp(22),dp(20),dp(36));body.setBackgroundColor(bg);scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);}
    private void render(){String title=decode(story.optString("title","Untitled Story"));TextView heading=text(title,27,ink,true);heading.setLineSpacing(dp(2),1f);body.addView(heading);LinearLayout author=new LinearLayout(this);author.setGravity(Gravity.CENTER_VERTICAL);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,-2);ap.topMargin=dp(17);ap.bottomMargin=dp(18);body.addView(author,ap);
        ImageView avatar=new ImageView(this);avatar.setImageResource(R.drawable.ic_phisk_default_avatar);avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);avatar.setBackground(new android.graphics.drawable.GradientDrawable(){ {setColor(surface);setShape(android.graphics.drawable.GradientDrawable.OVAL);setStroke(dp(1),divider);} });avatar.setClipToOutline(true);author.addView(avatar,new LinearLayout.LayoutParams(dp(42),dp(42)));loadImage(story.optString("author_avatar",""),avatar,false);
        LinearLayout names=new LinearLayout(this);names.setOrientation(LinearLayout.VERTICAL);LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,-2,1);np.leftMargin=dp(11);author.addView(names,np);TextView creator=text(decode(story.optString("author","PhiskVideos Creator")),14,ink,true);names.addView(creator);TextView date=text(story.optString("date",""),12,muted,false);LinearLayout.LayoutParams datep=new LinearLayout.LayoutParams(-1,-2);datep.topMargin=dp(3);names.addView(date,datep);int creatorId=story.optInt("author_id",0);if(creatorId>0){View.OnClickListener channel=v->{Intent i=new Intent(this,NativeCreatorChannelActivity.class);i.putExtra("creator_id",creatorId);startActivity(i);};avatar.setOnClickListener(channel);creator.setOnClickListener(channel);}
        String featured=story.optString("image","");if(valid(featured)){ImageView hero=new ImageView(this);hero.setScaleType(ImageView.ScaleType.CENTER_CROP);hero.setBackgroundColor(dark?Color.rgb(42,43,49):Color.rgb(241,242,245));hero.setClipToOutline(true);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(220));hp.bottomMargin=dp(22);body.addView(hero,hp);loadImage(featured,hero,true);}
        String html=story.optString("content","");if(html.trim().isEmpty())html="<p>Story content is unavailable.</p>";TextView article=text("",17,ink,false);article.setLineSpacing(dp(5),1.12f);article.setTextIsSelectable(true);article.setMovementMethod(LinkMovementMethod.getInstance());article.setLinkTextColor(dark?Color.rgb(190,160,255):VIOLET);article.setText(Html.fromHtml(html,Html.FROM_HTML_MODE_COMPACT,new StoryImageGetter(article),null));body.addView(article);
        View divider=new View(this);divider.setBackgroundColor(divider);LinearLayout.LayoutParams dpv=new LinearLayout.LayoutParams(-1,dp(1));dpv.topMargin=dp(24);dpv.bottomMargin=dp(14);body.addView(divider,dpv);TextView foot=text("Published on PhiskVideos",12,muted,false);body.addView(foot);
    }
    private class StoryImageGetter implements Html.ImageGetter {private final TextView target;StoryImageGetter(TextView t){target=t;}public Drawable getDrawable(String source){URLDrawable placeholder=new URLDrawable();placeholder.setBounds(0,0,dp(280),dp(170));if(valid(source))images.execute(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(source).openConnection();c.setConnectTimeout(10000);c.setReadTimeout(15000);Bitmap b=BitmapFactory.decodeStream(c.getInputStream());c.disconnect();if(b!=null)runOnUiThread(()->{BitmapDrawable d=new BitmapDrawable(getResources(),b);int w=Math.min(dp(320),Math.max(dp(180),b.getWidth()));int h=(int)((float)b.getHeight()/Math.max(1,b.getWidth())*w);placeholder.setImage(d,w,h);target.invalidate();});}catch(Exception ignored){}});return placeholder;}}
    private static class URLDrawable extends Drawable {private Drawable inner=new ColorDrawable(Color.TRANSPARENT);private int w=1,h=1;void setImage(Drawable d,int width,int height){inner=d;w=width;h=height;setBounds(getBounds());}public void draw(android.graphics.Canvas c){inner.setBounds(getBounds());inner.draw(c);}public void setAlpha(int a){inner.setAlpha(a);}public void setColorFilter(android.graphics.ColorFilter f){inner.setColorFilter(f);}public int getOpacity(){return android.graphics.PixelFormat.TRANSLUCENT;}public int getIntrinsicWidth(){return w;}public int getIntrinsicHeight(){return h;}}
    private void loadImage(String url,ImageView view,boolean large){if(!valid(url))return;images.execute(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(10000);c.setReadTimeout(15000);Bitmap b=BitmapFactory.decodeStream(c.getInputStream());c.disconnect();if(b!=null)runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())view.setImageBitmap(b);});}catch(Exception ignored){}});}
    private boolean valid(String u){try{Uri x=Uri.parse(u);return "https".equalsIgnoreCase(x.getScheme())&&x.getHost()!=null;}catch(Exception e){return false;}}
    private String decode(String s){return android.text.Html.fromHtml(s==null?"":s,Html.FROM_HTML_MODE_LEGACY).toString().trim();}
    private void share(){String url=story.optString("permalink",HOME);Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,decode(story.optString("title","Story"))+"\n"+url);startActivity(Intent.createChooser(i,"Share Story"));}
    @Override protected void onDestroy(){images.shutdownNow();super.onDestroy();}
}
