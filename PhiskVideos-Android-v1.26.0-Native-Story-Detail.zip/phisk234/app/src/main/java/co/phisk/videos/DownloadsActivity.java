package co.phisk.videos;

import android.content.Intent;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;
import android.text.Html;

import org.json.JSONObject;

import java.io.File;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DownloadsActivity extends Activity {
    private static final String PREFS = "phisk_download_metadata";
    private static final String DOWNLOAD_CONTROL = "phisk_download_control";
    private static final int VIOLET = Color.rgb(124, 58, 237);
    private LinearLayout list;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable refresher = new Runnable() {
        @Override public void run() {
            if (!playerVisible) refreshList();
            handler.postDelayed(this, 1200);
        }
    };
    private final Map<String, RowHolder> rows = new LinkedHashMap<>();
    private final Map<String, Bitmap> thumbnailCache = new HashMap<>();
    private final List<String> displayedOrder = new ArrayList<>();
    private boolean listBuilt = false;
    private final Set<String> loadingThumbnails = new HashSet<>();
    private final ExecutorService imageExecutor = Executors.newFixedThreadPool(2);
    private boolean playerVisible = false;
    private File activeFile;
    private int savedPosition = 0;
    private boolean resumeAfterRebuild = true;
    private VideoView activeVideo;

    @Override public void onCreate(Bundle state) {
        PhiskTheme.configureActivityTheme(this);super.onCreate(state);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.WHITE);
        showDownloads();
    }

    @Override protected void onResume() {
        super.onResume();PhiskTheme.apply(this);
        handler.removeCallbacks(refresher);
        handler.post(refresher);
    }

    @Override protected void onPause() {
        handler.removeCallbacks(refresher);
        super.onPause();
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (playerVisible && activeFile != null) {
            if (activeVideo != null) {
                try { savedPosition = activeVideo.getCurrentPosition(); resumeAfterRebuild = activeVideo.isPlaying(); }
                catch (Exception ignored) { }
            }
            buildPlayer();
        } else {
            showSystemBars();
            refreshList();
        }
    }

    private void showDownloads() {
        playerVisible = false;
        activeVideo = null;
        showSystemBars();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(12), dp(18), dp(12));
        root.setBackgroundColor(Color.WHITE);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Downloads");
        title.setTextColor(Color.BLACK);
        title.setTextSize(23);
        title.setTypeface(null, 1);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        TextView close = textAction("Close", VIOLET);
        close.setOnClickListener(v -> finish());
        header.addView(close);
        root.addView(header);

        TextView subtitle = new TextView(this);
        subtitle.setText("Videos saved on this device");
        subtitle.setTextColor(Color.DKGRAY);
        subtitle.setTextSize(13);
        subtitle.setPadding(0, dp(4), 0, dp(16));
        root.addView(subtitle);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        displayedOrder.clear();
        listBuilt = false;
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        refreshList();
    }

    private void refreshList() {
        if (list == null || playerVisible) return;
        File dir = new File(getFilesDir(), "downloads");
        File[] files = dir.listFiles();
        if (files == null) files = new File[0];
        Arrays.sort(files, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));

        List<String> visibleKeys = new ArrayList<>();
        List<RowHolder> orderedRows = new ArrayList<>();
        for (File file : files) {
            if (!file.isFile()) continue;
            boolean downloading = file.getName().endsWith(".part");
            String rowKey = downloading ? file.getName().substring(0, file.getName().length() - 5) : file.getName();
            JSONObject meta = readMeta(rowKey);
            RowHolder holder = rows.get(rowKey);
            if (holder == null) {
                holder = createRow(rowKey);
                rows.put(rowKey, holder);
            }
            holder.file = file;
            holder.meta = meta;
            updateRow(holder, downloading);
            visibleKeys.add(rowKey);
            orderedRows.add(holder);
        }

        Set<String> visible = new HashSet<>(visibleKeys);
        rows.keySet().removeIf(key -> !visible.contains(key));
        boolean orderChanged = !listBuilt || !visibleKeys.equals(displayedOrder);
        if (orderChanged) {
            list.removeAllViews();
            displayedOrder.clear();
            displayedOrder.addAll(visibleKeys);
            listBuilt = true;
            if (orderedRows.isEmpty()) {
                TextView empty = new TextView(this);
                empty.setText("No downloaded videos yet.");
                empty.setTextColor(Color.GRAY);
                empty.setGravity(Gravity.CENTER);
                list.addView(empty, new LinearLayout.LayoutParams(-1, dp(180)));
                return;
            }
            for (RowHolder holder : orderedRows) {
                list.addView(holder.row);
                View divider = new View(this);
                divider.setBackgroundColor(0xFFEAEAEA);
                list.addView(divider, new LinearLayout.LayoutParams(-1, dp(1)));
            }
        }
    }

    private RowHolder createRow(String key) {
        RowHolder holder = new RowHolder();
        holder.key = key;
        holder.row = new LinearLayout(this);
        holder.row.setOrientation(LinearLayout.HORIZONTAL);
        holder.row.setGravity(Gravity.CENTER_VERTICAL);
        holder.row.setPadding(0, dp(10), 0, dp(10));

        holder.thumb = new ImageView(this);
        holder.thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
        holder.thumb.setBackgroundColor(0xFFEDE9FE);
        holder.row.addView(holder.thumb, new LinearLayout.LayoutParams(dp(104), dp(66)));

        LinearLayout details = new LinearLayout(this);
        details.setOrientation(LinearLayout.VERTICAL);
        details.setPadding(dp(11), 0, dp(4), 0);
        holder.row.addView(details, new LinearLayout.LayoutParams(0, -2, 1));

        holder.name = new TextView(this);
        holder.name.setTextColor(Color.BLACK);
        holder.name.setTextSize(14);
        holder.name.setTypeface(null, 1);
        holder.name.setMaxLines(2);
        details.addView(holder.name);

        holder.by = new TextView(this);
        holder.by.setTextColor(Color.GRAY);
        holder.by.setTextSize(12);
        holder.by.setPadding(0, dp(3), 0, dp(4));
        details.addView(holder.by);

        holder.meter = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        holder.meter.setMax(100);
        holder.meter.setProgressTintList(android.content.res.ColorStateList.valueOf(VIOLET));
        details.addView(holder.meter, new LinearLayout.LayoutParams(-1, dp(4)));

        holder.progressLabel = new TextView(this);
        holder.progressLabel.setTextColor(Color.GRAY);
        holder.progressLabel.setTextSize(11);
        holder.progressLabel.setPadding(0, dp(3), 0, 0);
        details.addView(holder.progressLabel);

        holder.more = new TextView(this);
        holder.more.setText("⋮");
        holder.more.setTextSize(25);
        holder.more.setTextColor(Color.DKGRAY);
        holder.more.setGravity(Gravity.CENTER);
        holder.more.setPadding(dp(10), dp(8), 0, dp(8));
        holder.row.addView(holder.more);
        holder.more.setOnClickListener(v -> showActions(holder.more, holder.file, holder.key, holder.meta));
        holder.row.setOnClickListener(v -> {
            if (holder.file != null && !holder.file.getName().endsWith(".part")) play(holder.file);
        });
        holder.thumb.setOnClickListener(v -> {
            if (holder.file != null && !holder.file.getName().endsWith(".part")) play(holder.file);
        });
        holder.name.setOnClickListener(v -> {
            if (holder.file != null && !holder.file.getName().endsWith(".part")) play(holder.file);
        });
        return holder;
    }

    private void updateRow(RowHolder holder, boolean downloading) {
        JSONObject meta = holder.meta;
        String title = meta.optString("title", holder.file.getName()
                .replaceFirst("^[0-9]+_", "")
                .replaceFirst("(?i)\\.(mp4|m4v|mov|webm|ogv)(\\.part)?$", ""));
        String channel = meta.optString("channel", "");
        int pct = meta.optInt("progress", downloading ? 0 : 100);
        holder.name.setText(Html.fromHtml(title, Html.FROM_HTML_MODE_LEGACY).toString());
        String control = getSharedPreferences(DOWNLOAD_CONTROL, MODE_PRIVATE).getString(holder.key, "running");
        holder.by.setText(channel.isEmpty() ? (downloading ? ("paused".equals(control) ? "Paused" : "Downloading…") : formatSize(holder.file.length())) : "By " + Html.fromHtml(channel, Html.FROM_HTML_MODE_LEGACY).toString());
        holder.meter.setProgress(pct);
        holder.meter.setVisibility(downloading ? View.VISIBLE : View.GONE);
        holder.progressLabel.setText(downloading ? ("paused".equals(control) ? "Paused • " : "") + (pct > 0 ? pct + "% downloaded" : "Downloading…") : "Saved offline • " + formatSize(holder.file.length()));
        holder.progressLabel.setTextColor(Color.GRAY);
        holder.more.setVisibility(View.VISIBLE);

        String localThumbnail = meta.optString("thumbnail_local_path", "");
        String thumbnailUrl = meta.optString("thumbnail", "");
        String imageKey = localThumbnail.isEmpty() ? thumbnailUrl : localThumbnail;
        if (imageKey.equals(holder.thumbnailUrl)) return;
        holder.thumbnailUrl = imageKey;
        holder.thumb.setImageDrawable(null);
        if (!localThumbnail.isEmpty()) { Bitmap bitmap = BitmapFactory.decodeFile(localThumbnail); if (bitmap != null) holder.thumb.setImageBitmap(bitmap); } else loadThumbnail(holder.thumb, thumbnailUrl);
    }

    private JSONObject readMeta(String key) {
        try { return new JSONObject(getSharedPreferences(PREFS, MODE_PRIVATE).getString(key, "{}")); }
        catch (Exception e) { return new JSONObject(); }
    }

    private void loadThumbnail(ImageView view, String imageUrl) {
        if (imageUrl == null || !imageUrl.startsWith("https://")) return;
        view.setTag(imageUrl);
        Bitmap cached = thumbnailCache.get(imageUrl);
        if (cached != null) { view.setImageBitmap(cached); return; }
        if (!loadingThumbnails.add(imageUrl)) return;
        imageExecutor.execute(() -> {
            Bitmap bitmap = null;
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(imageUrl).openConnection();
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(15000);
                connection.setInstanceFollowRedirects(true);
                connection.setRequestProperty("User-Agent", "PhiskVideosApp/1.3.6");
                bitmap = PhiskImageCache.getBitmap(this, imageUrl);
            } catch (Exception ignored) {
            } finally {
                if (connection != null) connection.disconnect();
            }
            final Bitmap result = bitmap;
            runOnUiThread(() -> {
                loadingThumbnails.remove(imageUrl);
                if (result != null) {
                    thumbnailCache.put(imageUrl, result);
                    if (imageUrl.equals(view.getTag())) view.setImageBitmap(result);
                }
            });
        });
    }

    private void showActions(View anchor, File file, String key, JSONObject meta) {
        if (file == null) return;
        boolean downloading = file.getName().endsWith(".part");
        String control = getSharedPreferences(DOWNLOAD_CONTROL, MODE_PRIVATE).getString(key, "running");
        PopupMenu menu = new PopupMenu(this, anchor);
        if (downloading) menu.getMenu().add("paused".equals(control) ? "Continue" : "Pause");
        else menu.getMenu().add("Play");
        menu.getMenu().add("Delete");
        menu.setOnMenuItemClickListener(item -> {
            String action = item.getTitle().toString();
            if ("Play".equals(action)) play(file);
            else if ("Pause".equals(action)) {
                getSharedPreferences(DOWNLOAD_CONTROL, MODE_PRIVATE).edit().putString(key, "paused").apply();
                updateProgressState(key, meta, "Paused");
                refreshList();
            } else if ("Continue".equals(action)) {
                getSharedPreferences(DOWNLOAD_CONTROL, MODE_PRIVATE).edit().putString(key, "running").apply();
                updateProgressState(key, meta, "Downloading…");
                refreshList();
            } else if ("Delete".equals(action)) {
                if (downloading) {
                    getSharedPreferences(DOWNLOAD_CONTROL, MODE_PRIVATE).edit().putString(key, "delete").apply();
                    file.delete();
                } else {
                    file.delete();
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(key).apply();
                }
                refreshList();
            }
            return true;
        });
        menu.show();
    }

    private void updateProgressState(String key, JSONObject meta, String state) {
        try {
            JSONObject updated = meta == null ? new JSONObject() : new JSONObject(meta.toString());
            updated.put("state", state);
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(key, updated.toString()).apply();
        } catch (Exception ignored) { }
    }

    private void play(File file) {
        if (file == null || !file.exists()) return;
        Intent intent = new Intent(this, OfflineVideoActivity.class);
        intent.putExtra("offline_file", file.getAbsolutePath());
        startActivity(intent);
    }

    private void buildPlayer() {
        if (activeFile == null) return;
        boolean landscape = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        if (landscape) enterImmersiveMode(); else showSystemBars();

        JSONObject meta = readMeta(activeFile.getName());
        String titleText = meta.optString("title", activeFile.getName().replaceFirst("^[0-9]+_", "")
                .replaceFirst("(?i)\\.(mp4|m4v|mov|webm|ogv)$", ""));
        String channel = meta.optString("channel", "");

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(landscape ? Color.BLACK : Color.WHITE);

        if (!landscape) {
            LinearLayout top = new LinearLayout(this);
            top.setOrientation(LinearLayout.HORIZONTAL);
            top.setGravity(Gravity.CENTER_VERTICAL);
            top.setPadding(dp(16), dp(8), dp(16), dp(8));
            TextView close = textAction("‹  Close", VIOLET);
            close.setOnClickListener(v -> closeDownloadsActivity());
            top.addView(close, new LinearLayout.LayoutParams(0, dp(44), 1));
            TextView fullscreen = textAction("⛶", VIOLET);
            fullscreen.setTextSize(24);
            fullscreen.setContentDescription("Open fullscreen player");
            fullscreen.setOnClickListener(v -> setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE));
            top.addView(fullscreen);
            root.addView(top);
        }

        FrameLayout playerFrame = new FrameLayout(this);
        playerFrame.setBackgroundColor(Color.BLACK);
        LinearLayout.LayoutParams frameParams = landscape
                ? new LinearLayout.LayoutParams(-1, 0, 1f)
                : new LinearLayout.LayoutParams(-1, dp(230));
        root.addView(playerFrame, frameParams);

        VideoView video = new VideoView(this);
        video.setBackgroundColor(Color.BLACK);
        video.setFocusable(true);
        video.setFocusableInTouchMode(true);
        playerFrame.addView(video, new FrameLayout.LayoutParams(-1, -1));
        activeVideo = video;

        if (landscape) {
            TextView exitFullscreen = textAction("⛶", Color.WHITE);
            exitFullscreen.setTextSize(22);
            exitFullscreen.setGravity(Gravity.CENTER);
            exitFullscreen.setBackground(roundBackground(0x88000000, dp(8)));
            FrameLayout.LayoutParams exitParams = new FrameLayout.LayoutParams(dp(48), dp(48), Gravity.TOP | Gravity.END);
            exitParams.setMargins(0, dp(12), dp(12), 0);
            playerFrame.addView(exitFullscreen, exitParams);
            exitFullscreen.setOnClickListener(v -> setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT));
        }

        MediaController controls = new MediaController(this);
        controls.setAnchorView(video);
        final int seekTo = savedPosition;
        final boolean shouldResume = resumeAfterRebuild;
        video.setOnPreparedListener(mp -> {
            // Explicitly select the local file's video track and start only after
            // VideoView has a prepared decoder and an attached rendering surface.
            try {
                mp.setOnVideoSizeChangedListener((player, width, height) -> {
                    if (width > 0 && height > 0) video.setBackgroundColor(Color.TRANSPARENT);
                });
            } catch (Exception ignored) { }
            if (seekTo > 0) video.seekTo(seekTo);
            if (shouldResume) video.start();
        });
        video.setOnErrorListener((mp, what, extra) -> {
            Toast.makeText(this, "Unable to play this downloaded video. The file may be incomplete or use an unsupported format.", Toast.LENGTH_LONG).show();
            return true;
        });
        video.setMediaController(controls);
        video.setKeepScreenOn(true);
        video.setZOrderOnTop(false);

        if (!landscape) {
            LinearLayout details = new LinearLayout(this);
            details.setOrientation(LinearLayout.VERTICAL);
            details.setPadding(dp(18), dp(14), dp(18), dp(18));
            root.addView(details, new LinearLayout.LayoutParams(-1, -2));

            TextView title = new TextView(this);
            title.setText(titleText);
            title.setTextColor(Color.BLACK);
            title.setTextSize(18);
            title.setTypeface(null, 1);
            details.addView(title);

            TextView creator = new TextView(this);
            creator.setText(channel.isEmpty() ? "Creator information unavailable" : "By " + channel);
            creator.setTextColor(VIOLET);
            creator.setTextSize(13);
            creator.setPadding(0, dp(7), 0, dp(9));
            details.addView(creator);

            TextView info = new TextView(this);
            info.setText("Saved for offline viewing • " + formatSize(activeFile.length()) + "\nThis video is stored on this device and can be watched without an internet connection.");
            info.setTextColor(0xFF667085);
            info.setTextSize(13);
            info.setLineSpacing(dp(3), 1f);
            details.addView(info);
        }

        setContentView(root);
        // Wait until the VideoView is attached and its SurfaceView can create a
        // rendering surface before opening the private local MP4 file.
        video.post(() -> {
            if (activeVideo == video && activeFile != null && activeFile.isFile()) {
                video.setVideoURI(Uri.fromFile(activeFile));
            }
        });
    }

    private void closeDownloadsActivity() {
        if (activeVideo != null) {
            try { activeVideo.stopPlayback(); } catch (Exception ignored) { }
            activeVideo = null;
        }
        playerVisible = false;
        finish();
    }

    private void returnToDownloads() {
        savedPosition = 0;
        activeFile = null;
        activeVideo = null;
        playerVisible = false;
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        showDownloads();
    }

    private void enterImmersiveMode() {
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().setBackgroundDrawableResource(android.R.color.black);
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
        }
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    private void showSystemBars() {
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(true);
        }
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().setBackgroundDrawableResource(android.R.color.white);
    }

    private TextView textAction(String text, int color) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(color);
        view.setTextSize(16);
        view.setGravity(Gravity.CENTER_VERTICAL);
        view.setPadding(dp(4), 0, dp(4), 0);
        return view;
    }

    private android.graphics.drawable.GradientDrawable roundBackground(int color, int radius) {
        android.graphics.drawable.GradientDrawable drawable = new android.graphics.drawable.GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        return drawable;
    }

    private String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format(java.util.Locale.US, "%.1f KB", bytes / 1024.0);
        return String.format(java.util.Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0));
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override public void onBackPressed() {
        // The offline screen is a temporary destination over the website. Back/Close
        // must reveal that exact website page rather than rebuilding the app activity.
        closeDownloadsActivity();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(refresher);
        imageExecutor.shutdownNow();
        if (activeVideo != null) { try { activeVideo.stopPlayback(); } catch (Exception ignored) { } }
        super.onDestroy();
    }

    private static class RowHolder {
        String key;
        String thumbnailUrl = "";
        File file;
        JSONObject meta;
        LinearLayout row;
        ImageView thumb;
        TextView name;
        TextView by;
        ProgressBar meter;
        TextView progressLabel;
        TextView more;
    }
}
