# Native Stories Feed API

`GET /wp-json/phisk/v1/stories/feed?feed=following|discover&page=1&per_page=20&interest=slug`

The response includes `items` and `has_more`. Each item includes `id`, `title`, `excerpt`, `content` (formatted WordPress HTML), `image`, `author`, `author_id`, `author_avatar`, `date`, `published`, and `permalink`.

`author_id` and `author_avatar` are provided for native creator identity and channel navigation. Stories do not currently expose likes or a native comments endpoint through this API.
