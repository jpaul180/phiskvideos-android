# PhiskVideos Android 1.25.1 — Stories Pagination

- Renamed the homepage navigation tab from “Top Stories” to “Stories”.
- Following requests exactly 10 Stories and does not offer pagination or Load More.
- Discover requests 20 Stories per batch.
- Discover uses a manual “Load More” button; scrolling no longer triggers automatic Stories requests.
- Discover category selection remains applied to subsequent batches.
- The WordPress Stories endpoint retains its server-side maximum of 20 items per request.
