# PhiskVideos Android 1.25.0 — Native Stories

- Replaced the Top Stories placeholder with a native Stories feed experience.
- Added Following and Discover feed switching.
- Added Discover-only horizontal category filtering.
- Added compact, uniform article cards with image, title, excerpt, creator and publication date.
- Added independent chronological pagination and pull-to-refresh.
- Connected the app to new authenticated/public-read Video Manager REST endpoints backed by the existing WordPress Story and subscription data.
- Preserved the existing Explore, video feeds, Creator Studio and app navigation.

Article cards open the published article URL through the app's existing in-app navigation.
