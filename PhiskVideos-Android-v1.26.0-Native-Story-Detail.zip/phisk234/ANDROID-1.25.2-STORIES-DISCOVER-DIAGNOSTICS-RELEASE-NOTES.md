# PhiskVideos Android v1.25.2 — Stories Discover Diagnostics

- Fixed the Stories error-state retry action: it now retries the Stories feed from page 1 instead of invoking the generic homepage feed loader.
- Added Logcat diagnostics for Stories category/feed failures, including feed, page, selected category, and server response details.
- Shows a concise API error detail in the Stories error state so HTTP/PHP/REST failures can be distinguished from connectivity timeouts.
- Treats category loading as auxiliary: if the categories endpoint fails, the app still attempts to load the story feed.
- Increased the shared native API request read timeout to 30 seconds.
- Preserved Stories pagination: Following requests 10 items; Discover requests 20 items and retains manual Load More.
