# PhiskVideos Android 1.26.0 — Native Story Detail

- Story cards now open a dedicated native Story Detail screen instead of routing to the WebView.
- Added native title, creator identity, publication date, featured image, formatted article body, inline HTTPS images, and native sharing.
- Creator avatar/name navigate to the native Creator Channel when the author ID is available.
- Neutral editorial styling with restrained violet accents and app-wide light/dark theme support.
- Stories feed pagination and Following/Discover behavior are unchanged.
- Requires Phisk Video Manager 1.23.2 to supply the story author ID and avatar URL in feed items.
