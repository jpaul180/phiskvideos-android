package co.phisk.videos;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.Intent;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.net.Uri;
import org.json.*;
import java.net.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

/** Native notification inbox backed by the existing Phisk Video Manager REST API. */
public class NotificationCentreActivity extends Activity {
    private static final String API="https://videos.phisk.co/wp-json/phisk/v1/";
    private static final int VIOLET=Color.rgb(124,58,237), INK=Color.rgb(25,29,38), MUTED=Color.rgb(112,117,128);
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private LinearLayout list, root; private TextView unreadLabel; private ProgressBar loading;
    private int unread=0; private JSONArray items=new JSONArray();

    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(Color.WHITE); getWindow().setNavigationBarColor(Color.WHITE); getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR); build(); load(); }
    private GradientDrawable bg(int color,int stroke){ GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(9)); if(stroke!=0)d.setStroke(dp(1),stroke); return d; }
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);} 
    private TextView text(String value,int size,int color,boolean bold){ TextView t=new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t; }
    private void build(){
      root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.WHITE);
      LinearLayout header=new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setPadding(dp(18),dp(14),dp(18),dp(12));
      TextView back=text("‹",34,INK,false); header.addView(back,new LinearLayout.LayoutParams(dp(38),dp(44))); back.setOnClickListener(v->finish());
      LinearLayout titles=new LinearLayout(this); titles.setOrientation(LinearLayout.VERTICAL); TextView title=text("Notifications",22,INK,true); titles.addView(title); unreadLabel=text("Your latest activity",12,MUTED,false); titles.addView(unreadLabel); header.addView(titles,new LinearLayout.LayoutParams(0,-2,1));
      TextView all=text("Mark all read",12,VIOLET,true); header.addView(all); all.setOnClickListener(v->markAll()); root.addView(header);
      View divider=new View(this); divider.setBackgroundColor(Color.rgb(237,238,242)); root.addView(divider,new LinearLayout.LayoutParams(-1,dp(1)));
      FrameLayout body=new FrameLayout(this); list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(14),dp(12),dp(14),dp(20)); ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.addView(list); body.addView(scroll);
      loading=new ProgressBar(this); FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(42),dp(42),Gravity.CENTER); body.addView(loading,lp); root.addView(body,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }
    private String token(){return getSharedPreferences("phisk_native_auth",MODE_PRIVATE).getString("access_token","");}
    private JSONObject request(String path,String method,JSONObject data)throws Exception{
      HttpURLConnection c=(HttpURLConnection)new URL(API+path).openConnection(); c.setRequestMethod(method); c.setConnectTimeout(15000); c.setReadTimeout(20000); c.setRequestProperty("Accept","application/json"); c.setRequestProperty("Authorization","Bearer "+token());
      if(data!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=utf-8");try(OutputStream o=c.getOutputStream()){o.write(data.toString().getBytes("UTF-8"));}}
      int code=c.getResponseCode(); InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream(); ByteArrayOutputStream out=new ByteArrayOutputStream(); if(in!=null){byte[] buf=new byte[4096];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);in.close();} c.disconnect(); if(code<200||code>=300)throw new IOException("Server returned "+code); return new JSONObject(out.toString("UTF-8"));
    }
    private void load(){ loading.setVisibility(View.VISIBLE); io.execute(()->{try{JSONObject r=request("notifications?page=1&per_page=50","GET",null); JSONArray a=r.optJSONArray("notifications"); int count=r.optInt("unread_count"); runOnUiThread(()->render(a==null?new JSONArray():a,count));}catch(Exception e){runOnUiThread(()->error("Couldn't load notifications. Check your connection and try again."));}}); }
    private void error(String msg){loading.setVisibility(View.GONE); list.removeAllViews(); TextView t=text(msg,14,MUTED,false); t.setGravity(Gravity.CENTER); t.setPadding(dp(25),dp(45),dp(25),dp(45)); list.addView(t); Button retry=new Button(this);retry.setText("Try again");retry.setTextColor(VIOLET);list.addView(retry);retry.setOnClickListener(v->load());}
    private void render(JSONArray a,int count){ items=a; unread=count; loading.setVisibility(View.GONE); unreadLabel.setText(count==0?"You're all caught up":""+count+" unread notification"+(count==1?"":"s")); list.removeAllViews();
      if(a.length()==0){ LinearLayout empty=new LinearLayout(this);empty.setOrientation(LinearLayout.VERTICAL);empty.setGravity(Gravity.CENTER);empty.setPadding(dp(24),dp(65),dp(24),dp(30)); TextView mark=text("✓",42,VIOLET,true);empty.addView(mark);TextView msg=text("You're all caught up",18,INK,true);msg.setPadding(0,dp(12),0,dp(6));empty.addView(msg);TextView sub=text("New channel updates and important account notifications will appear here.",13,MUTED,false);sub.setGravity(Gravity.CENTER);empty.addView(sub);list.addView(empty);return;}
      for(int i=0;i<a.length();i++){JSONObject item=a.optJSONObject(i);if(item!=null)addItem(item);}
    }
    private int iconFor(String type){String t=type.toLowerCase(Locale.US);if(t.contains("approv"))return R.drawable.ic_notice_approval;if(t.contains("monet")||t.contains("wallet")||t.contains("payout"))return R.drawable.ic_notice_wallet;if(t.contains("strike")||t.contains("warning")||t.contains("caution"))return R.drawable.ic_notice_warning;if(t.contains("announcement")||t.contains("admin"))return R.drawable.ic_notice_announcement;return R.drawable.ic_notice_general;}
    private void addItem(JSONObject item){
      int id=item.optInt("id"); boolean read=item.optInt("is_read")==1 || "1".equals(item.optString("is_read")); String type=item.optString("type"), title=item.optString("title","PhiskVideos update"), message=item.optString("message"), date=item.optString("created_at"), target=item.optString("target_url","https://videos.phisk.co/");
      LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.HORIZONTAL);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(12),dp(12),dp(10),dp(12));card.setBackground(bg(read?Color.WHITE:Color.rgb(250,247,255),read?Color.rgb(235,236,240):Color.rgb(222,208,250)));
      ImageView icon=new ImageView(this);icon.setImageResource(iconFor(type));icon.setScaleType(ImageView.ScaleType.FIT_CENTER);card.addView(icon,new LinearLayout.LayoutParams(dp(48),dp(48)));
      LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(12),0,dp(6),0); TextView h=text(title,14,INK,true);TextView body=text(message,12,MUTED,false);body.setMaxLines(3);TextView when=text(date,10,MUTED,false);when.setPadding(0,dp(5),0,0);copy.addView(h);if(!message.isEmpty())copy.addView(body);copy.addView(when);card.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
      TextView del=text("×",23,MUTED,false);del.setGravity(Gravity.CENTER);card.addView(del,new LinearLayout.LayoutParams(dp(28),dp(42)));del.setContentDescription("Delete notification");del.setOnClickListener(v->delete(id));
      LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=dp(9);list.addView(card,cp);card.setOnClickListener(v->{if(!read)markRead(id);openTarget(target);});
    }
    private void markRead(int id){io.execute(()->{try{JSONObject d=new JSONObject();d.put("id",id);JSONObject r=request("notifications/read","POST",d);runOnUiThread(()->{unread=r.optInt("unread_count",Math.max(0,unread-1));load();});}catch(Exception ignored){}});}
    private void markAll(){io.execute(()->{try{request("notifications/read-all","POST",new JSONObject());runOnUiThread(this::load);}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Couldn't update notifications",Toast.LENGTH_SHORT).show());}});}
    private void delete(int id){io.execute(()->{try{JSONObject d=new JSONObject();d.put("id",id);request("notifications/delete","POST",d);runOnUiThread(this::load);}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Couldn't delete notification",Toast.LENGTH_SHORT).show());}});}
    private void openTarget(String value){try{Uri u=Uri.parse(value);String host=u.getHost();if("https".equalsIgnoreCase(u.getScheme())&&host!=null&&(host.equalsIgnoreCase("phisk.co")||host.toLowerCase(Locale.US).endsWith(".phisk.co"))){Intent i=new Intent(this,MainActivity.class);i.putExtra(MainActivity.EXTRA_NOTIFICATION_URL,u.toString());i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(i);finish();}}catch(Exception ignored){}}
    @Override protected void onDestroy(){io.shutdown();super.onDestroy();}
}
