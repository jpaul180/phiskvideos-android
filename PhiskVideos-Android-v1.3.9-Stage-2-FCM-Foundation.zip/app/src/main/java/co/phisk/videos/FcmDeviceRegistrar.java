package co.phisk.videos;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;

/** Registers this app installation's FCM token with the authenticated PhiskVideos account. */
public final class FcmDeviceRegistrar {
    private static final String HOME = "https://videos.phisk.co/";
    private static final String PREFS = "phisk_native_auth";
    private static final String DEVICE_PREFS = "phisk_fcm_device";
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();

    private FcmDeviceRegistrar() {}

    public static String getDeviceId(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(DEVICE_PREFS, Context.MODE_PRIVATE);
        String id = prefs.getString("device_id", null);
        if (id == null || id.trim().isEmpty()) {
            id = UUID.randomUUID().toString();
            prefs.edit().putString("device_id", id).apply();
        }
        return id;
    }

    public static void register(Context context, String fcmToken) {
        if (fcmToken == null || fcmToken.trim().isEmpty()) return;
        Context app = context.getApplicationContext();
        SharedPreferences auth = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String bearer = auth.getString("access_token", "");
        if (!auth.getBoolean("signed_in", false) || bearer.trim().isEmpty()) return;
        final String deviceId = getDeviceId(app);
        final String token = fcmToken.trim();
        EXECUTOR.execute(() -> {
            HttpURLConnection connection = null;
            try {
                JSONObject body = new JSONObject();
                body.put("fcm_token", token);
                body.put("device_id", deviceId);
                body.put("platform", "android");
                body.put("app_version", "1.3.9");
                connection = (HttpURLConnection) new URL(HOME + "wp-json/phisk/v1/app-devices/register").openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(20000);
                connection.setReadTimeout(25000);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                connection.setRequestProperty("Accept", "application/json");
                connection.setRequestProperty("Authorization", "Bearer " + bearer);
                byte[] bytes = body.toString().getBytes("UTF-8");
                try (OutputStream out = connection.getOutputStream()) { out.write(bytes); }
                int status = connection.getResponseCode();
                if (status >= 200 && status < 300) {
                    app.getSharedPreferences(DEVICE_PREFS, Context.MODE_PRIVATE).edit()
                            .putString("registered_token", token).apply();
                }
            } catch (Exception ignored) {
                // Registration is retried on the next token refresh or successful sign-in.
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    public static void revokeSession(Context context) {
        Context app = context.getApplicationContext();
        String bearer = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("access_token", "");
        if (bearer.trim().isEmpty()) return;
        EXECUTOR.execute(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(HOME + "wp-json/phisk/v1/app-auth/logout").openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(12000);
                connection.setReadTimeout(15000);
                connection.setRequestProperty("Authorization", "Bearer " + bearer);
                connection.setRequestProperty("Accept", "application/json");
                connection.getResponseCode();
            } catch (Exception ignored) {
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    public static void registerCurrentToken(Context context) {
        com.google.firebase.messaging.FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null) register(context, task.getResult());
                });
    }
}
