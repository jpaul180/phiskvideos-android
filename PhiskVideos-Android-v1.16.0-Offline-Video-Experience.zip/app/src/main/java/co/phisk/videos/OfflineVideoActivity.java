package co.phisk.videos;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;

/** Native offline copy of the PhiskVideos watch page. No online-only actions are shown. */
public class OfflineVideoActivity extends Activity {
    private static final int VIOLET=Color.rgb(124,58,237), INK=Color.rgb(25,29,38), MUTED=Color.rgb(112,117,128), BG=Color.rgb(247,248,250);
    private static final String PREFS="phisk_download_metadata";
    private ExoPlayer player;
    private PlayerView playerView;
    private LinearLayout content;
    private File videoFile;
    private JSONObject video;
    private JSONArray related;
    private boolean resumeOnReturn=true;

    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private String clean(String value){return android.text.Html.fromHtml(value==null?"":value,android.text.Html.FROM_HTML_MODE_LEGACY).toString();}
    private TextView text(String value,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(clean(value));t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}

    @Override protected void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(Color.BLACK);getWindow().setNavigationBarColor(Color.WHITE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);String path=getIntent().getStringExtra("offline_file");videoFile=path==null?null:new File(path);if(videoFile==null||!videoFile.isFile()){Toast.makeText(this,"This downloaded video is no longer available.",Toast.LENGTH_LONG).show();finish();return;}String key=videoFile.getName();JSONObject meta;try{meta=new JSONObject(getSharedPreferences(PREFS,MODE_PRIVATE).getString(key,"{}"));}catch(Exception e){meta=new JSONObject();}video=meta.optJSONObject("video");related=meta.optJSONArray("related");if(video==null){video=new JSONObject();try{video.put("title",meta.optString("title","Downloaded video"));video.put("views",0);video.put("description","");video.put("creator",new JSONObject().put("name",meta.optString("channel","Creator")));}catch(Exception ignored){}}if(related==null)related=new JSONArray();buildShell();render();}

    private void buildShell(){LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.WHITE);FrameLayout dock=new FrameLayout(this);dock.setBackgroundColor(Color.BLACK);dock.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(220)));playerView=new PlayerView(this);playerView.setUseController(true);playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);dock.addView(playerView,new FrameLayout.LayoutParams(-1,-1));root.addView(dock);ScrollView scroll=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(16),dp(16),dp(16),dp(24));content.setBackgroundColor(BG);scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));TextView back=text("‹  Downloads",14,VIOLET,true);back.setGravity(Gravity.CENTER_VERTICAL);back.setPadding(dp(16),dp(12),dp(16),dp(12));back.setBackgroundColor(Color.WHITE);back.setOnClickListener(v->finish());root.addView(back);setContentView(root);player=new ExoPlayer.Builder(this).build();playerView.setPlayer(player);player.setMediaItem(MediaItem.fromUri(Uri.fromFile(videoFile)));player.prepare();player.setPlayWhenReady(true);}

    private void render(){content.removeAllViews();TextView title=text(video.optString("title","Downloaded video"),21,INK,true);content.addView(title);TextView meta=text(String.format(java.util.Locale.US,"%,d views  ·  %,d likes",video.optInt("views"),video.optInt("like_count"))+(video.optString("published_at").isEmpty()?"":"  ·  "+video.optString("published_at")),12,MUTED,false);meta.setPadding(0,dp(6),0,0);content.addView(meta);
        LinearLayout creator=new LinearLayout(this);creator.setGravity(Gravity.CENTER_VERTICAL);creator.setPadding(0,dp(16),0,dp(16));ImageView avatar=new ImageView(this);avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);avatar.setImageResource(R.drawable.ic_phisk_default_avatar);avatar.setBackground(shape(0xFFE6DEF7,40));avatar.setClipToOutline(true);creator.addView(avatar,new LinearLayout.LayoutParams(dp(44),dp(44)));JSONObject creatorData=video.optJSONObject("creator");if(creatorData!=null)loadLocalImage(avatar,creatorData.optString("avatar_local_path",""));TextView creatorName=text(creatorData==null?"Creator":creatorData.optString("name","Creator"),15,INK,true);creatorName.setPadding(dp(10),0,0,0);creator.addView(creatorName);content.addView(creator);
        TextView offline=text("Saved offline on this device",12,VIOLET,true);offline.setPadding(dp(11),dp(9),dp(11),dp(9));offline.setBackground(shape(0xFFEDE7FB,6));content.addView(offline);
        String description=video.optString("description",video.optString("excerpt",""));if(!description.isEmpty()){TextView desc=text(description,14,INK,false);desc.setPadding(dp(13),dp(12),dp(13),dp(12));desc.setBackground(shape(Color.WHITE,8));content.addView(desc);}
        if(related.length()>0){TextView heading=text("Related videos",18,INK,true);heading.setPadding(0,dp(20),0,dp(10));content.addView(heading);for(int i=0;i<related.length();i++){JSONObject item=related.optJSONObject(i);if(item!=null)addRelated(item);}}
    }

    private void addRelated(JSONObject item){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(0,0,0,dp(12));ImageView thumb=new ImageView(this);thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);thumb.setBackground(shape(0xFFE5E5E5,7));thumb.setClipToOutline(true);row.addView(thumb,new LinearLayout.LayoutParams(dp(126),dp(78)));String local=item.optString("thumbnail_local_path","");loadLocalImage(thumb,local);LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(10),0,0,0);copy.addView(text(item.optString("title","Video"),14,INK,true));copy.addView(text(String.format(java.util.Locale.US,"%,d views",item.optInt("views")),12,MUTED,false));row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));content.addView(row);row.setOnClickListener(v->{int id=item.optInt("id",0);File downloaded=findDownloadedVideo(id);if(downloaded!=null){Intent intent=new Intent(this,OfflineVideoActivity.class);intent.putExtra("offline_file",downloaded.getAbsolutePath());startActivity(intent);}else if(isOnline()&&id>0){Intent intent=new Intent(this,NativePlayerActivity.class);intent.putExtra("video_id",id);startActivity(intent);}else Toast.makeText(this,"Connect to the internet or download this related video first.",Toast.LENGTH_LONG).show();});}

    private void loadLocalImage(ImageView target,String path){if(path==null||path.isEmpty())return;File file=new File(path);if(file.isFile()){android.graphics.Bitmap bitmap=BitmapFactory.decodeFile(path);if(bitmap!=null)target.setImageBitmap(bitmap);}}
    private File findDownloadedVideo(int id){if(id<=0)return null;File dir=new File(getFilesDir(),"downloads");File[] files=dir.listFiles();if(files==null)return null;for(File f:files){if(!f.isFile()||f.getName().endsWith(".part"))continue;try{JSONObject m=new JSONObject(getSharedPreferences(PREFS,MODE_PRIVATE).getString(f.getName(),"{}"));if(m.optInt("video_id",0)==id&&m.optBoolean("complete",false))return f;}catch(Exception ignored){}}return null;}
    private boolean isOnline(){try{ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);Network n=cm==null?null:cm.getActiveNetwork();NetworkCapabilities c=n==null?null:cm.getNetworkCapabilities(n);return c!=null&&(c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)||c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)||c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));}catch(Exception e){return false;}}
    @Override protected void onPause(){super.onPause();if(player!=null){resumeOnReturn=player.getPlayWhenReady();player.pause();}}
    @Override protected void onResume(){super.onResume();if(player!=null&&resumeOnReturn)player.play();}
    @Override protected void onDestroy(){if(player!=null){player.release();player=null;}super.onDestroy();}
}
