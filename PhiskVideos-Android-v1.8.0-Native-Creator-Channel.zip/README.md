# PhiskVideos Android 1.7.0 — Native Watch Page

This update integrates the native watch page with the authenticated Phisk Video Manager Native Watch API (Video Manager v1.14.0).

## Included
- Native watch screen opened by video ID from the native homepage.
- Sticky 16:9 player dock while watch details scroll beneath it.
- Native Media3/ExoPlayer playback for supported direct HTTPS media URLs.
- YouTube playback through the official YouTube embedded player (no stream extraction).
- Video title, views/date, creator information, description expand/collapse.
- Related-video list and authenticated comment loading/submission.
- Persistent native bottom navigation and return-to-feed behavior.

## Required WordPress plugin
Install and activate **Phisk Video Manager v1.14.0 Native Watch API** before testing this Android build. The app uses:
- `GET /wp-json/phisk/v1/videos/{id}`
- `GET /wp-json/phisk/v1/videos/{id}/related`
- `GET /wp-json/phisk/v1/videos/{id}/comments`
- `POST /wp-json/phisk/v1/videos/{id}/comments`

Requests use the existing native app bearer token. The app must be signed in.

## Build
Use the accompanying `android.yml` GitHub Actions workflow. Upload this archive to the repository root, then replace `.github/workflows/android.yml` with the accompanying workflow file and run the Android build workflow.

## Current scope note
Like toggling, real subscription toggling, threaded reply retrieval/reply UI, and direct integration with the existing offline-download manager are not yet connected because the v1.14.0 API does not expose those operations. Their visible controls are marked as not yet available rather than pretending to perform the action. YouTube videos are played using the official embedded player; direct HTTPS media uses ExoPlayer.


## Stage 4.3 — Native Creator Channel (v1.8.0)

- Adds the native Creator Channel activity with owner-aware Edit Channel / Creator Studio controls.
- Adds Videos and Stories tabs with 10-item pagination.
- Creator avatars and creator controls on the native homepage and watch page open the native channel screen.
- Requires Phisk Video Manager v1.15.0 for the `/wp-json/phisk/v1/creators/` endpoints.
- The API reuses existing `phisk_following`, `phisk_subscriber_count`, channel metadata, published `phisk_video` posts, and published Story posts.
