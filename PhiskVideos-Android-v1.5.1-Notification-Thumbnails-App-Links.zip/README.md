# PhiskVideos Android v1.5.1

This source package is based on the successfully tested v1.5.0 Stage 3 Notification Centre build.

## v1.5.1 changes
- Adds Android verified App Links for `https://videos.phisk.co/*`.
- Handles App Links and FCM notification destinations on cold start and when the app is already running.
- Preserves incoming destinations until the user signs in, then opens the requested destination.
- Supports destination keys used by notification intents and Firebase data payloads (`target_url`, `url`, and `link`).
- Displays notification image URLs returned by the WordPress notifications API (`thumbnail_url`, with avatar/image fallbacks) instead of always using the category icon.
- Retains category icons as fallbacks when an image is absent or cannot be loaded.
- Updates app version to 1.5.1 / versionCode 15 and the WebView user-agent marker.
- Keeps existing FCM, authentication, notification inbox, downloads, and app design.

## Android App Links domain verification
The app manifest is configured with `android:autoVerify="true"` for `videos.phisk.co`.
Publish the accompanying `assetlinks.json` at:

`https://videos.phisk.co/.well-known/assetlinks.json`

The included fingerprint is the current GitHub Actions release-signing certificate. When Google Play App Signing is enabled, add Google's **App signing key** SHA-256 fingerprint to the same `sha256_cert_fingerprints` array. Keep the upload-key fingerprint separate; it is not the certificate used to sign Play-delivered installs.

## Build outputs
The updated GitHub Actions workflow builds:
- Signed APK for direct installation/testing.
- Signed Android App Bundle (AAB) for future Google Play submission.

Do not upload the AAB to Play until the Play Console app-signing setup and store listing are ready.
