# PhiskVideos Android v1.24.6 — Native Channel Content Management

- Replaced the channel content text-glyph menu with a custom bottom-sheet menu using the supplied Edit, Stats, and Delete SVG assets.
- Added dedicated native statistics and content-edit screens for published videos and Stories.
- Added authenticated, owner-verified WordPress REST media replacement for published videos, reusing the configured Publitio or WordPress media provider and existing video validation.
- Added thumbnail replacement through the existing WordPress featured-image system.
- Kept Story media gallery unchanged; Story title and text are editable.
- Statistics use existing stored platform counters; Story likes/comments are not presented as fabricated zero values.
- Content operations remain on-demand. No polling, telemetry, analytics tables, or scheduled jobs were added.

## Validation

- WordPress plugin PHP syntax check passed (`php -l`).
- Android Gradle build was not run locally because this source archive does not include `gradlew` and Gradle is not installed in the environment. GitHub Actions build is required for compile validation.
