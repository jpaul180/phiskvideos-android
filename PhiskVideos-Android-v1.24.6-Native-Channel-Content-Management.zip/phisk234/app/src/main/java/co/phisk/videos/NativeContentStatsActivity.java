package co.phisk.videos;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Owner-only statistics page for a published video or Story. */
public class NativeContentStatsActivity extends Activity {
    private static final String HOME="https://videos.phisk.co/";
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final int INK=Color.rgb(25,29,38), MUTED=Color.rgb(112,117,128), VIOLET=Color.rgb(124,58,237);
    private LinearLayout content;
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable shape(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
    private TextView label(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    @Override public void onCreate(Bundle b){PhiskTheme.configureActivityTheme(this);super.onCreate(b);getWindow().setStatusBarColor(Color.WHITE);getWindow().setNavigationBarColor(Color.WHITE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(247,248,250));setContentView(root);
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(18),0,dp(18),0);bar.setBackgroundColor(Color.WHITE);root.addView(bar,new LinearLayout.LayoutParams(-1,dp(58)));
        TextView back=label("‹",34,INK,false);bar.addView(back,new LinearLayout.LayoutParams(dp(42),-2));back.setOnClickListener(v->finish());bar.addView(label("Statistics",19,INK,true));
        ScrollView scroll=new ScrollView(this);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));content=new LinearLayout(this);content.setPadding(dp(18),dp(18),dp(18),dp(28));content.setOrientation(LinearLayout.VERTICAL);scroll.addView(content);
        TextView loading=label("Loading statistics…",14,MUTED,false);content.addView(loading);
        int id=getIntent().getIntExtra("content_id",0);boolean video=getIntent().getBooleanExtra("is_video",true);if(id<=0){loading.setText("Content not found.");return;}
        io.execute(()->{try{JSONObject d=request("creator-content/"+id);runOnUiThread(()->render(d,video));}catch(Exception e){runOnUiThread(()->{content.removeAllViews();content.addView(label("Couldn't load statistics. Please try again.",14,MUTED,false));});}});
    }
    private void render(JSONObject d,boolean video){content.removeAllViews();String title=d.optString("title","Untitled");String thumb=getIntent().getStringExtra("thumbnail_url");if(thumb!=null&&!thumb.isEmpty()){WebViewImage.add(this,content,thumb,dp(205));}
        TextView heading=label(title,19,INK,true);heading.setPadding(0,dp(16),0,dp(18));content.addView(heading);
        addStat("Views",d.optLong("views"));if(video){addStat("Likes",d.optLong("likes"));addStat("Comments",d.optLong("comments"));}else{TextView note=label("Likes and comments are not available for this Story.",12,MUTED,false);note.setPadding(dp(3),dp(8),dp(3),0);content.addView(note);}
        String date=d.optString("published_at","");if(!date.isEmpty()){TextView published=label("Published · "+date,12,MUTED,false);published.setPadding(dp(2),dp(18),0,0);content.addView(published);}
    }
    private void addStat(String name,long value){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(16),dp(15),dp(16),dp(15));row.setBackground(shape(Color.WHITE,12));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(66));p.bottomMargin=dp(10);content.addView(row,p);row.addView(label(name,14,MUTED,true),new LinearLayout.LayoutParams(0,-2,1));row.addView(label(String.format(java.util.Locale.US,"%,d",Math.max(0,value)),20,VIOLET,true));}
    private JSONObject request(String path)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(HOME+"wp-json/phisk/v1/"+path).openConnection();try{c.setRequestMethod("GET");c.setConnectTimeout(15000);c.setReadTimeout(20000);c.setRequestProperty("Accept","application/json");c.setRequestProperty("Authorization","Bearer "+getSharedPreferences("phisk_native_auth",MODE_PRIVATE).getString("access_token",""));int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();ByteArrayOutputStream out=new ByteArrayOutputStream();if(in!=null){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);in.close();}String raw=out.toString("UTF-8");if(code<200||code>=300)throw new Exception(raw);return new JSONObject(raw);}finally{c.disconnect();}}
    static class WebViewImage { static void add(Activity a,LinearLayout parent,String url,int height){android.webkit.WebView w=new android.webkit.WebView(a);w.setBackgroundColor(Color.TRANSPARENT);w.setVerticalScrollBarEnabled(false);w.setHorizontalScrollBarEnabled(false);w.loadDataWithBaseURL(null,"<html><body style='margin:0;background:transparent'><img src='"+url.replace("'","%27")+"' style='width:100%;height:"+(height/(a.getResources().getDisplayMetrics().density))+"px;object-fit:cover;border-radius:13px'/></body></html>","text/html","UTF-8",null);parent.addView(w,new LinearLayout.LayoutParams(-1,height));} }
}
