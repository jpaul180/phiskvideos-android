# PhiskVideos Android v1.17.1 — Profile Image, Public Username & Live Availability Check

This release adds a native Android version of the website's **Account Settings → Personal Information** form. It is deliberately separate from Creator Channel Management.

## Native Edit Profile
- Username (3–24 lowercase letters, numbers or underscores; website's 30-day username-change cooldown and availability rules are enforced by the server).
- First Name.
- Last Name.
- Phone Number (optional).
- Account profile image upload/change (JPG, PNG or WebP; maximum 8 MB); uses `phisk_profile_image_id` only and never changes the channel cover.
- Debounced live availability checks for the editable public `phisk_username`, including username format and 30-day cooldown feedback.
- Loads and saves the signed-in user's own WordPress account through the authenticated Phisk Video Manager REST API.
- Uses existing Phisk bearer-session authentication; no credentials or tokens are embedded in the app.
- Supports the existing Phisk Light/Dark theme and Phisk Violet primary action.

This screen does **not** edit profile photos, cover images, channel names, channel descriptions, or creator-channel settings. Those remain in Creator Channel Management.

## Settings account header
The Settings identity header displays the editable public Phisk username (`phisk_username`) and email, not WordPress `user_login` or `display_name`.

## Backend dependency
Install the companion **Phisk Video Manager v1.20.5** plugin package. It provides:
- `GET` and `POST /wp-json/phisk/v1/account-settings`.
- `GET /wp-json/phisk/v1/account-settings/username-availability?username=...` for authenticated real-time checks.
- `POST /wp-json/phisk/v1/account-settings/profile-image` for authenticated multipart image uploads using the `image` file field.

All routes use the existing native bearer-session permission callback. Username availability is advisory while typing; the existing account update endpoint performs final server-side validation and applies the 30-day cooldown, history and previous-slug redirects. Profile image upload updates only `phisk_profile_image_id`.

## Build
- Android version: `1.17.1`
- Android version code: `40`
- Minimum SDK: 24
- Target/compile SDK: 35
- Java: 17
- GitHub Actions workflow builds signed APK and AAB outputs using the existing repository signing secrets.
